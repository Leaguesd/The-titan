package net.titans.entity.minion;

public enum EnumMinionType {
    LOYALIST,
    PRIEST,
    ZEALOT,
    BISHOP,
    TEMPLAR,
    SPECIAL;
}
