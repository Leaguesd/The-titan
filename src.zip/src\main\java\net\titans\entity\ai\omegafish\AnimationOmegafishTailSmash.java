package net.titans.entity.ai.omegafish;

import net.titans.animation.AIAnimation;
import net.titans.entity.titan.EntityOmegafish;

public class AnimationOmegafishTailSmash extends AIAnimation {
    private EntityOmegafish entity;

    public AnimationOmegafishTailSmash(EntityOmegafish entity) {
        super(entity);
        this.entity = entity;
    }

    @Override
    public int getAnimationID() {
        return 3;
    }

    @Override
    public boolean isAutomatic() {
        return true;
    }

    @Override
    public int getDuration() {
        return 60;
    }

    @Override
    public boolean canContinueToUse() {
        return this.entity.getAnimationTick() <= this.getDuration() && !this.entity.isStunned ? super.canContinueToUse() : false;
    }

    public void tick() {
        if (this.entity.getTarget() != null && this.entity.getAnimationTick() < 36) {
            this.entity.getLookControl().setLookAt(this.entity.getTarget(), 5.0F, 40.0F);
        }
    }
}
