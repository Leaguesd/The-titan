package net.titans.item;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.util.Mth;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity.RemovalReason;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.item.PrimedTnt;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.Fireball;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.Item.Properties;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.Level.ExplosionInteraction;
import net.minecraft.world.level.block.BaseFireBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.gameevent.GameEvent;
import net.minecraft.world.level.gameevent.GameEvent.Context;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.client.extensions.common.IClientItemExtensions;
import net.titans.damage.DamageSourceTitanAttack;
import net.titans.entity.titan.EntityTitan;
import net.titans.loader.TheTitansSounds;
import net.titans.loader.TheTitansTiers;
import net.titans.render.item.TitanSpecialItemRenderer;
import net.titans.util.EntityUtils;

public class ItemOptimaAxe extends SwordItem {
    public ItemOptimaAxe(Properties properties) {
        super(TheTitansTiers.ULTIMA, 0, Float.MAX_VALUE, properties);
    }

    public void initializeClient(Consumer<IClientItemExtensions> consumer) {
        consumer.accept(TitanSpecialItemRenderer.createExtensions());
    }

    public int getDamage(ItemStack stack) {
        return 0;
    }

    public boolean isFoil(ItemStack stack) {
        return false;
    }

    public void appendHoverText(ItemStack stack, Level level, List<Component> tooltip, TooltipFlag flag) {
        super.appendHoverText(stack, level, tooltip, flag);
        tooltip.add(Component.translatable("item.titan.optima_axe.info1").withStyle(ChatFormatting.BOLD).withStyle(ChatFormatting.DARK_AQUA));
        tooltip.add(Component.translatable("item.titan.optima_axe.info2").withStyle(ChatFormatting.BOLD).withStyle(ChatFormatting.DARK_AQUA));
        tooltip.add(Component.translatable("item.titan.optima_axe.info3").withStyle(ChatFormatting.BOLD).withStyle(ChatFormatting.DARK_AQUA));
    }

    public void inventoryTick(ItemStack stack, Level level, Entity entity, int slotId, boolean isSelected) {
        if (entity instanceof Player player) {
            for (int i = 0; i < 3; i++) {
                level.addParticle(
                    ParticleTypes.PORTAL,
                    player.getX() + (level.random.nextDouble() - 0.5) * (double)player.getBbWidth(),
                    player.getY() + level.random.nextDouble() * (double)player.getBbHeight(),
                    player.getZ() + (level.random.nextDouble() - 0.5) * (double)player.getBbWidth(),
                    (level.random.nextDouble() - 0.5) * 2.0,
                    1.0,
                    (level.random.nextDouble() - 0.5) * 2.0
                );
                level.addParticle(
                    ParticleTypes.LARGE_SMOKE,
                    player.getX() + (level.random.nextDouble() - 0.5) * (double)player.getBbWidth(),
                    player.getY() + level.random.nextDouble() * (double)player.getBbHeight(),
                    player.getZ() + (level.random.nextDouble() - 0.5) * (double)player.getBbWidth(),
                    (level.random.nextDouble() - 0.5) * 2.0,
                    1.0,
                    (level.random.nextDouble() - 0.5) * 2.0
                );
            }

            if (player.getY() < -100.0) {
                player.push(0.0, 10.0, 0.0);
            }

            player.heal(player.getMaxHealth());
            if (!level.isClientSide()) {
                player.addEffect(new MobEffectInstance(MobEffects.ABSORPTION, 5, 249, false, false));
            }
        }
    }

    public boolean mineBlock(ItemStack stack, Level level, BlockState state, BlockPos pos, LivingEntity livingEntity) {
        if (livingEntity instanceof Player player) {
            player.playSound((SoundEvent)TheTitansSounds.TITAN_SWING.get(), 10.0F, 1.0F);

            for (int y = -2; y <= 2; y++) {
                for (int x = -4; x <= 4; x++) {
                    for (int z = -4; z <= 4; z++) {
                        BlockPos rangePos = new BlockPos(
                            Mth.floor((float)(pos.getX() + x)), Mth.floor((float)(pos.getY() + y)), Mth.floor((float)(pos.getZ() + z))
                        );
                        BlockState rangeState = level.getBlockState(rangePos);
                        Block rangeBlock = rangeState.getBlock();
                        if (!rangeState.isAir()) {
                            if (!level.isClientSide() && !player.isCreative()) {
                                List<ItemStack> drops = new ArrayList<>();
                                List<ItemStack> blockDrops = Block.getDrops(rangeState, (ServerLevel)level, rangePos, null);
                                if (!blockDrops.isEmpty()) {
                                    drops.addAll(blockDrops);
                                } else {
                                    drops.add(new ItemStack(rangeBlock));
                                }

                                if (!drops.isEmpty()) {
                                    for (ItemStack drop : drops) {
                                        ItemEntity itemEntity = new ItemEntity(
                                            level, (double)rangePos.getX(), (double)rangePos.getY(), (double)rangePos.getZ(), drop
                                        );
                                        itemEntity.setDefaultPickUpDelay();
                                        itemEntity.push(
                                            -Math.sin((double)player.getYRot() * Math.PI / 180.0) * 1.0,
                                            0.75,
                                            Math.cos((double)player.getYRot() * Math.PI / 180.0) * 1.0
                                        );
                                        level.addFreshEntity(itemEntity);
                                    }
                                }
                            }

                            if (!(rangeBlock instanceof BaseFireBlock)) {
                                level.levelEvent(2001, rangePos, Block.getId(rangeState));
                            }

                            level.setBlockAndUpdate(rangePos, Blocks.AIR.defaultBlockState());
                            level.gameEvent(GameEvent.BLOCK_DESTROY, rangePos, Context.of(player, rangeState));
                        }
                    }
                }
            }
        }

        return super.mineBlock(stack, level, state, pos, livingEntity);
    }

    public boolean onEntitySwing(ItemStack stack, LivingEntity livingEntity) {
        Level level = livingEntity.level();
        if (livingEntity instanceof Player player) {
            player.playSound((SoundEvent)TheTitansSounds.TITAN_SWING.get(), 10.0F, 1.0F);
            if (!player.isCrouching()) {
                for (int i = 0; i < 12; i++) {
                    double d8 = 12.0;
                    Vec3 vec3 = player.getViewVector(1.0F);
                    double dx = vec3.x * (double)i;
                    double dy = vec3.y * (double)i + (double)player.getEyeHeight();
                    double dz = vec3.z * (double)i;
                    List<Entity> entities = level.getEntities(player, player.getBoundingBox().inflate(d8, 8.0, d8).move(dx, dy, dz));
                    List<Entity> bigEntities = EntityUtils.getEntities(entities, player, d8, 8.0, d8, dx, dy, dz);
                    if (!bigEntities.isEmpty()) {
                        entities.addAll(bigEntities);
                    }

                    for (Entity entity : entities) {
                        if (entity != null) {
                            DamageSourceTitanAttack damageSource = new DamageSourceTitanAttack(player);
                            if (entity instanceof EntityTitan
                                || entity instanceof PrimedTnt
                                || entity instanceof Fireball
                                || entity instanceof LivingEntity) {
                                player.playSound((SoundEvent)TheTitansSounds.TITAN_PUNCH.get(), 2.0F, 0.5F + level.random.nextFloat() * 0.25F);
                                player.playSound((SoundEvent)TheTitansSounds.SLASH_FLESH.get(), 10.0F, 1.0F);
                            }

                            if (entity instanceof EntityTitan) {
                                player.playSound((SoundEvent)TheTitansSounds.TITAN_PUNCH.get(), 10.0F, 1.0F);
                                EntityTitan titan = (EntityTitan)entity;
                                titan.hurt(damageSource, 2000.0F);
                            } else if (entity instanceof PrimedTnt) {
                                if (!level.isClientSide()) {
                                    level.explode(player, entity.getX(), entity.getY(), entity.getZ(), 4.0F, false, ExplosionInteraction.MOB);
                                    entity.remove(RemovalReason.KILLED);
                                }
                            } else if (entity instanceof Fireball) {
                                if (!level.isClientSide()) {
                                    level.explode(player, entity.getX(), entity.getY(), entity.getZ(), 0.0F, false, ExplosionInteraction.MOB);
                                    entity.remove(RemovalReason.KILLED);
                                }
                            } else if (entity instanceof LivingEntity) {
                                entity.setRemainingFireTicks(Integer.MAX_VALUE);
                                if (!entity.hurt(damageSource, 20000.0F)) {
                                    ((LivingEntity)entity).setHealth(0.0F);
                                }

                                entity.push(
                                    -Math.sin((double)player.getYRot() * Math.PI / 180.0) * 6.0,
                                    6.0,
                                    Math.cos((double)player.getYRot() * Math.PI / 180.0) * 6.0
                                );
                            }
                        }
                    }
                }
            } else {
                double d8 = 64.0;
                List<Entity> entities = level.getEntities(player, player.getBoundingBox().inflate(d8, d8, d8));
                List<Entity> bigEntities = EntityUtils.getEntities(entities, player, d8, d8, d8);
                if (!bigEntities.isEmpty()) {
                    entities.addAll(bigEntities);
                }

                for (Entity entityx : entities) {
                    if (entityx != null) {
                        DamageSourceTitanAttack damageSource = new DamageSourceTitanAttack(player);
                        player.playSound((SoundEvent)TheTitansSounds.TITAN_PUNCH.get(), 2.0F, 0.5F + level.random.nextFloat() * 0.25F);
                        player.playSound((SoundEvent)TheTitansSounds.SLASH_FLESH.get(), 10.0F, 1.0F);
                        if (entityx instanceof EntityTitan) {
                            player.playSound((SoundEvent)TheTitansSounds.TITAN_PUNCH.get(), 10.0F, 1.0F);
                            EntityTitan titan = (EntityTitan)entityx;
                            titan.hurt(damageSource, 2000.0F);
                        } else if (entityx instanceof LivingEntity) {
                            entityx.setRemainingFireTicks(Integer.MAX_VALUE);
                            if (!entityx.hurt(damageSource, Float.MAX_VALUE)) {
                                ((LivingEntity)entityx).setHealth(0.0F);
                            }

                            entityx.push(
                                -Math.sin((double)player.getYRot() * Math.PI / 180.0) * 6.0,
                                6.0,
                                Math.cos((double)player.getYRot() * Math.PI / 180.0) * 6.0
                            );
                        } else {
                            entityx.hurt(entityx.damageSources().playerAttack(player), 20000.0F);
                        }
                    }
                }
            }
        }

        return false;
    }
}
