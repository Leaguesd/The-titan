package net.titans;

import com.mojang.logging.LogUtils;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.event.lifecycle.FMLDedicatedServerSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.fml.loading.FMLEnvironment;
import net.titans.loader.TheTitansArmorMaterials;
import net.titans.loader.TheTitansAttributes;
import net.titans.loader.TheTitansBiomeModifiers;
import net.titans.loader.TheTitansRegistries;
import net.titans.loader.TheTitansChunkGenerators;
import net.titans.loader.TheTitansEnchantments;
import net.titans.loader.TheTitansEntities;
import net.titans.loader.TheTitansEntityRenderers;
import net.titans.loader.TheTitansEvents;
import net.titans.loader.TheTitansFeatures;
import net.titans.loader.TheTitansGlobalLootModifiers;
import net.titans.loader.TheTitansRegistries;
import net.titans.loader.TheTitansMinions;
import net.titans.loader.TheTitansMobEffects;
import net.titans.loader.TheTitansNetworks;
import net.titans.loader.TheTitansSounds;
import net.titans.loader.TheTitansTabs;
import net.titans.loader.TheTitansTriggers;
import org.slf4j.Logger;

@Mod("titan")
public class theTitans {
    public static final String MODID = "titan";
    public static final String NAME = "泰坦生物";
    public static final String VERSION = "1.0.7";
    public static final String[] AUTHORS = new String[]{""};
    public static final Logger LOGGER = LogUtils.getLogger();

    public theTitans() {
        IEventBus modEventBus = FMLJavaModLoadingContext.get().getModEventBus();
        TheTitansArmorMaterials.registerArmorMaterials(modEventBus);
        TheTitansAttributes.registerAttributes(modEventBus);
        TheTitansRegistries.register(modEventBus);
        TheTitansEntities.registerEntities(modEventBus);
        TheTitansSounds.registerSounds(modEventBus);
        TheTitansMobEffects.registerMobEffects(modEventBus);
        TheTitansTabs.registerTabs(modEventBus);
        TheTitansNetworks.registerNetworks(modEventBus);
        TheTitansTriggers.registerTriggers();
        TheTitansFeatures.registerFeatures(modEventBus);
        TheTitansChunkGenerators.registerChunkGenerators(modEventBus);
        TheTitansBiomeModifiers.registerBiomeModifiers(modEventBus);
        TheTitansEnchantments.registerEnchantments(modEventBus);
        TheTitansGlobalLootModifiers.registerGlobalLootModifiers(modEventBus);
        TheTitansEvents.registerEvents();
        TheTitansMinions.registerMinions();
        if (FMLEnvironment.dist.isClient()) {
            TheTitansEntityRenderers.registerEntityRenderers(modEventBus);
        }

        modEventBus.addListener(this::commonSetup);
        modEventBus.addListener(this::clientSetup);
        modEventBus.addListener(this::serverSetup);
    }

    private void commonSetup(FMLCommonSetupEvent event) {
        event.enqueueWork(() -> TheTitansRegistries.registerRepairIngredients());
    }

    private void clientSetup(FMLClientSetupEvent event) {
        event.enqueueWork(() -> {
            TheTitansRegistries.initItemProperties();
            TheTitansRegistries.registerItemRenderers();
        });
    }

    private void serverSetup(FMLDedicatedServerSetupEvent event) {
    }
}
