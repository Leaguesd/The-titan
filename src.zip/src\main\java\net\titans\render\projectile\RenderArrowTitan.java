package net.titans.render.projectile;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.blaze3d.vertex.PoseStack.Pose;
import com.mojang.math.Axis;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider.Context;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.titans.entity.projectile.EntityArrowTitan;

public class RenderArrowTitan extends EntityRenderer<EntityArrowTitan> {
    public static final ResourceLocation ARROW = new ResourceLocation("minecraft", "textures/entity/projectiles/arrow.png");

    public RenderArrowTitan(Context context) {
        super(context);
    }

    public void vertex(Pose pose, VertexConsumer vertexConsumer, int x, int y, int z, float u, float v, int normalX, int normalY, int normalZ, int packedLight) {
        vertexConsumer.vertex(pose.pose(), (float)x, (float)y, (float)z)
            .color(255, 255, 255, 255)
            .uv(u, v)
            .overlayCoords(OverlayTexture.NO_OVERLAY)
            .uv2(packedLight)
            .normal(pose.normal(), (float)normalX, (float)normalZ, (float)normalY)
            .endVertex();
    }

    public void render(EntityArrowTitan entity, float entityYaw, float partialTicks, PoseStack poseStack, MultiBufferSource multiBufferSource, int packedLight) {
        if (!entity.isInvisible()) {
            poseStack.pushPose();
            poseStack.scale(16.0F, 16.0F, 16.0F);
            poseStack.mulPose(Axis.YP.rotationDegrees(Mth.lerp(partialTicks, entity.yRotO, entity.getYRot()) - 90.0F));
            poseStack.mulPose(Axis.ZP.rotationDegrees(Mth.lerp(partialTicks, entity.xRotO, entity.getXRot())));
            float i = (float)entity.shakeTime - partialTicks;
            if (i > 0.0F) {
                float f2 = -Mth.sin(i * 3.0F) * i;
                poseStack.mulPose(Axis.ZP.rotationDegrees(f2));
            }

            poseStack.mulPose(Axis.XP.rotationDegrees(45.0F));
            poseStack.scale(0.05625F, 0.05625F, 0.05625F);
            poseStack.translate(-4.0F, 0.0F, 0.0F);
            VertexConsumer vertexConsumer = multiBufferSource.getBuffer(RenderType.entityCutout(this.getTextureLocation(entity)));
            Pose poseStack$pose = poseStack.last();
            this.vertex(poseStack$pose, vertexConsumer, -7, -2, -2, 0.0F, 0.15625F, -1, 0, 0, packedLight);
            this.vertex(poseStack$pose, vertexConsumer, -7, -2, 2, 0.15625F, 0.15625F, -1, 0, 0, packedLight);
            this.vertex(poseStack$pose, vertexConsumer, -7, 2, 2, 0.15625F, 0.3125F, -1, 0, 0, packedLight);
            this.vertex(poseStack$pose, vertexConsumer, -7, 2, -2, 0.0F, 0.3125F, -1, 0, 0, packedLight);
            this.vertex(poseStack$pose, vertexConsumer, -7, 2, -2, 0.0F, 0.15625F, 1, 0, 0, packedLight);
            this.vertex(poseStack$pose, vertexConsumer, -7, 2, 2, 0.15625F, 0.15625F, 1, 0, 0, packedLight);
            this.vertex(poseStack$pose, vertexConsumer, -7, -2, 2, 0.15625F, 0.3125F, 1, 0, 0, packedLight);
            this.vertex(poseStack$pose, vertexConsumer, -7, -2, -2, 0.0F, 0.3125F, 1, 0, 0, packedLight);

            for (int j = 0; j < 4; j++) {
                poseStack.mulPose(Axis.XP.rotationDegrees(90.0F));
                this.vertex(poseStack$pose, vertexConsumer, -8, -2, 0, 0.0F, 0.0F, 0, 1, 0, packedLight);
                this.vertex(poseStack$pose, vertexConsumer, 8, -2, 0, 0.5F, 0.0F, 0, 1, 0, packedLight);
                this.vertex(poseStack$pose, vertexConsumer, 8, 2, 0, 0.5F, 0.15625F, 0, 1, 0, packedLight);
                this.vertex(poseStack$pose, vertexConsumer, -8, 2, 0, 0.0F, 0.15625F, 0, 1, 0, packedLight);
            }

            poseStack.popPose();
            super.render(entity, entityYaw, partialTicks, poseStack, multiBufferSource, packedLight);
        }
    }

    public ResourceLocation getTextureLocation(EntityArrowTitan entity) {
        return ARROW;
    }
}
