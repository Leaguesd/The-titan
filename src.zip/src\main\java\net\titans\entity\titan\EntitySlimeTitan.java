package net.titans.entity.titan;

import java.lang.reflect.Constructor;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import javax.annotation.Nullable;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.Mth;
import net.minecraft.world.Difficulty;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityDimensions;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.Pose;
import net.minecraft.world.entity.SpawnGroupData;
import net.minecraft.world.entity.Entity.RemovalReason;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier.Builder;
import net.minecraft.world.entity.monster.MagmaCube;
import net.minecraft.world.entity.monster.Slime;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.ItemLike;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.ServerLevelAccessor;
import net.minecraft.world.level.Level.ExplosionInteraction;
import net.titans.entity.IBossBarDisplay;
import net.titans.entity.ai.EntityAINearestTargetTitan;
import net.titans.loader.TheTitansEntities;
import net.titans.loader.TheTitansRegistries;
import net.titans.loader.TheTitansPredicateTargets;
import net.titans.loader.TheTitansSounds;

public class EntitySlimeTitan extends EntityTitan implements IBossBarDisplay {
    private static final EntityDataAccessor<Integer> SLIME_SIZE = SynchedEntityData.defineId(EntitySlimeTitan.class, EntityDataSerializers.INT);
    public float squishAmount;
    public float squishFactor;
    public float prevSquishFactor;
    private int slimeJumpDelay;
    private boolean wasOnGround;
    public boolean doubleJumped;

    public EntitySlimeTitan(EntityType<? extends EntityTitan> entityType, Level level) {
    super(entityType, level);
    this.setSlimeSize(4);

    // 兜底：若因任何原因基类构造器里的 setTitanHealth 没成功（例如外部模组
    // 在 defineSynchedData 之后、构造器之前把 SLIME_SIZE 又改回 0），
    // 这里用正确的最大血量强制补一次。仅在初始化阶段生效，不影响正常受伤。
    if (this.getTitanHealth() <= 1.0F && this.getTitanMaxHealth() > 1.0F) {
        this.setTitanHealthForced(this.getTitanMaxHealth());
    }
}

    public EntitySlimeTitan(Level level) {
        this((EntityType<? extends EntityTitan>)TheTitansEntities.SLIME_TITAN.get(), level);
    }

    public static Builder createAttributes() {
        return EntityTitan.createAttributes().add(Attributes.MAX_HEALTH, 4000.0).add(Attributes.ATTACK_DAMAGE, 500.0);
    }

    @Override
    public ResourceLocation getBossBarTexture() {
        return ResourceLocation.tryBuild("titan", "textures/gui/bossbar/slime_titan.png");
    }

    @Override
    public int getBossBarNameColor() {
        return 5349438;
    }

    @Override
    public int getBossBarWidth() {
        return 190;
    }

    @Override
    public int getBossBarHeight() {
        return 22;
    }

    @Override
    public int getBossBarInterval() {
        return 2;
    }

    @Override
    public int getBossBarVOffset() {
        return 0;
    }

    @Override
    public int getBossBarVHeight() {
        return 0;
    }

    @Override
    public int getBossBarTextOffset() {
        return 14;
    }

    @Override
    protected void registerGoals() {
        super.registerGoals();
        this.targetSelector.addGoal(0, new EntityAINearestTargetTitan(this, EntitySnowGolemTitan.class, false));
        this.targetSelector.addGoal(0, new EntityAINearestTargetTitan(this, EntityIronGolemTitan.class, false));
        this.targetSelector
            .addGoal(0, new EntityAINearestTargetTitan<LivingEntity>(this, LivingEntity.class, 0, false, false, TheTitansPredicateTargets.SlimeTitan));
    }

    public int getSlimeSize() {
        return (Integer)this.entityData.get(SLIME_SIZE);
    }

    public void setSlimeSize(int slimeSize) {
        this.entityData.set(SLIME_SIZE, slimeSize);
        this.refreshTitanAttributes();
    }

    protected void alterSquishAmount() {
        this.squishAmount *= 0.85F;
    }

    public int getJumpDelay() {
        return this.random.nextInt(40) + 20;
    }

@Override
protected void defineSynchedData() {
    super.defineSynchedData();
    // 默认值必须是有效尺寸（4），不能是 0。
    // 基类 EntityTitan 构造器会在子类构造器执行前调用 refreshTitanAttributes()，
    // 那时读到的就是这个默认值；若为 0，MAX_HEALTH 会算成 0，
    // 导致基类里的 setTitanHealth(getTitanMaxHealth()) 被拒绝，血量永久卡在 1.0F。
    // 对 /summon 这类不经过 finalizeSpawn 的生成路径尤其致命。
    this.entityData.define(SLIME_SIZE, 4);
}
    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        this.setSlimeSize(tag.getInt("SlimeSize"));
        this.wasOnGround = tag.getBoolean("wasOnGround");
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putInt("SlimeSize", this.getSlimeSize());
        tag.putBoolean("wasOnGround", this.wasOnGround);
    }

    @Override
    public SpawnGroupData finalizeSpawn(
        ServerLevelAccessor level, DifficultyInstance difficulty, MobSpawnType spawnType, @Nullable SpawnGroupData spawnGroupData, @Nullable CompoundTag tag
    ) {
        SpawnGroupData groupData = super.finalizeSpawn(level, difficulty, spawnType, spawnGroupData, null);
        int i = this.random.nextInt(3);
        if (i < 2 && this.random.nextFloat() < 0.5F) {
            i++;
        }

        int j = 1 << i;
        this.setSlimeSize(j);
        this.setTitanHealth(this.getTitanMaxHealth());
        return groupData;
    }

    protected EntityDimensions getDefaultDimensions(Pose pose) {
        float width = 8.0F * (float)this.getSlimeSize();
        float height = 8.0F * (float)this.getSlimeSize();
        float eyeHeight = 0.625F * height;
        return EntityDimensions.scalable(width, height);
    }

    @Override
    protected void refreshAttributes() {
        if (this.level().getDifficulty() == Difficulty.HARD) {
            this.getAttribute(Attributes.MAX_HEALTH).setBaseValue((double)this.getSlimeSize() * 2000.0 + (double)this.getExtraPower() * 200.0);
            this.getAttribute(Attributes.ATTACK_DAMAGE).setBaseValue(500.0 + (double)this.getExtraPower() * 18.0);
        } else {
            this.getAttribute(Attributes.MAX_HEALTH).setBaseValue((double)this.getSlimeSize() * 1000.0 + (double)this.getExtraPower() * 100.0);
            this.getAttribute(Attributes.ATTACK_DAMAGE).setBaseValue(250.0 + (double)this.getExtraPower() * 9.0);
        }
    }

    @Override
    public boolean canAttack() {
        return true;
    }

    @Override
    public boolean canAttackEntity(Entity entity) {
        return this.getClass() != EntitySlimeTitan.class
            ? super.canAttackEntity(entity)
            : super.canAttackEntity(entity) && !(entity instanceof EntitySlimeTitan) && !(entity instanceof Slime);
    }

    @Override
    public boolean shouldMove() {
        return false;
    }

    @Override
    public boolean canRegen() {
        return false;
    }

    @Override
    public SimpleParticleType getParticles() {
        return ParticleTypes.ITEM_SLIME;
    }

    @Override
    public int getParticleCount() {
        return 4;
    }

    @Override
    public EnumTitanStatus getTitanStatus() {
        return EnumTitanStatus.LESSER;
    }

    public int getMaxHeadXRot() {
        return 30;
    }

    protected SoundEvent getHurtSound(DamageSource damageSource) {
        return SoundEvents.SLIME_HURT;
    }

    protected SoundEvent getDeathSound() {
        return SoundEvents.SLIME_DEATH;
    }

    protected SoundEvent getSquishSound() {
        return SoundEvents.SLIME_SQUISH;
    }

    public SoundEvent getJumpSound() {
        return SoundEvents.SLIME_JUMP;
    }

    @Override
    public float getSoundVolume() {
        return 1.0F * (float)this.getSlimeSize();
    }

    public float getSoundPitch() {
        float f = 1.4F;
        return ((this.random.nextFloat() - this.random.nextFloat()) * 0.2F + 1.0F) * f;
    }

    @Override
    public void push(Entity entity) {
        if (entity instanceof EntityTitan) {
            super.push(entity);
        }

        float amount = (float)this.getAttributeBaseValue(Attributes.ATTACK_DAMAGE);
        int knockbackAmount = this.getKnockbackAmount();
        if (entity != null && entity instanceof LivingEntity && this.canAttackEntity(entity)) {
            LivingEntity livingEntity = (LivingEntity)entity;
            if (this.isAlive() && this.tickCount % 5 == 0) {
                this.attackEntity(livingEntity, amount);
                this.knockbackEntity(livingEntity, (float)knockbackAmount);
                if (!entity.isAlive() && !(entity instanceof EntityTitan)) {
                    this.playSound(SoundEvents.SLIME_ATTACK, 100.0F, 0.5F);
                    if (!this.level().isClientSide()) {
                        this.level().broadcastEntityEvent(entity, (byte)60);
                        entity.remove(RemovalReason.KILLED);
                        Slime slime = (Slime)(this instanceof EntityMagmaCubeTitan
                            ? new MagmaCube(EntityType.MAGMA_CUBE, this.level())
                            : new Slime(EntityType.SLIME, this.level()));
                        this.setPos(this.getX(), this.getY(), this.getZ());
                        this.setYRot(this.getYRot());
                        slime.finalizeSpawn((ServerLevelAccessor)this.level(), this.level().getCurrentDifficultyAt(slime.blockPosition()), MobSpawnType.CONVERSION, null, null);
                        slime.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 100, 4, true, false));
                        this.level().addFreshEntity(slime);
                    }
                }
            }
        }
    }

    public void playerTouch(Player player) {
    }

    @Override
    public void jumpFromGround() {
        this.setTitanDeltaMovement(this.getDeltaMovement().x, 1.5 + (double)((float)this.getSlimeSize() * 0.2F), this.getDeltaMovement().z);
        this.hasImpulse = true;
        if (this.getTarget() != null) {
            double d0 = this.getTarget().getX() - this.getX();
            double d1 = this.getTarget().getZ() - this.getZ();
            double d2 = Math.sqrt(d0 * d0 + d1 * d1);
            double hor = 1.5 + (double)this.getSlimeSize() * 0.25;
            this.setTitanDeltaMovement(
                d0 / d2 * hor * hor + this.getDeltaMovement().x * hor, this.getDeltaMovement().y, d1 / d2 * hor * hor + this.getDeltaMovement().z * hor
            );
        }
    }

    @Override
    public boolean causeFallDamage(float fallDistance, float multiplier, DamageSource damageSource) {
        this.setOnGround(true);
        this.hasImpulse = false;
        if (fallDistance <= 0.0F) {
            return false;
        } else {
            MobEffectInstance mobEffectInstance = this.getEffect(MobEffects.JUMP);
            float f1 = mobEffectInstance != null ? (float)(mobEffectInstance.getAmplifier() + 1) : 0.0F;
            int i = Mth.ceil(fallDistance - 12.0F - f1);
            if (i > 0) {
                this.playSound((SoundEvent)TheTitansSounds.TITAN_SLAM.get(), 5.0F * (float)this.getSlimeSize(), 2.0F - (float)(this.getSlimeSize() / 4));
                this.playSound(SoundEvents.SLIME_JUMP, 5.0F * (float)this.getSlimeSize(), 2.0F - (float)(this.getSlimeSize() / 8));
                float amount = (float)this.getAttributeBaseValue(Attributes.ATTACK_DAMAGE);

                for (Entity entity : this.level()
                    .getEntities(
                        this, this.getBoundingBox().inflate(6.0 * (double)this.getSlimeSize(), 6.0 * (double)this.getSlimeSize(), 6.0 * (double)this.getSlimeSize())
                    )) {
                    if (entity != null
                        && entity instanceof LivingEntity
                        && this.canAttackEntity(entity)
                        && this.distanceToSqr(entity) <= (double)(this.getBbWidth() * this.getBbWidth() + this.getBbWidth() * this.getBbWidth())) {
                        LivingEntity livingEntity = (LivingEntity)entity;
                        this.attackEntity(livingEntity, amount);
                        double d0 = this.getBoundingBox().minX + this.getBoundingBox().maxX;
                        double d1 = this.getBoundingBox().minZ + this.getBoundingBox().maxZ;
                        double d2 = entity.getX() - d0;
                        double d3 = entity.getZ() - d1;
                        double d4 = d2 * d2 + d3 * d3;
                        if (d4 >= 0.01) {
                            double d5 = d2 / d4 * 8.0 * (this.doubleJumped ? 2.0 : 1.0);
                            double d6 = 1.0 * (this.doubleJumped ? 2.0 : 1.0);
                            double d7 = d3 / d4 * 8.0 * (this.doubleJumped ? 2.0 : 1.0);
                            livingEntity.push(d5, d6, d7);
                        }
                    }
                }
            }

            return true;
        }
    }

    public void kill() {
        super.kill();
        this.setTitanHealth(0.0F);
    }

    @Override
    public void aiStep() {
        super.aiStep();
        LivingEntity entity = this.getTarget();
        if (this.onGround()) {
            this.setSpeed((float)this.getAttributeValue(Attributes.MOVEMENT_SPEED));
            if (this.slimeJumpDelay-- <= 0 && this.getInvulTime() <= 0) {
                this.slimeJumpDelay = this.getJumpDelay();
                if (entity != null) {
                    this.slimeJumpDelay /= 3;
                    this.getLookControl().setLookAt(entity, 180.0F, 60.0F);
                }

                this.jumpFromGround();
                this.playSound(this.getJumpSound(), this.getSoundVolume(), this.getSoundPitch());
            } else {
                this.xxa = 0.0F;
                this.zza = 0.0F;
                this.setSpeed(0.0F);
            }
        } else {
            this.setSpeed((float)this.getAttributeValue(Attributes.MOVEMENT_SPEED));
        }
    }

    @Override
    protected void dropExperienceOrb() {
        for (int x = 0; x < this.getSlimeSize(); x++) {
            EntityExperienceOrbTitan experienceOrbTitan = new EntityExperienceOrbTitan(
                this.level(),
                this.getX() + (double)(this.random.nextFloat() * 12.0F - 6.0F),
                this.getY() + 4.0,
                this.getZ() + (double)(this.random.nextFloat() * 12.0F - 6.0F),
                1000
            );
            experienceOrbTitan.push(0.0, 1.0, 0.0);
            this.level().addFreshEntity(experienceOrbTitan);
        }
    }

    @Override
    protected void dropAllItem() {
        Map<ItemStack, Integer> drops = new HashMap<>();
        Map<ItemStack, Integer> rateDrops = new HashMap<>();
        drops.put(new ItemStack(Items.SLIME_BALL), 64);
        drops.put(new ItemStack(Items.COAL), 16);
        rateDrops.put(new ItemStack(Items.SLIME_BALL), 64);
        rateDrops.put(new ItemStack(Items.COAL), 16);
        rateDrops.put(new ItemStack(Items.EMERALD), 8);
        rateDrops.put(new ItemStack(Items.DIAMOND), 8);
        rateDrops.put(new ItemStack((ItemLike)TheTitansRegistries.HARCADIUM_WAFLET.get()), 4);

        for (Entry<ItemStack, Integer> entry : drops.entrySet()) {
            ItemStack itemStack = entry.getKey();
            int count = entry.getValue();
            EntityItemTitan itemTitan = new EntityItemTitan(
                this.level(),
                this.getX() + (double)(this.random.nextFloat() * 12.0F - 6.0F),
                this.getY() + 4.0,
                this.getZ() + (double)(this.random.nextFloat() * 12.0F - 6.0F),
                itemStack,
                count
            );
            itemTitan.setPickUpDelay(40);
            this.level().addFreshEntity(itemTitan);
        }

        for (Entry<ItemStack, Integer> entry : rateDrops.entrySet()) {
            ItemStack itemStack = entry.getKey();
            int count = entry.getValue();
            int randomCount = this.random.nextInt(count) + 1;
            EntityItemTitan itemTitan = new EntityItemTitan(
                this.level(),
                this.getX() + (double)(this.random.nextFloat() * 12.0F - 6.0F),
                this.getY() + 4.0,
                this.getZ() + (double)(this.random.nextFloat() * 12.0F - 6.0F),
                itemStack,
                randomCount
            );
            itemTitan.setPickUpDelay(40);
            this.level().addFreshEntity(itemTitan);
        }
    }

    @Override
    protected void tickTitanDeath() {
        super.tickTitanDeath();
        this.animateHurt(180.0F);
        this.destroyBlocksInAABB(this.getBoundingBox());
        if (this.deathTicks >= 20 && !this.level().isClientSide() && !this.isRemoved()) {
            this.level().explode(this, this.getX(), this.getY() + 3.0, this.getZ(), 0.0F, false, ExplosionInteraction.MOB);
            int i = this.getSlimeSize();
            if (i > 1) {
                try {
                    int j = 2 + this.random.nextInt(3);

                    for (int k = 0; k < j; k++) {
                        float f = ((float)(k % 2) - 0.5F) * (float)i * 6.0F;
                        float f1 = ((float)(k / 2) - 0.5F) * (float)i * 6.0F;
                        Constructor<? extends EntitySlimeTitan> constructor = (Constructor<? extends EntitySlimeTitan>)this.getClass()
                            .getDeclaredConstructor(Level.class);
                        EntitySlimeTitan slimeTitan = constructor.newInstance(this.level());
                        slimeTitan.setPos(this.getX() + (double)f, this.getY() + 0.5, this.getZ() + (double)f1);
                        slimeTitan.setXRot(this.random.nextFloat() * 360.0F);
                        if (this.hasCustomName()) {
                            slimeTitan.setCustomName(this.getCustomName());
                        }

                        slimeTitan.setSlimeSize(i / 2);
                        slimeTitan.setTitanHealth(slimeTitan.getTitanMaxHealth());
                        this.level().addFreshEntity(slimeTitan);
                    }
                } catch (Exception var8) {
                    var8.printStackTrace();
                }
            } else {
                this.onDeath();
            }

            this.removeTitan(RemovalReason.KILLED);
        }
    }

    @Override
    public void tick() {
        super.tick();
        this.refreshDimensions();
        this.yBodyRot = this.getYRot();
        this.destroyBlocksInAABB(
            this.getBoundingBox().move(this.getDeltaMovement().x, this.getDeltaMovement().y > 0.0 ? this.getDeltaMovement().y : 0.0, this.getDeltaMovement().z)
        );
        this.squishFactor = this.squishFactor + (this.squishAmount - this.squishFactor) * 0.5F;
        this.prevSquishFactor = this.squishFactor;
        if (this.onGround() && !this.wasOnGround) {
            int i = this.getSlimeSize();

            for (int j = 0; j < i * 32; j++) {
                float f = this.random.nextFloat() * (float) Math.PI * 2.0F;
                float f1 = this.random.nextFloat() * 8.0F + 8.0F;
                float f2 = (float)(Math.sin((double)f) * (double)i * 0.5 * (double)f1);
                float f3 = (float)(Math.cos((double)f) * (double)i * 0.5 * (double)f1);
                this.level()
                    .addParticle(ParticleTypes.ITEM_SLIME, this.getX() + (double)f2, this.getBoundingBox().minY, this.getZ() + (double)f3, 0.0, 0.0, 0.0);
            }

            this.playSound(this.getJumpSound(), this.getSoundVolume(), ((this.random.nextFloat() - this.random.nextFloat()) * 0.2F + 1.0F) / 0.8F);
            this.squishAmount = -0.5F;
        } else if (!this.onGround() && this.wasOnGround) {
            this.squishAmount = 1.0F;
        }

        this.wasOnGround = this.onGround();
        this.alterSquishAmount();
        if (this.getTarget() != null) {
            this.lookAt(this.getTarget(), 180.0F, 40.0F);
            if (!this.onGround() && !this.doubleJumped && this.random.nextInt(100) == 0) {
                this.squishAmount = 2.0F;
                this.jumpFromGround();
                this.doubleJumped = true;
                this.playSound(this.getJumpSound(), this.getSoundVolume(), ((this.random.nextFloat() - this.random.nextFloat()) * 0.2F + 1.0F) * 0.8F);
            }
        } else if (this.doubleJumped) {
            this.doubleJumped = false;
        }

        if (this.onGround()) {
            this.doubleJumped = false;
        }
    }
}
