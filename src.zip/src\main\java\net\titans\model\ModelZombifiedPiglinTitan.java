package net.titans.model;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.util.Mth;
import net.titans.animation.Animator;
import net.titans.entity.titan.EntityZombifiedPiglinTitan;

public class ModelZombifiedPiglinTitan extends EntityModel<EntityZombifiedPiglinTitan> {
    public Animator animator;
    public ModelPart torso;
    public ModelPart leftThigh;
    public ModelPart rightThigh;
    public ModelPart middleBody;
    public ModelPart topBody;
    public ModelPart head;
    public ModelPart leftEar;
    public ModelPart rightEar;
    public ModelPart leftShoulder;
    public ModelPart rightShoulder;
    public ModelPart leftForearm;
    public ModelPart rightForearm;
    public ModelPart heldItem;
    public ModelPart leftCalf;
    public ModelPart rightCalf;

    public ModelZombifiedPiglinTitan(float grow) {
        ModelPart root = createBodyLayer(grow).bakeRoot();
        this.torso = root.getChild("torso");
        this.leftThigh = root.getChild("leftThigh");
        this.rightThigh = root.getChild("rightThigh");
        this.middleBody = root.getChild("torso").getChild("middleBody");
        this.topBody = root.getChild("torso").getChild("middleBody").getChild("topBody");
        this.head = root.getChild("torso").getChild("middleBody").getChild("topBody").getChild("head");
        this.leftEar = root.getChild("torso").getChild("middleBody").getChild("topBody").getChild("head").getChild("leftEar");
        this.rightEar = root.getChild("torso").getChild("middleBody").getChild("topBody").getChild("head").getChild("rightEar");
        this.leftShoulder = root.getChild("torso").getChild("middleBody").getChild("topBody").getChild("leftShoulder");
        this.rightShoulder = root.getChild("torso").getChild("middleBody").getChild("topBody").getChild("rightShoulder");
        this.leftForearm = root.getChild("torso").getChild("middleBody").getChild("topBody").getChild("leftShoulder").getChild("leftForearm");
        this.rightForearm = root.getChild("torso").getChild("middleBody").getChild("topBody").getChild("rightShoulder").getChild("rightForearm");
        this.heldItem = root.getChild("torso")
            .getChild("middleBody")
            .getChild("topBody")
            .getChild("rightShoulder")
            .getChild("rightForearm")
            .getChild("heldItem");
        this.leftCalf = root.getChild("leftThigh").getChild("leftCalf");
        this.rightCalf = root.getChild("rightThigh").getChild("rightCalf");
        this.animator = new Animator(root);
    }

    public static LayerDefinition createBodyLayer(float grow) {
        MeshDefinition meshDefinition = new MeshDefinition();
        PartDefinition partDefinition = meshDefinition.getRoot();
        CubeDeformation cubeDeformation = new CubeDeformation(grow);
        partDefinition.addOrReplaceChild(
            "torso",
            CubeListBuilder.create().texOffs(16, 32).addBox(-4.0F, -4.0F, -2.0F, 8.0F, 4.0F, 4.0F, cubeDeformation),
            PartPose.offsetAndRotation(0.0F, 12.0F, 0.0F, 0.0F, 0.0F, 0.0F)
        );
        partDefinition.getChild("torso")
            .addOrReplaceChild(
                "middleBody",
                CubeListBuilder.create().texOffs(16, 24).addBox(-4.0F, -4.0F, -2.0F, 8.0F, 4.0F, 4.0F, cubeDeformation),
                PartPose.offsetAndRotation(0.0F, -4.0F, 0.0F, 0.0F, 0.0F, 0.0F)
            );
        partDefinition.addOrReplaceChild(
            "leftThigh",
            CubeListBuilder.create().mirror().texOffs(0, 16).addBox(-2.0F, 0.0F, -2.0F, 4.0F, 6.0F, 4.0F, cubeDeformation),
            PartPose.offsetAndRotation(2.0F, 12.0F, 0.0F, 0.0F, 0.0F, 0.0F)
        );
        partDefinition.getChild("leftThigh")
            .addOrReplaceChild(
                "leftCalf",
                CubeListBuilder.create().mirror().texOffs(0, 26).addBox(-2.0F, 0.0F, -2.0F, 4.0F, 6.0F, 4.0F, cubeDeformation),
                PartPose.offsetAndRotation(0.0F, 6.0F, 0.0F, 0.0F, 0.0F, 0.0F)
            );
        partDefinition.addOrReplaceChild(
            "rightThigh",
            CubeListBuilder.create().texOffs(0, 16).addBox(-2.0F, 0.0F, -2.0F, 4.0F, 6.0F, 4.0F, cubeDeformation),
            PartPose.offsetAndRotation(-2.0F, 12.0F, 0.0F, 0.0F, 0.0F, 0.0F)
        );
        partDefinition.getChild("rightThigh")
            .addOrReplaceChild(
                "rightCalf",
                CubeListBuilder.create().texOffs(0, 26).addBox(-2.0F, 0.0F, -2.0F, 4.0F, 6.0F, 4.0F, cubeDeformation),
                PartPose.offsetAndRotation(0.0F, 6.0F, 0.0F, 0.0F, 0.0F, 0.0F)
            );
        partDefinition.getChild("torso")
            .getChild("middleBody")
            .addOrReplaceChild(
                "topBody",
                CubeListBuilder.create().texOffs(16, 16).addBox(-4.0F, -4.0F, -2.0F, 8.0F, 4.0F, 4.0F, cubeDeformation),
                PartPose.offsetAndRotation(0.0F, -4.0F, 0.0F, 0.0F, 0.0F, 0.0F)
            );
        partDefinition.getChild("torso")
            .getChild("middleBody")
            .getChild("topBody")
            .addOrReplaceChild(
                "leftShoulder",
                CubeListBuilder.create().mirror().texOffs(40, 16).addBox(-2.0F, -2.0F, -2.0F, 4.0F, 6.0F, 4.0F, cubeDeformation),
                PartPose.offsetAndRotation(6.0F, -2.0F, 0.0F, 0.0F, 0.0F, 0.0F)
            );
        partDefinition.getChild("torso")
            .getChild("middleBody")
            .getChild("topBody")
            .getChild("leftShoulder")
            .addOrReplaceChild(
                "leftForearm",
                CubeListBuilder.create().mirror().texOffs(40, 26).addBox(-2.0F, 0.0F, -2.0F, 4.0F, 6.0F, 4.0F, cubeDeformation),
                PartPose.offsetAndRotation(0.0F, 4.0F, 0.0F, 0.0F, 0.0F, 0.0F)
            );
        partDefinition.getChild("torso")
            .getChild("middleBody")
            .getChild("topBody")
            .addOrReplaceChild(
                "rightShoulder",
                CubeListBuilder.create().texOffs(40, 16).addBox(-2.0F, -2.0F, -2.0F, 4.0F, 6.0F, 4.0F, cubeDeformation),
                PartPose.offsetAndRotation(-6.0F, -2.0F, 0.0F, 0.0F, 0.0F, 0.0F)
            );
        partDefinition.getChild("torso")
            .getChild("middleBody")
            .getChild("topBody")
            .getChild("rightShoulder")
            .addOrReplaceChild(
                "rightForearm",
                CubeListBuilder.create().texOffs(40, 26).addBox(-2.0F, 0.0F, -2.0F, 4.0F, 6.0F, 4.0F, cubeDeformation),
                PartPose.offsetAndRotation(0.0F, 4.0F, 0.0F, 0.0F, 0.0F, 0.0F)
            );
        partDefinition.getChild("torso")
            .getChild("middleBody")
            .getChild("topBody")
            .getChild("rightShoulder")
            .getChild("rightForearm")
            .addOrReplaceChild(
                "heldItem",
                CubeListBuilder.create().texOffs(32, 32).addBox(0.0F, -12.0F, -12.0F, 0.0F, 16.0F, 16.0F, cubeDeformation),
                PartPose.offsetAndRotation(0.0F, 4.0F, 0.0F, 0.0F, 0.0F, 0.0F)
            );
        partDefinition.getChild("torso")
            .getChild("middleBody")
            .getChild("topBody")
            .addOrReplaceChild(
                "head",
                CubeListBuilder.create()
                    .texOffs(0, 0)
                    .addBox(-5.0F, -8.0F, -4.0F, 10.0F, 8.0F, 8.0F, cubeDeformation)
                    .texOffs(31, 1)
                    .addBox(-2.0F, -4.0F, -5.0F, 4.0F, 4.0F, 1.0F, cubeDeformation)
                    .texOffs(2, 4)
                    .addBox(2.0F, -2.0F, -5.0F, 1.0F, 2.0F, 1.0F, cubeDeformation)
                    .texOffs(2, 0)
                    .addBox(-3.0F, -2.0F, -5.0F, 1.0F, 2.0F, 1.0F, cubeDeformation),
                PartPose.offsetAndRotation(0.0F, -4.0F, 0.0F, 0.0F, 0.0F, 0.0F)
            );
        partDefinition.getChild("torso")
            .getChild("middleBody")
            .getChild("topBody")
            .getChild("head")
            .addOrReplaceChild(
                "leftEar",
                CubeListBuilder.create().texOffs(51, 6).addBox(0.0F, 0.0F, -2.0F, 1.0F, 5.0F, 4.0F, cubeDeformation),
                PartPose.offsetAndRotation(4.5F, -6.0F, 0.0F, 0.0F, 0.0F, (float) (-Math.PI / 6))
            );
        partDefinition.getChild("torso")
            .getChild("middleBody")
            .getChild("topBody")
            .getChild("head")
            .addOrReplaceChild(
                "rightEar",
                CubeListBuilder.create().texOffs(39, 6).addBox(-1.0F, 0.0F, -2.0F, 1.0F, 5.0F, 4.0F, cubeDeformation),
                PartPose.offsetAndRotation(-4.5F, -6.0F, 0.0F, 0.0F, 0.0F, (float) (Math.PI / 6))
            );
        return LayerDefinition.create(meshDefinition, 64, 64);
    }

    public void setupAnim(EntityZombifiedPiglinTitan entity, float limbSwing, float limbSwingAmount, float ageInTicks, float headYaw, float headPitch) {
        this.animate(entity, limbSwing, limbSwingAmount, ageInTicks, headYaw, headPitch);
        float f = 1.2F;
        float f1 = ageInTicks * 0.1F + limbSwing * 0.5F;
        float f2 = 0.08F + limbSwingAmount * 0.4F;
        this.leftEar.zRot = (float) (-Math.PI / 6) - Mth.cos(f1 * f) * f2;
        this.rightEar.zRot = (float) (Math.PI / 6) + Mth.cos(f1) * f2;
    }

    public void renderToBuffer(PoseStack poseStack, VertexConsumer vertexConsumer, int packedLight, int packedOverlay, float red, float green, float blue, float alpha) {
        if (this.young) {
            float f6 = 2.0F;
            poseStack.pushPose();
            poseStack.scale(1.0F / f6, 1.0F / f6, 1.0F / f6);
            poseStack.translate(0.0F, 1.5F, 0.0F);
            this.torso.render(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
            this.leftThigh.render(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
            this.rightThigh.render(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
            poseStack.popPose();
        } else {
            this.torso.render(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
            this.leftThigh.render(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
            this.rightThigh.render(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
        }
    }

    public void setAngles() {
        this.leftShoulder.xRot = (float) (-Math.PI / 2);
        this.rightShoulder.xRot = (float) (-Math.PI / 2);
        this.heldItem.xRot = (float) (Math.PI / 4);
        this.rightThigh.z = 0.0F;
        this.leftThigh.z = 0.0F;
        this.torso.z = 0.0F;
        this.torso.x = 0.0F;
        this.torso.y = 12.0F;
        this.heldItem.z = 0.0F;
        this.heldItem.x = 0.0F;
        this.heldItem.y = 4.0F;
        this.rightThigh.y = 12.0F;
        this.leftThigh.y = 12.0F;
    }

    public void animate(EntityZombifiedPiglinTitan entity, float limbSwing, float limbSwingAmount, float ageInTicks, float headYaw, float headPitch) {
        float partialTicks = Minecraft.getInstance().getFrameTime();
        if (!entity.onGround()) {
            limbSwingAmount = 0.0F;
        }

        this.animator.update(entity);
        this.setAngles();
        float fo = 0.16655F;
        if (entity.deathTicks <= 0) {
            float f6 = Mth.cos(ageInTicks * 0.1F);
            if (entity.getAnimationID() == 0) {
                this.middleBody.xRot = (0.001F + 0.005F * f6) * (float) Math.PI;
                this.topBody.xRot = (0.001F + 0.005F * f6) * (float) Math.PI;
                this.head.xRot = (0.001F + 0.0075F * f6) * (float) Math.PI;
                this.rightShoulder.yRot = (-0.001F + 0.01F * f6) * (float) Math.PI;
                this.leftShoulder.yRot = (0.001F + -0.01F * f6) * (float) Math.PI;
            }

            if (this.riding) {
                this.rightThigh.xRot = (float) (-Math.PI / 2);
                this.leftThigh.xRot = (float) (-Math.PI / 2);
                this.rightThigh.yRot = (float) (Math.PI / 10);
                this.leftThigh.yRot = (float) (-Math.PI / 10);
                this.rightCalf.xRot = (float) (Math.PI / 3);
                this.leftCalf.xRot = (float) (Math.PI / 3);
            } else if (entity.getAnimationID() == 0) {
                this.torso.zRot = Mth.cos(limbSwing * fo) * 0.2F * limbSwingAmount;
                this.middleBody.zRot = Mth.cos(limbSwing * fo - 1.0F) * 0.2F * limbSwingAmount;
                this.topBody.zRot = Mth.cos(limbSwing * fo - 2.0F) * 0.2F * limbSwingAmount;
                this.rightThigh.xRot = Mth.cos(limbSwing * fo - 0.5F) * 0.75F * limbSwingAmount;
                this.leftThigh.xRot = Mth.cos(limbSwing * fo + 2.6415927F) * 0.75F * limbSwingAmount;
                this.rightCalf.xRot = Mth.cos(limbSwing * fo + (float) Math.PI) * 0.75F * limbSwingAmount;
                this.leftCalf.xRot = Mth.cos(limbSwing * fo) * 0.75F * limbSwingAmount;
                this.torso.y = 12.0F - Mth.cos(limbSwing * fo * 2.0F + 1.0F) * 2.0F * limbSwingAmount;
                this.rightThigh.y = 12.0F - Mth.cos(limbSwing * fo * 2.0F + 1.0F) * 2.0F * limbSwingAmount;
                this.leftThigh.y = 12.0F - Mth.cos(limbSwing * fo * 2.0F + 1.0F) * 2.0F * limbSwingAmount;
                if (this.rightCalf.xRot < 0.0F) {
                    this.rightCalf.xRot = 0.0F;
                }

                if (this.leftCalf.xRot < 0.0F) {
                    this.leftCalf.xRot = 0.0F;
                }
            }

            float faceYaw = headYaw * (float) Math.PI / 180.0F;
            float facePitch = headPitch * (float) Math.PI / 180.0F;
            if (entity.getAnimationID() == 0) {
                this.head.xRot += facePitch * 0.3F;
                this.head.yRot += faceYaw * 0.3F;
                this.topBody.xRot += facePitch * 0.3F;
                this.topBody.yRot += faceYaw * 0.3F;
                this.middleBody.xRot += facePitch * 0.3F;
                this.middleBody.yRot += faceYaw * 0.3F;
            } else {
                this.head.xRot += facePitch * 0.9F;
                this.head.yRot += faceYaw * 0.9F;
            }

            if (!entity.onGround() && !this.riding && entity.getY() > -63.0) {
                this.torso.zRot = 0.0F;
                this.middleBody.zRot = 0.0F;
                this.topBody.zRot = 0.0F;
                this.head.zRot = 0.0F;
                this.rightShoulder.xRot = this.rightShoulder.xRot - entity.walkAnimation.speed(partialTicks);
                this.leftShoulder.xRot = this.leftShoulder.xRot - entity.walkAnimation.speed(partialTicks);
                this.head.xRot = this.head.xRot - entity.walkAnimation.speed(partialTicks);
                this.torso.xRot = this.torso.xRot + entity.walkAnimation.speed(partialTicks);
                this.rightThigh.zRot = 0.25F;
                this.leftThigh.zRot = -0.25F;
                this.rightThigh.yRot = -0.25F;
                this.leftThigh.yRot = 0.25F;
                this.rightThigh.xRot = Mth.cos(ageInTicks * 0.2F) * 0.25F
                    - (float)(entity.getDeltaMovement().y / 5.0)
                    + entity.walkAnimation.speed(partialTicks);
                this.leftThigh.xRot = Mth.cos(ageInTicks * 0.2F - (float) Math.PI) * 0.25F
                    - (float)(entity.getDeltaMovement().y / 5.0)
                    + entity.walkAnimation.speed(partialTicks);
                this.rightCalf.xRot = 0.5F - Mth.cos(ageInTicks * 0.2F + 0.5F) * 0.5F;
                this.leftCalf.xRot = 0.5F - Mth.cos(ageInTicks * 0.2F - 2.6415927F) * 0.5F;
            }

            if (entity.getAnimationID() == 11 && entity.getAnimationTick() > 30 && entity.getAnimationTick() < 160) {
                this.head.zRot = Mth.cos(ageInTicks * 0.25F - 3.0F) * 0.5F;
                this.topBody.zRot = Mth.cos(ageInTicks * 0.25F - 2.0F) * 0.25F;
                this.middleBody.zRot = Mth.cos(ageInTicks * 0.25F - 1.0F) * 0.25F;
                this.torso.zRot = Mth.cos(ageInTicks * 0.25F) * 0.25F;
            }

            if (entity.getAnimationID() == 12 && entity.getAnimationTick() > 30 && entity.getAnimationTick() < 50) {
                this.rightForearm.xRot = 0.1F * Mth.cos(ageInTicks * 2.0F) * (float) Math.PI;
                this.leftForearm.xRot = -(0.1F * Mth.cos(ageInTicks * 2.0F) * (float) Math.PI);
            }

            if (entity.getAnimationID() == 1) {
                switch (entity.getAntiTitanAttackAnimationID()) {
                    case 0:
                        this.animateAntiTitanAttack1();
                        break;
                    case 1:
                        this.animateAntiTitanAttack2();
                        break;
                    case 2:
                        this.animateAntiTitanAttack3();
                        break;
                    case 3:
                        this.animateAntiTitanAttack4();
                }
            }

            this.animateBirth();
            this.animateRoar();
            this.animateRangedAttackThrow();
            this.animateSlam();
            this.animateSwat();
            this.animateSwordDig();
            this.animateLightning();
            this.animateStomp();
            this.animateDownwardSlash();
            this.animateStun();
            this.animateSidewaySlash();
        } else {
            this.animateDeath();
        }
    }

    private void animateAntiTitanAttack1() {
        this.animator.setAnimationID(1);
        this.animator.startPhase(10);
        this.animator.move(this.torso, 0.0F, 2.0F, 5.0F);
        this.animator.move(this.rightThigh, 0.0F, 2.0F, 5.0F);
        this.animator.move(this.leftThigh, 0.0F, 2.0F, 5.0F);
        this.animator.rotate(this.rightThigh, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.leftThigh, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.rightCalf, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.leftCalf, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.head, 0.5F, -1.5F, 0.0F);
        this.animator.rotate(this.topBody, 0.5F, 0.5F, 0.0F);
        this.animator.rotate(this.middleBody, -0.5F, 0.5F, 0.0F);
        this.animator.rotate(this.torso, -0.5F, 0.5F, 0.0F);
        this.animator.rotate(this.rightShoulder, 3.0F, 0.0F, 0.0F);
        this.animator.rotate(this.rightForearm, -1.5F, 0.0F, 0.0F);
        this.animator.rotate(this.leftShoulder, 1.0F, 0.0F, -1.0F);
        this.animator.rotate(this.leftForearm, -1.5F, 0.0F, 0.0F);
        this.animator.rotate(this.heldItem, -12.0F, 0.0F, 0.0F);
        this.animator.endPhase();
        this.animator.startPhase(10);
        this.animator.move(this.torso, 0.0F, 1.0F, -5.0F);
        this.animator.move(this.rightThigh, 0.0F, 1.0F, -5.0F);
        this.animator.move(this.leftThigh, 0.0F, 1.0F, -5.0F);
        this.animator.rotate(this.rightThigh, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.leftThigh, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.rightCalf, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.leftCalf, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.head, -0.5F, 1.5F, 0.0F);
        this.animator.rotate(this.topBody, -0.5F, -0.5F, 0.0F);
        this.animator.rotate(this.middleBody, 0.5F, -0.5F, 0.0F);
        this.animator.rotate(this.torso, 0.5F, -0.5F, 0.0F);
        this.animator.rotate(this.rightShoulder, -1.5F, 0.0F, -1.2F);
        this.animator.rotate(this.rightForearm, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.leftShoulder, 3.0F, 0.0F, -1.0F);
        this.animator.rotate(this.leftForearm, -1.0F, 0.0F, 0.0F);
        this.animator.rotate(this.heldItem, -11.5F, 0.0F, 0.0F);
        this.animator.endPhase();
        this.animator.resetPhase(10);
    }

    private void animateAntiTitanAttack2() {
        this.animator.setAnimationID(1);
        this.animator.startPhase(8);
        this.animator.move(this.torso, 0.0F, 1.0F, 0.0F);
        this.animator.move(this.rightThigh, 0.0F, 1.0F, 0.0F);
        this.animator.move(this.leftThigh, 0.0F, 1.0F, 0.0F);
        this.animator.rotate(this.rightThigh, -0.25F, 0.0F, 0.0F);
        this.animator.rotate(this.leftThigh, -0.25F, 0.0F, 0.0F);
        this.animator.rotate(this.rightCalf, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.leftCalf, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.head, -1.0F, 0.0F, 0.0F);
        this.animator.rotate(this.topBody, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.middleBody, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.rightShoulder, 0.8F, 0.5F, 0.5F);
        this.animator.rotate(this.leftShoulder, 0.8F, -0.5F, -0.5F);
        this.animator.rotate(this.rightForearm, -1.6F, 0.0F, 0.0F);
        this.animator.rotate(this.leftForearm, -1.6F, 0.0F, 0.0F);
        this.animator.rotate(this.heldItem, 1.0F, 0.5F, 0.75F);
        this.animator.endPhase();
        this.animator.startPhase(12);
        this.animator.move(this.torso, 0.0F, 1.0F, -5.0F);
        this.animator.move(this.rightThigh, 0.0F, 1.0F, -5.0F);
        this.animator.move(this.leftThigh, 0.0F, 1.0F, -5.0F);
        this.animator.rotate(this.rightThigh, 1.8F, -10.0F, 0.5F);
        this.animator.rotate(this.rightCalf, 0.0F, 0.0F, 0.5F);
        this.animator.rotate(this.leftThigh, -0.5F, -10.0F, 0.0F);
        this.animator.rotate(this.leftCalf, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.torso, 1.75F, -10.0F, 0.0F);
        this.animator.endPhase();
        this.animator.startPhase(10);
        this.animator.rotate(this.rightThigh, 0.0F, -12.6F, 0.0F);
        this.animator.rotate(this.leftThigh, 0.0F, -12.6F, 0.0F);
        this.animator.rotate(this.torso, 0.0F, -12.6F, 0.0F);
        this.animator.endPhase();
        this.animator.resetPhase(0);
    }

    private void animateAntiTitanAttack3() {
        this.animator.setAnimationID(1);
        this.animator.startPhase(10);
        this.animator.move(this.torso, 0.0F, 2.0F, 5.0F);
        this.animator.move(this.rightThigh, 0.0F, 2.0F, 5.0F);
        this.animator.move(this.leftThigh, 0.0F, 2.0F, 5.0F);
        this.animator.rotate(this.rightThigh, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.leftThigh, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.rightCalf, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.leftCalf, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.head, 0.5F, 1.5F, 0.0F);
        this.animator.rotate(this.topBody, 0.5F, -0.5F, 0.0F);
        this.animator.rotate(this.middleBody, -0.5F, -0.5F, 0.0F);
        this.animator.rotate(this.torso, -0.5F, -0.5F, 0.0F);
        this.animator.rotate(this.leftShoulder, 2.0F, -1.0F, -1.0F);
        this.animator.rotate(this.leftForearm, -2.0F, 0.0F, 0.0F);
        this.animator.rotate(this.heldItem, 3.0F, 0.0F, 0.0F);
        this.animator.endPhase();
        this.animator.startPhase(10);
        this.animator.move(this.torso, 0.0F, 1.0F, -5.0F);
        this.animator.move(this.rightThigh, 0.0F, 1.0F, -5.0F);
        this.animator.move(this.leftThigh, 0.0F, 1.0F, -5.0F);
        this.animator.rotate(this.rightThigh, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.leftThigh, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.rightCalf, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.leftCalf, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.head, -0.5F, -1.5F, 0.0F);
        this.animator.rotate(this.topBody, -0.5F, 0.5F, 0.0F);
        this.animator.rotate(this.middleBody, 0.5F, 0.5F, 0.0F);
        this.animator.rotate(this.torso, 0.5F, 0.5F, 0.0F);
        this.animator.rotate(this.rightShoulder, -0.6F, 0.0F, -1.0F);
        this.animator.rotate(this.leftShoulder, -0.5F, 0.0F, 1.0F);
        this.animator.rotate(this.rightForearm, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.leftForearm, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.heldItem, 3.0F, 0.0F, 0.0F);
        this.animator.endPhase();
        this.animator.resetPhase(10);
    }

    private void animateAntiTitanAttack4() {
        this.animator.setAnimationID(1);
        this.animator.startPhase(10);
        this.animator.move(this.torso, 0.0F, 1.0F, 5.0F);
        this.animator.move(this.rightThigh, 0.0F, 1.0F, 5.0F);
        this.animator.move(this.leftThigh, 0.0F, 1.0F, 5.0F);
        this.animator.rotate(this.rightThigh, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.leftThigh, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.rightCalf, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.leftCalf, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.head, 1.6F, 0.0F, 0.0F);
        this.animator.rotate(this.topBody, -0.8F, 0.0F, 0.0F);
        this.animator.rotate(this.middleBody, -0.8F, 0.0F, 0.0F);
        this.animator.rotate(this.rightShoulder, -2.0F, 0.0F, 0.0F);
        this.animator.rotate(this.leftShoulder, -2.0F, 0.0F, 0.0F);
        this.animator.rotate(this.leftForearm, -1.0F, 0.0F, 0.5F);
        this.animator.rotate(this.rightForearm, -1.0F, 0.0F, -0.5F);
        this.animator.rotate(this.heldItem, -1.0F, 0.0F, 0.0F);
        this.animator.endPhase();
        this.animator.startPhase(10);
        this.animator.move(this.torso, 0.0F, 2.0F, -12.0F);
        this.animator.move(this.rightThigh, 0.0F, 2.0F, -12.0F);
        this.animator.move(this.leftThigh, 0.0F, 2.0F, -12.0F);
        this.animator.rotate(this.rightThigh, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.leftThigh, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.rightCalf, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.leftCalf, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.head, -2.0F, 0.0F, 0.0F);
        this.animator.rotate(this.topBody, 1.0F, 0.0F, 0.0F);
        this.animator.rotate(this.middleBody, 1.0F, 0.0F, 0.0F);
        this.animator.rotate(this.rightShoulder, 0.0F, 0.0F, 0.0F);
        this.animator.rotate(this.leftShoulder, 0.0F, 0.0F, 0.0F);
        this.animator.rotate(this.leftForearm, -0.5F, 0.0F, 0.5F);
        this.animator.rotate(this.rightForearm, -0.5F, 0.0F, -0.5F);
        this.animator.rotate(this.heldItem, 1.0F, 0.0F, 0.0F);
        this.animator.endPhase();
        this.animator.resetPhase(10);
    }

    private void animateSwat() {
        this.animator.setAnimationID(2);
        this.animator.startPhase(20);
        this.animator.move(this.torso, 0.0F, 2.0F, 0.0F);
        this.animator.move(this.rightThigh, 0.0F, 2.0F, 0.0F);
        this.animator.move(this.leftThigh, 0.0F, 2.0F, 0.0F);
        this.animator.rotate(this.rightThigh, -0.5F, 0.25F, 0.0F);
        this.animator.rotate(this.leftThigh, -0.5F, -0.25F, 0.0F);
        this.animator.rotate(this.rightCalf, 1.0F, 0.0F, 0.0F);
        this.animator.rotate(this.leftCalf, 1.0F, 0.0F, 0.0F);
        this.animator.rotate(this.head, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.head, -1.0F, 1.0F, 0.0F);
        this.animator.rotate(this.leftShoulder, -1.0F, 0.0F, 1.0F);
        this.animator.rotate(this.leftForearm, 0.0F, 0.0F, 0.0F);
        this.animator.rotate(this.topBody, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.middleBody, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.torso, 0.5F, -1.0F, 0.0F);
        this.animator.rotate(this.heldItem, 4.0F, 0.0F, 0.0F);
        this.animator.endPhase();
        this.animator.startPhase(20);
        this.animator.move(this.torso, 0.0F, 4.0F, 0.0F);
        this.animator.move(this.rightThigh, 0.0F, 4.0F, 0.0F);
        this.animator.move(this.leftThigh, 0.0F, 4.0F, 0.0F);
        this.animator.rotate(this.rightThigh, -1.0F, 0.5F, 0.0F);
        this.animator.rotate(this.leftThigh, -1.0F, -0.5F, 0.0F);
        this.animator.rotate(this.rightCalf, 2.0F, 0.0F, 0.0F);
        this.animator.rotate(this.leftCalf, 2.0F, 0.0F, 0.0F);
        this.animator.rotate(this.head, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.head, -1.5F, 0.0F, 0.0F);
        this.animator.rotate(this.leftShoulder, -1.0F, 0.0F, -1.0F);
        this.animator.rotate(this.leftForearm, -1.0F, 0.0F, 0.0F);
        this.animator.rotate(this.topBody, 0.75F, 0.0F, 0.0F);
        this.animator.rotate(this.middleBody, 0.75F, 0.0F, 0.0F);
        this.animator.rotate(this.torso, 0.75F, 1.0F, 0.0F);
        this.animator.rotate(this.heldItem, 4.0F, 0.0F, 0.0F);
        this.animator.endPhase();
        this.animator.resetPhase(20);
    }

    private void animateSwordDig() {
        this.animator.setAnimationID(4);
        this.animator.startPhase(25);
        this.animator.move(this.torso, 0.0F, 1.0F, 0.0F);
        this.animator.move(this.rightThigh, 0.0F, 1.0F, 0.0F);
        this.animator.move(this.leftThigh, 0.0F, 1.0F, 0.0F);
        this.animator.rotate(this.rightThigh, -0.25F, 0.0F, 0.0F);
        this.animator.rotate(this.leftThigh, -0.25F, 0.0F, 0.0F);
        this.animator.rotate(this.rightCalf, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.leftCalf, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.head, -1.0F, 0.0F, 0.0F);
        this.animator.rotate(this.topBody, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.middleBody, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.rightShoulder, 0.8F, 0.5F, 0.5F);
        this.animator.rotate(this.leftShoulder, 0.8F, -0.5F, -0.5F);
        this.animator.rotate(this.rightForearm, -1.6F, 0.0F, 0.0F);
        this.animator.rotate(this.leftForearm, -1.6F, 0.0F, 0.0F);
        this.animator.rotate(this.heldItem, 1.0F, 0.0F, 0.0F);
        this.animator.endPhase();
        this.animator.startPhase(25);
        this.animator.move(this.torso, 0.0F, 0.0F, 0.0F);
        this.animator.move(this.rightThigh, 0.0F, -1.0F, 0.0F);
        this.animator.move(this.leftThigh, 0.0F, 0.0F, 0.0F);
        this.animator.rotate(this.rightThigh, -2.0F, 0.2F, 0.0F);
        this.animator.rotate(this.leftThigh, 0.0F, -0.2F, 0.0F);
        this.animator.rotate(this.rightCalf, 2.0F, 0.0F, 0.0F);
        this.animator.rotate(this.leftCalf, 0.1F, 0.0F, 0.0F);
        this.animator.rotate(this.head, 1.6F, 0.0F, 0.0F);
        this.animator.rotate(this.topBody, -0.8F, 0.0F, 0.0F);
        this.animator.rotate(this.middleBody, -0.8F, 0.0F, 0.0F);
        this.animator.rotate(this.rightShoulder, 0.0F, 0.2F, 0.0F);
        this.animator.rotate(this.leftShoulder, 0.0F, -0.2F, 0.0F);
        this.animator.rotate(this.rightForearm, 0.0F, -0.4F, 0.0F);
        this.animator.rotate(this.leftForearm, 0.0F, 0.4F, 0.0F);
        this.animator.rotate(this.heldItem, 1.0F, 0.0F, 0.0F);
        this.animator.endPhase();
        this.animator.startPhase(10);
        this.animator.move(this.torso, 0.0F, 3.0F, 1.0F);
        this.animator.move(this.rightThigh, 0.0F, 1.0F, 0.0F);
        this.animator.move(this.leftThigh, 0.0F, 1.0F, 0.0F);
        this.animator.rotate(this.head, -1.2F, 0.0F, 0.0F);
        this.animator.rotate(this.topBody, 0.4F, 0.0F, 0.0F);
        this.animator.rotate(this.middleBody, 0.4F, 0.0F, 0.0F);
        this.animator.rotate(this.torso, 0.4F, 0.0F, 0.0F);
        this.animator.rotate(this.rightShoulder, -1.0F, 0.0F, 0.75F);
        this.animator.rotate(this.leftShoulder, -1.0F, 0.0F, -0.75F);
        this.animator.rotate(this.rightForearm, -0.25F, 0.0F, -0.5F);
        this.animator.rotate(this.leftForearm, -0.25F, 0.0F, 0.5F);
        this.animator.rotate(this.heldItem, 3.0F, 0.0F, 0.0F);
        this.animator.endPhase();
        this.animator.setStationaryPhase(40);
        this.animator.startPhase(30);
        this.animator.move(this.torso, 0.0F, 3.0F, 1.0F);
        this.animator.move(this.rightThigh, 0.0F, 1.0F, 0.0F);
        this.animator.move(this.leftThigh, 0.0F, 1.0F, 0.0F);
        this.animator.rotate(this.head, -0.75F, 0.0F, 0.0F);
        this.animator.rotate(this.topBody, 0.25F, 0.0F, 0.0F);
        this.animator.rotate(this.middleBody, 0.25F, 0.0F, 0.0F);
        this.animator.rotate(this.torso, 0.25F, 0.0F, 0.0F);
        this.animator.rotate(this.rightShoulder, -1.0F, 0.0F, 0.75F);
        this.animator.rotate(this.leftShoulder, -1.0F, 0.0F, -0.75F);
        this.animator.rotate(this.rightForearm, 0.0F, 0.0F, -0.5F);
        this.animator.rotate(this.leftForearm, 0.0F, 0.0F, 0.5F);
        this.animator.rotate(this.heldItem, 2.0F, 0.0F, 2.0F);
        this.animator.endPhase();
        this.animator.resetPhase(20);
    }

    private void animateSlam() {
        this.animator.setAnimationID(3);
        this.animator.startPhase(10);
        this.animator.move(this.torso, 0.0F, 1.0F, 0.0F);
        this.animator.move(this.rightThigh, 0.0F, 1.0F, 0.0F);
        this.animator.move(this.leftThigh, 0.0F, 1.0F, 0.0F);
        this.animator.rotate(this.rightThigh, -0.25F, 0.0F, 0.0F);
        this.animator.rotate(this.leftThigh, -0.25F, 0.0F, 0.0F);
        this.animator.rotate(this.rightCalf, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.leftCalf, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.head, -1.0F, 0.0F, 0.0F);
        this.animator.rotate(this.topBody, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.middleBody, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.rightShoulder, 0.8F, 0.5F, 0.5F);
        this.animator.rotate(this.leftShoulder, 0.8F, -0.5F, -0.5F);
        this.animator.rotate(this.rightForearm, -1.6F, 0.0F, 0.0F);
        this.animator.rotate(this.leftForearm, -1.6F, 0.0F, 0.0F);
        this.animator.rotate(this.heldItem, 0.6F, 0.0F, 0.75F);
        this.animator.endPhase();
        this.animator.startPhase(15);
        this.animator.move(this.torso, 0.0F, -1.0F, 0.0F);
        this.animator.move(this.rightThigh, 0.0F, -1.0F, 0.0F);
        this.animator.move(this.leftThigh, 0.0F, 0.0F, 0.0F);
        this.animator.rotate(this.rightThigh, -1.6F, 0.2F, 0.0F);
        this.animator.rotate(this.leftThigh, 0.0F, 0.2F, 0.0F);
        this.animator.rotate(this.rightCalf, 0.9F, 0.0F, 0.0F);
        this.animator.rotate(this.leftCalf, 0.1F, 0.0F, 0.0F);
        this.animator.rotate(this.head, 1.6F, 0.0F, 0.0F);
        this.animator.rotate(this.topBody, -0.8F, 0.0F, 0.0F);
        this.animator.rotate(this.middleBody, -0.8F, 0.0F, 0.0F);
        this.animator.rotate(this.rightShoulder, -2.0F, 0.0F, 0.0F);
        this.animator.rotate(this.leftShoulder, -2.0F, 0.0F, 0.0F);
        this.animator.rotate(this.rightForearm, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.leftForearm, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.heldItem, -0.3F, 0.0F, -0.75F);
        this.animator.endPhase();
        this.animator.startPhase(15);
        this.animator.move(this.torso, 0.0F, 3.0F, 1.0F);
        this.animator.move(this.rightThigh, 0.0F, 1.0F, 0.0F);
        this.animator.move(this.leftThigh, 0.0F, 1.0F, 0.0F);
        this.animator.rotate(this.rightThigh, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.leftThigh, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.rightCalf, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.leftCalf, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.head, -1.5F, 0.0F, 0.0F);
        this.animator.rotate(this.topBody, 0.75F, 0.0F, 0.0F);
        this.animator.rotate(this.middleBody, 0.75F, 0.0F, 0.0F);
        this.animator.rotate(this.torso, 1.0F, 0.0F, 0.0F);
        this.animator.rotate(this.rightShoulder, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.leftShoulder, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.rightForearm, -0.5F, 0.0F, -0.5F);
        this.animator.rotate(this.leftForearm, -0.5F, 0.0F, 0.5F);
        this.animator.endPhase();
        this.animator.resetPhase(30);
    }

    private void animateLightning() {
        this.animator.setAnimationID(5);
        this.animator.startPhase(10);
        this.animator.move(this.torso, 0.0F, 1.0F, 0.0F);
        this.animator.move(this.rightThigh, 0.0F, 1.0F, 0.0F);
        this.animator.move(this.leftThigh, 0.0F, 1.0F, 0.0F);
        this.animator.rotate(this.rightThigh, -0.25F, 0.0F, 0.0F);
        this.animator.rotate(this.leftThigh, -0.25F, 0.0F, 0.0F);
        this.animator.rotate(this.rightCalf, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.leftCalf, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.head, -1.0F, 0.0F, 0.0F);
        this.animator.rotate(this.topBody, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.middleBody, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.rightShoulder, 0.8F, 0.5F, 0.5F);
        this.animator.rotate(this.leftShoulder, 0.8F, -0.5F, -0.5F);
        this.animator.rotate(this.rightForearm, -1.6F, 0.0F, 0.0F);
        this.animator.rotate(this.leftForearm, -1.6F, 0.0F, 0.0F);
        this.animator.rotate(this.heldItem, 0.0F, 0.0F, 0.75F);
        this.animator.endPhase();
        this.animator.startPhase(20);
        this.animator.move(this.torso, 0.0F, 0.0F, 0.0F);
        this.animator.move(this.rightThigh, 0.0F, -1.0F, 0.0F);
        this.animator.move(this.leftThigh, 0.0F, 0.0F, 0.0F);
        this.animator.rotate(this.rightThigh, -2.0F, 0.2F, 0.0F);
        this.animator.rotate(this.leftThigh, 0.0F, -0.2F, 0.0F);
        this.animator.rotate(this.rightCalf, 2.0F, 0.0F, 0.0F);
        this.animator.rotate(this.leftCalf, 0.1F, 0.0F, 0.0F);
        this.animator.rotate(this.head, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.topBody, -0.8F, 0.0F, 0.0F);
        this.animator.rotate(this.middleBody, -0.8F, 0.0F, 0.0F);
        this.animator.rotate(this.rightShoulder, 0.35F, 0.4F, 0.0F);
        this.animator.rotate(this.leftShoulder, 0.35F, -0.4F, 0.0F);
        this.animator.endPhase();
        this.animator.setStationaryPhase(20);
        this.animator.startPhase(10);
        this.animator.move(this.torso, 0.0F, 0.0F, 0.0F);
        this.animator.move(this.rightThigh, 0.0F, -1.0F, 0.0F);
        this.animator.move(this.leftThigh, 0.0F, 0.0F, 0.0F);
        this.animator.rotate(this.rightThigh, -2.0F, 0.2F, 0.0F);
        this.animator.rotate(this.leftThigh, 0.0F, -0.2F, 0.0F);
        this.animator.rotate(this.rightCalf, 2.0F, 0.0F, 0.0F);
        this.animator.rotate(this.leftCalf, 0.1F, 0.0F, 0.0F);
        this.animator.rotate(this.head, 1.5F, 0.0F, 0.0F);
        this.animator.rotate(this.topBody, -0.75F, 0.0F, 0.0F);
        this.animator.rotate(this.middleBody, -0.75F, 0.0F, 0.0F);
        this.animator.rotate(this.rightShoulder, 0.35F, 0.4F, 0.0F);
        this.animator.rotate(this.leftShoulder, 0.35F, -0.4F, 0.0F);
        this.animator.endPhase();
        this.animator.setStationaryPhase(5);
        this.animator.startPhase(5);
        this.animator.move(this.torso, 0.0F, 3.0F, 1.0F);
        this.animator.move(this.rightThigh, 0.0F, 1.0F, 0.0F);
        this.animator.move(this.leftThigh, 0.0F, 1.0F, 0.0F);
        this.animator.rotate(this.head, -1.0F, 0.0F, 0.0F);
        this.animator.rotate(this.topBody, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.middleBody, 0.25F, 0.0F, 0.0F);
        this.animator.rotate(this.torso, 0.25F, 0.0F, 0.0F);
        this.animator.rotate(this.rightShoulder, -0.9F, 0.0F, 0.75F);
        this.animator.rotate(this.leftShoulder, -0.9F, 0.0F, -0.75F);
        this.animator.rotate(this.rightForearm, -0.25F, 0.0F, -0.5F);
        this.animator.rotate(this.leftForearm, -0.25F, 0.0F, 0.5F);
        this.animator.rotate(this.heldItem, 2.0F, 0.0F, 2.0F);
        this.animator.endPhase();
        this.animator.resetPhase(20);
    }

    private void animateStomp() {
        this.animator.setAnimationID(6);
        this.animator.startPhase(25);
        this.animator.move(this.torso, 0.0F, 1.0F, 0.0F);
        this.animator.move(this.rightThigh, 0.0F, 1.0F, 0.0F);
        this.animator.move(this.leftThigh, 0.0F, 1.0F, 0.0F);
        this.animator.rotate(this.rightThigh, -0.25F, 0.0F, 0.0F);
        this.animator.rotate(this.leftThigh, -0.25F, 0.0F, 0.0F);
        this.animator.rotate(this.rightCalf, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.leftCalf, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.head, -1.0F, 0.0F, 0.0F);
        this.animator.rotate(this.topBody, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.middleBody, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.rightShoulder, 0.8F, 0.5F, 0.5F);
        this.animator.rotate(this.leftShoulder, 0.8F, -0.5F, -0.5F);
        this.animator.rotate(this.rightForearm, -1.6F, 0.0F, 0.0F);
        this.animator.rotate(this.leftForearm, -1.6F, 0.0F, 0.0F);
        this.animator.rotate(this.heldItem, 1.0F, 0.5F, 0.75F);
        this.animator.endPhase();
        this.animator.startPhase(25);
        this.animator.move(this.torso, 0.0F, 0.0F, 0.0F);
        this.animator.move(this.rightThigh, 0.0F, -2.0F, 0.0F);
        this.animator.move(this.leftThigh, 0.0F, 0.0F, 0.0F);
        this.animator.rotate(this.rightThigh, -2.0F, 0.2F, 0.75F);
        this.animator.rotate(this.leftThigh, 0.0F, 0.2F, 0.0F);
        this.animator.rotate(this.rightCalf, 1.5F, 0.0F, -0.5F);
        this.animator.rotate(this.leftCalf, 0.0F, 0.0F, 0.0F);
        this.animator.rotate(this.head, 1.0F, 0.0F, 0.5F);
        this.animator.rotate(this.topBody, -1.0F, 0.0F, 0.0F);
        this.animator.rotate(this.middleBody, -1.0F, 0.0F, 0.0F);
        this.animator.rotate(this.torso, 0.0F, 0.0F, 0.25F);
        this.animator.rotate(this.rightShoulder, -0.75F, 0.0F, -0.75F);
        this.animator.rotate(this.leftShoulder, -0.75F, 0.0F, 0.75F);
        this.animator.rotate(this.rightForearm, -0.3F, 0.0F, 0.0F);
        this.animator.rotate(this.leftForearm, -0.3F, 0.0F, 0.0F);
        this.animator.rotate(this.heldItem, 1.0F, 0.5F, 0.75F);
        this.animator.endPhase();
        this.animator.startPhase(20);
        this.animator.move(this.torso, 0.0F, 2.0F, 0.0F);
        this.animator.move(this.rightThigh, 0.0F, 2.0F, 0.0F);
        this.animator.move(this.leftThigh, 0.0F, 0.0F, 0.0F);
        this.animator.rotate(this.rightThigh, -0.5F, 0.5F, 0.0F);
        this.animator.rotate(this.leftThigh, 0.0F, 0.0F, 0.0F);
        this.animator.rotate(this.rightCalf, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.leftCalf, 0.1F, 0.0F, 0.0F);
        this.animator.rotate(this.head, 0.5F, 0.0F, 0.5F);
        this.animator.rotate(this.topBody, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.middleBody, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.torso, 0.0F, 0.0F, -0.4F);
        this.animator.rotate(this.rightShoulder, -0.75F, 0.0F, -0.75F);
        this.animator.rotate(this.leftShoulder, -0.75F, 0.0F, -0.75F);
        this.animator.rotate(this.rightForearm, -0.3F, 0.0F, 0.75F);
        this.animator.rotate(this.leftForearm, -0.3F, 0.0F, -0.75F);
        this.animator.endPhase();
        this.animator.setStationaryPhase(5);
        this.animator.startPhase(20);
        this.animator.move(this.torso, 0.0F, 0.0F, 0.0F);
        this.animator.move(this.rightThigh, 0.0F, 0.0F, 0.0F);
        this.animator.move(this.leftThigh, 0.0F, -2.0F, 0.0F);
        this.animator.rotate(this.rightThigh, 0.0F, 0.0F, 0.0F);
        this.animator.rotate(this.leftThigh, -2.0F, 0.0F, -0.75F);
        this.animator.rotate(this.rightCalf, 0.0F, 0.0F, 0.0F);
        this.animator.rotate(this.leftCalf, 1.5F, 0.0F, 0.5F);
        this.animator.rotate(this.head, 1.0F, 0.0F, -0.5F);
        this.animator.rotate(this.topBody, -1.0F, 0.0F, 0.0F);
        this.animator.rotate(this.middleBody, -1.0F, 0.0F, 0.0F);
        this.animator.rotate(this.torso, 0.0F, 0.0F, -0.25F);
        this.animator.rotate(this.rightShoulder, -0.75F, 0.0F, -0.75F);
        this.animator.rotate(this.leftShoulder, -0.75F, 0.0F, 0.75F);
        this.animator.rotate(this.rightForearm, -0.3F, 0.0F, 0.0F);
        this.animator.rotate(this.leftForearm, -0.3F, 0.0F, 0.0F);
        this.animator.rotate(this.heldItem, 1.0F, 0.5F, 0.75F);
        this.animator.endPhase();
        this.animator.startPhase(20);
        this.animator.move(this.torso, 0.0F, 2.0F, 0.0F);
        this.animator.move(this.rightThigh, 0.0F, 0.0F, 0.0F);
        this.animator.move(this.leftThigh, 0.0F, 2.0F, 0.0F);
        this.animator.rotate(this.rightThigh, 0.0F, 0.0F, 0.0F);
        this.animator.rotate(this.leftThigh, -0.5F, -0.5F, 0.0F);
        this.animator.rotate(this.rightCalf, 0.0F, 0.0F, 0.0F);
        this.animator.rotate(this.leftCalf, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.head, 0.5F, 0.0F, -0.5F);
        this.animator.rotate(this.topBody, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.middleBody, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.torso, 0.0F, 0.0F, 0.4F);
        this.animator.rotate(this.rightShoulder, -0.75F, 0.0F, 0.75F);
        this.animator.rotate(this.leftShoulder, -0.75F, 0.0F, 0.75F);
        this.animator.rotate(this.rightForearm, -0.3F, 0.0F, -0.75F);
        this.animator.rotate(this.leftForearm, -0.3F, 0.0F, 0.75F);
        this.animator.endPhase();
        this.animator.setStationaryPhase(20);
        this.animator.resetPhase(20);
    }

    private void animateDownwardSlash() {
        this.animator.setAnimationID(7);
        this.animator.startPhase(40);
        this.animator.move(this.torso, 0.0F, 1.0F, 0.0F);
        this.animator.move(this.rightThigh, 0.0F, 1.0F, 0.0F);
        this.animator.move(this.leftThigh, 0.0F, 1.0F, 0.0F);
        this.animator.rotate(this.rightThigh, -0.25F, 0.0F, 0.0F);
        this.animator.rotate(this.leftThigh, -0.25F, 0.0F, 0.0F);
        this.animator.rotate(this.rightCalf, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.leftCalf, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.head, -1.0F, -0.2F, 0.0F);
        this.animator.rotate(this.topBody, 0.5F, 0.1F, 0.0F);
        this.animator.rotate(this.middleBody, 0.5F, 0.1F, 0.0F);
        this.animator.rotate(this.rightShoulder, 1.0F, 0.0F, 0.75F);
        this.animator.rotate(this.leftShoulder, 0.8F, 0.0F, 0.0F);
        this.animator.rotate(this.rightForearm, -1.0F, 0.0F, 0.0F);
        this.animator.rotate(this.leftForearm, -1.6F, 0.0F, 0.0F);
        this.animator.rotate(this.heldItem, 1.0F, 0.0F, 0.0F);
        this.animator.endPhase();
        this.animator.startPhase(40);
        this.animator.move(this.torso, 0.0F, 2.0F, 5.0F);
        this.animator.move(this.rightThigh, 0.0F, 2.0F, 5.5F);
        this.animator.move(this.leftThigh, 0.0F, 2.0F, 5.5F);
        this.animator.rotate(this.rightThigh, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.leftThigh, -0.65F, 0.0F, 0.0F);
        this.animator.rotate(this.rightCalf, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.leftCalf, 0.65F, 0.0F, 0.0F);
        this.animator.rotate(this.head, 1.0F, -1.0F, 0.0F);
        this.animator.rotate(this.topBody, -0.5F, 0.5F, 0.0F);
        this.animator.rotate(this.middleBody, -0.5F, 0.5F, 0.0F);
        this.animator.rotate(this.torso, -0.5F, 0.5F, 0.0F);
        this.animator.rotate(this.rightShoulder, -1.5F, 0.0F, -0.75F);
        this.animator.rotate(this.leftShoulder, 0.0F, -1.5F, 0.0F);
        this.animator.rotate(this.rightForearm, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.leftForearm, 0.0F, 0.0F, 0.75F);
        this.animator.rotate(this.heldItem, 0.5F, 0.0F, 0.0F);
        this.animator.endPhase();
        this.animator.startPhase(50);
        this.animator.move(this.torso, 0.0F, 1.0F, -5.0F);
        this.animator.move(this.rightThigh, 0.0F, 1.0F, -5.5F);
        this.animator.move(this.leftThigh, 0.0F, 1.0F, -5.5F);
        this.animator.rotate(this.rightThigh, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.leftThigh, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.rightCalf, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.leftCalf, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.head, -1.0F, 1.0F, 0.0F);
        this.animator.rotate(this.topBody, 0.5F, -0.25F, 0.0F);
        this.animator.rotate(this.middleBody, 0.5F, -0.25F, 0.0F);
        this.animator.rotate(this.torso, 0.5F, -0.25F, 0.0F);
        this.animator.rotate(this.rightShoulder, -0.75F, 0.0F, -0.75F);
        this.animator.rotate(this.leftShoulder, 1.0F, 0.0F, -0.5F);
        this.animator.rotate(this.rightForearm, -0.25F, 0.0F, 0.0F);
        this.animator.rotate(this.leftForearm, 0.0F, 0.0F, 0.0F);
        this.animator.rotate(this.heldItem, 1.5F, 0.0F, 0.0F);
        this.animator.endPhase();
        this.animator.setStationaryPhase(20);
        this.animator.startPhase(20);
        this.animator.move(this.torso, 0.0F, 1.0F, -5.0F);
        this.animator.move(this.rightThigh, 0.0F, 1.0F, -5.5F);
        this.animator.move(this.leftThigh, 0.0F, 1.0F, -5.5F);
        this.animator.rotate(this.rightThigh, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.leftThigh, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.rightCalf, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.leftCalf, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.head, -1.5F, 0.0F, 0.0F);
        this.animator.rotate(this.topBody, 0.5F, -0.25F, 0.0F);
        this.animator.rotate(this.middleBody, 0.5F, -0.25F, 0.0F);
        this.animator.rotate(this.torso, 0.5F, -0.25F, 0.0F);
        this.animator.rotate(this.rightShoulder, -0.55F, 0.0F, -0.75F);
        this.animator.rotate(this.leftShoulder, 1.0F, 0.0F, 0.0F);
        this.animator.rotate(this.rightForearm, -0.25F, 0.0F, 0.0F);
        this.animator.rotate(this.leftForearm, 0.0F, 0.0F, 0.0F);
        this.animator.rotate(this.heldItem, 1.5F, -1.5F, 0.0F);
        this.animator.endPhase();
        this.animator.startPhase(40);
        this.animator.move(this.torso, 0.0F, 2.0F, 5.0F);
        this.animator.move(this.rightThigh, 0.0F, 2.0F, 5.5F);
        this.animator.move(this.leftThigh, 0.0F, 2.0F, 5.5F);
        this.animator.rotate(this.rightThigh, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.leftThigh, -0.65F, 0.0F, 0.0F);
        this.animator.rotate(this.rightCalf, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.leftCalf, 0.65F, 0.0F, 0.0F);
        this.animator.rotate(this.head, 0.0F, 0.0F, 0.0F);
        this.animator.rotate(this.topBody, 0.25F, 0.0F, 0.0F);
        this.animator.rotate(this.middleBody, 0.25F, 0.0F, 0.0F);
        this.animator.rotate(this.torso, 0.25F, 0.0F, 0.0F);
        this.animator.rotate(this.rightShoulder, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.leftShoulder, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.rightForearm, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.leftForearm, 0.0F, 0.0F, 0.0F);
        this.animator.rotate(this.heldItem, 2.0F, 0.0F, 0.0F);
        this.animator.endPhase();
        this.animator.resetPhase(20);
    }

    private void animateStun() {
        this.animator.setAnimationID(8);
        this.animator.startPhase(0);
        this.animator.move(this.torso, 0.0F, 1.0F, -3.0F);
        this.animator.move(this.rightThigh, 0.0F, 1.0F, -2.5F);
        this.animator.move(this.leftThigh, 0.0F, 1.0F, -3.5F);
        this.animator.rotate(this.rightThigh, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.leftThigh, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.rightCalf, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.leftCalf, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.head, 1.0F, -0.5F, 0.0F);
        this.animator.rotate(this.topBody, 0.5F, -0.25F, 0.0F);
        this.animator.rotate(this.middleBody, 0.5F, -0.25F, 0.0F);
        this.animator.rotate(this.torso, 0.5F, -0.25F, 0.0F);
        this.animator.rotate(this.rightShoulder, -0.75F, 0.0F, -0.5F);
        this.animator.rotate(this.leftShoulder, 1.0F, 0.0F, 0.0F);
        this.animator.rotate(this.rightForearm, -0.25F, 0.0F, 0.0F);
        this.animator.rotate(this.leftForearm, 0.0F, 0.0F, 0.0F);
        this.animator.rotate(this.heldItem, 1.75F, 0.0F, 0.0F);
        this.animator.endPhase();
        this.animator.startPhase(40);
        this.animator.move(this.torso, 0.0F, 1.0F, -5.0F);
        this.animator.move(this.rightThigh, 0.0F, 1.0F, -5.5F);
        this.animator.move(this.leftThigh, 0.0F, 1.0F, -5.5F);
        this.animator.rotate(this.rightThigh, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.leftThigh, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.rightCalf, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.leftCalf, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.head, -1.5F, 1.0F, 0.0F);
        this.animator.rotate(this.topBody, 0.5F, -0.25F, 0.0F);
        this.animator.rotate(this.middleBody, 0.5F, -0.25F, 0.0F);
        this.animator.rotate(this.torso, 0.5F, -0.25F, 0.0F);
        this.animator.rotate(this.rightShoulder, -0.75F, 0.0F, -0.75F);
        this.animator.rotate(this.leftShoulder, 1.0F, 0.0F, -0.5F);
        this.animator.rotate(this.rightForearm, -0.25F, 0.0F, 0.0F);
        this.animator.rotate(this.leftForearm, 0.0F, 0.0F, 0.0F);
        this.animator.rotate(this.heldItem, 1.75F, 0.0F, 0.0F);
        this.animator.endPhase();
        this.animator.startPhase(10);
        this.animator.move(this.torso, 0.0F, 1.0F, -5.0F);
        this.animator.move(this.rightThigh, 0.0F, 1.0F, -5.5F);
        this.animator.move(this.leftThigh, 0.0F, 1.0F, -5.5F);
        this.animator.rotate(this.rightThigh, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.leftThigh, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.rightCalf, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.leftCalf, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.head, -2.0F, 0.0F, 0.0F);
        this.animator.rotate(this.topBody, 0.5F, -0.25F, 0.0F);
        this.animator.rotate(this.middleBody, 0.5F, -0.25F, 0.0F);
        this.animator.rotate(this.torso, 0.5F, -0.25F, 0.0F);
        this.animator.rotate(this.rightShoulder, -0.55F, 0.0F, -0.75F);
        this.animator.rotate(this.leftShoulder, 1.0F, 0.0F, 0.0F);
        this.animator.rotate(this.rightForearm, -0.25F, 0.0F, 0.0F);
        this.animator.rotate(this.leftForearm, 0.0F, 0.0F, 0.0F);
        this.animator.rotate(this.heldItem, 1.75F, 0.0F, 0.0F);
        this.animator.endPhase();
        this.animator.startPhase(10);
        this.animator.move(this.torso, 0.0F, 1.0F, -5.0F);
        this.animator.move(this.rightThigh, 0.0F, 1.0F, -5.5F);
        this.animator.move(this.leftThigh, 0.0F, 1.0F, -5.5F);
        this.animator.rotate(this.rightThigh, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.leftThigh, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.rightCalf, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.leftCalf, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.head, -1.0F, 0.0F, 0.0F);
        this.animator.rotate(this.topBody, 0.5F, -0.25F, 0.0F);
        this.animator.rotate(this.middleBody, 0.5F, -0.25F, 0.0F);
        this.animator.rotate(this.torso, 0.5F, -0.25F, 0.0F);
        this.animator.rotate(this.rightShoulder, -0.55F, 0.0F, -0.75F);
        this.animator.rotate(this.leftShoulder, 1.0F, 0.0F, 0.0F);
        this.animator.rotate(this.rightForearm, -0.25F, 0.0F, 0.0F);
        this.animator.rotate(this.leftForearm, 0.0F, 0.0F, 0.0F);
        this.animator.rotate(this.heldItem, 1.75F, 0.0F, 0.0F);
        this.animator.endPhase();
        this.animator.startPhase(10);
        this.animator.move(this.torso, 0.0F, 1.0F, -5.0F);
        this.animator.move(this.rightThigh, 0.0F, 1.0F, -5.5F);
        this.animator.move(this.leftThigh, 0.0F, 1.0F, -5.5F);
        this.animator.rotate(this.rightThigh, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.leftThigh, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.rightCalf, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.leftCalf, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.head, -2.0F, 0.0F, 0.0F);
        this.animator.rotate(this.topBody, 0.5F, -0.25F, 0.0F);
        this.animator.rotate(this.middleBody, 0.5F, -0.25F, 0.0F);
        this.animator.rotate(this.torso, 0.5F, -0.25F, 0.0F);
        this.animator.rotate(this.rightShoulder, -0.55F, 0.0F, -0.75F);
        this.animator.rotate(this.leftShoulder, 1.0F, 0.0F, 0.0F);
        this.animator.rotate(this.rightForearm, -0.25F, 0.0F, 0.0F);
        this.animator.rotate(this.leftForearm, 0.0F, 0.0F, 0.0F);
        this.animator.rotate(this.heldItem, 1.75F, 0.0F, 0.0F);
        this.animator.endPhase();
        this.animator.startPhase(10);
        this.animator.move(this.torso, 0.0F, 1.0F, -5.0F);
        this.animator.move(this.rightThigh, 0.0F, 1.0F, -5.5F);
        this.animator.move(this.leftThigh, 0.0F, 1.0F, -5.5F);
        this.animator.rotate(this.rightThigh, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.leftThigh, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.rightCalf, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.leftCalf, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.head, -1.0F, 0.0F, 0.0F);
        this.animator.rotate(this.topBody, 0.5F, -0.25F, 0.0F);
        this.animator.rotate(this.middleBody, 0.5F, -0.25F, 0.0F);
        this.animator.rotate(this.torso, 0.5F, -0.25F, 0.0F);
        this.animator.rotate(this.rightShoulder, -0.55F, 0.0F, -0.75F);
        this.animator.rotate(this.leftShoulder, 1.0F, 0.0F, 0.0F);
        this.animator.rotate(this.rightForearm, -0.25F, 0.0F, 0.0F);
        this.animator.rotate(this.leftForearm, 0.0F, 0.0F, 0.0F);
        this.animator.rotate(this.heldItem, 1.75F, 0.0F, 0.0F);
        this.animator.endPhase();
        this.animator.startPhase(10);
        this.animator.move(this.torso, 0.0F, 1.0F, -5.0F);
        this.animator.move(this.rightThigh, 0.0F, 1.0F, -5.5F);
        this.animator.move(this.leftThigh, 0.0F, 1.0F, -5.5F);
        this.animator.rotate(this.rightThigh, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.leftThigh, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.rightCalf, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.leftCalf, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.head, -2.0F, 0.0F, 0.0F);
        this.animator.rotate(this.topBody, 0.5F, -0.25F, 0.0F);
        this.animator.rotate(this.middleBody, 0.5F, -0.25F, 0.0F);
        this.animator.rotate(this.torso, 0.5F, -0.25F, 0.0F);
        this.animator.rotate(this.rightShoulder, -0.55F, 0.0F, -0.75F);
        this.animator.rotate(this.leftShoulder, 1.0F, 0.0F, 0.0F);
        this.animator.rotate(this.rightForearm, -0.25F, 0.0F, 0.0F);
        this.animator.rotate(this.leftForearm, 0.0F, 0.0F, 0.0F);
        this.animator.rotate(this.heldItem, 1.75F, 0.0F, 0.0F);
        this.animator.endPhase();
        this.animator.startPhase(10);
        this.animator.move(this.torso, 0.0F, 1.0F, -5.0F);
        this.animator.move(this.rightThigh, 0.0F, 1.0F, -5.5F);
        this.animator.move(this.leftThigh, 0.0F, 1.0F, -5.5F);
        this.animator.rotate(this.rightThigh, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.leftThigh, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.rightCalf, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.leftCalf, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.head, -1.5F, 0.0F, 0.0F);
        this.animator.rotate(this.topBody, 0.5F, -0.25F, 0.0F);
        this.animator.rotate(this.middleBody, 0.5F, -0.25F, 0.0F);
        this.animator.rotate(this.torso, 0.5F, -0.25F, 0.0F);
        this.animator.rotate(this.rightShoulder, -0.55F, 0.0F, -0.75F);
        this.animator.rotate(this.leftShoulder, 1.0F, 0.0F, 0.0F);
        this.animator.rotate(this.rightForearm, -0.25F, 0.0F, 0.0F);
        this.animator.rotate(this.leftForearm, 0.0F, 0.0F, 0.0F);
        this.animator.rotate(this.heldItem, 1.75F, 0.0F, 0.0F);
        this.animator.endPhase();
        this.animator.setStationaryPhase(40);
        this.animator.startPhase(10);
        this.animator.move(this.torso, 0.0F, 0.0F, 0.0F);
        this.animator.move(this.rightThigh, 0.0F, 0.0F, 0.0F);
        this.animator.move(this.leftThigh, 0.0F, 0.0F, 0.0F);
        this.animator.rotate(this.rightThigh, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.leftThigh, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.rightCalf, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.leftCalf, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.head, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.topBody, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.middleBody, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.rightShoulder, -0.75F, 0.0F, 0.75F);
        this.animator.rotate(this.leftShoulder, -0.25F, 0.0F, 0.0F);
        this.animator.rotate(this.rightForearm, -0.25F, 0.0F, 0.0F);
        this.animator.rotate(this.leftForearm, 0.0F, 0.0F, 0.0F);
        this.animator.rotate(this.heldItem, -0.5F, 0.0F, 0.0F);
        this.animator.endPhase();
        this.animator.setStationaryPhase(160);
        this.animator.startPhase(40);
        this.animator.rotate(this.rightThigh, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.leftThigh, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.rightCalf, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.leftCalf, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.head, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.topBody, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.middleBody, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.rightShoulder, -0.75F, 0.0F, 0.75F);
        this.animator.rotate(this.leftShoulder, -0.75F, 0.0F, -0.75F);
        this.animator.rotate(this.rightForearm, -0.25F, 0.0F, 0.0F);
        this.animator.rotate(this.leftForearm, 0.0F, 0.0F, 0.0F);
        this.animator.rotate(this.heldItem, -0.5F, 0.0F, 0.0F);
        this.animator.endPhase();
        this.animator.startPhase(10);
        this.animator.move(this.torso, 0.0F, 0.0F, 0.0F);
        this.animator.move(this.rightThigh, 0.0F, 0.0F, 0.0F);
        this.animator.move(this.leftThigh, 0.0F, 0.0F, 0.0F);
        this.animator.rotate(this.rightThigh, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.leftThigh, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.rightCalf, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.leftCalf, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.head, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.topBody, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.middleBody, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.rightShoulder, 1.5F, -0.75F, 0.0F);
        this.animator.rotate(this.leftShoulder, 1.5F, 0.75F, 0.0F);
        this.animator.rotate(this.heldItem, 0.0F, 0.0F, 0.0F);
        this.animator.endPhase();
        this.animator.startPhase(40);
        this.animator.move(this.torso, 0.0F, 1.0F, 0.0F);
        this.animator.move(this.rightThigh, 0.0F, 1.0F, 0.0F);
        this.animator.move(this.leftThigh, 0.0F, 1.0F, 0.0F);
        this.animator.rotate(this.rightThigh, -0.25F, 0.0F, 0.0F);
        this.animator.rotate(this.leftThigh, -0.25F, 0.0F, 0.0F);
        this.animator.rotate(this.rightCalf, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.leftCalf, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.head, -1.0F, 0.0F, 0.0F);
        this.animator.rotate(this.topBody, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.middleBody, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.rightShoulder, 0.8F, 0.5F, 0.5F);
        this.animator.rotate(this.leftShoulder, 0.8F, -0.5F, -0.5F);
        this.animator.rotate(this.rightForearm, -1.6F, 0.0F, 0.0F);
        this.animator.rotate(this.leftForearm, -1.6F, 0.0F, 0.0F);
        this.animator.rotate(this.heldItem, 0.0F, 0.0F, 0.75F);
        this.animator.endPhase();
        this.animator.startPhase(30);
        this.animator.move(this.torso, 0.0F, 2.0F, 0.0F);
        this.animator.move(this.rightThigh, 0.0F, 2.0F, 0.0F);
        this.animator.move(this.leftThigh, 0.0F, 2.0F, 0.0F);
        this.animator.rotate(this.rightThigh, -0.25F, 0.25F, 0.25F);
        this.animator.rotate(this.leftThigh, -0.25F, -0.25F, -0.25F);
        this.animator.rotate(this.rightCalf, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.leftCalf, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.head, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.topBody, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.middleBody, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.rightShoulder, 0.25F, 1.0F, 0.0F);
        this.animator.rotate(this.leftShoulder, 0.25F, -1.0F, 0.0F);
        this.animator.endPhase();
        this.animator.setStationaryPhase(60);
        this.animator.resetPhase(20);
    }

    private void animateSidewaySlash() {
        this.animator.setAnimationID(9);
        this.animator.startPhase(40);
        this.animator.move(this.torso, 0.0F, 1.0F, 0.0F);
        this.animator.move(this.rightThigh, 0.0F, 1.0F, 0.0F);
        this.animator.move(this.leftThigh, 0.0F, 1.0F, 0.0F);
        this.animator.rotate(this.rightThigh, -0.25F, 0.0F, 0.0F);
        this.animator.rotate(this.leftThigh, -0.25F, 0.0F, 0.0F);
        this.animator.rotate(this.rightCalf, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.leftCalf, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.topBody, 0.5F, 0.1F, 0.0F);
        this.animator.rotate(this.middleBody, 0.5F, 0.1F, 0.0F);
        this.animator.rotate(this.rightShoulder, 1.0F, 0.0F, 0.75F);
        this.animator.rotate(this.leftShoulder, 0.8F, 0.0F, 0.0F);
        this.animator.rotate(this.rightForearm, -1.0F, 0.0F, 0.0F);
        this.animator.rotate(this.leftForearm, -1.6F, 0.0F, 0.0F);
        this.animator.rotate(this.heldItem, 1.0F, 0.0F, 0.0F);
        this.animator.endPhase();
        this.animator.startPhase(40);
        this.animator.move(this.torso, 0.0F, 2.0F, 5.0F);
        this.animator.move(this.rightThigh, 0.0F, 2.0F, 5.5F);
        this.animator.move(this.leftThigh, 0.0F, 2.0F, 5.5F);
        this.animator.rotate(this.rightThigh, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.leftThigh, -0.65F, 0.0F, 0.0F);
        this.animator.rotate(this.rightCalf, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.leftCalf, 0.65F, 0.0F, 0.0F);
        this.animator.rotate(this.topBody, -0.25F, 0.5F, -0.5F);
        this.animator.rotate(this.middleBody, -0.25F, 0.5F, -0.5F);
        this.animator.rotate(this.torso, -0.25F, 0.5F, -0.5F);
        this.animator.rotate(this.rightShoulder, -1.5F, 0.0F, -1.0F);
        this.animator.rotate(this.leftShoulder, 0.0F, -1.5F, 0.0F);
        this.animator.rotate(this.rightForearm, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.leftForearm, 0.0F, 0.0F, 0.75F);
        this.animator.rotate(this.heldItem, 0.5F, 0.0F, 0.0F);
        this.animator.endPhase();
        this.animator.startPhase(40);
        this.animator.move(this.torso, 0.0F, 1.0F, -5.0F);
        this.animator.move(this.rightThigh, 0.0F, 1.0F, -5.5F);
        this.animator.move(this.leftThigh, 0.0F, 1.0F, -5.5F);
        this.animator.rotate(this.rightThigh, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.leftThigh, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.rightCalf, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.leftCalf, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.topBody, 0.5F, -0.25F, -0.25F);
        this.animator.rotate(this.middleBody, 0.5F, -0.25F, -0.25F);
        this.animator.rotate(this.torso, 1.0F, -0.25F, -0.5F);
        this.animator.rotate(this.rightShoulder, -1.0F, 0.0F, -1.0F);
        this.animator.rotate(this.leftShoulder, 1.0F, 0.0F, -0.5F);
        this.animator.rotate(this.rightForearm, 0.5F, 0.0F, -0.75F);
        this.animator.rotate(this.leftForearm, 0.0F, 0.0F, 0.0F);
        this.animator.rotate(this.heldItem, 2.0F, 0.0F, -0.5F);
        this.animator.endPhase();
        this.animator.resetPhase(40);
    }

    private void animateDeath() {
        this.animator.setAnimationID(10);
        this.animator.startPhase(40);
        this.animator.move(this.torso, 0.0F, 2.0F, 4.0F);
        this.animator.move(this.rightThigh, 0.0F, 2.0F, 4.0F);
        this.animator.move(this.leftThigh, 0.0F, 2.0F, 4.0F);
        this.animator.rotate(this.rightThigh, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.leftThigh, -0.65F, 0.0F, 0.0F);
        this.animator.rotate(this.rightCalf, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.leftCalf, 0.65F, 0.0F, 0.0F);
        this.animator.rotate(this.head, 1.0F, 0.0F, 0.0F);
        this.animator.rotate(this.topBody, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.middleBody, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.torso, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.rightShoulder, -0.5F, 0.5F, 0.5F);
        this.animator.rotate(this.leftShoulder, -0.5F, -0.5F, -0.5F);
        this.animator.rotate(this.rightForearm, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.leftForearm, -0.5F, 0.0F, 0.0F);
        this.animator.endPhase();
        this.animator.startPhase(40);
        this.animator.move(this.torso, 0.0F, 2.0F, 8.0F);
        this.animator.move(this.rightThigh, 0.0F, 2.0F, 8.0F);
        this.animator.move(this.leftThigh, 0.0F, 2.0F, 8.0F);
        this.animator.rotate(this.rightThigh, -0.65F, 0.0F, 0.0F);
        this.animator.rotate(this.leftThigh, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.rightCalf, 0.65F, 0.0F, 0.0F);
        this.animator.rotate(this.leftCalf, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.head, 1.0F, 0.0F, 0.0F);
        this.animator.rotate(this.topBody, 0.6F, 0.0F, 0.0F);
        this.animator.rotate(this.middleBody, 0.6F, 0.0F, 0.0F);
        this.animator.rotate(this.torso, 0.6F, 0.0F, 0.0F);
        this.animator.rotate(this.rightShoulder, -0.5F, 0.5F, 0.5F);
        this.animator.rotate(this.leftShoulder, -0.5F, -0.5F, -0.5F);
        this.animator.rotate(this.rightForearm, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.leftForearm, -0.5F, 0.0F, 0.0F);
        this.animator.endPhase();
        this.animator.startPhase(40);
        this.animator.move(this.torso, 0.0F, 2.0F, 9.0F);
        this.animator.move(this.rightThigh, 0.0F, 2.0F, 9.0F);
        this.animator.move(this.leftThigh, 0.0F, 2.0F, 9.0F);
        this.animator.rotate(this.rightThigh, -0.65F, 0.0F, 0.0F);
        this.animator.rotate(this.leftThigh, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.rightCalf, 0.65F, 0.0F, 0.0F);
        this.animator.rotate(this.leftCalf, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.head, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.topBody, -0.25F, 0.0F, 0.0F);
        this.animator.rotate(this.middleBody, -0.25F, 0.0F, 0.0F);
        this.animator.rotate(this.torso, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.rightShoulder, 0.35F, 0.4F, 0.0F);
        this.animator.rotate(this.leftShoulder, 0.35F, -0.4F, 0.0F);
        this.animator.rotate(this.rightForearm, 0.25F, 0.0F, 0.0F);
        this.animator.rotate(this.leftForearm, 0.25F, 0.0F, 0.0F);
        this.animator.rotate(this.heldItem, 2.0F, 0.0F, 0.0F);
        this.animator.endPhase();
        this.animator.startPhase(80);
        this.animator.move(this.torso, 0.0F, 10.0F, 1.0F);
        this.animator.move(this.rightThigh, 0.0F, 10.0F, 0.0F);
        this.animator.move(this.leftThigh, 0.0F, 10.0F, 0.0F);
        this.animator.rotate(this.rightThigh, 1.4F, -0.5F, 0.0F);
        this.animator.rotate(this.leftThigh, 1.4F, 0.5F, 0.0F);
        this.animator.rotate(this.rightCalf, 1.0F, 0.0F, 0.0F);
        this.animator.rotate(this.leftCalf, 1.0F, 0.0F, 0.0F);
        this.animator.rotate(this.head, 0.0F, 0.9F, 0.0F);
        this.animator.rotate(this.topBody, -0.25F, 0.0F, 0.0F);
        this.animator.rotate(this.middleBody, -0.25F, 0.0F, 0.0F);
        this.animator.rotate(this.torso, 1.75F, 0.0F, 0.0F);
        this.animator.rotate(this.rightShoulder, -1.5F, 0.0F, -0.5F);
        this.animator.rotate(this.leftShoulder, -1.5F, 0.0F, 0.5F);
        this.animator.rotate(this.rightForearm, -0.25F, 0.0F, 0.0F);
        this.animator.rotate(this.leftForearm, -0.25F, 0.0F, 0.0F);
        this.animator.move(this.heldItem, 0.0F, 0.0F, 30.0F);
        this.animator.endPhase();
        this.animator.startPhase(100);
        this.animator.move(this.torso, 0.0F, 10.0F, 1.0F);
        this.animator.move(this.rightThigh, 0.0F, 10.0F, 0.0F);
        this.animator.move(this.leftThigh, 0.0F, 10.0F, 0.0F);
        this.animator.rotate(this.rightThigh, 1.6F, -0.5F, 0.0F);
        this.animator.rotate(this.leftThigh, 1.6F, 0.5F, 0.0F);
        this.animator.rotate(this.rightCalf, 0.0F, 0.0F, 0.0F);
        this.animator.rotate(this.leftCalf, 0.0F, 0.0F, 0.0F);
        this.animator.rotate(this.head, 0.0F, 0.9F, 0.0F);
        this.animator.rotate(this.topBody, -0.2F, 0.0F, 0.0F);
        this.animator.rotate(this.middleBody, -0.2F, 0.0F, 0.0F);
        this.animator.rotate(this.torso, 1.75F, 0.0F, 0.0F);
        this.animator.rotate(this.rightShoulder, -1.3F, 0.0F, -0.5F);
        this.animator.rotate(this.leftShoulder, -1.3F, 0.0F, 0.5F);
        this.animator.rotate(this.rightForearm, 0.0F, 0.0F, 0.0F);
        this.animator.rotate(this.leftForearm, 0.0F, 0.0F, 0.0F);
        this.animator.move(this.heldItem, 0.0F, 0.0F, 30.0F);
        this.animator.endPhase();
        this.animator.setStationaryPhase(1700);
        this.animator.resetPhase(0);
    }

    private void animateRoar() {
        this.animator.setAnimationID(11);
        this.animator.startPhase(10);
        this.animator.move(this.torso, 0.0F, 1.0F, 0.0F);
        this.animator.move(this.rightThigh, 0.0F, 1.0F, 0.0F);
        this.animator.move(this.leftThigh, 0.0F, 1.0F, 0.0F);
        this.animator.rotate(this.rightThigh, -0.25F, 0.0F, 0.0F);
        this.animator.rotate(this.leftThigh, -0.25F, 0.0F, 0.0F);
        this.animator.rotate(this.rightCalf, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.leftCalf, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.head, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.topBody, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.middleBody, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.rightShoulder, 0.8F, 0.5F, 0.5F);
        this.animator.rotate(this.leftShoulder, 0.8F, -0.5F, -0.5F);
        this.animator.rotate(this.rightForearm, -1.6F, 0.0F, -0.75F);
        this.animator.rotate(this.leftForearm, -1.6F, 0.0F, 0.75F);
        this.animator.rotate(this.heldItem, 0.0F, 0.0F, 0.75F);
        this.animator.endPhase();
        this.animator.startPhase(5);
        this.animator.move(this.torso, 0.0F, 2.0F, 0.0F);
        this.animator.move(this.rightThigh, 0.0F, 2.0F, 0.0F);
        this.animator.move(this.leftThigh, 0.0F, 2.0F, 0.0F);
        this.animator.rotate(this.rightThigh, -0.25F, 0.25F, 0.25F);
        this.animator.rotate(this.leftThigh, -0.25F, -0.25F, -0.25F);
        this.animator.rotate(this.rightCalf, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.leftCalf, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.head, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.topBody, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.middleBody, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.rightShoulder, 0.25F, 1.0F, 0.0F);
        this.animator.rotate(this.leftShoulder, 0.25F, -1.0F, 0.0F);
        this.animator.rotate(this.rightForearm, 0.0F, -1.0F, 0.0F);
        this.animator.rotate(this.leftForearm, 0.0F, 1.0F, 0.0F);
        this.animator.endPhase();
        this.animator.startPhase(5);
        this.animator.move(this.torso, 0.0F, 2.0F, 0.0F);
        this.animator.move(this.rightThigh, 0.0F, 2.0F, 0.0F);
        this.animator.move(this.leftThigh, 0.0F, 2.0F, 0.0F);
        this.animator.rotate(this.rightThigh, -0.25F, 0.25F, 0.25F);
        this.animator.rotate(this.leftThigh, -0.25F, -0.25F, -0.25F);
        this.animator.rotate(this.rightCalf, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.leftCalf, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.head, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.topBody, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.middleBody, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.rightShoulder, 0.25F, 1.0F, 0.0F);
        this.animator.rotate(this.leftShoulder, 0.25F, -1.0F, 0.0F);
        this.animator.endPhase();
        this.animator.setStationaryPhase(140);
        this.animator.resetPhase(40);
    }

    private void animateRangedAttackThrow() {
        this.animator.setAnimationID(12);
        this.animator.startPhase(25);
        this.animator.move(this.torso, 0.0F, 1.0F, 0.0F);
        this.animator.move(this.rightThigh, 0.0F, 1.0F, 0.0F);
        this.animator.move(this.leftThigh, 0.0F, 1.0F, 0.0F);
        this.animator.rotate(this.rightThigh, -0.25F, 0.0F, 0.0F);
        this.animator.rotate(this.leftThigh, -0.25F, 0.0F, 0.0F);
        this.animator.rotate(this.rightCalf, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.leftCalf, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.head, -1.0F, 0.0F, 0.0F);
        this.animator.rotate(this.topBody, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.middleBody, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.rightShoulder, 0.8F, 0.5F, 0.5F);
        this.animator.rotate(this.leftShoulder, 0.8F, -0.5F, -0.5F);
        this.animator.rotate(this.rightForearm, -1.6F, 0.0F, 0.0F);
        this.animator.rotate(this.leftForearm, -1.6F, 0.0F, 0.0F);
        this.animator.rotate(this.heldItem, 4.0F, 0.0F, 0.0F);
        this.animator.endPhase();
        this.animator.startPhase(25);
        this.animator.move(this.torso, 0.0F, 2.0F, 5.0F);
        this.animator.move(this.rightThigh, 0.0F, 2.0F, 5.5F);
        this.animator.move(this.leftThigh, 0.0F, 2.0F, 5.5F);
        this.animator.rotate(this.rightThigh, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.leftThigh, -0.65F, 0.0F, 0.0F);
        this.animator.rotate(this.rightCalf, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.leftCalf, 0.65F, 0.0F, 0.0F);
        this.animator.rotate(this.head, -0.5F, -1.5F, 0.0F);
        this.animator.rotate(this.topBody, 0.5F, 0.75F, 0.0F);
        this.animator.rotate(this.middleBody, 0.5F, 0.75F, 0.0F);
        this.animator.rotate(this.rightShoulder, -0.5F, 0.0F, 0.8F);
        this.animator.rotate(this.leftShoulder, -0.5F, 0.0F, -0.8F);
        this.animator.rotate(this.rightForearm, -0.25F, 0.0F, -0.8F);
        this.animator.rotate(this.leftForearm, -0.25F, 0.0F, 0.8F);
        this.animator.rotate(this.heldItem, 4.0F, 0.0F, 0.0F);
        this.animator.endPhase();
        this.animator.startPhase(20);
        this.animator.move(this.torso, 0.0F, 1.0F, -5.0F);
        this.animator.move(this.rightThigh, 0.0F, 1.0F, -5.5F);
        this.animator.move(this.leftThigh, 0.0F, 1.0F, -5.5F);
        this.animator.rotate(this.rightThigh, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.leftThigh, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.rightCalf, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.leftCalf, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.topBody, 0.25F, 0.0F, 0.0F);
        this.animator.rotate(this.middleBody, 0.25F, 0.0F, 0.0F);
        this.animator.rotate(this.torso, -0.75F, 0.0F, 0.0F);
        this.animator.rotate(this.rightShoulder, -0.25F, 0.0F, 0.0F);
        this.animator.rotate(this.leftShoulder, -0.25F, 0.0F, 0.0F);
        this.animator.rotate(this.rightForearm, -0.75F, 0.0F, 0.0F);
        this.animator.rotate(this.leftForearm, -0.75F, 0.0F, 0.0F);
        this.animator.rotate(this.heldItem, 4.0F, 0.0F, 0.0F);
        this.animator.endPhase();
        this.animator.setStationaryPhase(20);
        this.animator.resetPhase(20);
    }

    private void animateBirth() {
        this.animator.setAnimationID(13);
        this.animator.startPhase(0);
        this.animator.move(this.torso, 0.0F, 11.0F, 0.0F);
        this.animator.move(this.rightThigh, 0.0F, 10.0F, 0.0F);
        this.animator.move(this.leftThigh, 0.0F, 10.0F, 0.0F);
        this.animator.rotate(this.rightThigh, -1.4F, 1.25F, 0.0F);
        this.animator.rotate(this.leftThigh, -1.4F, -1.25F, 0.0F);
        this.animator.rotate(this.rightCalf, 1.0F, 0.0F, 0.0F);
        this.animator.rotate(this.leftCalf, 1.0F, 0.0F, 0.0F);
        this.animator.rotate(this.head, 0.6F, 0.0F, 0.0F);
        this.animator.rotate(this.topBody, 0.3F, 0.0F, 0.0F);
        this.animator.rotate(this.middleBody, 0.3F, 0.0F, 0.0F);
        this.animator.rotate(this.torso, 0.3F, 0.0F, 0.0F);
        this.animator.rotate(this.rightShoulder, -0.75F, 0.75F, -0.75F);
        this.animator.rotate(this.leftShoulder, 0.0F, -0.75F, 0.75F);
        this.animator.rotate(this.rightForearm, -0.25F, 0.0F, 0.0F);
        this.animator.rotate(this.leftForearm, 0.75F, 0.0F, 0.0F);
        this.animator.rotate(this.heldItem, 3.0F, 0.25F, -0.5F);
        this.animator.endPhase();
        this.animator.setStationaryPhase(60);
        this.animator.startPhase(40);
        this.animator.move(this.torso, 0.0F, 11.0F, 0.0F);
        this.animator.move(this.rightThigh, 0.0F, 10.0F, 0.0F);
        this.animator.move(this.leftThigh, 0.0F, 10.0F, 0.0F);
        this.animator.rotate(this.rightThigh, -1.4F, 1.25F, 0.0F);
        this.animator.rotate(this.leftThigh, -1.4F, -1.25F, 0.0F);
        this.animator.rotate(this.rightCalf, 1.0F, 0.0F, 0.0F);
        this.animator.rotate(this.leftCalf, 1.0F, 0.0F, 0.0F);
        this.animator.rotate(this.head, -0.3F, 0.0F, 0.0F);
        this.animator.rotate(this.topBody, 0.3F, 0.0F, 0.0F);
        this.animator.rotate(this.middleBody, 0.3F, 0.0F, 0.0F);
        this.animator.rotate(this.torso, 0.3F, 0.0F, 0.0F);
        this.animator.rotate(this.rightShoulder, -0.75F, 0.75F, -0.75F);
        this.animator.rotate(this.leftShoulder, 0.0F, -0.75F, 0.75F);
        this.animator.rotate(this.rightForearm, -0.25F, 0.0F, 0.0F);
        this.animator.rotate(this.leftForearm, 0.75F, 0.0F, 0.0F);
        this.animator.rotate(this.heldItem, 3.0F, 0.25F, -0.5F);
        this.animator.endPhase();
        this.animator.startPhase(20);
        this.animator.move(this.torso, 0.0F, 7.0F, 0.0F);
        this.animator.move(this.rightThigh, 0.0F, 7.0F, 0.0F);
        this.animator.move(this.leftThigh, 0.0F, 7.0F, 0.0F);
        this.animator.rotate(this.rightThigh, -1.0F, 0.0F, 0.0F);
        this.animator.rotate(this.leftThigh, -1.0F, -1.0F, 0.0F);
        this.animator.rotate(this.rightCalf, 2.3F, 0.0F, 0.0F);
        this.animator.rotate(this.leftCalf, 1.3F, 0.0F, 0.0F);
        this.animator.rotate(this.head, 0.3F, 0.0F, 0.0F);
        this.animator.rotate(this.topBody, 0.3F, 0.0F, 0.0F);
        this.animator.rotate(this.middleBody, 0.3F, 0.0F, 0.0F);
        this.animator.rotate(this.torso, 0.3F, 0.0F, 0.0F);
        this.animator.rotate(this.rightShoulder, -1.25F, 0.75F, -0.75F);
        this.animator.rotate(this.leftShoulder, -0.5F, -0.75F, 0.75F);
        this.animator.rotate(this.rightForearm, -0.25F, 0.0F, 0.0F);
        this.animator.rotate(this.leftForearm, 1.75F, 0.0F, 0.0F);
        this.animator.rotate(this.heldItem, 3.0F, 0.0F, 0.0F);
        this.animator.endPhase();
        this.animator.startPhase(20);
        this.animator.move(this.torso, 0.0F, 5.0F, 0.0F);
        this.animator.move(this.rightThigh, 0.0F, 5.0F, 0.0F);
        this.animator.move(this.leftThigh, 0.0F, 5.0F, 0.0F);
        this.animator.rotate(this.rightThigh, 1.0F, 0.0F, 0.0F);
        this.animator.rotate(this.leftThigh, -1.0F, 0.0F, 0.0F);
        this.animator.rotate(this.rightCalf, 1.0F, 0.0F, 0.0F);
        this.animator.rotate(this.leftCalf, 1.3F, 0.0F, 0.0F);
        this.animator.rotate(this.head, 0.3F, 0.0F, 0.0F);
        this.animator.rotate(this.topBody, 0.6F, 0.0F, 0.0F);
        this.animator.rotate(this.middleBody, 0.6F, 0.0F, 0.0F);
        this.animator.rotate(this.torso, 0.6F, 0.0F, 0.0F);
        this.animator.rotate(this.rightShoulder, -0.5F, 0.75F, -0.75F);
        this.animator.rotate(this.leftShoulder, 0.0F, -0.75F, 0.75F);
        this.animator.rotate(this.rightForearm, -0.25F, 0.0F, 0.0F);
        this.animator.rotate(this.leftForearm, 0.75F, 0.0F, 0.0F);
        this.animator.rotate(this.heldItem, 3.0F, 0.0F, 0.0F);
        this.animator.endPhase();
        this.animator.startPhase(20);
        this.animator.move(this.torso, 0.0F, 3.0F, 6.0F);
        this.animator.move(this.rightThigh, 0.0F, 3.0F, 6.0F);
        this.animator.move(this.leftThigh, 0.0F, 3.0F, 6.0F);
        this.animator.rotate(this.rightThigh, -0.75F, 0.0F, 0.0F);
        this.animator.rotate(this.leftThigh, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.rightCalf, 0.75F, 0.0F, 0.0F);
        this.animator.rotate(this.leftCalf, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.head, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.topBody, -0.25F, 0.0F, 0.0F);
        this.animator.rotate(this.middleBody, -0.25F, 0.0F, 0.0F);
        this.animator.rotate(this.torso, 0.0F, 0.0F, 0.5F);
        this.animator.rotate(this.rightShoulder, 0.0F, 0.5F, 0.0F);
        this.animator.rotate(this.leftShoulder, 0.0F, -0.5F, 0.0F);
        this.animator.rotate(this.rightForearm, 0.0F, 0.0F, 0.0F);
        this.animator.rotate(this.leftForearm, 0.0F, 0.0F, 0.0F);
        this.animator.rotate(this.heldItem, 2.0F, 0.0F, 0.0F);
        this.animator.endPhase();
        this.animator.startPhase(20);
        this.animator.move(this.torso, 0.0F, 0.0F, -4.0F);
        this.animator.move(this.rightThigh, 0.0F, 0.0F, -4.0F);
        this.animator.move(this.leftThigh, 0.0F, 0.0F, -4.0F);
        this.animator.rotate(this.rightThigh, 0.25F, 0.0F, 0.0F);
        this.animator.rotate(this.leftThigh, -0.25F, 0.0F, 0.0F);
        this.animator.rotate(this.rightCalf, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.leftCalf, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.head, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.topBody, 0.0F, 0.0F, 0.0F);
        this.animator.rotate(this.middleBody, 0.0F, 0.0F, 0.0F);
        this.animator.rotate(this.torso, 0.0F, 0.0F, -0.5F);
        this.animator.rotate(this.rightShoulder, 0.0F, 0.0F, 0.0F);
        this.animator.rotate(this.leftShoulder, 0.0F, 0.0F, 0.0F);
        this.animator.rotate(this.rightForearm, 0.0F, 0.0F, 0.0F);
        this.animator.rotate(this.leftForearm, 0.0F, 0.0F, 0.0F);
        this.animator.rotate(this.heldItem, 1.0F, 0.0F, 0.0F);
        this.animator.endPhase();
        this.animator.startPhase(40);
        this.animator.move(this.torso, 0.0F, 0.0F, 0.0F);
        this.animator.move(this.rightThigh, 0.0F, 0.0F, 0.0F);
        this.animator.move(this.leftThigh, 0.0F, 0.0F, 0.0F);
        this.animator.rotate(this.rightThigh, 0.0F, 0.0F, 0.0F);
        this.animator.rotate(this.leftThigh, 0.0F, 0.0F, 0.0F);
        this.animator.rotate(this.rightCalf, 0.0F, 0.0F, 0.0F);
        this.animator.rotate(this.leftCalf, 0.0F, 0.0F, 0.0F);
        this.animator.rotate(this.head, 0.0F, 0.0F, 0.0F);
        this.animator.rotate(this.topBody, 0.0F, 0.0F, 0.0F);
        this.animator.rotate(this.middleBody, 0.0F, 0.0F, 0.0F);
        this.animator.rotate(this.torso, 0.0F, 0.0F, 0.0F);
        this.animator.rotate(this.rightShoulder, 0.0F, 0.0F, 0.0F);
        this.animator.rotate(this.leftShoulder, 0.0F, 0.0F, 0.0F);
        this.animator.rotate(this.rightForearm, 0.0F, 0.0F, 0.0F);
        this.animator.rotate(this.leftForearm, 0.0F, 0.0F, 0.0F);
        this.animator.rotate(this.heldItem, 0.0F, 0.0F, 0.0F);
        this.animator.endPhase();
        this.animator.startPhase(10);
        this.animator.move(this.torso, 0.0F, 1.0F, 0.0F);
        this.animator.move(this.rightThigh, 0.0F, 1.0F, 0.0F);
        this.animator.move(this.leftThigh, 0.0F, 1.0F, 0.0F);
        this.animator.rotate(this.rightThigh, -0.25F, 0.0F, 0.0F);
        this.animator.rotate(this.leftThigh, -0.25F, 0.0F, 0.0F);
        this.animator.rotate(this.rightCalf, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.leftCalf, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.head, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.topBody, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.middleBody, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.rightShoulder, 0.8F, 0.5F, 0.5F);
        this.animator.rotate(this.leftShoulder, 0.8F, -0.5F, -0.5F);
        this.animator.rotate(this.rightForearm, -1.6F, 0.0F, -0.75F);
        this.animator.rotate(this.leftForearm, -1.6F, 0.0F, 0.75F);
        this.animator.rotate(this.heldItem, 0.0F, 0.0F, 0.75F);
        this.animator.endPhase();
        this.animator.startPhase(5);
        this.animator.move(this.torso, 0.0F, 2.0F, 0.0F);
        this.animator.move(this.rightThigh, 0.0F, 2.0F, 0.0F);
        this.animator.move(this.leftThigh, 0.0F, 2.0F, 0.0F);
        this.animator.rotate(this.rightThigh, -0.25F, 0.25F, 0.25F);
        this.animator.rotate(this.leftThigh, -0.25F, -0.25F, -0.25F);
        this.animator.rotate(this.rightCalf, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.leftCalf, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.head, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.topBody, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.middleBody, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.rightShoulder, 0.25F, 1.0F, 0.0F);
        this.animator.rotate(this.leftShoulder, 0.25F, -1.0F, 0.0F);
        this.animator.rotate(this.rightForearm, 0.0F, -1.0F, 0.0F);
        this.animator.rotate(this.leftForearm, 0.0F, 1.0F, 0.0F);
        this.animator.endPhase();
        this.animator.startPhase(5);
        this.animator.move(this.torso, 0.0F, 2.0F, 0.0F);
        this.animator.move(this.rightThigh, 0.0F, 2.0F, 0.0F);
        this.animator.move(this.leftThigh, 0.0F, 2.0F, 0.0F);
        this.animator.rotate(this.rightThigh, -0.25F, 0.25F, 0.25F);
        this.animator.rotate(this.leftThigh, -0.25F, -0.25F, -0.25F);
        this.animator.rotate(this.rightCalf, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.leftCalf, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.head, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.topBody, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.middleBody, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.rightShoulder, 0.5F, 1.0F, 0.0F);
        this.animator.rotate(this.leftShoulder, 0.5F, -1.0F, 0.0F);
        this.animator.rotate(this.rightForearm, -0.75F, 0.0F, 0.0F);
        this.animator.rotate(this.leftForearm, -0.75F, 0.0F, 0.0F);
        this.animator.endPhase();
        this.animator.setStationaryPhase(80);
        this.animator.resetPhase(40);
    }
}
