package net.titans.entity.ai.omegafish;

import net.titans.animation.AIAnimation;
import net.titans.entity.titan.EntityOmegafish;

public class AnimationOmegafishStunned extends AIAnimation {
    private EntityOmegafish entity;

    public AnimationOmegafishStunned(EntityOmegafish entity) {
        super(entity);
        this.entity = entity;
    }

    @Override
    public int getAnimationID() {
        return 8;
    }

    @Override
    public boolean isAutomatic() {
        return true;
    }

    @Override
    public int getDuration() {
        return 500;
    }

    @Override
    public boolean canContinueToUse() {
        return this.entity.getAnimationTick() > this.getDuration() ? false : super.canContinueToUse();
    }
}
