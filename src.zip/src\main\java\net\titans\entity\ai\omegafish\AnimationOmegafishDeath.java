package net.titans.entity.ai.omegafish;

import net.titans.animation.AIAnimation;
import net.titans.entity.titan.EntityOmegafish;

public class AnimationOmegafishDeath extends AIAnimation {
    private EntityOmegafish entity;

    public AnimationOmegafishDeath(EntityOmegafish entity) {
        super(entity);
        this.entity = entity;
    }

    @Override
    public int getAnimationID() {
        return 10;
    }

    @Override
    public boolean isAutomatic() {
        return true;
    }

    @Override
    public int getDuration() {
        return 2000;
    }

    @Override
    public boolean canUse() {
        return this.entity.deathTicks > 0 && !this.entity.isAlive() ? super.canUse() : false;
    }

    @Override
    public boolean canContinueToUse() {
        return this.entity.deathTicks > 0 && !this.entity.isAlive() ? super.canContinueToUse() : false;
    }
}
