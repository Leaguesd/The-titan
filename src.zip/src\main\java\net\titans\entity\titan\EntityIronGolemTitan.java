package net.titans.entity.titan;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.Difficulty;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.SpawnGroupData;
import net.minecraft.world.entity.Entity.RemovalReason;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier.Builder;
import net.minecraft.world.entity.animal.IronGolem;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.ItemLike;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.ServerLevelAccessor;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;
import net.titans.entity.IBossBarDisplay;
import net.titans.entity.ai.EntityAINearestTargetTitan;
import net.titans.entity.ai.irongolemtitan.AnimationIronGolemTitanAntiTitanAttack;
import net.titans.entity.ai.irongolemtitan.AnimationIronGolemTitanAttack1;
import net.titans.entity.ai.irongolemtitan.AnimationIronGolemTitanAttack2;
import net.titans.entity.ai.irongolemtitan.AnimationIronGolemTitanAttack3;
import net.titans.entity.ai.irongolemtitan.AnimationIronGolemTitanAttack4;
import net.titans.entity.ai.irongolemtitan.AnimationIronGolemTitanDeath;
import net.titans.entity.ai.irongolemtitan.AnimationIronGolemTitanRangedAttack;
import net.titans.entity.projectile.EntityIronIngotTitan;
import net.titans.loader.TheTitansEntities;
import net.titans.loader.TheTitansRegistries;
import net.titans.loader.TheTitansPredicateTargets;
import net.titans.loader.TheTitansSounds;
import net.titans.util.AnimationUtils;

public class EntityIronGolemTitan extends EntityTitan implements IBossBarDisplay {
    private static final EntityDataAccessor<Boolean> PLAYER_CREATED = SynchedEntityData.defineId(EntityIronGolemTitan.class, EntityDataSerializers.BOOLEAN);
    private int attackTimer;
    private int holdRoseTick;

    public EntityIronGolemTitan(EntityType<? extends EntityTitan> entityType, Level level) {
        super(entityType, level);
    }

    public EntityIronGolemTitan(Level level) {
        this((EntityType<? extends EntityTitan>)TheTitansEntities.IRON_GOLEM_TITAN.get(), level);
    }

    public static Builder createAttributes() {
        return EntityTitan.createAttributes().add(Attributes.MAX_HEALTH, 500000.0).add(Attributes.ATTACK_DAMAGE, 5000.0);
    }

    @Override
    public ResourceLocation getBossBarTexture() {
        return ResourceLocation.tryBuild("titan", "textures/gui/bossbar/iron_golem_titan.png");
    }

    @Override
    public int getBossBarNameColor() {
        return 7237230;
    }

    @Override
    public int getBossBarWidth() {
        return 191;
    }

    @Override
    public int getBossBarHeight() {
        return 26;
    }

    @Override
    public int getBossBarInterval() {
        return 5;
    }

    @Override
    public int getBossBarVOffset() {
        return 0;
    }

    @Override
    public int getBossBarVHeight() {
        return 0;
    }

    @Override
    public int getBossBarTextOffset() {
        return 7;
    }

    @Override
    protected void registerGoals() {
        super.registerGoals();
        this.goalSelector.addGoal(1, new AnimationIronGolemTitanDeath(this));
        this.goalSelector.addGoal(1, new AnimationIronGolemTitanAntiTitanAttack(this));
        this.goalSelector.addGoal(1, new AnimationIronGolemTitanAttack1(this));
        this.goalSelector.addGoal(1, new AnimationIronGolemTitanAttack2(this));
        this.goalSelector.addGoal(1, new AnimationIronGolemTitanAttack3(this));
        this.goalSelector.addGoal(1, new AnimationIronGolemTitanAttack4(this));
        this.goalSelector.addGoal(1, new AnimationIronGolemTitanRangedAttack(this));
        this.targetSelector.addGoal(0, new EntityAINearestTargetTitan(this, Mob.class, 0, false, false, entity -> entity instanceof Enemy));
        this.targetSelector.addGoal(0, new EntityAINearestTargetTitan(this, EntityTitan.class, 0, false, false, TheTitansPredicateTargets.IronGolemTitan));
    }

    public boolean isPlayerCreated() {
        return (Boolean)this.entityData.get(PLAYER_CREATED);
    }

    public void setPlayerCreated(boolean playerCreated) {
        this.entityData.set(PLAYER_CREATED, playerCreated);
    }

    public int getAttackTimer() {
        return this.attackTimer;
    }

    public int getHoldRoseTick() {
        return this.holdRoseTick;
    }

    public void setHoldingRose(boolean holdingRose) {
        if (holdingRose) {
            this.holdRoseTick = 800;
            this.level().broadcastEntityEvent(this, (byte)11);
        } else {
            this.holdRoseTick = 0;
            this.level().broadcastEntityEvent(this, (byte)34);
        }
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(PLAYER_CREATED, false);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        this.setPlayerCreated(tag.getBoolean("PlayerCreated"));
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
    }

    @Override
    public SpawnGroupData finalizeSpawn(
        ServerLevelAccessor level, DifficultyInstance difficulty, MobSpawnType spawnType, @Nullable SpawnGroupData spawnGroupData, @Nullable CompoundTag tag
    ) {
        return super.finalizeSpawn(level, difficulty, spawnType, spawnGroupData, null);
    }

    @Override
    protected void refreshAttributes() {
        if (this.level().getDifficulty() == Difficulty.HARD) {
            this.getAttribute(Attributes.MAX_HEALTH).setBaseValue(500000.0 + (double)this.getExtraPower() * 2500.0);
            this.getAttribute(Attributes.ATTACK_DAMAGE).setBaseValue(5000.0 + (double)this.getExtraPower() * 3000.0);
        } else {
            this.getAttribute(Attributes.MAX_HEALTH).setBaseValue(500000.0 + (double)this.getExtraPower() * 1250.0);
            this.getAttribute(Attributes.ATTACK_DAMAGE).setBaseValue(2500.0 + (double)this.getExtraPower() * 1500.0);
        }
    }

    @Override
    public boolean canAttack() {
        return true;
    }

    @Override
    public boolean canAttackEntity(Entity entity) {
        return super.canAttackEntity(entity) && !(entity instanceof IronGolem) && (!(entity instanceof Player) || !this.isPlayerCreated());
    }

    @Override
    public boolean canBeHurtByPlayer() {
        return !this.isPlayerCreated() && !this.isInvulnerable();
    }

    @Override
    public boolean shouldMove() {
        return this.getAnimationID() == 0 && this.getTarget() != null ? super.shouldMove() : false;
    }

    @Override
    public double getMeleeRange() {
        return (double)(
                this.getBbWidth() * this.getBbWidth() + (this.getTarget().getBbWidth() > 48.0F ? 2304.0F : this.getTarget().getBbWidth() * this.getTarget().getBbWidth())
            )
            + 2000.0;
    }

    @Override
    public EnumTitanStatus getTitanStatus() {
        return EnumTitanStatus.GREATER;
    }

    public int getArmorValue() {
        return 24;
    }

    protected SoundEvent getAmbientSound() {
        return null;
    }

    protected SoundEvent getHurtSound(DamageSource damageSource) {
        return SoundEvents.IRON_GOLEM_HURT;
    }

    protected SoundEvent getDeathSound() {
        return SoundEvents.IRON_GOLEM_DEATH;
    }

    protected void playStepSound(BlockPos pos, BlockState state) {
        this.shakeNearbyPlayerCameras(6000.0);

        for (int i = 0; i < 8; i++) {
            this.playSound(SoundEvents.IRON_GOLEM_STEP, 10.0F, 0.5F);
        }

        this.playSound((SoundEvent)TheTitansSounds.TITAN_STEP.get(), 10.0F, 1.0F);
    }

    @Override
    protected float getSoundVolume() {
        return 100.0F;
    }

    public float getVoicePitch() {
        return this.isBaby()
            ? (this.random.nextFloat() - this.random.nextFloat()) * 0.2F + 1.0F
            : (this.random.nextFloat() - this.random.nextFloat()) * 0.2F + 0.5F;
    }

    @Override
    public void attackEntity(LivingEntity entity, float amount) {
        if (entity instanceof EntityWitherzilla) {
            amount *= 5.0F;
        }

        if (entity instanceof EntityGhastTitan && entity.getY() > this.getY() + 32.0) {
            EntityGhastTitan titan = (EntityGhastTitan)entity;
            titan.setTitanDeltaMovement(titan.getDeltaMovement().x, titan.getDeltaMovement().y - 1.0, titan.getDeltaMovement().z);
        }

        for (int i = 0; i < 7 + this.random.nextInt(14); i++) {
            super.attackEntity(entity, amount);
        }
    }

    public boolean doHurtTarget(Entity entity) {
        this.level().broadcastEntityEvent(this, (byte)4);
        return super.doHurtTarget(entity);
    }

    @Override
    public boolean hurt(DamageSource damageSource, float amount) {
        if (amount > 1000.0F) {
            amount = 1000.0F;
        }

        return super.hurt(damageSource, amount);
    }

    public void handleEntityEvent(byte id) {
        if (id == 4) {
            this.playSound(SoundEvents.IRON_GOLEM_ATTACK, 100.0F, 0.5F);
            this.attackTimer = 10;
        } else if (id == 11) {
            this.holdRoseTick = 800;
        } else if (id == 34) {
            this.holdRoseTick = 0;
        } else {
            super.handleEntityEvent(id);
        }
    }

    @Override
    public void aiStep() {
        super.aiStep();
        if (this.attackTimer > 0) {
            this.attackTimer--;
        }

        if (this.holdRoseTick > 0) {
            this.holdRoseTick--;
        }

        float amount = (float)this.getAttributeBaseValue(Attributes.ATTACK_DAMAGE);

        for (Entity entity : this.level().getEntities(this, this.getBoundingBox())) {
            if (entity != null
                && (entity instanceof LivingEntity || entity instanceof Player && !this.isPlayerCreated())
                && entity.onGround()
                && !(entity instanceof EntityTitan)
                && !this.canAttackEntity(entity)) {
                LivingEntity livingEntity = (LivingEntity)entity;
                super.attackEntity(livingEntity, amount / 2.0F);
            }
        }
    }

    @Override
    protected void dropExperienceOrb() {
        for (int x = 0; x < 24; x++) {
            EntityExperienceOrbTitan experienceOrbTitan = new EntityExperienceOrbTitan(
                this.level(),
                this.getX() + (double)(this.random.nextFloat() * 12.0F - 6.0F),
                this.getY() + 4.0,
                this.getZ() + (double)(this.random.nextFloat() * 12.0F - 6.0F),
                24000
            );
            experienceOrbTitan.push(0.0, 1.0, 0.0);
            if (!this.level().isClientSide()) {
                this.level().addFreshEntity(experienceOrbTitan);
            }
        }
    }

    @Override
    protected void dropAllItem() {
        Map<ItemStack, Integer> drops = new HashMap<>();
        Map<ItemStack, Integer> rateDrops = new HashMap<>();
        drops.put(new ItemStack(Blocks.IRON_BLOCK), 512);
        drops.put(new ItemStack(Items.POPPY), 128);
        drops.put(new ItemStack(Items.EMERALD), 32);
        drops.put(new ItemStack(Items.DIAMOND), 32);
        rateDrops.put(new ItemStack(Blocks.IRON_BLOCK), 512);
        rateDrops.put(new ItemStack(Items.POPPY), 128);
        rateDrops.put(new ItemStack(Items.EMERALD), 32);
        rateDrops.put(new ItemStack(Items.DIAMOND), 32);
        rateDrops.put(new ItemStack(Items.EMERALD), 96);
        rateDrops.put(new ItemStack(Items.DIAMOND), 96);
        rateDrops.put(new ItemStack((ItemLike)TheTitansRegistries.HARCADIUM.get()), 16);
        rateDrops.put(new ItemStack(Blocks.BEDROCK), 8);

        for (Entry<ItemStack, Integer> entry : drops.entrySet()) {
            ItemStack itemStack = entry.getKey();
            int count = entry.getValue();
            EntityItemTitan itemTitan = new EntityItemTitan(
                this.level(),
                this.getX() + (double)(this.random.nextFloat() * 12.0F - 6.0F),
                this.getY() + 4.0,
                this.getZ() + (double)(this.random.nextFloat() * 12.0F - 6.0F),
                itemStack,
                count
            );
            itemTitan.setPickUpDelay(40);
            this.level().addFreshEntity(itemTitan);
        }

        for (Entry<ItemStack, Integer> entry : rateDrops.entrySet()) {
            ItemStack itemStack = entry.getKey();
            int count = entry.getValue();
            int randomCount = this.random.nextInt(count) + 1;
            EntityItemTitan itemTitan = new EntityItemTitan(
                this.level(),
                this.getX() + (double)(this.random.nextFloat() * 12.0F - 6.0F),
                this.getY() + 4.0,
                this.getZ() + (double)(this.random.nextFloat() * 12.0F - 6.0F),
                itemStack,
                randomCount
            );
            itemTitan.setPickUpDelay(40);
            this.level().addFreshEntity(itemTitan);
        }
    }

    @Override
    protected void tickTitanDeath() {
        super.tickTitanDeath();
        AnimationUtils.sendPacket(this, 10);
        if (this.deathTicks >= 500) {
            this.setInvulTime(this.getInvulTime() + 8);
        }

        if (this.getInvulTime() >= this.getThreashHold()) {
            this.onDeath();
            if (!this.level().isClientSide() && !this.isRemoved()) {
                this.removeTitan(RemovalReason.KILLED);
            }
        }
    }

    public void animationTick() {
        if (this.getAnimationID() == 1 && this.getAnimationTick() == 12 && this.getTarget() != null) {
            this.shakeNearbyPlayerCameras(20000.0);
            float amount = (float)this.getAttributeBaseValue(Attributes.ATTACK_DAMAGE);
            int knockbackAmount = this.getKnockbackAmount();

            for (int i = 0; i < 4; i++) {
                this.attackEntity(this.getTarget(), amount);
            }

            this.knockbackEntity(this.getTarget(), (float)knockbackAmount);

            for (Entity entity : this.level().getEntities(this.getTarget(), this.getTarget().getBoundingBox().inflate(8.0, 8.0, 8.0))) {
                if (entity != null && entity != this && entity instanceof LivingEntity && this.canAttackEntity(entity)) {
                    LivingEntity livingEntity = (LivingEntity)entity;

                    for (int i = 0; i < 6; i++) {
                        super.attackEntity(livingEntity, amount);
                    }

                    this.knockbackEntity(livingEntity, (float)knockbackAmount);
                }
            }
        }

        if (this.getAnimationID() == 5 && this.getAnimationTick() == 34 && this.getTarget() != null) {
            float amount = (float)this.getAttributeBaseValue(Attributes.ATTACK_DAMAGE);
            int knockbackAmount = this.getKnockbackAmount();
            this.attackEntity(this.getTarget(), amount);
            this.knockbackEntity(this.getTarget(), (float)knockbackAmount);
            double d8 = 30.0;
            Vec3 vec3 = this.getViewVector(1.0F);
            double dx = vec3.x * d8;
            double dz = vec3.z * d8;
            double d0 = this.getX() + dx;
            double d1 = this.getY() + d8;
            double d2 = this.getZ() + dz;
            double d3 = this.getTarget().getX() - d0;
            double d4 = this.getTarget().getY() - d1;
            double d5 = this.getTarget().getZ() - d2;
            EntityIronIngotTitan ironIngotTitan = new EntityIronIngotTitan(this.level(), this);
            ironIngotTitan.setOwner(this);
            ironIngotTitan.setPos(d0, d1, d2);
            ironIngotTitan.shoot(d3, d4, d5, 1.0F, 0.0F);
            if (!this.level().isClientSide()) {
                this.level().addFreshEntity(ironIngotTitan);
            }
        }

        if (this.getAnimationID() == 6) {
            if (this.getAnimationTick() == 34) {
                this.playSound((SoundEvent)TheTitansSounds.TITAN_SWING.get(), 100.0F, 1.0F);

                for (int i = 0; i < 2; i++) {
                    this.playSound(SoundEvents.IRON_GOLEM_ATTACK, 100.0F, 0.5F);
                }
            }

            if (this.getAnimationTick() == 38) {
                this.shakeNearbyPlayerCameras(20000.0);
                this.playSound((SoundEvent)TheTitansSounds.TITAN_STRIKE.get(), 20.0F, 1.0F);
                this.playSound((SoundEvent)TheTitansSounds.TITAN_SLAM.get(), 20.0F, 1.0F);
                this.playSound((SoundEvent)TheTitansSounds.TITAN_STEP.get(), 20.0F, 1.0F);
                double d8 = 48.0;
                Vec3 vec3 = this.getViewVector(1.0F);
                double dx = vec3.x * d8;
                double dz = vec3.z * d8;
                float amount = (float)this.getAttributeBaseValue(Attributes.ATTACK_DAMAGE);
                int knockbackAmount = this.getKnockbackAmount();

                for (Entity entityx : this.level().getEntities(this, this.getBoundingBox().inflate(48.0, 16.0, 48.0).move(dx, -16.0, dz))) {
                    if (entityx != null && entityx instanceof LivingEntity && this.canAttackEntity(entityx)) {
                        LivingEntity livingEntity = (LivingEntity)entityx;

                        for (int i = 0; i < 2; i++) {
                            this.attackEntity(livingEntity, amount);
                        }

                        this.knockbackEntity(livingEntity, (float)knockbackAmount);
                    }
                }
            }
        }

        if (this.getAnimationID() == 7 && (this.getAnimationTick() == 60 || this.getAnimationTick() == 104)) {
            this.shakeNearbyPlayerCameras(20000.0);
            this.playSound((SoundEvent)TheTitansSounds.TITAN_SLAM.get(), 20.0F, 1.0F);
            float amount = (float)this.getAttributeBaseValue(Attributes.ATTACK_DAMAGE);

            for (Entity entityxx : this.level().getEntities(this, this.getBoundingBox().inflate(48.0, 16.0, 48.0))) {
                if (entityxx != null && entityxx instanceof LivingEntity && this.canAttackEntity(entityxx)) {
                    LivingEntity livingEntity = (LivingEntity)entityxx;
                    this.attackEntity(livingEntity, amount);
                    livingEntity.push(0.0, 2.0 + this.random.nextDouble() + this.random.nextDouble(), 0.0);
                }
            }
        }

        if (this.getAnimationID() == 8) {
            if (this.getAnimationTick() == 26) {
                this.playSound((SoundEvent)TheTitansSounds.TITAN_SWING.get(), 100.0F, 1.0F);

                for (int i = 0; i < 2; i++) {
                    this.playSound(SoundEvents.IRON_GOLEM_ATTACK, 100.0F, 0.5F);
                }
            }

            if (this.getAnimationTick() == 28 && this.getTarget() != null) {
                float amount = (float)this.getAttributeBaseValue(Attributes.ATTACK_DAMAGE);
                int knockbackAmount = this.getKnockbackAmount() * 20;
                super.attackEntity(this.getTarget(), amount);
                this.attackEntity(this.getTarget(), amount);
                this.knockbackEntity(this.getTarget(), (float)knockbackAmount);
                this.getTarget().push(0.0, 2.0, 0.0);

                for (Entity entityxxx : this.level().getEntities(this.getTarget(), this.getTarget().getBoundingBox().inflate(6.0, 2.0, 6.0))) {
                    if (entityxxx != null && entityxxx != this && entityxxx instanceof LivingEntity && this.canAttackEntity(entityxxx)) {
                        LivingEntity livingEntity = (LivingEntity)entityxxx;
                        super.attackEntity(livingEntity, amount);
                        this.knockbackEntity(livingEntity, (float)knockbackAmount);
                        livingEntity.push(0.0, 2.0, 0.0);
                    }
                }
            }
        }

        if (this.getAnimationID() == 9) {
            if (this.getAnimationTick() == 44) {
                this.playSound((SoundEvent)TheTitansSounds.TITAN_SWING.get(), 100.0F, 1.0F);
                this.playSound(SoundEvents.IRON_GOLEM_ATTACK, 100.0F, 0.5F);
            }

            if (this.getAnimationTick() == 48) {
                this.shakeNearbyPlayerCameras(20000.0);
                this.playSound((SoundEvent)TheTitansSounds.TITAN_SLAM.get(), 20.0F, 1.0F);

                for (int i = 0; i < 4; i++) {
                    this.playSound((SoundEvent)TheTitansSounds.TITAN_STEP.get(), 20.0F, 1.0F);
                }

                double d8 = 24.0;
                Vec3 vec3 = this.getViewVector(1.0F);
                double dx = vec3.x * d8;
                double dz = vec3.z * d8;
                float amount = (float)this.getAttributeBaseValue(Attributes.ATTACK_DAMAGE);
                int knockbackAmount = 15;

                for (Entity entityxxxx : this.level().getEntities(this, this.getBoundingBox().inflate(32.0, 4.0, 32.0).move(dx, -2.0, dz))) {
                    if (entityxxxx != null && entityxxxx instanceof LivingEntity && this.canAttackEntity(entityxxxx)) {
                        LivingEntity livingEntity = (LivingEntity)entityxxxx;
                        this.attackEntity(livingEntity, amount);
                        this.knockbackEntity(this.getTarget(), (float)knockbackAmount, true);
                    }
                }
            }
        }

        if (this.getAnimationID() == 10) {
            if (this.getAnimationTick() == 30 || this.getAnimationTick() == 70) {
                this.playStepSound(new BlockPos(0, 0, 0), Blocks.STONE.defaultBlockState());
            }

            if (this.getAnimationTick() == 190) {
                this.shakeNearbyPlayerCameras(40000.0);
                this.playSound((SoundEvent)TheTitansSounds.TITAN_FALL.get(), 20.0F, 0.9F);
                this.playSound((SoundEvent)TheTitansSounds.GROUND_SMASH.get(), 20.0F, 1.0F);
            }

            if (this.getAnimationTick() == 200) {
                this.playSound((SoundEvent)TheTitansSounds.DISTANT_LARGE_FALL.get(), 10000.0F, 0.5F);
            }
        }
    }

    @Override
    public void tick() {
        super.tick();
        if (this.getAnimationID() == 0 && this.getTarget() != null) {
            double d0 = this.distanceToSqr(this.getTarget());
            if (d0 < this.getMeleeRange()) {
                if (!(this.getTarget() instanceof EntityTitan) && !(this.getTarget().getBbHeight() >= 6.0F) && !(this.getTarget().getY() > this.getY() + 6.0)) {
                    switch (this.random.nextInt(4)) {
                        case 0:
                            AnimationUtils.sendPacket(this, 6);
                            break;
                        case 1:
                            AnimationUtils.sendPacket(this, 7);
                            break;
                        case 2:
                            AnimationUtils.sendPacket(this, 8);
                            break;
                        case 3:
                            AnimationUtils.sendPacket(this, 9);
                    }
                } else {
                    AnimationUtils.sendPacket(this, 1);
                }
            } else if (this.random.nextInt(160) == 0) {
                AnimationUtils.sendPacket(this, 5);
            }
        }

        if (this.getDeltaMovement().y > 1.0) {
            this.setTitanDeltaMovement(this.getDeltaMovement().x, 1.0, this.getDeltaMovement().z);
        }

        for (Entity entity : this.level().getEntities(this, this.getBoundingBox().inflate(96.0, 96.0, 96.0))) {
            if (entity != null && entity instanceof IronGolem) {
                IronGolem ironGolem = (IronGolem)entity;
                if (ironGolem.horizontalCollision) {
                    ironGolem.setDeltaMovement(this.getDeltaMovement().x, 0.25, this.getDeltaMovement().z);
                }

                if (ironGolem.getTarget() == null && ironGolem.distanceToSqr(this) > 4096.0) {
                    ironGolem.getLookControl().setLookAt(this, 180.0F, 40.0F);
                    ironGolem.getMoveControl().setWantedPosition(this.getX(), this.getY(), this.getZ(), 1.0);
                }

                if (ironGolem.tickCount == 20) {
                    ironGolem.targetSelector
                        .addGoal(0, new EntityAINearestTargetTitan(this, EntityTitan.class, 0, false, false, TheTitansPredicateTargets.IronGolemTitan));
                }
            }
        }

        float randomRate = this.random.nextFloat() * 100.0F;
        if (this.isAlive() && this.tickCount % 20 == 0 && (double)randomRate < 5.0) {
            IronGolem ironGolemx = new IronGolem(EntityType.IRON_GOLEM, this.level());
            ironGolemx.setPos(
                this.getX() + ((double)this.random.nextFloat() - 0.5) * (double)this.getBbWidth(),
                this.getY(),
                this.getZ() + ((double)this.random.nextFloat() - 0.5) * (double)this.getBbWidth()
            );
            ironGolemx.setYRot(this.getYRot());
            ironGolemx.getAttribute(Attributes.MAX_HEALTH).setBaseValue(2000.0);
            ironGolemx.getAttribute(Attributes.FOLLOW_RANGE).setBaseValue(32.0);
            ironGolemx.setHealth(2000.0F);
            ironGolemx.setCustomName(Component.translatable("entity.titan.reinforced_iron_golem"));
            if (!this.level().isClientSide()) {
                this.level().addFreshEntity(ironGolemx);
            }
        }

        this.animationTick();
    }
}
