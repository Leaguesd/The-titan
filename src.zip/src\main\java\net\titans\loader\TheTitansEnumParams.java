package net.titans.loader;

import net.minecraft.world.item.Rarity;

public class TheTitansEnumParams {
    public static final TheTitansEnumParams.RarityProxy GODLY_RARITY_ENUM_PROXY = new TheTitansEnumParams.RarityProxy(Rarity.EPIC);

    public static record RarityProxy(Rarity value) {
        public Rarity getValue() {
            return this.value;
        }
    }
}
