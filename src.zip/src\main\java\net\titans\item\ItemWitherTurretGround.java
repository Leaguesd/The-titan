package net.titans.item;

import net.minecraft.world.item.Item.Properties;
import net.minecraft.world.level.Level;
import net.titans.entity.EntityWitherTurret;
import net.titans.entity.EntityWitherTurretGround;

public class ItemWitherTurretGround extends ItemWitherTurret {
    public ItemWitherTurretGround(Properties properties) {
        super(properties);
    }

    @Override
    public EntityWitherTurret getEntity(Level level) {
        return new EntityWitherTurretGround(level);
    }
}
