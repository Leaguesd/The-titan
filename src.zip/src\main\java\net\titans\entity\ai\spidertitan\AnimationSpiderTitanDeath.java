package net.titans.entity.ai.spidertitan;

import net.titans.animation.AIAnimation;
import net.titans.entity.titan.EntitySpiderTitan;

public class AnimationSpiderTitanDeath extends AIAnimation {
    private EntitySpiderTitan entity;

    public AnimationSpiderTitanDeath(EntitySpiderTitan entity) {
        super(entity);
        this.entity = entity;
    }

    @Override
    public int getAnimationID() {
        return 10;
    }

    @Override
    public boolean isAutomatic() {
        return true;
    }

    @Override
    public int getDuration() {
        return 2000;
    }

    @Override
    public boolean canUse() {
        return this.entity.deathTicks > 0 && !this.entity.isAlive() ? super.canUse() : false;
    }

    @Override
    public boolean canContinueToUse() {
        return this.entity.deathTicks > 0 && !this.entity.isAlive() ? super.canContinueToUse() : false;
    }
}
