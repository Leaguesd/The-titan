package net.titans.entity.ai.creepertitan;

import net.titans.animation.AIAnimation;
import net.titans.entity.titan.EntityCreeperTitan;
import net.titans.util.AnimationUtils;

public class AnimationCreeperTitanAntiTitanAttack extends AIAnimation {
    private EntityCreeperTitan entity;

    public AnimationCreeperTitanAntiTitanAttack(EntityCreeperTitan entity) {
        super(entity);
        this.entity = entity;
    }

    @Override
    public int getAnimationID() {
        return 1;
    }

    @Override
    public boolean isAutomatic() {
        return true;
    }

    @Override
    public int getDuration() {
        return 30;
    }

    @Override
    public boolean canContinueToUse() {
        return this.entity.getAnimationTick() <= this.getDuration() && !this.entity.isStunned ? super.canContinueToUse() : false;
    }

    @Override
    public void start() {
        super.start();
        AnimationUtils.sendAttackPacket(this.entity, this.entity.level().random.nextInt(4));
    }

    public void tick() {
        if (this.entity.getTarget() != null) {
            this.entity.getLookControl().setLookAt(this.entity.getTarget(), 5.0F, 40.0F);
        }
    }
}
