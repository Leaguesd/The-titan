package net.titans.feature;

import com.mojang.serialization.Codec;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.core.BlockPos;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.WorldGenLevel;
import net.minecraft.world.level.block.BaseFireBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.LiquidBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap.Types;
import net.minecraft.world.level.levelgen.feature.Feature;
import net.minecraft.world.level.levelgen.feature.FeaturePlaceContext;
import net.minecraft.world.level.levelgen.feature.configurations.NoneFeatureConfiguration;
import net.minecraft.world.phys.AABB;
import net.titans.theTitans;
import net.titans.data.SavedDataSpawnedPos;
import net.titans.entity.titan.EntityBlazeTitan;
import net.titans.entity.titan.EntityCaveSpiderTitan;
import net.titans.entity.titan.EntityCreeperTitan;
import net.titans.entity.titan.EntityEnderColossus;
import net.titans.entity.titan.EntityGhastTitan;
import net.titans.entity.titan.EntityMagmaCubeTitan;
import net.titans.entity.titan.EntityOmegafish;
import net.titans.entity.titan.EntitySkeletonTitan;
import net.titans.entity.titan.EntitySlimeTitan;
import net.titans.entity.titan.EntitySpiderTitan;
import net.titans.entity.titan.EntityTitan;
import net.titans.entity.titan.EntityWitherSkeletonTitan;
import net.titans.entity.titan.EntityWitherzilla;
import net.titans.entity.titan.EntityZombieTitan;
import net.titans.entity.titan.EntityZombifiedPiglinTitan;
import net.titans.loader.TheTitansDimensions;

public class FeatureTitanSpawn extends Feature<NoneFeatureConfiguration> {
    public FeatureTitanSpawn(Codec<NoneFeatureConfiguration> codec) {
        super(codec);
    }

    public float distanceToPos(BlockPos blockPos1, BlockPos blockPos2) {
        int x = blockPos1.getX() - blockPos2.getX();
        int y = blockPos1.getY() - blockPos2.getY();
        int z = blockPos1.getZ() - blockPos2.getZ();
        return Mth.sqrt((float)(x * x + y * y + z * z));
    }

    public boolean isTitanSpawned(WorldGenLevel level, Entity entity, double range) {
        SavedDataSpawnedPos savedData = (SavedDataSpawnedPos)level.getLevel()
            .getDataStorage()
            .computeIfAbsent(SavedDataSpawnedPos::load, SavedDataSpawnedPos::new, "titan_spawned_pos");

        for (BlockPos blockPos : savedData.getSpawnedPos()) {
            if ((double)this.distanceToPos(blockPos, entity.blockPosition()) < range) {
                return true;
            }
        }

        return false;
    }

    public void setTitanSpawned(WorldGenLevel level, Entity entity) {
        SavedDataSpawnedPos savedData = (SavedDataSpawnedPos)level.getLevel()
            .getDataStorage()
            .computeIfAbsent(SavedDataSpawnedPos::load, SavedDataSpawnedPos::new, "titan_spawned_pos");
        savedData.getSpawnedPos().add(entity.blockPosition().immutable());
        if (savedData.getSpawnedPos().size() >= 100) {
            List<BlockPos> newList = new ArrayList<>(savedData.getSpawnedPos().subList(savedData.getSpawnedPos().size() - 80, savedData.getSpawnedPos().size()));
            savedData.getSpawnedPos().clear();
            savedData.getSpawnedPos().addAll(newList);
        }

        savedData.setDirty();
    }

    public boolean hasTitan(WorldGenLevel level, Entity entity, double range) {
        List<EntityTitan> entities = level.getLevel().getEntitiesOfClass(EntityTitan.class, entity.getBoundingBox().inflate(range, range, range));
        return !entities.isEmpty();
    }

    public int getSurface(WorldGenLevel level, int x, int z) {
        int y = level.getHeight(Types.WORLD_SURFACE, x, z);

        for (int i = level.getMinBuildHeight(); i < y - 1; i++) {
            BlockPos blockPos = new BlockPos(x, i, z);
            if (level.isEmptyBlock(blockPos) && !level.isEmptyBlock(blockPos.below())) {
                return i;
            }
        }

        return y;
    }

    public int getNetherSurface(WorldGenLevel level, int x, int z) {
        return level.getHeight(Types.WORLD_SURFACE, x, z);
    }

    public void destroyBlocksInAABB(WorldGenLevel level, AABB aabb) {
        if (aabb != null && !level.isClientSide()) {
            int minX = Mth.floor(aabb.minX);
            int minY = Mth.floor(aabb.minY);
            int minZ = Mth.floor(aabb.minZ);
            int maxX = Mth.floor(aabb.maxX);
            int maxY = Mth.floor(aabb.maxY);
            int maxZ = Mth.floor(aabb.maxZ);

            for (int y = minY; y <= maxY; y++) {
                for (int x = minX; x <= maxX; x++) {
                    for (int z = minZ; z <= maxZ; z++) {
                        BlockPos blockPos = new BlockPos(x, y, z);
                        BlockState blockState = level.getBlockState(blockPos);
                        Block block = blockState.getBlock();
                        if (!blockState.isAir() && blockState.getDestroySpeed(level, blockPos) >= 0.0F) {
                            if (!(block instanceof BaseFireBlock)) {
                                level.levelEvent(2001, blockPos, Block.getId(blockState));
                            }

                            level.setBlock(blockPos, Blocks.AIR.defaultBlockState(), 0);
                        }
                    }
                }
            }
        }
    }

    public EntityTitan generateTitan(
        WorldGenLevel level, RandomSource random, EntityTitan titan, int x, int y, int z, boolean spawnPosProtect, boolean canSpawnLiquid
    ) {
        BlockPos blockPos = new BlockPos(x, y, z);
        BlockState blockState = level.getBlockState(blockPos);
        BlockPos belowPos = blockPos.below();
        BlockState belowState = level.getBlockState(belowPos);
        Block belowBlock = belowState.getBlock();
        if (spawnPosProtect
            && (double)this.distanceToPos(blockPos, level.getLevel().getSharedSpawnPos()) <= 1024.0) {
            return null;
        } else if (!canSpawnLiquid && belowBlock instanceof LiquidBlock) {
            return null;
        } else {
            if (blockState.isAir()) {
                titan.setPos((double)x + 0.5, (double)y, (double)z + 0.5);
                titan.setYRot(random.nextFloat() * 360.0F);
                if (!this.isTitanSpawned(level.getLevel(), titan, 512.0)) {
                    titan.finalizeSpawn(level.getLevel(), level.getCurrentDifficultyAt(titan.blockPosition()), MobSpawnType.STRUCTURE, null, null);
                    titan.setTitanHealth(titan.getTitanMaxHealth());
                    this.destroyBlocksInAABB(level, titan.getBoundingBox());
                    level.addFreshEntity(titan);
                    this.setTitanSpawned(level, titan);
                    theTitans.LOGGER
                        .info(
                            "Found a succesfully spawned {} at {}, {}, {}.",
                            new Object[]{
                                titan.getName().getString(), Mth.floor(titan.getX()), Mth.floor(titan.getY()), Mth.floor(titan.getZ())
                            }
                        );
                    return titan;
                }
            }

            return null;
        }
    }

    public void generateWeb(WorldGenLevel level, int x, int y, int z) {
        for (int l1 = x - 11; l1 <= x + 11; l1++) {
            for (int j1 = y - 11; j1 <= y; j1++) {
                for (int i2 = z - 11; i2 <= z + 11; i2++) {
                    BlockPos blockPos = new BlockPos(l1, j1, i2);
                    BlockState blockState = level.getBlockState(blockPos);
                    if (blockState.getDestroySpeed(level, blockPos) >= 0.0F) {
                        level.setBlock(blockPos, Blocks.COBWEB.defaultBlockState(), 0, 2);
                    }
                }
            }
        }
    }

    public void generateGold(WorldGenLevel level, int x, int y, int z, int diax, int diaz) {
        for (int l1 = x - diax; l1 <= x + diax; l1++) {
            for (int i2 = z - diaz; i2 <= z + diaz; i2++) {
                BlockPos blockPos = new BlockPos(l1, y, i2);
                BlockState blockState = level.getBlockState(blockPos);
                if (!blockState.isSolidRender(level, blockPos)) {
                    level.setBlock(blockPos, Blocks.GOLD_BLOCK.defaultBlockState(), 0, 1);
                }
            }
        }
    }

    public boolean place(FeaturePlaceContext<NoneFeatureConfiguration> context) {
        WorldGenLevel worldGenLevel = context.level();
        RandomSource randomSource = context.random();
        BlockPos blockPos = context.origin();
        if (worldGenLevel.getLevel().dimension() != TheTitansDimensions.THE_VOID) {
            return false;
        } else {
            float randomRate = randomSource.nextFloat() * 100.0F;
            if (worldGenLevel.getLevel().dimension() == TheTitansDimensions.THE_VOID) {
                if (blockPos.getX() == 0 && blockPos.getZ() == 0) {
                    this.generateTitan(worldGenLevel, randomSource, new EntityWitherzilla(worldGenLevel.getLevel()), 0, 200, 0, false, true);
                }
            } else if (worldGenLevel.getLevel().dimension() == TheTitansDimensions.THE_NOWHERE) {
                randomRate = randomSource.nextFloat() * 100.0F;
                if ((double)randomRate < 0.002) {
                    int i = blockPos.getX() + randomSource.nextInt(16) + 8;
                    int j = blockPos.getZ() + randomSource.nextInt(16) + 8;
                    int k = worldGenLevel.getHeight(Types.WORLD_SURFACE, i, j);
                    this.generateTitan(worldGenLevel, randomSource, new EntityEnderColossus(worldGenLevel.getLevel()), i, k, j, false, false);
                }
            } else if (worldGenLevel.getLevel().dimension() == Level.NETHER) {
                randomRate = randomSource.nextFloat() * 100.0F;
                if ((double)randomRate < 0.05) {
                    int i = blockPos.getX() + randomSource.nextInt(16) + 8;
                    int j = blockPos.getZ() + randomSource.nextInt(16) + 8;
                    int k = this.getNetherSurface(worldGenLevel, i, j);
                    this.generateTitan(worldGenLevel, randomSource, new EntityMagmaCubeTitan(worldGenLevel.getLevel()), i, k, j, true, true);
                }

                randomRate = randomSource.nextFloat() * 100.0F;
                if ((double)randomRate < 0.025) {
                    int i = blockPos.getX() + randomSource.nextInt(16) + 8;
                    int j = blockPos.getZ() + randomSource.nextInt(16) + 8;
                    int k = this.getNetherSurface(worldGenLevel, i, j);
                    this.generateTitan(worldGenLevel, randomSource, new EntityWitherSkeletonTitan(worldGenLevel.getLevel()), i, k, j, true, false);
                }

                randomRate = randomSource.nextFloat() * 100.0F;
                if ((double)randomRate < 0.05) {
                    int i = blockPos.getX() + randomSource.nextInt(16) + 8;
                    int j = blockPos.getZ() + randomSource.nextInt(16) + 8;
                    int k = this.getNetherSurface(worldGenLevel, i, j);
                    EntityTitan zombifiedPiglinTitan = this.generateTitan(
                        worldGenLevel, randomSource, new EntityZombifiedPiglinTitan(worldGenLevel.getLevel()), i, k, j, true, false
                    );
                    if (zombifiedPiglinTitan != null) {
                        this.generateGold(worldGenLevel, i, k + 4, j, 5, 5);
                        this.generateGold(worldGenLevel, i, k + 3, j, 6, 6);
                        this.generateGold(worldGenLevel, i, k + 2, j, 7, 7);
                        this.generateGold(worldGenLevel, i, k + 1, j, 8, 8);
                        this.generateGold(worldGenLevel, i, k, j, 9, 9);
                    }
                }

                randomRate = randomSource.nextFloat() * 100.0F;
                if ((double)randomRate < 0.025) {
                    int i = blockPos.getX() + randomSource.nextInt(16) + 8;
                    int j = blockPos.getZ() + randomSource.nextInt(16) + 8;
                    int k = this.getNetherSurface(worldGenLevel, i, j);
                    this.generateTitan(worldGenLevel, randomSource, new EntityBlazeTitan(worldGenLevel.getLevel()), i, k, j, true, false);
                }

                randomRate = randomSource.nextFloat() * 100.0F;
                if ((double)randomRate < 0.025) {
                    int i = blockPos.getX() + randomSource.nextInt(16) + 8;
                    int j = blockPos.getZ() + randomSource.nextInt(16) + 8;
                    int k = worldGenLevel.getHeight(Types.WORLD_SURFACE, i, j);
                    this.generateTitan(worldGenLevel, randomSource, new EntityGhastTitan(worldGenLevel.getLevel()), i, k, j, true, false);
                }
            } else if (worldGenLevel.getLevel().dimension() == Level.OVERWORLD) {
                randomRate = randomSource.nextFloat() * 100.0F;
                if ((double)randomRate < 0.1) {
                    int i = blockPos.getX() + randomSource.nextInt(16) + 8;
                    int j = blockPos.getZ() + randomSource.nextInt(16) + 8;
                    int k = worldGenLevel.getHeight(Types.WORLD_SURFACE, i, j);
                    this.generateTitan(worldGenLevel, randomSource, new EntitySlimeTitan(worldGenLevel.getLevel()), i, k, j, true, false);
                }

                randomRate = randomSource.nextFloat() * 100.0F;
                if ((double)randomRate < 0.08) {
                    int i = blockPos.getX() + randomSource.nextInt(16) + 8;
                    int j = blockPos.getZ() + randomSource.nextInt(16) + 8;
                    int k = this.getSurface(worldGenLevel, i, j);
                    this.generateTitan(worldGenLevel, randomSource, new EntityOmegafish(worldGenLevel.getLevel()), i, k, j, true, false);
                }

                randomRate = randomSource.nextFloat() * 100.0F;
                if ((double)randomRate < 0.05) {
                    int i = blockPos.getX() + randomSource.nextInt(16) + 8;
                    int j = blockPos.getZ() + randomSource.nextInt(16) + 8;
                    int k = worldGenLevel.getHeight(Types.WORLD_SURFACE, i, j);
                    this.generateTitan(worldGenLevel, randomSource, new EntityZombieTitan(worldGenLevel.getLevel()), i, k, j, true, false);
                }

                randomRate = randomSource.nextFloat() * 100.0F;
                if ((double)randomRate < 0.05) {
                    int i = blockPos.getX() + randomSource.nextInt(16) + 8;
                    int j = blockPos.getZ() + randomSource.nextInt(16) + 8;
                    int k = worldGenLevel.getHeight(Types.WORLD_SURFACE, i, j);
                    this.generateTitan(worldGenLevel, randomSource, new EntitySkeletonTitan(worldGenLevel.getLevel()), i, k, j, true, false);
                }

                randomRate = randomSource.nextFloat() * 100.0F;
                if ((double)randomRate < 0.05) {
                    int i = blockPos.getX() + randomSource.nextInt(16) + 8;
                    int j = blockPos.getZ() + randomSource.nextInt(16) + 8;
                    int k = worldGenLevel.getHeight(Types.WORLD_SURFACE, i, j);
                    this.generateTitan(worldGenLevel, randomSource, new EntityCreeperTitan(worldGenLevel.getLevel()), i, k, j, true, false);
                }

                randomRate = randomSource.nextFloat() * 100.0F;
                if ((double)randomRate < 0.08) {
                    int i = blockPos.getX() + randomSource.nextInt(16) + 8;
                    int j = blockPos.getZ() + randomSource.nextInt(16) + 8;
                    int k = worldGenLevel.getHeight(Types.WORLD_SURFACE, i, j);
                    EntityTitan spiderTitan = this.generateTitan(
                        worldGenLevel, randomSource, new EntitySpiderTitan(worldGenLevel.getLevel()), i, k, j, true, false
                    );
                    if (spiderTitan != null) {
                        this.generateWeb(worldGenLevel, i, k, j);
                    }
                }

                randomRate = randomSource.nextFloat() * 100.0F;
                if ((double)randomRate < 0.08) {
                    int i = blockPos.getX() + randomSource.nextInt(16) + 8;
                    int j = blockPos.getZ() + randomSource.nextInt(16) + 8;
                    int k = this.getSurface(worldGenLevel, i, j);
                    EntityTitan caveSpiderTitan = this.generateTitan(
                        worldGenLevel, randomSource, new EntityCaveSpiderTitan(worldGenLevel.getLevel()), i, k, j, true, false
                    );
                    if (caveSpiderTitan != null) {
                        this.generateWeb(worldGenLevel, i, k, j);
                    }
                }

                randomRate = randomSource.nextFloat() * 100.0F;
                if ((double)randomRate < 0.0125) {
                    int i = blockPos.getX() + randomSource.nextInt(16) + 8;
                    int j = blockPos.getZ() + randomSource.nextInt(16) + 8;
                    int k = worldGenLevel.getHeight(Types.WORLD_SURFACE, i, j);
                    EntityTitan spiderTitan = this.generateTitan(
                        worldGenLevel, randomSource, new EntitySpiderTitan(worldGenLevel.getLevel()), i, k, j, true, false
                    );
                    EntityTitan skeletonTitan = this.generateTitan(
                        worldGenLevel, randomSource, new EntitySkeletonTitan(worldGenLevel.getLevel()), i, k, j, true, false
                    );
                    if (skeletonTitan != null && spiderTitan != null) {
                        skeletonTitan.startRiding(spiderTitan);
                    }
                }
            }

            return true;
        }
    }
}
