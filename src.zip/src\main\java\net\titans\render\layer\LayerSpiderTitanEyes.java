package net.titans.render.layer;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.titans.entity.titan.EntitySpiderTitan;
import net.titans.model.ModelSpiderTitan;
import net.titans.render.RenderSpiderTitan;

@OnlyIn(Dist.CLIENT)
public class LayerSpiderTitanEyes extends RenderLayer<EntitySpiderTitan, ModelSpiderTitan> {
    public LayerSpiderTitanEyes(RenderLayerParent<EntitySpiderTitan, ModelSpiderTitan> renderer) {
        super(renderer);
    }

    public void render(
        PoseStack poseStack,
        MultiBufferSource multiBufferSource,
        int packedLight,
        EntitySpiderTitan entity,
        float limbSwing,
        float limbSwingAmount,
        float partialTicks,
        float ageInTicks,
        float headYaw,
        float headPitch
    ) {
        VertexConsumer vertexconsumer = multiBufferSource.getBuffer(RenderType.eyes(RenderSpiderTitan.SPIDER_TITAN_EYE));
        ((ModelSpiderTitan)this.getParentModel()).renderToBuffer(poseStack, vertexconsumer, 15728640, OverlayTexture.NO_OVERLAY, 1.0F, 1.0F, 1.0F, 1.0F);
    }
}
