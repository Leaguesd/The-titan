package net.titans.render.minion;

import net.minecraft.client.renderer.entity.CreeperRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider.Context;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.monster.Creeper;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.titans.entity.minion.IMinion;

@OnlyIn(Dist.CLIENT)
public class RenderCreeperTitanMinion extends CreeperRenderer {
    public static final ResourceLocation CREEPER = new ResourceLocation("minecraft", "textures/entity/creeper/creeper.png");
    public static final ResourceLocation CREEPER_PRIEST = ResourceLocation.tryBuild("titan", "textures/entity/minions/creeper/creeper_priest.png");
    public static final ResourceLocation CREEPER_ZEALOT = ResourceLocation.tryBuild("titan", "textures/entity/minions/creeper/creeper_zealot.png");
    public static final ResourceLocation CREEPER_BISHOP = ResourceLocation.tryBuild("titan", "textures/entity/minions/creeper/creeper_bishop.png");
    public static final ResourceLocation CREEPER_TEMPLAR = ResourceLocation.tryBuild("titan", "textures/entity/minions/creeper/creeper_templar.png");

    public RenderCreeperTitanMinion(Context context) {
        super(context);
    }

    public ResourceLocation getTextureLocation(Creeper entity) {
        if (entity instanceof IMinion minion) {
            switch (minion.getMinionType()) {
                case PRIEST:
                    return CREEPER_PRIEST;
                case ZEALOT:
                    return CREEPER_ZEALOT;
                case BISHOP:
                    return CREEPER_BISHOP;
                case TEMPLAR:
                    return CREEPER_TEMPLAR;
                default:
                    return CREEPER;
            }
        } else {
            return super.getTextureLocation(entity);
        }
    }
}
