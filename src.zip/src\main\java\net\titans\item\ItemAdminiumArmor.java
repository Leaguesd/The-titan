package net.titans.item;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Holder;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.registries.Registries;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.util.Mth;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageType;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.OwnableEntity;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.animal.AbstractGolem;
import net.minecraft.world.entity.item.FallingBlockEntity;
import net.minecraft.world.entity.npc.Villager;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ArmorMaterial;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.ArmorItem.Type;
import net.minecraft.world.item.Item.Properties;
import net.minecraft.world.level.GameRules;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.Level.ExplosionInteraction;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.LiquidBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.titans.entity.projectile.EntityHarcadiumArrow;
import net.titans.entity.titan.EntityItemTitan;
import net.titans.entity.titan.EntityTitan;
import net.titans.loader.TheTitansDamageTypes;
import net.titans.loader.TheTitansRegistries;
import net.titans.loader.TheTitansMobEffects;
import net.titans.loader.TheTitansSounds;

public class ItemAdminiumArmor extends ArmorItem {
    public ItemAdminiumArmor(ArmorMaterial material, Type type, Properties properties) {
        super(material, type, properties);
    }

    public boolean isFoil(ItemStack stack) {
        return true;
    }

    public void inventoryTick(ItemStack stack, Level level, Entity entity, int slotId, boolean isSelected) {
        super.inventoryTick(stack, level, entity, slotId, isSelected);
        if (entity instanceof Player player) {
            stack.setDamageValue(stack.getDamageValue() - 10);
            if (this.getEquipmentSlot() == EquipmentSlot.HEAD && slotId == 39) {
                player.playSound((SoundEvent)TheTitansSounds.HARCACADIUM_HUM.get(), 5.0F, 0.5F);
                player.removeEffect(MobEffects.BLINDNESS);
                player.addEffect(new MobEffectInstance(MobEffects.WATER_BREATHING, 300, 0));
                player.addEffect(new MobEffectInstance(MobEffects.NIGHT_VISION, 300, 0));
            } else if (this.getEquipmentSlot() == EquipmentSlot.CHEST && slotId == 38) {
                player.playSound((SoundEvent)TheTitansSounds.HARCACADIUM_HUM.get(), 5.0F, 0.5F);
                player.removeEffect(MobEffects.WEAKNESS);
                player.removeEffect(MobEffects.DIG_SLOWDOWN);
                player.addEffect(new MobEffectInstance(MobEffects.DIG_SPEED, 300, 99));
                player.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 300, 3));
                player.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST, 300, 999));
                player.addEffect(new MobEffectInstance(MobEffects.FIRE_RESISTANCE, 300, 0));
            } else if (this.getEquipmentSlot() == EquipmentSlot.LEGS && slotId == 37) {
                player.playSound((SoundEvent)TheTitansSounds.HARCACADIUM_HUM.get(), 5.0F, 0.0F);
                player.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 300, 199));
                player.removeEffect(MobEffects.CONFUSION);
                player.removeEffect(MobEffects.HUNGER);
                player.removeEffect(MobEffects.POISON);
            } else if (this.getEquipmentSlot() == EquipmentSlot.FEET && slotId == 36) {
                player.playSound((SoundEvent)TheTitansSounds.HARCACADIUM_HUM.get(), 5.0F, 0.5F);
                player.removeEffect(MobEffects.MOVEMENT_SLOWDOWN);
                player.addEffect(new MobEffectInstance(MobEffects.JUMP, 300, 19));
                player.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 300, 39));
            }

            if (player.getItemBySlot(EquipmentSlot.HEAD).getItem() == TheTitansRegistries.ADMINIUM_HELMET.get()
                && player.getItemBySlot(EquipmentSlot.CHEST).getItem() == TheTitansRegistries.ADMINIUM_CHESTPLATE.get()
                && player.getItemBySlot(EquipmentSlot.LEGS).getItem() == TheTitansRegistries.ADMINIUM_LEGGINGS.get()
                && player.getItemBySlot(EquipmentSlot.FEET).getItem() == TheTitansRegistries.ADMINIUM_BOOTS.get()) {
                for (int i = 0; i < 2; i++) {
                    level.addParticle(
                        ParticleTypes.SMOKE,
                        player.getX() + (player.getRandom().nextDouble() - 0.5) * (double)player.getBbWidth(),
                        player.getY() - 1.8 + player.getRandom().nextDouble() * (double)player.getBbHeight(),
                        player.getZ() + (player.getRandom().nextDouble() - 0.5) * (double)player.getBbWidth(),
                        0.0,
                        0.0,
                        0.0
                    );
                    level.addParticle(
                        ParticleTypes.PORTAL,
                        player.getX() + (player.getRandom().nextDouble() - 0.5) * (double)player.getBbWidth(),
                        player.getY() - 1.8 + player.getRandom().nextDouble() * (double)player.getBbHeight(),
                        player.getZ() + (player.getRandom().nextDouble() - 0.5) * (double)player.getBbWidth(),
                        (player.getRandom().nextDouble() - 0.5) * 2.0,
                        -player.getRandom().nextDouble(),
                        (player.getRandom().nextDouble() - 0.5) * 2.0
                    );
                }

                player.getAttribute(Attributes.MAX_HEALTH).setBaseValue(6500.0);
                if (!level.isClientSide() && player.getHealth() < player.getMaxHealth()) {
                    player.heal(95.0F);
                }

                player.addEffect(new MobEffectInstance(MobEffects.SATURATION, 300, 199));
                player.extinguishFire();
                player.fallDistance = 0.0F;
                player.heal(player.getHealth() < player.getMaxHealth() / 4.0F ? 50.0F : 10.0F);

                if (player.getDeltaMovement().y > 3.0) {
                    player.setDeltaMovement(player.getDeltaMovement().x, 0.0, player.getDeltaMovement().z);
                }

                if (player.getHealth() < player.getMaxHealth()) {
                    player.addEffect(new MobEffectInstance(MobEffects.HEAL, 300, 2));
                }

                if (!level.isClientSide()) {
                    for (Entity radiatedEntity : player.level().getEntities(player, player.getBoundingBox().inflate(10.0, 10.0, 10.0))) {
                        if (radiatedEntity != null
                            && radiatedEntity.isAlive()
                            && entity.tickCount % 10 == 0
                            && radiatedEntity instanceof LivingEntity
                            && !(radiatedEntity instanceof EntityTitan)
                            && !(radiatedEntity instanceof AbstractGolem)
                            && !(radiatedEntity instanceof OwnableEntity)
                            && !(radiatedEntity instanceof Villager)) {
                            LivingEntity livingEntity = (LivingEntity)radiatedEntity;
                            if (!(livingEntity instanceof Player)) {
                                Holder<DamageType> damageType = entity.level()
                                    .registryAccess()
                                    .registryOrThrow(Registries.DAMAGE_TYPE)
                                    .getHolderOrThrow(TheTitansDamageTypes.RADIATION);
                                livingEntity.hurt(new DamageSource(damageType), 10.0F);
                                livingEntity.invulnerableTime = 0;
                                livingEntity.addEffect(new MobEffectInstance((MobEffect)TheTitansMobEffects.RADIATION.get(), 5000, 1));
                            }
                        }
                    }

                    List<Entity> entities = player.level().getEntities(player, player.getBoundingBox().inflate(32.0, 8.0, 32.0));
                    BlockPos blockPos = player.blockPosition().below();
                    BlockState blockState = level.getBlockState(blockPos);
                    if (!player.onGround() && blockState.isSolid()) {
                        if (player.getBoundingBox() != null && level.getGameRules().getBoolean(GameRules.RULE_MOBGRIEFING)) {
                            int minX = Mth.floor(player.getBoundingBox().minX - 3.0);
                            int minY = Mth.floor(player.getBoundingBox().minY - 1.0);
                            int minZ = Mth.floor(player.getBoundingBox().minZ - 3.0);
                            int maxX = Mth.floor(player.getBoundingBox().maxX + 3.0);
                            int maxY = Mth.floor(player.getBoundingBox().maxY + 1.0);
                            int maxZ = Mth.floor(player.getBoundingBox().maxZ + 3.0);
                            List<BlockPos> fallBlocks = new ArrayList<>();

                            for (int y = minY; y <= maxY; y++) {
                                for (int x = minX; x <= maxX; x++) {
                                    for (int z = minZ; z <= maxZ; z++) {
                                        BlockPos rangePos = new BlockPos(x, y, z);
                                        BlockState rangeState = level.getBlockState(rangePos);
                                        Block rangeBlock = rangeState.getBlock();
                                        if (player.tickCount > 5
                                            && level.hasChunkAt(rangePos)
                                            && !rangeState.isAir()
                                            && rangeState.getDestroySpeed(level, rangePos) >= 0.0F) {
                                            if (!(rangeBlock instanceof LiquidBlock) && rangeBlock != Blocks.FIRE && rangeBlock != Blocks.COBWEB) {
                                                if (player.getRandom().nextInt(3) == 0) {
                                                    fallBlocks.add(rangePos.immutable());
                                                } else if (level.getNearestPlayer(player, 16.0) != null) {
                                                    level.destroyBlock(rangePos, true);
                                                } else {
                                                    level.setBlockAndUpdate(rangePos, Blocks.AIR.defaultBlockState());
                                                }
                                            } else {
                                                level.setBlockAndUpdate(rangePos, Blocks.AIR.defaultBlockState());
                                            }
                                        }
                                    }
                                }
                            }

                            for (BlockPos rangePos : fallBlocks) {
                                BlockState rangeState = level.getBlockState(rangePos);
                                if (!rangeState.isAir()
                                    && rangeState.getDestroySpeed(level, rangePos) >= 0.0F
                                    && player.getRandom().nextDouble()
                                        < 1.0 * Math.pow((double)fallBlocks.size(), 0.5)) {
                                    FallingBlockEntity fallingBlock = FallingBlockEntity.fall(level, rangePos, rangeState);
                                    double d0 = (player.getBoundingBox().minX + player.getBoundingBox().maxX) / 2.0;
                                    double d1 = (player.getBoundingBox().minZ + player.getBoundingBox().maxZ) / 2.0;
                                    double d2 = fallingBlock.getX() - d0;
                                    double d3 = fallingBlock.getZ() - d1;
                                    double d4 = d2 * d2 + d3 * d3;
                                    fallingBlock.setRemainingFireTicks(10);
                                    if (d4 >= 0.01) {
                                        double d5 = d2 / d4 * 10.0;
                                        double d6 = 2.0 + player.getRandom().nextGaussian();
                                        double d7 = d3 / d4 * 10.0;
                                        fallingBlock.push(d5, d6, d7);
                                    }
                                }
                            }

                            fallBlocks.clear();
                            level.explode(player, player.getX(), player.getY() - 2.0, player.getZ(), 3.0F, ExplosionInteraction.MOB);
                        }

                        for (Entity hurtEntity : entities) {
                            if (hurtEntity != null
                                && hurtEntity instanceof LivingEntity
                                && !(hurtEntity instanceof EntityTitan)
                                && !(hurtEntity instanceof AbstractGolem)
                                && !(hurtEntity instanceof OwnableEntity)
                                && !(hurtEntity instanceof Villager)) {
                                LivingEntity livingEntity = (LivingEntity)hurtEntity;
                                livingEntity.hurt(livingEntity.damageSources().explosion(livingEntity, player), 300.0F);
                                livingEntity.push(0.0, 1.0, 0.0);
                            }
                        }
                    }

                    for (Entity attractedEntity : player.level().getEntities(player, player.getBoundingBox().inflate(48.0, 48.0, 48.0))) {
                        if (attractedEntity != null
                            && !(attractedEntity instanceof EntityTitan)
                            && !(attractedEntity instanceof EntityItemTitan)
                            && !(attractedEntity instanceof EntityHarcadiumArrow)) {
                            double d0 = (player.getX() - attractedEntity.getX()) / 48.0;
                            double d1 = (player.getY() + 1.0 - attractedEntity.getY()) / 48.0;
                            double d2 = (player.getZ() - attractedEntity.getZ()) / 48.0;
                            double d3 = Math.sqrt(d0 * d0 + d1 * d1 + d2 * d2);
                            double d4 = 1.0 - d3;
                            if (d4 > 0.0) {
                                d4 *= d4;
                                double d5 = d0 / d3 * d4 * 0.1;
                                double d6 = d1 / d3 * d4 * 0.1;
                                double d7 = d2 / d3 * d4 * 0.1;
                                attractedEntity.push(d5, d6, d7);
                            }
                        }
                    }

                }

                player.getAttribute(Attributes.KNOCKBACK_RESISTANCE).setBaseValue(1.0);
            } else {
                player.getAttribute(Attributes.KNOCKBACK_RESISTANCE).setBaseValue(0.0);
                if (player.getAttribute(Attributes.MAX_HEALTH).getBaseValue() == 6500.0) {
                    player.getAttribute(Attributes.MAX_HEALTH).setBaseValue(20.0);
                    if (player.getHealth() > player.getMaxHealth()) {
                        player.setHealth(player.getMaxHealth());
                    }
                }
            }
        }
    }
}
