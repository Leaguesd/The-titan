package net.titans.loader;

import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.simple.SimpleChannel;
import net.titans.network.PacketAnimation;

public class TheTitansNetworks {
    private static final String PROTOCOL_VERSION = "1";
    public static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(
        ResourceLocation.tryBuild("titan", "main"), () -> "1", "1"::equals, "1"::equals
    );

    public static void registerNetworks(IEventBus modEventBus) {
        int index = 0;
        CHANNEL.registerMessage(index++, PacketAnimation.class, PacketAnimation::toNetwork, PacketAnimation::fromNetwork, PacketAnimation::handle);
    }
}
