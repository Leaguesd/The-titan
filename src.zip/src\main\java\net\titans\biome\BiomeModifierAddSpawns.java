package net.titans.biome;

import com.mojang.datafixers.util.Either;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.List;
import java.util.function.Function;
import net.minecraft.core.Holder;
import net.minecraft.core.HolderSet;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.level.biome.Biome;
import net.minecraft.world.level.biome.MobSpawnSettings.SpawnerData;
import net.minecraftforge.common.world.BiomeModifier;
import net.minecraftforge.common.world.MobSpawnSettingsBuilder;
import net.minecraftforge.common.world.BiomeModifier.Phase;
import net.minecraftforge.common.world.ModifiableBiomeInfo.BiomeInfo.Builder;

public record BiomeModifierAddSpawns(HolderSet<Biome> biomes, MobCategory category, List<SpawnerData> spawners) implements BiomeModifier {
    public static final Codec<BiomeModifierAddSpawns> CODEC = RecordCodecBuilder.create(
        builder -> builder.group(
                    Biome.LIST_CODEC.fieldOf("biomes").forGetter(BiomeModifierAddSpawns::biomes),
                    MobCategory.CODEC.fieldOf("category").forGetter(BiomeModifierAddSpawns::category),
                    Codec.either(SpawnerData.CODEC.listOf(), SpawnerData.CODEC)
                        .xmap(
                            either -> either.map(Function.identity(), List::of),
                            list -> list.size() == 1 ? Either.right(list.get(0)) : Either.left(list)
                        )
                        .fieldOf("spawners")
                        .forGetter(BiomeModifierAddSpawns::spawners)
                )
                .apply(builder, BiomeModifierAddSpawns::new)
    );

    public static BiomeModifierAddSpawns singleSpawn(HolderSet<Biome> biomes, MobCategory category, SpawnerData spawner) {
        Codec.either(SpawnerData.CODEC.listOf(), SpawnerData.CODEC)
            .xmap(
                either -> either.map(Function.identity(), List::of),
                list -> list.size() == 1 ? Either.right(list.get(0)) : Either.left(list)
            );
        return new BiomeModifierAddSpawns(biomes, category, List.of(spawner));
    }

    public Codec<? extends BiomeModifier> codec() {
        return CODEC;
    }

    public void modify(Holder<Biome> biome, Phase phase, Builder builder) {
        if (phase == Phase.ADD && this.biomes.contains(biome)) {
            MobSpawnSettingsBuilder spawns = builder.getMobSpawnSettings();

            for (SpawnerData spawner : this.spawners) {
                spawns.addSpawn(this.category, spawner);
            }
        }
    }
}
