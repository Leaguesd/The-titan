package net.titans.render;

import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.LivingEntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider.Context;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.titans.entity.titan.EntityOmegafish;
import net.titans.model.ModelOmegafish;
import net.titans.render.layer.LayerOmegafishArmor;

@OnlyIn(Dist.CLIENT)
public class RenderOmegafish extends LivingEntityRenderer<EntityOmegafish, ModelOmegafish> {
    public static final ResourceLocation OMEGAFISH_TITAN = ResourceLocation.tryBuild("titan", "textures/entity/titans/omegafish.png");

    public RenderOmegafish(Context context) {
        super(context, new ModelOmegafish(0.0F), 0.5F);
        this.addLayer(new LayerOmegafishArmor(this));
    }

    public void render(EntityOmegafish entity, float entityYaw, float partialTicks, PoseStack poseStack, MultiBufferSource multiBufferSource, int packedLight) {
        super.render(entity, entityYaw, partialTicks, poseStack, multiBufferSource, packedLight);
    }

    protected void scale(EntityOmegafish entity, PoseStack poseStack, float partialTick) {
        float f1 = 16.0F;
        int i = entity.getInvulTime();
        if (i > 0) {
            f1 -= ((float)i - partialTick) / 440.0F * 7.75F;
        }

        int i2 = entity.getExtraPower();
        if (i2 > 0) {
            f1 += (float)i2 * 0.5F;
        }

        if (entity.isBurrowing) {
            poseStack.translate(0.0F, 8.0F, 0.0F);
        }

        poseStack.scale(f1, f1, f1);
        poseStack.translate(0.0F, 0.01F, 0.0F);
    }

    protected float getShadowRadius(EntityOmegafish entity) {
        return this.shadowRadius * entity.getBbWidth();
    }

    protected boolean shouldShowName(EntityOmegafish entity) {
        return false;
    }

    public ResourceLocation getTextureLocation(EntityOmegafish entity) {
        return OMEGAFISH_TITAN;
    }
}
