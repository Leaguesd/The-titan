package net.titans.entity.titan;

public enum EnumTitanStatus {
    SIMPLE,
    UTILITY,
    LESSER,
    AVERAGE,
    GREATER,
    GOD;
}
