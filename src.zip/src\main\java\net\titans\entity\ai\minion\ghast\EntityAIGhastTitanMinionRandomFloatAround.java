package net.titans.entity.ai.minion.ghast;

import java.util.EnumSet;
import net.minecraft.world.entity.ai.control.MoveControl;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.goal.Goal.Flag;
import net.minecraft.world.entity.player.Player;
import net.titans.entity.minion.EntityGhastTitanMinion;

public class EntityAIGhastTitanMinionRandomFloatAround extends Goal {
    private EntityGhastTitanMinion entity;

    public EntityAIGhastTitanMinionRandomFloatAround(EntityGhastTitanMinion entity) {
        this.entity = entity;
        this.setFlags(EnumSet.of(Flag.MOVE));
    }

    public boolean canUse() {
        MoveControl moveControl = this.entity.getMoveControl();
        if (!moveControl.hasWanted()) {
            return true;
        } else {
            double d0 = moveControl.getWantedX() - this.entity.getX();
            double d1 = moveControl.getWantedY() - this.entity.getY();
            double d2 = moveControl.getWantedZ() - this.entity.getZ();
            double d3 = d0 * d0 + d1 * d1 + d2 * d2;
            return d3 < 1.0 || d3 > 10000.0;
        }
    }

    public boolean canContinueToUse() {
        return false;
    }

    public void start() {
        MoveControl moveControl = this.entity.getMoveControl();
        double d0 = moveControl.getWantedX() - this.entity.getX();
        double d1 = moveControl.getWantedY() - this.entity.getY();
        double d2 = moveControl.getWantedZ() - this.entity.getZ();
        if (this.entity.master != null) {
            double extra = 0.0;
            if (this.entity.getTarget() != null && this.entity.getTarget().getBbHeight() > 4.0F) {
                extra = 64.0;
            }

            double x = this.entity.master.getX();
            double y = this.entity.master.getY() + 32.0 + extra;
            double z = this.entity.master.getZ();
            d0 += this.entity.level().random.nextDouble() * 96.0 - 48.0;
            d1 += this.entity.level().random.nextDouble() * 96.0 - 48.0;
            d2 += this.entity.level().random.nextDouble() * 96.0 - 48.0;
            moveControl.setWantedPosition(x + d0, y + d1, z + d2, 1.0);
        } else if (this.entity.getTarget() != null) {
            double x = this.entity.getTarget().getX() + (this.entity.level().random.nextDouble() * 2.0 - 1.0) * 16.0;
            double y = this.entity.getTarget().getY() + 32.0 + (this.entity.level().random.nextDouble() * 2.0 - 1.0) * 16.0;
            double z = this.entity.getTarget().getZ() + (this.entity.level().random.nextDouble() * 2.0 - 1.0) * 16.0;
            moveControl.setWantedPosition(x, y, z, 1.0);
        } else {
            Player player = this.entity.level().getNearestPlayer(this.entity, 512.0);
            if (player != null) {
                double x = player.getX() + (this.entity.level().random.nextDouble() * 2.0 - 1.0) * 16.0;
                double y = player.getY() + 32.0 + (this.entity.level().random.nextDouble() * 2.0 - 1.0) * 16.0;
                double z = player.getZ() + (this.entity.level().random.nextDouble() * 2.0 - 1.0) * 16.0;
                moveControl.setWantedPosition(x, y, z, 1.0);
            } else {
                double x = this.entity.getX() + (this.entity.level().random.nextDouble() * 2.0 - 1.0) * 16.0;
                double y = this.entity.getY() + (this.entity.level().random.nextDouble() * 2.0 - 1.0) * 16.0;
                double z = this.entity.getZ() + (this.entity.level().random.nextDouble() * 2.0 - 1.0) * 16.0;
                moveControl.setWantedPosition(x, y, z, 1.0);
            }
        }
    }
}
