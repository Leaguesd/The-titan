package net.titans.render;

import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.LivingEntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider.Context;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.titans.entity.EntityWitherTurretGround;
import net.titans.model.ModelWitherTurretGround;

@OnlyIn(Dist.CLIENT)
public class RenderWitherTurretGround extends LivingEntityRenderer<EntityWitherTurretGround, ModelWitherTurretGround> {
    public static final ResourceLocation WITHER = new ResourceLocation("minecraft", "textures/entity/wither/wither.png");

    public RenderWitherTurretGround(Context context) {
        super(context, new ModelWitherTurretGround(), 1.0F);
    }

    public void render(
        EntityWitherTurretGround entity, float entityYaw, float partialTicks, PoseStack poseStack, MultiBufferSource multiBufferSource, int packedLight
    ) {
        super.render(entity, entityYaw, partialTicks, poseStack, multiBufferSource, packedLight);
    }

    protected void scale(EntityWitherTurretGround entity, PoseStack poseStack, float partialTick) {
        poseStack.scale(2.0F, 2.0F, 2.0F);
    }

    protected boolean shouldShowName(EntityWitherTurretGround entity) {
        return false;
    }

    public ResourceLocation getTextureLocation(EntityWitherTurretGround entity) {
        return WITHER;
    }
}
