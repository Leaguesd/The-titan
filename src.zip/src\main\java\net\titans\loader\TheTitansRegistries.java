package net.titans.loader;

import java.util.HashMap;
import java.util.Map;
import net.minecraft.client.renderer.item.ItemProperties;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.valueproviders.UniformInt;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.food.FoodProperties.Builder;
import net.minecraft.world.item.ArmorItem.Type;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.AxeItem;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.HoeItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemNameBlockItem;
import net.minecraft.world.item.PickaxeItem;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.ShovelItem;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.level.ItemLike;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.DropExperienceBlock;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour.Properties;
import net.minecraft.world.level.material.MapColor;
import net.minecraft.world.level.material.PushReaction;
import net.minecraftforge.common.ForgeSpawnEggItem;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.RegistryObject;
import net.titans.block.BlockHarcadiumBlock;
import net.titans.block.BlockHarcadiumOre;
import net.titans.block.BlockMalgrumCrop;
import net.titans.block.BlockPleasantBladeCrop;
import net.titans.block.BlockVoidBlock;
import net.titans.block.BlockVoidOre;
import net.titans.item.ItemAdminiumArmor;
import net.titans.item.ItemAdminiumAxe;
import net.titans.item.ItemAdminiumHoe;
import net.titans.item.ItemAdminiumPickaxe;
import net.titans.item.ItemAdminiumShovel;
import net.titans.item.ItemAdminiumSword;
import net.titans.item.ItemCreepyWitherDoll;
import net.titans.item.ItemFoodMalgrum;
import net.titans.item.ItemGrowthSerum;
import net.titans.item.ItemHarcadium;
import net.titans.item.ItemHarcadiumArmor;
import net.titans.item.ItemHarcadiumAxe;
import net.titans.item.ItemHarcadiumBow;
import net.titans.item.ItemHarcadiumHoe;
import net.titans.item.ItemHarcadiumPickaxe;
import net.titans.item.ItemHarcadiumShovel;
import net.titans.item.ItemHarcadiumSword;
import net.titans.item.ItemMalgrumSeeds;
import net.titans.item.ItemOptimaAxe;
import net.titans.item.ItemPleasantBladeBrew;
import net.titans.item.ItemPleasantBladeFlower;
import net.titans.item.ItemRngRelinquisher;
import net.titans.item.ItemTitanSpawnEgg;
import net.titans.item.ItemUltimaBlade;
import net.titans.item.ItemVoidArmor;
import net.titans.item.ItemVoidAxe;
import net.titans.item.ItemVoidHoe;
import net.titans.item.ItemVoidPickaxe;
import net.titans.item.ItemVoidShovel;
import net.titans.item.ItemVoidSword;
import net.titans.item.ItemWitherTurret;
import net.titans.item.ItemWitherTurretGround;
import net.titans.item.ItemWitherTurretMortar;

/**
 * 泰坦模组的物品与方块注册中心。
 * 方块、方块物品、普通物品集中在这一个类里，不再按「方块 / 物品」拆成两个注册文件；
 * 方块字段声明在方块物品之前，避免静态初始化顺序问题。
 */
public class TheTitansRegistries {
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(Registries.ITEM, "titan");
    public static final Map<Item, Object> ITEMRENDERERS = new HashMap<>();
    public static final Rarity GODLY_RARITY = TheTitansEnumParams.GODLY_RARITY_ENUM_PROXY.getValue();
    public static final DeferredRegister<Block> BLOCKS = DeferredRegister.create(Registries.BLOCK, "titan");

    // ------------------------------ 方块 ------------------------------

    public static final RegistryObject<Block> MALGRUM_CROP_BLOCK = BLOCKS.register(
        "malgrum",
        () -> new BlockMalgrumCrop(
                Properties.of()
                    .mapColor(MapColor.PLANT)
                    .noCollission()
                    .randomTicks()
                    .instabreak()
                    .sound(SoundType.CROP)
                    .pushReaction(PushReaction.DESTROY)
            )
    );
    public static final RegistryObject<Item> MALGRUM_SEEDS = ITEMS
        .register("malgrum_seeds", () -> new ItemMalgrumSeeds((Block)MALGRUM_CROP_BLOCK.get(), new net.minecraft.world.item.Item.Properties()));
    public static final RegistryObject<Block> PLEASANT_BLADE_BLOCK = BLOCKS.register(
        "pleasant_blade",
        () -> new BlockPleasantBladeCrop(
                Properties.of()
                    .mapColor(MapColor.PLANT)
                    .noCollission()
                    .randomTicks()
                    .instabreak()
                    .sound(SoundType.CROP)
                    .pushReaction(PushReaction.DESTROY)
            )
    );
    public static final RegistryObject<Item> PLEASANT_BLADE_SEED = ITEMS
        .register("pleasant_blade_seed", () -> new ItemNameBlockItem((Block)PLEASANT_BLADE_BLOCK.get(), new net.minecraft.world.item.Item.Properties()));
    public static final RegistryObject<Block> NETHER_STONE_ORE_BLOCK = BLOCKS.register(
        "nether_stone_ore",
        () -> new DropExperienceBlock(
                Properties.of().mapColor(MapColor.STONE).requiresCorrectToolForDrops().strength(1.5F, 10.0F).sound(SoundType.STONE), UniformInt.of(0, 1)
            )
    );
    public static final RegistryObject<Block> NETHER_COAL_ORE_BLOCK = BLOCKS.register(
        "nether_coal_ore",
        () -> new DropExperienceBlock(
                Properties.of().mapColor(MapColor.STONE).requiresCorrectToolForDrops().strength(3.0F, 5.0F).sound(SoundType.STONE), UniformInt.of(0, 2)
            )
    );
    public static final RegistryObject<Block> NETHER_GOLD_ORE_BLOCK = BLOCKS.register(
        "nether_gold_ore",
        () -> new DropExperienceBlock(
                Properties.of().mapColor(MapColor.STONE).requiresCorrectToolForDrops().strength(3.0F, 5.0F).sound(SoundType.STONE), UniformInt.of(2, 5)
            )
    );
    public static final RegistryObject<Block> NETHER_DIAMOND_ORE_BLOCK = BLOCKS.register(
        "nether_diamond_ore",
        () -> new DropExperienceBlock(
                Properties.of().mapColor(MapColor.STONE).requiresCorrectToolForDrops().strength(3.0F, 5.0F).sound(SoundType.STONE), UniformInt.of(3, 7)
            )
    );
    public static final RegistryObject<Block> HARCADIUM_ORE_BLOCK = BLOCKS.register(
        "harcadium_ore",
        () -> new BlockHarcadiumOre(Properties.of().mapColor(MapColor.STONE).requiresCorrectToolForDrops().strength(50.0F, 2000.0F).sound(SoundType.STONE))
    );
    public static final RegistryObject<Block> HARCADIUM_ORE_END_STONE_BLOCK = BLOCKS.register(
        "harcadium_ore_end_stone",
        () -> new BlockHarcadiumOre(Properties.of().mapColor(MapColor.STONE).requiresCorrectToolForDrops().strength(50.0F, 2000.0F).sound(SoundType.STONE))
    );
    public static final RegistryObject<Block> HARCADIUM_ORE_OBSIDIAN_BLOCK = BLOCKS.register(
        "harcadium_ore_obsidian",
        () -> new BlockHarcadiumOre(Properties.of().mapColor(MapColor.STONE).requiresCorrectToolForDrops().strength(50.0F, 2000.0F).sound(SoundType.STONE))
    );
    public static final RegistryObject<Block> HARCADIUM_BLOCK_BLOCK = BLOCKS.register(
        "harcadium_block",
        () -> new BlockHarcadiumBlock(
                Properties.of().mapColor(MapColor.STONE).requiresCorrectToolForDrops().strength(100.0F, 18000.0F).lightLevel(state -> 1).sound(SoundType.STONE)
            )
    );
    public static final RegistryObject<Block> VOID_ORE_BLOCK = BLOCKS.register(
        "void_ore",
        () -> new BlockVoidOre(Properties.of().mapColor(MapColor.STONE).requiresCorrectToolForDrops().strength(800.0F, 6000000.0F).sound(SoundType.STONE))
    );
    public static final RegistryObject<Block> VOID_ORE_END_STONE_BLOCK = BLOCKS.register(
        "void_ore_end_stone",
        () -> new BlockVoidOre(Properties.of().mapColor(MapColor.STONE).requiresCorrectToolForDrops().strength(800.0F, 6000000.0F).sound(SoundType.STONE))
    );
    public static final RegistryObject<Block> VOID_ORE_OBSIDIAN_BLOCK = BLOCKS.register(
        "void_ore_obsidian",
        () -> new BlockVoidOre(Properties.of().mapColor(MapColor.STONE).requiresCorrectToolForDrops().strength(800.0F, 6000000.0F).sound(SoundType.STONE))
    );
    public static final RegistryObject<Block> VOID_BLOCK_BLOCK = BLOCKS.register(
        "void_block",
        () -> new BlockVoidBlock(Properties.of().mapColor(MapColor.STONE).requiresCorrectToolForDrops().strength(2400.0F, 1.8E7F).sound(SoundType.STONE))
    );
    public static final RegistryObject<Block> ADAMANTIUM_ORE_BLOCK = BLOCKS.register(
        "adamantium_ore",
        () -> new DropExperienceBlock(
                Properties.of().mapColor(MapColor.STONE).requiresCorrectToolForDrops().strength(-1.0F, 1.0E9F).sound(SoundType.STONE),
                UniformInt.of(1000000000, 1000000000)
            )
    );
    public static final RegistryObject<Block> BEDROCK_COMPACT_BLOCK = BLOCKS.register(
        "bedrock_compact",
        () -> new Block(Properties.of().mapColor(MapColor.STONE).requiresCorrectToolForDrops().strength(-1.0F, 3600000.0F).noLootTable().sound(SoundType.STONE))
    );
    public static final RegistryObject<Item> NETHER_STONE_ORE_BLOCK_ITEM = ITEMS
        .register("nether_stone_ore", () -> new BlockItem((Block)NETHER_STONE_ORE_BLOCK.get(), new net.minecraft.world.item.Item.Properties()));
    public static final RegistryObject<Item> NETHER_COAL_ORE_BLOCK_ITEM = ITEMS
        .register("nether_coal_ore", () -> new BlockItem((Block)NETHER_COAL_ORE_BLOCK.get(), new net.minecraft.world.item.Item.Properties()));
    public static final RegistryObject<Item> NETHER_GOLD_ORE_BLOCK_ITEM = ITEMS
        .register("nether_gold_ore", () -> new BlockItem((Block)NETHER_GOLD_ORE_BLOCK.get(), new net.minecraft.world.item.Item.Properties()));
    public static final RegistryObject<Item> NETHER_DIAMOND_ORE_BLOCK_ITEM = ITEMS
        .register("nether_diamond_ore", () -> new BlockItem((Block)NETHER_DIAMOND_ORE_BLOCK.get(), new net.minecraft.world.item.Item.Properties()));
    public static final RegistryObject<Item> HARCADIUM_ORE_BLOCK_ITEM = ITEMS
        .register("harcadium_ore", () -> new BlockItem((Block)HARCADIUM_ORE_BLOCK.get(), new net.minecraft.world.item.Item.Properties()));
    public static final RegistryObject<Item> HARCADIUM_ORE_END_STONE_BLOCK_ITEM = ITEMS
        .register("harcadium_ore_end_stone", () -> new BlockItem((Block)HARCADIUM_ORE_END_STONE_BLOCK.get(), new net.minecraft.world.item.Item.Properties()));
    public static final RegistryObject<Item> HARCADIUM_ORE_OBSIDIAN_BLOCK_ITEM = ITEMS
        .register("harcadium_ore_obsidian", () -> new BlockItem((Block)HARCADIUM_ORE_OBSIDIAN_BLOCK.get(), new net.minecraft.world.item.Item.Properties()));
    public static final RegistryObject<Item> HARCADIUM_BLOCK_BLOCK_ITEM = ITEMS
        .register("harcadium_block", () -> new BlockItem((Block)HARCADIUM_BLOCK_BLOCK.get(), new net.minecraft.world.item.Item.Properties()));
    public static final RegistryObject<Item> VOID_ORE_BLOCK_ITEM = ITEMS
        .register("void_ore", () -> new BlockItem((Block)VOID_ORE_BLOCK.get(), new net.minecraft.world.item.Item.Properties()));
    public static final RegistryObject<Item> VOID_ORE_END_STONE_BLOCK_ITEM = ITEMS
        .register("void_ore_end_stone", () -> new BlockItem((Block)VOID_ORE_END_STONE_BLOCK.get(), new net.minecraft.world.item.Item.Properties()));
    public static final RegistryObject<Item> VOID_ORE_OBSIDIAN_BLOCK_ITEM = ITEMS
        .register("void_ore_obsidian", () -> new BlockItem((Block)VOID_ORE_OBSIDIAN_BLOCK.get(), new net.minecraft.world.item.Item.Properties()));
    public static final RegistryObject<Item> VOID_BLOCK_BLOCK_ITEM = ITEMS
        .register("void_block", () -> new BlockItem((Block)VOID_BLOCK_BLOCK.get(), new net.minecraft.world.item.Item.Properties()));
    public static final RegistryObject<Item> ADAMANTIUM_ORE_BLOCK_ITEM = ITEMS
        .register("adamantium_ore", () -> new BlockItem((Block)ADAMANTIUM_ORE_BLOCK.get(), new net.minecraft.world.item.Item.Properties()));
    public static final RegistryObject<Item> BEDROCK_COMPACT_BLOCK_ITEM = ITEMS
        .register("bedrock_compact", () -> new BlockItem((Block)BEDROCK_COMPACT_BLOCK.get(), new net.minecraft.world.item.Item.Properties()));


    // ------------------------------ 物品（含方块物品） ------------------------------

    public static final RegistryObject<Item> DIAMOND_STRING = ITEMS.register("diamond_string", () -> new Item(new Item.Properties()));
    public static final RegistryObject<Item> HARCADIUM_WAFLET = ITEMS.register("harcadium_waflet", () -> new ItemHarcadium(new Item.Properties()));
    public static final RegistryObject<Item> HARCADIUM_WAFER = ITEMS.register("harcadium_wafer", () -> new ItemHarcadium(new Item.Properties()));
    public static final RegistryObject<Item> HARCADIUM_NUGGET = ITEMS.register("harcadium_nugget", () -> new ItemHarcadium(new Item.Properties()));
    public static final RegistryObject<Item> HARCADIUM = ITEMS.register("harcadium", () -> new ItemHarcadium(new Item.Properties()));
    public static final RegistryObject<Item> VOID = ITEMS.register("void", () -> new Item(new Item.Properties()));
    public static final RegistryObject<Item> ADAMANTIUM = ITEMS.register("adamantium", () -> new Item(new Item.Properties()));
    public static final RegistryObject<Item> GROWTH_SERUM = ITEMS.register("growth_serum", () -> new ItemGrowthSerum(new Item.Properties()));
    public static final RegistryObject<ItemUltimaBlade> ULTIMA_BLADE = ITEMS.register(
        "ultima_blade", () -> new ItemUltimaBlade(new Item.Properties().rarity(GODLY_RARITY))
    );
    public static final RegistryObject<ItemOptimaAxe> OPTIMA_AXE = ITEMS.register(
        "optima_axe", () -> new ItemOptimaAxe(new Item.Properties().rarity(GODLY_RARITY))
    );
    public static final RegistryObject<Item> HARCADIUM_ARROW = ITEMS.register("harcadium_arrow", () -> new Item(new Item.Properties()));
    public static final RegistryObject<Item> HARCADIUM_BOW = ITEMS.register("harcadium_bow", () -> new ItemHarcadiumBow(new Item.Properties()));
    public static final RegistryObject<Item> HARCADIUM_SWORD = ITEMS.register("harcadium_sword", () -> new ItemHarcadiumSword(new Item.Properties()));
    public static final RegistryObject<Item> HARCADIUM_AXE = ITEMS.register("harcadium_axe", () -> new ItemHarcadiumAxe(new Item.Properties()));
    public static final RegistryObject<Item> HARCADIUM_PICKAXE = ITEMS.register("harcadium_pickaxe", () -> new ItemHarcadiumPickaxe(new Item.Properties()));
    public static final RegistryObject<Item> HARCADIUM_SHOVEL = ITEMS.register("harcadium_shovel", () -> new ItemHarcadiumShovel(new Item.Properties()));
    public static final RegistryObject<Item> HARCADIUM_HOE = ITEMS.register("harcadium_hoe", () -> new ItemHarcadiumHoe(new Item.Properties()));
    public static final RegistryObject<Item> HARCADIUM_HELMET = ITEMS.register(
        "harcadium_helmet", () -> new ItemHarcadiumArmor(TheTitansArmorMaterials.HARCADIUM, Type.HELMET, new Item.Properties().durability(55001))
    );
    public static final RegistryObject<Item> HARCADIUM_CHESTPLATE = ITEMS.register(
        "harcadium_chestplate", () -> new ItemHarcadiumArmor(TheTitansArmorMaterials.HARCADIUM, Type.CHESTPLATE, new Item.Properties().durability(80001))
    );
    public static final RegistryObject<Item> HARCADIUM_LEGGINGS = ITEMS.register(
        "harcadium_leggings", () -> new ItemHarcadiumArmor(TheTitansArmorMaterials.HARCADIUM, Type.LEGGINGS, new Item.Properties().durability(75001))
    );
    public static final RegistryObject<Item> HARCADIUM_BOOTS = ITEMS.register(
        "harcadium_boots", () -> new ItemHarcadiumArmor(TheTitansArmorMaterials.HARCADIUM, Type.BOOTS, new Item.Properties().durability(65001))
    );
    public static final RegistryObject<Item> VOID_SWORD = ITEMS.register("void_sword", () -> new ItemVoidSword(new Item.Properties()));
    public static final RegistryObject<Item> VOID_AXE = ITEMS.register("void_axe", () -> new ItemVoidAxe(new Item.Properties()));
    public static final RegistryObject<Item> VOID_PICKAXE = ITEMS.register("void_pickaxe", () -> new ItemVoidPickaxe(new Item.Properties()));
    public static final RegistryObject<Item> VOID_SHOVEL = ITEMS.register("void_shovel", () -> new ItemVoidShovel(new Item.Properties()));
    public static final RegistryObject<Item> VOID_HOE = ITEMS.register("void_hoe", () -> new ItemVoidHoe(new Item.Properties()));
    public static final RegistryObject<Item> VOID_HELMET = ITEMS.register(
        "void_helmet", () -> new ItemVoidArmor(TheTitansArmorMaterials.VOID, Type.HELMET, new Item.Properties().durability(1100001))
    );
    public static final RegistryObject<Item> VOID_CHESTPLATE = ITEMS.register(
        "void_chestplate", () -> new ItemVoidArmor(TheTitansArmorMaterials.VOID, Type.CHESTPLATE, new Item.Properties().durability(1600001))
    );
    public static final RegistryObject<Item> VOID_LEGGINGS = ITEMS.register(
        "void_leggings", () -> new ItemVoidArmor(TheTitansArmorMaterials.VOID, Type.LEGGINGS, new Item.Properties().durability(1500001))
    );
    public static final RegistryObject<Item> VOID_BOOTS = ITEMS.register(
        "void_boots", () -> new ItemVoidArmor(TheTitansArmorMaterials.VOID, Type.BOOTS, new Item.Properties().durability(1300001))
    );
    public static final RegistryObject<Item> ADMINIUM_SWORD = ITEMS.register(
        "adminium_sword", () -> new ItemAdminiumSword(new Item.Properties().rarity(GODLY_RARITY))
    );
    public static final RegistryObject<Item> ADMINIUM_AXE = ITEMS.register("adminium_axe", () -> new ItemAdminiumAxe(new Item.Properties().rarity(GODLY_RARITY)));
    public static final RegistryObject<Item> ADMINIUM_PICKAXE = ITEMS.register(
        "adminium_pickaxe", () -> new ItemAdminiumPickaxe(new Item.Properties().rarity(GODLY_RARITY))
    );
    public static final RegistryObject<Item> ADMINIUM_SHOVEL = ITEMS.register(
        "adminium_shovel", () -> new ItemAdminiumShovel(new Item.Properties().rarity(GODLY_RARITY))
    );
    public static final RegistryObject<Item> ADMINIUM_HOE = ITEMS.register("adminium_hoe", () -> new ItemAdminiumHoe(new Item.Properties().rarity(GODLY_RARITY)));
    public static final RegistryObject<Item> ADMINIUM_HELMET = ITEMS.register(
        "adminium_helmet",
        () -> new ItemAdminiumArmor(TheTitansArmorMaterials.ADMINIUM, Type.HELMET, new Item.Properties().durability(1100000001).rarity(GODLY_RARITY))
    );
    public static final RegistryObject<Item> ADMINIUM_CHESTPLATE = ITEMS.register(
        "adminium_chestplate",
        () -> new ItemAdminiumArmor(TheTitansArmorMaterials.ADMINIUM, Type.CHESTPLATE, new Item.Properties().durability(1600000001).rarity(GODLY_RARITY))
    );
    public static final RegistryObject<Item> ADMINIUM_LEGGINGS = ITEMS.register(
        "adminium_leggings",
        () -> new ItemAdminiumArmor(TheTitansArmorMaterials.ADMINIUM, Type.LEGGINGS, new Item.Properties().durability(1500000001).rarity(GODLY_RARITY))
    );
    public static final RegistryObject<Item> ADMINIUM_BOOTS = ITEMS.register(
        "adminium_boots",
        () -> new ItemAdminiumArmor(TheTitansArmorMaterials.ADMINIUM, Type.BOOTS, new Item.Properties().durability(1300000001).rarity(GODLY_RARITY))
    );
    public static final RegistryObject<Item> CREEPY_WITHER_DOLL = ITEMS.register("creepy_wither_doll", () -> new ItemCreepyWitherDoll(new Item.Properties()));
    public static final RegistryObject<Item> RNG_RELINQUISHER = ITEMS.register("rng_relinquisher", () -> new ItemRngRelinquisher(new Item.Properties()));
    public static final RegistryObject<Item> WITHER_TURRET = ITEMS.register("wither_turret", () -> new ItemWitherTurret(new Item.Properties().rarity(Rarity.RARE)));
    public static final RegistryObject<Item> WITHER_TURRET_GROUND = ITEMS.register(
        "wither_turret_ground", () -> new ItemWitherTurretGround(new Item.Properties().rarity(Rarity.RARE))
    );
    public static final RegistryObject<Item> WITHER_TURRET_MORTAR = ITEMS.register(
        "wither_turret_mortar", () -> new ItemWitherTurretMortar(new Item.Properties().rarity(Rarity.RARE))
    );
    public static final RegistryObject<Item> SPAWN_EGG_OMEGAFISH_MINION = ITEMS.register(
        "spawn_egg_omegafish_minion",
        () -> new ForgeSpawnEggItem(() -> (EntityType)TheTitansEntities.OMEGAFISH_MINION.get(), 7237230, 3158064, new Item.Properties())
    );
    public static final RegistryObject<Item> SPAWN_EGG_ZOMBIE_TITAN_MINION = ITEMS.register(
        "spawn_egg_zombie_titan_minion",
        () -> new ForgeSpawnEggItem(() -> (EntityType)TheTitansEntities.ZOMBIE_TITAN_MINION.get(), 44975, 7969893, new Item.Properties())
    );
    public static final RegistryObject<Item> SPAWN_EGG_SKELETON_TITAN_MINION = ITEMS.register(
        "spawn_egg_skeleton_titan_minion",
        () -> new ForgeSpawnEggItem(() -> (EntityType)TheTitansEntities.SKELETON_TITAN_MINION.get(), 12698049, 4802889, new Item.Properties())
    );
    public static final RegistryObject<Item> SPAWN_EGG_WITHER_SKELETON_TITAN_MINION = ITEMS.register(
        "spawn_egg_wither_skeleton_titan_minion",
        () -> new ForgeSpawnEggItem(() -> (EntityType)TheTitansEntities.WITHER_SKELETON_TITAN_MINION.get(), 1315860, 4672845, new Item.Properties())
    );
    public static final RegistryObject<Item> SPAWN_EGG_CREEPER_TITAN_MINION = ITEMS.register(
        "spawn_egg_creeper_titan_minion",
        () -> new ForgeSpawnEggItem(() -> (EntityType)TheTitansEntities.CREEPER_TITAN_MINION.get(), 894731, 0, new Item.Properties())
    );
    public static final RegistryObject<Item> SPAWN_EGG_SPIDER_TITAN_MINION = ITEMS.register(
        "spawn_egg_spider_titan_minion",
        () -> new ForgeSpawnEggItem(() -> (EntityType)TheTitansEntities.SPIDER_TITAN_MINION.get(), 3419431, 11013646, new Item.Properties())
    );
    public static final RegistryObject<Item> SPAWN_EGG_CAVE_SPIDER_TITAN_MINION = ITEMS.register(
        "spawn_egg_cave_spider_titan_minion",
        () -> new ForgeSpawnEggItem(() -> (EntityType)TheTitansEntities.CAVE_SPIDER_TITAN_MINION.get(), 803406, 11013646, new Item.Properties())
    );
    public static final RegistryObject<Item> SPAWN_EGG_ZOMBIFIED_PIGLIN_TITAN_MINION = ITEMS.register(
        "spawn_egg_zombified_piglin_titan_minion",
        () -> new ForgeSpawnEggItem(() -> (EntityType)TheTitansEntities.ZOMBIFIED_PIGLIN_TITAN_MINION.get(), 15373203, 5009705, new Item.Properties())
    );
    public static final RegistryObject<Item> SPAWN_EGG_BLAZE_TITAN_MINION = ITEMS.register(
        "spawn_egg_blaze_titan_minion",
        () -> new ForgeSpawnEggItem(() -> (EntityType)TheTitansEntities.BLAZE_TITAN_MINION.get(), 16167425, 16775294, new Item.Properties())
    );
    public static final RegistryObject<Item> SPAWN_EGG_ENDER_COLOSSUS_MINION = ITEMS.register(
        "spawn_egg_ender_colossus_minion",
        () -> new ForgeSpawnEggItem(() -> (EntityType)TheTitansEntities.ENDER_COLOSSUS_MINION.get(), 1447446, 0, new Item.Properties())
    );
    public static final RegistryObject<Item> SPAWN_EGG_GHAST_TITAN_MINION = ITEMS.register(
        "spawn_egg_ghast_titan_minion",
        () -> new ForgeSpawnEggItem(() -> (EntityType)TheTitansEntities.GHAST_TITAN_MINION.get(), 16382457, 12369084, new Item.Properties())
    );
    public static final RegistryObject<Item> SPAWN_EGG_WITHERZILLA_MINION = ITEMS.register(
        "spawn_egg_witherzilla_minion",
        () -> new ForgeSpawnEggItem(() -> (EntityType)TheTitansEntities.WITHERZILLA_MINION.get(), 1315860, 1842204, new Item.Properties())
    );
    public static final RegistryObject<Item> SPAWN_EGG_ZOMBIE_TITAN_GIANT_MINION = ITEMS.register(
        "spawn_egg_zombie_titan_giant_minion",
        () -> new ForgeSpawnEggItem(() -> (EntityType)TheTitansEntities.ZOMBIE_TITAN_GIANT_MINION.get(), 44975, 5870909, new Item.Properties())
    );
    public static final RegistryObject<Item> SPAWN_EGG_GHAST_GUARD_MINION = ITEMS.register(
        "spawn_egg_ghast_guard_minion",
        () -> new ForgeSpawnEggItem(() -> (EntityType)TheTitansEntities.GHAST_GUARD_MINION.get(), 16382457, 12369084, new Item.Properties())
    );
    public static final RegistryObject<Item> SPAWN_EGG_WITHER_MINION = ITEMS.register(
        "spawn_egg_wither_minion", () -> new ForgeSpawnEggItem(() -> (EntityType)TheTitansEntities.WITHER_MINION.get(), 1315860, 1842204, new Item.Properties())
    );
    public static final RegistryObject<Item> SPAWN_EGG_DRAGON_MINION = ITEMS.register(
        "spawn_egg_dragon_minion", () -> new ForgeSpawnEggItem(() -> (EntityType)TheTitansEntities.DRAGON_MINION.get(), 1447446, 13369594, new Item.Properties())
    );
    public static final RegistryObject<Item> SPAWN_EGG_SNOW_GOLEM_TITAN = ITEMS.register(
        "spawn_egg_snow_golem_titan",
        () -> new ItemTitanSpawnEgg(new Item.Properties().rarity(Rarity.UNCOMMON), ResourceLocation.tryBuild("titan", "snow_golem_titan"))
    );
    public static final RegistryObject<Item> SPAWN_EGG_SLIME_TITAN = ITEMS.register(
        "spawn_egg_slime_titan",
        () -> new ItemTitanSpawnEgg(new Item.Properties().rarity(Rarity.UNCOMMON), ResourceLocation.tryBuild("titan", "slime_titan"))
    );
    public static final RegistryObject<Item> SPAWN_EGG_MAGMACUBE_TITAN = ITEMS.register(
        "spawn_egg_magmacube_titan",
        () -> new ItemTitanSpawnEgg(new Item.Properties().rarity(Rarity.UNCOMMON), ResourceLocation.tryBuild("titan", "magmacube_titan"))
    );
    public static final RegistryObject<Item> SPAWN_EGG_OMEGAFISH = ITEMS.register(
        "spawn_egg_omegafish", () -> new ItemTitanSpawnEgg(new Item.Properties().rarity(Rarity.UNCOMMON), ResourceLocation.tryBuild("titan", "omegafish"))
    );
    public static final RegistryObject<Item> SPAWN_EGG_ZOMBIE_TITAN = ITEMS.register(
        "spawn_egg_zombie_titan",
        () -> new ItemTitanSpawnEgg(new Item.Properties().rarity(Rarity.UNCOMMON), ResourceLocation.tryBuild("titan", "zombie_titan"))
    );
    public static final RegistryObject<Item> SPAWN_EGG_SKELETON_TITAN = ITEMS.register(
        "spawn_egg_skeleton_titan",
        () -> new ItemTitanSpawnEgg(new Item.Properties().rarity(Rarity.UNCOMMON), ResourceLocation.tryBuild("titan", "skeleton_titan"))
    );
    public static final RegistryObject<Item> SPAWN_EGG_WITHER_SKELETON_TITAN = ITEMS.register(
        "spawn_egg_wither_skeleton_titan",
        () -> new ItemTitanSpawnEgg(
                new Item.Properties().rarity(Rarity.UNCOMMON), ResourceLocation.tryBuild("titan", "wither_skeleton_titan")
            )
    );
    public static final RegistryObject<Item> SPAWN_EGG_CREEPER_TITAN = ITEMS.register(
        "spawn_egg_creeper_titan",
        () -> new ItemTitanSpawnEgg(new Item.Properties().rarity(Rarity.UNCOMMON), ResourceLocation.tryBuild("titan", "creeper_titan"))
    );
    public static final RegistryObject<Item> SPAWN_EGG_CHARGED_CREEPER_TITAN = ITEMS.register(
        "spawn_egg_charged_creeper_titan",
        () -> new ItemTitanSpawnEgg(
                new Item.Properties().rarity(Rarity.UNCOMMON),
                ResourceLocation.tryBuild("titan", "creeper_titan"),
                1,
                TheTitansSpawns.SPAWNED_CHARGED_CREEPER_TITAN
            )
    );
    public static final RegistryObject<Item> SPAWN_EGG_SPIDER_TITAN = ITEMS.register(
        "spawn_egg_spider_titan",
        () -> new ItemTitanSpawnEgg(new Item.Properties().rarity(Rarity.UNCOMMON), ResourceLocation.tryBuild("titan", "spider_titan"))
    );
    public static final RegistryObject<Item> SPAWN_EGG_CAVE_SPIDER_TITAN = ITEMS.register(
        "spawn_egg_cave_spider_titan",
        () -> new ItemTitanSpawnEgg(new Item.Properties().rarity(Rarity.UNCOMMON), ResourceLocation.tryBuild("titan", "cave_spider_titan"))
    );
    public static final RegistryObject<Item> SPAWN_EGG_SPIDER_JOCKEY_TITAN = ITEMS.register(
        "spawn_egg_spider_jockey_titan",
        () -> new ItemTitanSpawnEgg(
                new Item.Properties().rarity(Rarity.UNCOMMON),
                ResourceLocation.tryBuild("titan", "spider_titan"),
                1,
                TheTitansSpawns.SPAWNED_SPIDER_JOCKEY_TITAN
            )
    );
    public static final RegistryObject<Item> SPAWN_EGG_ZOMBIFIED_PIGLIN_TITAN = ITEMS.register(
        "spawn_egg_zombified_piglin_titan",
        () -> new ItemTitanSpawnEgg(new Item.Properties().rarity(Rarity.UNCOMMON), ResourceLocation.tryBuild("titan", "zombified_piglin_titan"))
    );
    public static final RegistryObject<Item> SPAWN_EGG_BLAZE_TITAN = ITEMS.register(
        "spawn_egg_blaze_titan",
        () -> new ItemTitanSpawnEgg(new Item.Properties().rarity(Rarity.UNCOMMON), ResourceLocation.tryBuild("titan", "blaze_titan"))
    );
    public static final RegistryObject<Item> SPAWN_EGG_ENDER_COLOSSUS = ITEMS.register(
        "spawn_egg_ender_colossus",
        () -> new ItemTitanSpawnEgg(new Item.Properties().rarity(Rarity.UNCOMMON), ResourceLocation.tryBuild("titan", "ender_colossus"))
    );
    public static final RegistryObject<Item> SPAWN_EGG_GHAST_TITAN = ITEMS.register(
        "spawn_egg_ghast_titan",
        () -> new ItemTitanSpawnEgg(new Item.Properties().rarity(Rarity.UNCOMMON), ResourceLocation.tryBuild("titan", "ghast_titan"))
    );
    public static final RegistryObject<Item> SPAWN_EGG_IRON_GOLEM_TITAN = ITEMS.register(
        "spawn_egg_iron_golem_titan",
        () -> new ItemTitanSpawnEgg(new Item.Properties().rarity(Rarity.UNCOMMON), ResourceLocation.tryBuild("titan", "iron_golem_titan"))
    );
    public static final RegistryObject<Item> SPAWN_EGG_WITHERZILLA = ITEMS.register(
        "spawn_egg_witherzilla",
        () -> new ItemTitanSpawnEgg(new Item.Properties().rarity(Rarity.UNCOMMON), ResourceLocation.tryBuild("titan", "witherzilla"))
    );
    public static final RegistryObject<Item> MALGRUM_FRUIT = ITEMS.register(
        "malgrum_fruit",
        () -> new ItemFoodMalgrum(new Item.Properties().food(new Builder().saturationMod(20.0F).nutrition(20).alwaysEat().build()).rarity(Rarity.EPIC))
    );
    public static final RegistryObject<Item> PLEASANT_BLADE_FLOWER = ITEMS.register(
        "pleasant_blade_flower",
        () -> new ItemPleasantBladeFlower(new Item.Properties().food(new Builder().saturationMod(1.2F).nutrition(2).build()).rarity(Rarity.RARE))
    );
    public static final RegistryObject<Item> PLEASANT_BLADE_BREW = ITEMS.register(
        "pleasant_blade_brew", () -> new ItemPleasantBladeBrew(new Item.Properties().food(new Builder().saturationMod(0.0F).nutrition(0).alwaysEat().build()))
    );
    public static final RegistryObject<Item> PLEASANT_BLADE_LEAF = ITEMS.register("pleasant_blade_leaf", () -> new Item(new Item.Properties()));
    public static final RegistryObject<Item> GOLDEN_POTATO = ITEMS.register(
        "golden_potato",
        () -> new Item(
                new Item.Properties()
                    .food(
                        new Builder()
                            .saturationMod(1.2F)
                            .nutrition(6)
                            .effect(() -> new MobEffectInstance(MobEffects.REGENERATION, 100, 1), 1.0F)
                            .effect(() -> new MobEffectInstance(MobEffects.ABSORPTION, 2400, 0), 1.0F)
                            .alwaysEat()
                            .build()
                    )
                    .rarity(Rarity.RARE)
            )
    );
    public static final RegistryObject<Item> ENCHANTED_GOLDEN_POTATO = ITEMS.register(
        "enchanted_golden_potato",
        () -> new Item(
                new Item.Properties()
                    .food(
                        new Builder()
                            .saturationMod(1.2F)
                            .nutrition(6)
                            .effect(() -> new MobEffectInstance(MobEffects.REGENERATION, 400, 1), 1.0F)
                            .effect(() -> new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 6000, 0), 1.0F)
                            .effect(() -> new MobEffectInstance(MobEffects.FIRE_RESISTANCE, 6000, 0), 1.0F)
                            .effect(() -> new MobEffectInstance(MobEffects.ABSORPTION, 2400, 3), 1.0F)
                            .alwaysEat()
                            .build()
                    )
                    .rarity(Rarity.EPIC)
            )
    );
    public static final RegistryObject<Item> GOLDEN_BREAD = ITEMS.register(
        "golden_bread",
        () -> new Item(
                new Item.Properties()
                    .food(
                        new Builder()
                            .saturationMod(1.2F)
                            .nutrition(5)
                            .effect(() -> new MobEffectInstance(MobEffects.REGENERATION, 100, 1), 1.0F)
                            .effect(() -> new MobEffectInstance(MobEffects.ABSORPTION, 2400, 0), 1.0F)
                            .alwaysEat()
                            .build()
                    )
                    .rarity(Rarity.RARE)
            )
    );
    public static final RegistryObject<Item> ENCHANTED_GOLDEN_BREAD = ITEMS.register(
        "enchanted_golden_bread",
        () -> new Item(
                new Item.Properties()
                    .food(
                        new Builder()
                            .saturationMod(1.2F)
                            .nutrition(5)
                            .effect(() -> new MobEffectInstance(MobEffects.REGENERATION, 400, 1), 1.0F)
                            .effect(() -> new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 6000, 0), 1.0F)
                            .effect(() -> new MobEffectInstance(MobEffects.FIRE_RESISTANCE, 6000, 0), 1.0F)
                            .effect(() -> new MobEffectInstance(MobEffects.ABSORPTION, 2400, 3), 1.0F)
                            .alwaysEat()
                            .build()
                    )
                    .rarity(Rarity.EPIC)
            )
    );
    public static final RegistryObject<Item> GOLDEN_COOKIE = ITEMS.register(
        "golden_cookie",
        () -> new Item(
                new Item.Properties()
                    .food(
                        new Builder()
                            .saturationMod(1.2F)
                            .nutrition(2)
                            .effect(() -> new MobEffectInstance(MobEffects.REGENERATION, 100, 1), 1.0F)
                            .effect(() -> new MobEffectInstance(MobEffects.ABSORPTION, 2400, 0), 1.0F)
                            .alwaysEat()
                            .build()
                    )
                    .rarity(Rarity.RARE)
            )
    );
    public static final RegistryObject<Item> ENCHANTED_GOLDEN_COOKIE = ITEMS.register(
        "enchanted_golden_cookie",
        () -> new Item(
                new Item.Properties()
                    .food(
                        new Builder()
                            .saturationMod(1.2F)
                            .nutrition(2)
                            .effect(() -> new MobEffectInstance(MobEffects.REGENERATION, 400, 1), 1.0F)
                            .effect(() -> new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 6000, 0), 1.0F)
                            .effect(() -> new MobEffectInstance(MobEffects.FIRE_RESISTANCE, 6000, 0), 1.0F)
                            .effect(() -> new MobEffectInstance(MobEffects.ABSORPTION, 2400, 3), 1.0F)
                            .alwaysEat()
                            .build()
                    )
                    .rarity(Rarity.EPIC)
            )
    );
    public static final RegistryObject<Item> GOLDEN_MELON = ITEMS.register(
        "golden_melon",
        () -> new Item(
                new Item.Properties()
                    .food(
                        new Builder()
                            .saturationMod(1.2F)
                            .nutrition(2)
                            .effect(() -> new MobEffectInstance(MobEffects.REGENERATION, 100, 1), 1.0F)
                            .effect(() -> new MobEffectInstance(MobEffects.ABSORPTION, 2400, 0), 1.0F)
                            .alwaysEat()
                            .build()
                    )
                    .rarity(Rarity.RARE)
            )
    );
    public static final RegistryObject<Item> ENCHANTED_GOLDEN_MELON = ITEMS.register(
        "enchanted_golden_melon",
        () -> new Item(
                new Item.Properties()
                    .food(
                        new Builder()
                            .saturationMod(1.2F)
                            .nutrition(2)
                            .effect(() -> new MobEffectInstance(MobEffects.REGENERATION, 400, 1), 1.0F)
                            .effect(() -> new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 6000, 0), 1.0F)
                            .effect(() -> new MobEffectInstance(MobEffects.FIRE_RESISTANCE, 6000, 0), 1.0F)
                            .effect(() -> new MobEffectInstance(MobEffects.ABSORPTION, 2400, 3), 1.0F)
                            .alwaysEat()
                            .build()
                    )
                    .rarity(Rarity.EPIC)
            )
    );
    public static final RegistryObject<Item> GOLDEN_PUMPKIN_PIE = ITEMS.register(
        "golden_pumpkin_pie",
        () -> new Item(
                new Item.Properties()
                    .food(
                        new Builder()
                            .saturationMod(1.2F)
                            .nutrition(8)
                            .effect(() -> new MobEffectInstance(MobEffects.REGENERATION, 100, 1), 1.0F)
                            .effect(() -> new MobEffectInstance(MobEffects.ABSORPTION, 2400, 0), 1.0F)
                            .alwaysEat()
                            .build()
                    )
                    .rarity(Rarity.RARE)
            )
    );
    public static final RegistryObject<Item> ENCHANTED_GOLDEN_PUMPKIN_PIE = ITEMS.register(
        "enchanted_golden_pumpkin_pie",
        () -> new Item(
                new Item.Properties()
                    .food(
                        new Builder()
                            .saturationMod(1.2F)
                            .nutrition(8)
                            .effect(() -> new MobEffectInstance(MobEffects.REGENERATION, 400, 1), 1.0F)
                            .effect(() -> new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 6000, 0), 1.0F)
                            .effect(() -> new MobEffectInstance(MobEffects.FIRE_RESISTANCE, 6000, 0), 1.0F)
                            .effect(() -> new MobEffectInstance(MobEffects.ABSORPTION, 2400, 3), 1.0F)
                            .alwaysEat()
                            .build()
                    )
                    .rarity(Rarity.EPIC)
            )
    );
    public static final RegistryObject<Item> DIAMOND_APPLE = ITEMS.register(
        "diamond_apple",
        () -> new Item(
                new Item.Properties()
                    .food(
                        new Builder()
                            .saturationMod(2.4F)
                            .nutrition(4)
                            .effect(() -> new MobEffectInstance(MobEffects.REGENERATION, 100, 2), 1.0F)
                            .effect(() -> new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 2000, 0), 1.0F)
                            .effect(() -> new MobEffectInstance(MobEffects.FIRE_RESISTANCE, 2000, 0), 1.0F)
                            .effect(() -> new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 2000, 0), 1.0F)
                            .effect(() -> new MobEffectInstance(MobEffects.DIG_SPEED, 2000, 0), 1.0F)
                            .alwaysEat()
                            .build()
                    )
                    .rarity(Rarity.RARE)
            )
    );
    public static final RegistryObject<Item> ENCHANTED_DIAMOND_APPLE = ITEMS.register(
        "enchanted_diamond_apple",
        () -> new Item(
                new Item.Properties()
                    .food(
                        new Builder()
                            .saturationMod(2.4F)
                            .nutrition(4)
                            .effect(() -> new MobEffectInstance(MobEffects.REGENERATION, 1200, 9), 1.0F)
                            .effect(() -> new MobEffectInstance(MobEffects.DAMAGE_BOOST, 3000, 2), 1.0F)
                            .effect(() -> new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 6000, 2), 1.0F)
                            .effect(() -> new MobEffectInstance(MobEffects.FIRE_RESISTANCE, 6000, 0), 1.0F)
                            .effect(() -> new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 6000, 1), 1.0F)
                            .effect(() -> new MobEffectInstance(MobEffects.DIG_SPEED, 6000, 1), 1.0F)
                            .alwaysEat()
                            .build()
                    )
                    .rarity(Rarity.EPIC)
            )
    );
    public static final RegistryObject<Item> DIAMOND_POTATO = ITEMS.register(
        "diamond_potato",
        () -> new Item(
                new Item.Properties()
                    .food(
                        new Builder()
                            .saturationMod(2.4F)
                            .nutrition(6)
                            .effect(() -> new MobEffectInstance(MobEffects.REGENERATION, 100, 2), 1.0F)
                            .effect(() -> new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 2000, 0), 1.0F)
                            .effect(() -> new MobEffectInstance(MobEffects.FIRE_RESISTANCE, 2000, 0), 1.0F)
                            .effect(() -> new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 2000, 0), 1.0F)
                            .effect(() -> new MobEffectInstance(MobEffects.DIG_SPEED, 2000, 0), 1.0F)
                            .alwaysEat()
                            .build()
                    )
                    .rarity(Rarity.RARE)
            )
    );
    public static final RegistryObject<Item> ENCHANTED_DIAMOND_POTATO = ITEMS.register(
        "enchanted_diamond_potato",
        () -> new Item(
                new Item.Properties()
                    .food(
                        new Builder()
                            .saturationMod(2.4F)
                            .nutrition(6)
                            .effect(() -> new MobEffectInstance(MobEffects.REGENERATION, 1200, 9), 1.0F)
                            .effect(() -> new MobEffectInstance(MobEffects.DAMAGE_BOOST, 3000, 2), 1.0F)
                            .effect(() -> new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 6000, 2), 1.0F)
                            .effect(() -> new MobEffectInstance(MobEffects.FIRE_RESISTANCE, 6000, 0), 1.0F)
                            .effect(() -> new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 6000, 1), 1.0F)
                            .effect(() -> new MobEffectInstance(MobEffects.DIG_SPEED, 6000, 1), 1.0F)
                            .alwaysEat()
                            .build()
                    )
                    .rarity(Rarity.EPIC)
            )
    );
    public static final RegistryObject<Item> DIAMOND_BREAD = ITEMS.register(
        "diamond_bread",
        () -> new Item(
                new Item.Properties()
                    .food(
                        new Builder()
                            .saturationMod(2.4F)
                            .nutrition(5)
                            .effect(() -> new MobEffectInstance(MobEffects.REGENERATION, 100, 2), 1.0F)
                            .effect(() -> new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 2000, 0), 1.0F)
                            .effect(() -> new MobEffectInstance(MobEffects.FIRE_RESISTANCE, 2000, 0), 1.0F)
                            .effect(() -> new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 2000, 0), 1.0F)
                            .effect(() -> new MobEffectInstance(MobEffects.DIG_SPEED, 2000, 0), 1.0F)
                            .alwaysEat()
                            .build()
                    )
                    .rarity(Rarity.RARE)
            )
    );
    public static final RegistryObject<Item> ENCHANTED_DIAMOND_BREAD = ITEMS.register(
        "enchanted_diamond_bread",
        () -> new Item(
                new Item.Properties()
                    .food(
                        new Builder()
                            .saturationMod(2.4F)
                            .nutrition(5)
                            .effect(() -> new MobEffectInstance(MobEffects.REGENERATION, 1200, 9), 1.0F)
                            .effect(() -> new MobEffectInstance(MobEffects.DAMAGE_BOOST, 3000, 2), 1.0F)
                            .effect(() -> new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 6000, 2), 1.0F)
                            .effect(() -> new MobEffectInstance(MobEffects.FIRE_RESISTANCE, 6000, 0), 1.0F)
                            .effect(() -> new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 6000, 1), 1.0F)
                            .effect(() -> new MobEffectInstance(MobEffects.DIG_SPEED, 6000, 1), 1.0F)
                            .alwaysEat()
                            .build()
                    )
                    .rarity(Rarity.EPIC)
            )
    );
    public static final RegistryObject<Item> DIAMOND_COOKIE = ITEMS.register(
        "diamond_cookie",
        () -> new Item(
                new Item.Properties()
                    .food(
                        new Builder()
                            .saturationMod(2.4F)
                            .nutrition(2)
                            .effect(() -> new MobEffectInstance(MobEffects.REGENERATION, 100, 2), 1.0F)
                            .effect(() -> new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 2000, 0), 1.0F)
                            .effect(() -> new MobEffectInstance(MobEffects.FIRE_RESISTANCE, 2000, 0), 1.0F)
                            .effect(() -> new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 2000, 0), 1.0F)
                            .effect(() -> new MobEffectInstance(MobEffects.DIG_SPEED, 2000, 0), 1.0F)
                            .alwaysEat()
                            .build()
                    )
                    .rarity(Rarity.RARE)
            )
    );
    public static final RegistryObject<Item> ENCHANTED_DIAMOND_COOKIE = ITEMS.register(
        "enchanted_diamond_cookie",
        () -> new Item(
                new Item.Properties()
                    .food(
                        new Builder()
                            .saturationMod(2.4F)
                            .nutrition(2)
                            .effect(() -> new MobEffectInstance(MobEffects.REGENERATION, 1200, 9), 1.0F)
                            .effect(() -> new MobEffectInstance(MobEffects.DAMAGE_BOOST, 3000, 2), 1.0F)
                            .effect(() -> new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 6000, 2), 1.0F)
                            .effect(() -> new MobEffectInstance(MobEffects.FIRE_RESISTANCE, 6000, 0), 1.0F)
                            .effect(() -> new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 6000, 1), 1.0F)
                            .effect(() -> new MobEffectInstance(MobEffects.DIG_SPEED, 6000, 1), 1.0F)
                            .alwaysEat()
                            .build()
                    )
                    .rarity(Rarity.EPIC)
            )
    );
    public static final RegistryObject<Item> DIAMOND_MELON = ITEMS.register(
        "diamond_melon",
        () -> new Item(
                new Item.Properties()
                    .food(
                        new Builder()
                            .saturationMod(2.4F)
                            .nutrition(2)
                            .effect(() -> new MobEffectInstance(MobEffects.REGENERATION, 100, 2), 1.0F)
                            .effect(() -> new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 2000, 0), 1.0F)
                            .effect(() -> new MobEffectInstance(MobEffects.FIRE_RESISTANCE, 2000, 0), 1.0F)
                            .effect(() -> new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 2000, 0), 1.0F)
                            .effect(() -> new MobEffectInstance(MobEffects.DIG_SPEED, 2000, 0), 1.0F)
                            .alwaysEat()
                            .build()
                    )
                    .rarity(Rarity.RARE)
            )
    );
    public static final RegistryObject<Item> ENCHANTED_DIAMOND_MELON = ITEMS.register(
        "enchanted_diamond_melon",
        () -> new Item(
                new Item.Properties()
                    .food(
                        new Builder()
                            .saturationMod(2.4F)
                            .nutrition(2)
                            .effect(() -> new MobEffectInstance(MobEffects.REGENERATION, 1200, 9), 1.0F)
                            .effect(() -> new MobEffectInstance(MobEffects.DAMAGE_BOOST, 3000, 2), 1.0F)
                            .effect(() -> new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 6000, 2), 1.0F)
                            .effect(() -> new MobEffectInstance(MobEffects.FIRE_RESISTANCE, 6000, 0), 1.0F)
                            .effect(() -> new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 6000, 1), 1.0F)
                            .effect(() -> new MobEffectInstance(MobEffects.DIG_SPEED, 6000, 1), 1.0F)
                            .alwaysEat()
                            .build()
                    )
                    .rarity(Rarity.EPIC)
            )
    );
    public static final RegistryObject<Item> DIAMOND_PUMPKIN_PIE = ITEMS.register(
        "diamond_pumpkin_pie",
        () -> new Item(
                new Item.Properties()
                    .food(
                        new Builder()
                            .saturationMod(2.4F)
                            .nutrition(8)
                            .effect(() -> new MobEffectInstance(MobEffects.REGENERATION, 100, 2), 1.0F)
                            .effect(() -> new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 2000, 0), 1.0F)
                            .effect(() -> new MobEffectInstance(MobEffects.FIRE_RESISTANCE, 2000, 0), 1.0F)
                            .effect(() -> new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 2000, 0), 1.0F)
                            .effect(() -> new MobEffectInstance(MobEffects.DIG_SPEED, 2000, 0), 1.0F)
                            .alwaysEat()
                            .build()
                    )
                    .rarity(Rarity.RARE)
            )
    );
    public static final RegistryObject<Item> ENCHANTED_DIAMOND_PUMPKIN_PIE = ITEMS.register(
        "enchanted_diamond_pumpkin_pie",
        () -> new Item(
                new Item.Properties()
                    .food(
                        new Builder()
                            .saturationMod(2.4F)
                            .nutrition(8)
                            .effect(() -> new MobEffectInstance(MobEffects.REGENERATION, 1200, 9), 1.0F)
                            .effect(() -> new MobEffectInstance(MobEffects.DAMAGE_BOOST, 3000, 2), 1.0F)
                            .effect(() -> new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 6000, 2), 1.0F)
                            .effect(() -> new MobEffectInstance(MobEffects.FIRE_RESISTANCE, 6000, 0), 1.0F)
                            .effect(() -> new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 6000, 1), 1.0F)
                            .effect(() -> new MobEffectInstance(MobEffects.DIG_SPEED, 6000, 1), 1.0F)
                            .alwaysEat()
                            .build()
                    )
                    .rarity(Rarity.EPIC)
            )
    );


    // ------------------------------ 注册入口 ------------------------------

    public static void register(IEventBus modEventBus) {
        BLOCKS.register(modEventBus);
        ITEMS.register(modEventBus);
    }

    public static void registerRepairIngredients() {
        TheTitansTiers.HARCADIUM.setRepairIngredient(Ingredient.of(new ItemLike[]{(ItemLike)HARCADIUM.get()}));
        TheTitansTiers.VOID.setRepairIngredient(Ingredient.of(new ItemLike[]{(ItemLike)VOID.get()}));
    }

    public static void initItemProperties() {
        ItemProperties.register(
            (Item)HARCADIUM_BOW.get(),
            ResourceLocation.tryBuild("titan", "pull"),
            (stack, level, entity, i) -> entity == null ? 0.0F : (entity.getUseItem() != stack ? 0.0F : (float)((stack.getUseDuration() - entity.getUseItemRemainingTicks()) / 20))
        );
        ItemProperties.register(
            (Item)HARCADIUM_BOW.get(),
            ResourceLocation.tryBuild("titan", "pulling"),
            (stack, level, entity, i) -> entity != null && entity.isUsingItem() && entity.getUseItem() == stack ? 1.0F : 0.0F
        );
    }

    public static void registerItemRenderers() {
    }
}
