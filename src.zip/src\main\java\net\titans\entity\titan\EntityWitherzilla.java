package net.titans.entity.titan;

import com.google.common.collect.ImmutableList;
import com.google.common.collect.UnmodifiableIterator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import javax.annotation.Nullable;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.TicketType;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.Difficulty;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityDimensions;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.Pose;
import net.minecraft.world.entity.SpawnGroupData;
import net.minecraft.world.entity.Entity.RemovalReason;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier.Builder;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.monster.RangedAttackMob;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.WitherSkull;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.ItemLike;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.ServerLevelAccessor;
import net.minecraft.world.level.Level.ExplosionInteraction;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.WallTorchBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap.Types;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.titans.damage.DamageSourceTitanAttack;
import net.titans.entity.EntityColorLightningBolt;
import net.titans.entity.EntityWitherTurret;
import net.titans.entity.IBossBarDisplay;
import net.titans.entity.ai.EntityAINearestTargetTitan;
import net.titans.entity.minion.EntityWitherzillaMinion;
import net.titans.item.ItemOptimaAxe;
import net.titans.item.ItemTitanSpawnEgg;
import net.titans.item.ItemUltimaBlade;
import net.titans.loader.TheTitansRegistries;
import net.titans.loader.TheTitansDimensions;
import net.titans.loader.TheTitansEntities;
import net.titans.loader.TheTitansRegistries;
import net.titans.loader.TheTitansPredicateTargets;
import net.titans.loader.TheTitansSounds;

public class EntityWitherzilla extends EntityTitan implements RangedAttackMob, IBossBarDisplay {
    private static final EntityDataAccessor<Integer> DATA_TARGET_A = SynchedEntityData.defineId(EntityWitherzilla.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> DATA_TARGET_B = SynchedEntityData.defineId(EntityWitherzilla.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> DATA_TARGET_C = SynchedEntityData.defineId(EntityWitherzilla.class, EntityDataSerializers.INT);
    private static final List<EntityDataAccessor<Integer>> DATA_TARGETS = ImmutableList.of(DATA_TARGET_A, DATA_TARGET_B, DATA_TARGET_C);
    private float[] xRotHeads = new float[2];
    private float[] yRotHeads = new float[2];
    private float[] xRotOHeads = new float[2];
    private float[] yRotOHeads = new float[2];
    private int[] nextHeadUpdate = new int[2];
    private int[] idleHeadUpdates = new int[2];
    public int affectTicks;
    private int attackTimer;
    public int omegaCounter;

    public EntityWitherzilla(EntityType<? extends EntityTitan> entityType, Level level) {
        super(entityType, level);
        this.noPhysics = true;
        this.playSound((SoundEvent)TheTitansSounds.WITHERZILLA_SPAWN.get(), Float.MAX_VALUE, 1.0F);
    }

    public EntityWitherzilla(Level level) {
        this((EntityType<? extends EntityTitan>)TheTitansEntities.WITHERZILLA.get(), level);
    }

    public static Builder createAttributes() {
        return EntityTitan.createAttributes()
            .add(Attributes.MAX_HEALTH, 2.0E7)
            .add(Attributes.ATTACK_DAMAGE, Float.MAX_VALUE)
            .add(Attributes.MOVEMENT_SPEED, 0.5);
    }

    @Override
    public ResourceLocation getBossBarTexture() {
        return ResourceLocation.tryBuild("titan", "textures/gui/bossbar/witherzilla.png");
    }

    @Override
    public int getBossBarNameColor() {
        return 15728880 - (int)(Mth.cos((float)this.tickCount * 0.05F) * 1.572888E7F);
    }

    @Override
    public int getBossBarHealthColor() {
        return 15728880 - (int)(Mth.cos((float)this.tickCount * 0.05F) * 1.572888E7F);
    }

    @Override
    public int getBossBarWidth() {
        return 185;
    }

    @Override
    public int getBossBarHeight() {
        return 32;
    }

    @Override
    public int getBossBarInterval() {
        return 5;
    }

    @Override
    public int getBossBarVOffset() {
        return 0;
    }

    @Override
    public int getBossBarVHeight() {
        return 0;
    }

    @Override
    public int getBossBarTextOffset() {
        return 7;
    }

    @Override
    protected void registerGoals() {
        super.registerGoals();
        this.goalSelector.removeAllGoals(goal -> true);
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.targetSelector
            .addGoal(0, new EntityAINearestTargetTitan<LivingEntity>(this, LivingEntity.class, 0, false, false, TheTitansPredicateTargets.Witherzilla));
    }

    public int getAlternativeTarget(int head) {
        return (Integer)this.entityData.get(DATA_TARGETS.get(head));
    }

    public void setAlternativeTarget(int targetOffset, int newId) {
        this.entityData.set(DATA_TARGETS.get(targetOffset), newId);
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(DATA_TARGET_A, 0);
        this.entityData.define(DATA_TARGET_B, 0);
        this.entityData.define(DATA_TARGET_C, 0);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
    }

    public boolean isInOmegaForm() {
        return this.level().dimension() != TheTitansDimensions.THE_VOID;
    }

    protected double getHeadX(int head) {
        if (head <= 0) {
            return this.getX();
        } else {
            float f = (this.yBodyRot + (float)(180 * (head - 1))) * (float) (Math.PI / 180.0);
            float f2 = Mth.cos(f);
            return this.getX() + (double)f2 * 1.3 * (double)(this.isInOmegaForm() ? 256.0F : 128.0F);
        }
    }

    protected double getHeadY(int head) {
        return this.getEyeY();
    }

    protected double getHeadZ(int head) {
        if (head <= 0) {
            return this.getZ();
        } else {
            float f = (this.yBodyRot + (float)(180 * (head - 1))) * (float) (Math.PI / 180.0);
            float f2 = Mth.sin(f);
            return this.getZ() + (double)f2 * 1.3 * (double)(this.isInOmegaForm() ? 256.0F : 128.0F);
        }
    }

    public float getHeadXRot(int head) {
        return this.xRotHeads[head];
    }

    public float getHeadYRot(int head) {
        return this.yRotHeads[head];
    }

    private float rotlerp(float angle, float targetAngle, float max) {
        float f = Mth.wrapDegrees(targetAngle - angle);
        if (f > max) {
            f = max;
        }

        if (f < -max) {
            f = -max;
        }

        return angle + f;
    }

    private void createBeaconPortal(int x, int z) {
        int b0 = this.level().getHeight(Types.WORLD_SURFACE, x, z);
        int b1 = 4;

        for (int k = b0 - 1; k <= b0 + 32; k++) {
            for (int l = x - b1; l <= x + b1; l++) {
                for (int i1 = z - b1; i1 <= z + b1; i1++) {
                    double d0 = (double)(l - x);
                    double d1 = (double)(i1 - z);
                    double d2 = d0 * d0 + d1 * d1;
                    if (d2 <= ((double)b1 - 0.5) * ((double)b1 - 0.5)) {
                        if (k < b0) {
                            if (d2 <= ((double)(b1 - 1) - 0.5) * ((double)(b1 - 1) - 0.5)) {
                                this.level().setBlockAndUpdate(new BlockPos(l, k, i1), Blocks.BEDROCK.defaultBlockState());
                            }
                        } else if (k > b0) {
                            this.level().setBlockAndUpdate(new BlockPos(l, k, i1), Blocks.AIR.defaultBlockState());
                        } else if (d2 > ((double)(b1 - 1) - 0.5) * ((double)(b1 - 1) - 0.5)) {
                            this.level().setBlockAndUpdate(new BlockPos(l, k, i1), Blocks.BEDROCK.defaultBlockState());
                        } else {
                            this.level().setBlockAndUpdate(new BlockPos(l, k, i1), Blocks.END_PORTAL.defaultBlockState());
                        }
                    }
                }
            }
        }

        this.level().setBlockAndUpdate(new BlockPos(x, b0 + 0, z), Blocks.BEDROCK.defaultBlockState());
        this.level().setBlockAndUpdate(new BlockPos(x, b0 + 1, z), Blocks.BEDROCK.defaultBlockState());
        this.level().setBlockAndUpdate(new BlockPos(x, b0 + 2, z), Blocks.BEDROCK.defaultBlockState());
        this.level().setBlockAndUpdate(new BlockPos(x - 1, b0 + 2, z), (BlockState)Blocks.WALL_TORCH.defaultBlockState().setValue(WallTorchBlock.FACING, Direction.WEST));
        this.level().setBlockAndUpdate(new BlockPos(x + 1, b0 + 2, z), (BlockState)Blocks.WALL_TORCH.defaultBlockState().setValue(WallTorchBlock.FACING, Direction.EAST));
        this.level().setBlockAndUpdate(new BlockPos(x, b0 + 2, z - 1), (BlockState)Blocks.WALL_TORCH.defaultBlockState().setValue(WallTorchBlock.FACING, Direction.NORTH));
        this.level().setBlockAndUpdate(new BlockPos(x, b0 + 2, z + 1), (BlockState)Blocks.WALL_TORCH.defaultBlockState().setValue(WallTorchBlock.FACING, Direction.SOUTH));
        this.level().setBlockAndUpdate(new BlockPos(x, b0 + 3, z), Blocks.BEDROCK.defaultBlockState());
        this.level().setBlockAndUpdate(new BlockPos(x, b0 + 4, z), Blocks.DIAMOND_BLOCK.defaultBlockState());
        this.level().setBlockAndUpdate(new BlockPos(x + 1, b0 + 4, z + 1), Blocks.DIAMOND_BLOCK.defaultBlockState());
        this.level().setBlockAndUpdate(new BlockPos(x + 1, b0 + 4, z), Blocks.DIAMOND_BLOCK.defaultBlockState());
        this.level().setBlockAndUpdate(new BlockPos(x + 1, b0 + 4, z - 1), Blocks.DIAMOND_BLOCK.defaultBlockState());
        this.level().setBlockAndUpdate(new BlockPos(x - 1, b0 + 4, z + 1), Blocks.DIAMOND_BLOCK.defaultBlockState());
        this.level().setBlockAndUpdate(new BlockPos(x - 1, b0 + 4, z), Blocks.DIAMOND_BLOCK.defaultBlockState());
        this.level().setBlockAndUpdate(new BlockPos(x - 1, b0 + 4, z - 1), Blocks.DIAMOND_BLOCK.defaultBlockState());
        this.level().setBlockAndUpdate(new BlockPos(x, b0 + 4, z + 1), Blocks.DIAMOND_BLOCK.defaultBlockState());
        this.level().setBlockAndUpdate(new BlockPos(x, b0 + 4, z - 1), Blocks.DIAMOND_BLOCK.defaultBlockState());
        this.level().setBlockAndUpdate(new BlockPos(x, b0 + 5, z), Blocks.BEACON.defaultBlockState());
    }

    protected void performRangedAttack(int head, double x, double y, double z, boolean isDangerous) {
        double d0 = this.getHeadX(head);
        double d2 = this.getHeadY(head);
        double d3 = this.getHeadZ(head);
        double d4 = x - d0;
        double d5 = y - d2;
        double d6 = z - d3;
        Vec3 vec3 = new Vec3(d4, d5, d6);
        WitherSkull witherskull = new WitherSkull(this.level(), this, vec3.x, vec3.y, vec3.z);
        witherskull.setOwner(this);
        if (isDangerous) {
            witherskull.setDangerous(true);
        }

        witherskull.setPosRaw(d0, d2, d3);
        this.level().addFreshEntity(witherskull);
    }

    protected void performRangedAttack(int head, LivingEntity target) {
        this.performRangedAttack(
            head, target.getX(), target.getY() + (double)(target.getEyeHeight() * 0.5F), target.getZ(), head == 0 && this.random.nextFloat() < 0.001F
        );
        this.attackEntity(target, 20.0F);
        target.invulnerableTime = 0;
    }

    public void doLightningAttackTo(Entity entity) {
        if (entity != null && entity.isAlive() && !(entity instanceof EntityTitanPart)) {
            if (entity instanceof Player player) {
                player.sendSystemMessage(Component.literal(String.valueOf(this.random.nextInt(1234567890))).withStyle(ChatFormatting.OBFUSCATED));
            }

            if (entity instanceof EntityTitan titan) {
                titan.setInvulTime(titan.getInvulTime() - 20);
                this.attackEntity(titan, 5000.0F);
            } else {
                if (entity instanceof LivingEntity livingEntity) {
                    this.attackEntity(livingEntity, 20.0F);
                    // 玩家在这里只会吃到上面那一次普通伤害（伤害量 = 攻击力），
                    // 不再参与下面这些强制秒杀/强制移除的逻辑
                    boolean isPlayer = livingEntity instanceof Player;
                    if (!isPlayer && (livingEntity.getBbHeight() >= 6.0F || livingEntity.isInvulnerable())) {
                        livingEntity.setHealth(0.0F);
                        livingEntity.hurt(this.damageSources().fellOutOfWorld(), Float.MAX_VALUE);
                        livingEntity.die(this.damageSources().fellOutOfWorld());
                        livingEntity.discard();
                    }

                    if (!isPlayer && (livingEntity.getBbHeight() >= 6.0F || this.affectTicks >= 600)) {
                        livingEntity.setHealth(0.0F);

                        for (int i = 0; i < 50; i++) {
                            this.attackEntity(livingEntity, Float.MAX_VALUE);
                        }
                    }
                } else {
                    DamageSourceTitanAttack damageSource = new DamageSourceTitanAttack(this);
                    entity.hurt(damageSource, 20.0F);
                    entity.discard();
                }

                entity.push(0.0, 0.5, 0.0);
            }

            EntityColorLightningBolt colorLightningBolt = new EntityColorLightningBolt(
                this.level(), this.random.nextFloat(), this.random.nextFloat(), this.random.nextFloat()
            );
            colorLightningBolt.setPos(entity.getX(), entity.getY(), entity.getZ());
            if (!this.level().isClientSide()) {
                this.level().addFreshEntity(colorLightningBolt);
            }

            entity.invulnerableTime = 1;
        }
    }

    @Override
    public SpawnGroupData finalizeSpawn(
        ServerLevelAccessor level, DifficultyInstance difficulty, MobSpawnType spawnType, @Nullable SpawnGroupData spawnGroupData, @Nullable CompoundTag tag
    ) {
        return super.finalizeSpawn(level, difficulty, spawnType, spawnGroupData, null);
    }

    public Component getName() {
        return this.tickCount % 20 >= 3 + this.random.nextInt(3) && this.getInvulTime() < 1000
            ? Component.translatable("entity.titan.witherzilla").withStyle(ChatFormatting.BOLD)
            : Component.literal("Regnator");
    }

    protected EntityDimensions getDefaultDimensions(Pose pose) {
        float width = this.isInOmegaForm() ? 128.0F : 64.0F;
        float height = this.isInOmegaForm() ? 448.0F : 224.0F;
        float eyeHeight = this.isInOmegaForm() ? 380.8F : 190.4F;
        return EntityDimensions.scalable(width, height);
    }

    @Override
    protected void refreshAttributes() {
        if (this.isInOmegaForm()) {
            this.getAttribute(Attributes.MAX_HEALTH).setBaseValue(2.0E7);
            this.getAttribute(Attributes.ATTACK_DAMAGE).setBaseValue(Float.MAX_VALUE);
        } else {
            this.getAttribute(Attributes.MAX_HEALTH).setBaseValue(1.0E7);
            this.getAttribute(Attributes.ATTACK_DAMAGE).setBaseValue(Float.MAX_VALUE);
        }
    }

    @Override
    public boolean canAttackEntity(Entity entity) {
        return super.canAttackEntity(entity)
            && !(entity instanceof EntityWitherzillaMinion)
            && (!(entity instanceof EntityWitherTurret witherTurret) || witherTurret.isPlayerCreated());
    }

    @Override
    public boolean canBeHurtByPlayer() {
        return !this.isInvulnerable() && this.level().getDifficulty() != Difficulty.PEACEFUL;
    }

    @Override
    public boolean shouldMove() {
        return false;
    }

    @Override
    public boolean isArmored() {
        return this.deathTicks <= 0 && this.getHealth() <= this.getTitanMaxHealth() / 2.0F;
    }

    @Override
    public int getMinionCap() {
        return 50;
    }

    @Override
    public boolean canSpawnMinion() {
        boolean flag = this.getInvulTime() > 1 && this.tickCount % 20 == 0;
        float randomRate = this.random.nextFloat() * 100.0F;
        return flag || (double)randomRate < 5.0;
    }

    @Override
    public EnumTitanStatus getTitanStatus() {
        return EnumTitanStatus.GOD;
    }

    @Override
    public int getThreashHold() {
        return 210;
    }

    public float getLightLevelDependentMagicValue() {
        return 1.0F;
    }

    protected SoundEvent getAmbientSound() {
        return (SoundEvent)TheTitansSounds.WITHERZILLA_LIVING.get();
    }

    protected SoundEvent getHurtSound(DamageSource damageSource) {
        return (SoundEvent)TheTitansSounds.WITHERZILLA_GRUNT.get();
    }

    protected SoundEvent getDeathSound() {
        return (SoundEvent)TheTitansSounds.WITHERZILLA_DEATH.get();
    }

    @Override
    protected void pushEntities() {
    }

    public void setDeltaMovement(Vec3 deltaMovement) {
    }

    @Override
    public void setTitanDeltaMovement(Vec3 deltaMovement) {
    }

    @Override
    public void destroyBlocksInAABB(AABB aabb) {
        this.destroyBlocksInAABBGriefingBypass(aabb);
    }

    @Override
    public boolean hurt(DamageSource damageSource, float amount) {
        if (amount >= 100000.0F) {
            amount = 100000.0F;
        }        

        // 这里原本还有一行人为递增 tickCount 的代码：它会让被无敌帧 / 死亡状态
        // 挡掉的攻击也把 tickCount 顶高，导致 EntityTitan 的血量守卫误判为
        // “被外部清零”，在死亡动画期间把血量回滚到死前的值（0 血诈尸）。已删除。
        return super.hurt(damageSource, amount);
    }

    public void kill() {
        if (!this.level().players().isEmpty()) {
            for (Player player : this.level().players()) {
                player.sendSystemMessage(Component.translatable("entity.titan.witherzilla.killattempt"));
            }
        }
    }

    public void performRangedAttack(LivingEntity target, float velocity) {
        if (!(target instanceof EntityTitan) && !(target.getBbHeight() >= 6.0F)) {
            this.performRangedAttack(0, target);
        } else {
            double d0 = this.distanceToSqr(target);
            int knockbackAmount = 2;
            if (d0 < 1000.0 && this.attackTimer <= 0) {
                this.attackTimer = 1 + this.random.nextInt(9);

                for (int i = 0; i < 10; i++) {
                    this.attackEntity(target, Float.MAX_VALUE);
                    if (target instanceof EntityTitan) {
                        EntityTitan titan = (EntityTitan)target;
                        if (titan.getInvulTime() > 1) {
                            titan.setInvulTime(titan.getInvulTime() - 20);
                        }
                    }
                }

                this.knockbackEntity(target, (float)knockbackAmount);
            }
        }
    }

    @Override
    public void aiStep() {
        this.attackTimer--;
        if (this.getInvulTime() > 0) {
            // 这个分支完全跳过了父类 aiStep，重生状态的推进必须在这里补上；
            // 否则 invulTime 会在 0~5 之间来回，isRejuvinating 永远解除不掉。
            this.updateRejuvenation();
            if (this.tickCount % 1 == 0) {
                this.heal(this.getTitanMaxHealth() / 800.0F);
            }

            int i = this.getInvulTime() - 1;
            this.setInvulTime(i);
            if (i <= 0) {                
                if (!this.level().players().isEmpty()) {
                    for (Player player : this.level().players()) {
                        this.level()
                            .playLocalSound(player.blockPosition(), (SoundEvent)TheTitansSounds.WITHERZILLA_SPAWN.get(), SoundSource.MASTER, 10.0F, 1.0F, false);
                    }
                }
            }
        } else {
            super.aiStep();
            if (this.isInOmegaForm()) {
                this.omegaCounter = 600;
                if (this.tickCount % 400 == 0) {
                    Player player = this.level().getNearestPlayer(this, -1.0);
                    if (player != null && !player.getAbilities().invulnerable) {
                        this.setTarget(player);
                    }
                }
            }

            for (int i = 1; i < 3; i++) {
                if (this.tickCount >= this.nextHeadUpdate[i - 1] && this.getTarget() != null) {
                    this.nextHeadUpdate[i - 1] = this.tickCount + this.random.nextInt(20);
                    if (this.idleHeadUpdates[i - 1]++ > 15) {
                        for (int i2 = 0; i2 < 100; i2++) {
                            float f = 100.0F;
                            float f2 = 20.0F;
                            double d0 = Mth.nextDouble(this.random, this.getX() - (double)f, this.getX() + (double)f);
                            double d2 = Mth.nextDouble(this.random, this.getY() - (double)f2, this.getY() + (double)f2);
                            double d3 = Mth.nextDouble(this.random, this.getZ() - (double)f, this.getZ() + (double)f);
                            this.performRangedAttack(i + 1, d0, d2, d3, true);
                        }

                        this.idleHeadUpdates[i - 1] = 0;
                    }

                    int k = this.getAlternativeTarget(i);
                    if (k > 0) {
                        LivingEntity livingEntity = (LivingEntity)this.level().getEntity(k);
                        if (livingEntity != null && livingEntity.isAlive()) {
                            this.performRangedAttack(i + 1, livingEntity);
                            this.nextHeadUpdate[i - 1] = this.tickCount;
                            this.idleHeadUpdates[i - 1] = 0;
                        } else {
                            this.setAlternativeTarget(i, 0);
                        }
                    } else if (this.getTarget() != null && this.getTarget().isAlive()) {
                        this.setAlternativeTarget(i, this.getTarget().getId());
                    } else {
                        this.setAlternativeTarget(i, 0);
                    }
                }
            }

            if (this.getTarget() != null) {
                this.setAlternativeTarget(0, this.getTarget().getId());
            } else {
                this.setAlternativeTarget(0, 0);
            }
        }
    }

    @Override
    protected void dropExperienceOrb() {
        for (int x = 0; x < 250; x++) {
            EntityExperienceOrbTitan experienceOrbTitan = new EntityExperienceOrbTitan(
                this.level(),
                this.getX() + (double)(this.random.nextFloat() * 12.0F - 6.0F),
                this.getY() + 4.0,
                this.getZ() + (double)(this.random.nextFloat() * 12.0F - 6.0F),
                32000
            );
            experienceOrbTitan.push(0.0, 1.0, 0.0);
            this.level().addFreshEntity(experienceOrbTitan);
        }
    }

    @Override
    protected void dropAllItem() {
        Map<ItemStack, Integer> drops = new HashMap<>();
        drops.put(new ItemStack(Blocks.COAL_BLOCK), 1024);
        drops.put(new ItemStack(Blocks.IRON_BLOCK), 512);
        drops.put(new ItemStack(Blocks.GOLD_BLOCK), 512);
        drops.put(new ItemStack(Blocks.EMERALD_BLOCK), 256);
        drops.put(new ItemStack(Blocks.DIAMOND_BLOCK), 256);
        drops.put(new ItemStack(Blocks.DRAGON_EGG), 256);
        drops.put(new ItemStack((ItemLike)TheTitansRegistries.HARCADIUM_BLOCK_BLOCK_ITEM.get()), 128);
        drops.put(new ItemStack((ItemLike)TheTitansRegistries.VOID_BLOCK_BLOCK_ITEM.get()), 128);
        drops.put(new ItemStack((ItemLike)TheTitansRegistries.BEDROCK_COMPACT_BLOCK_ITEM.get()), 128);
        drops.put(new ItemStack((ItemLike)TheTitansRegistries.ULTIMA_BLADE.get()), 1);
        int i = 0;

        while (i < 256) {
            Item item = (Item)BuiltInRegistries.ITEM.byId(this.random.nextInt(BuiltInRegistries.ITEM.size()));
            if (item != null && !(item instanceof ItemUltimaBlade) && !(item instanceof ItemOptimaAxe) && !(item instanceof ItemTitanSpawnEgg)) {
                i++;
                drops.put(new ItemStack(item), 1);
            }
        }

        i = 0;

        while (i < 256) {
            Block block = (Block)BuiltInRegistries.BLOCK.byId(this.random.nextInt(BuiltInRegistries.BLOCK.size()));
            if (block != null) {
                i++;
                drops.put(new ItemStack(block), 1);
            }
        }

        for (Entry<ItemStack, Integer> entry : drops.entrySet()) {
            ItemStack itemStack = entry.getKey();
            int count = entry.getValue();
            if (count > 1) {
                EntityItemTitan itemTitan = new EntityItemTitan(
                    this.level(),
                    this.getX() + (double)(this.random.nextFloat() * 12.0F - 6.0F),
                    this.getY() + 4.0,
                    this.getZ() + (double)(this.random.nextFloat() * 12.0F - 6.0F),
                    itemStack,
                    count
                );
                itemTitan.setPickUpDelay(40);
                this.level().addFreshEntity(itemTitan);
            } else {
                ItemEntity itemEntity = new ItemEntity(
                    this.level(),
                    this.getX() + (double)(this.random.nextFloat() * 12.0F - 6.0F),
                    this.getY() + 4.0,
                    this.getZ() + (double)(this.random.nextFloat() * 12.0F - 6.0F),
                    itemStack
                );
                itemEntity.setPickUpDelay(40);
                this.level().addFreshEntity(itemEntity);
            }
        }
    }

    @Override
    protected void tickTitanDeath() {
        super.tickTitanDeath();
        if (!this.isInOmegaForm()) {
            this.setPos(0.0, 120.0, 0.0);
            this.setYRot((float)(this.deathTicks * 10));
            this.yHeadRot = this.getYRot();
            this.yBodyRot = this.getYRot();
        }

        if (this.deathTicks == 1 && !this.level().players().isEmpty()) {
            for (Player player : this.level().players()) {
                if (!this.level().isClientSide()) {
                    if (this.isInOmegaForm()) {
                        player.sendSystemMessage(Component.translatable("entity.titan.witherzilla.defeat"));
                    } else {
                        player.sendSystemMessage(Component.translatable("entity.titan.witherzilla.death"));
                    }
                }
            }
        }

        if (this.deathTicks > 180 && this.deathTicks % 1 == 0) {
            float f = (this.random.nextFloat() - 0.5F) * 24.0F;
            float f2 = (this.random.nextFloat() - 0.5F) * 80.0F;
            float f3 = (this.random.nextFloat() - 0.5F) * 24.0F;
            this.level()
                .addParticle(ParticleTypes.EXPLOSION, this.getX() + (double)f, this.getY() + 2.0 + (double)f2, this.getZ() + (double)f3, 0.0, 0.0, 0.0);
        }

        if (this.deathTicks >= 200) {
            this.setInvulTime(2000);
        }

        if (this.deathTicks >= 400) {
            this.onDeath();
            this.createBeaconPortal(Mth.floor(this.getX()), Mth.floor(this.getZ()));
            if (!this.level().isClientSide() && !this.isRemoved()) {
                this.removeTitan(RemovalReason.KILLED);
            }
        }
    }

    @Override
    public void tick() {
        super.tick();
        this.refreshTitanAttributes();
        this.refreshDimensions();
        if (this.isInOmegaForm()) {
            if (!this.level().isClientSide()) {
                ServerLevel serverLevel = (ServerLevel)this.level();
                ChunkPos chunkPos = this.chunkPosition();
                serverLevel.getChunkSource().addRegionTicket(TicketType.FORCED, chunkPos, 0, chunkPos);
                if (this.getTarget() != null && this.getTarget() instanceof EntityEnderColossus) {
                    serverLevel.setWeatherParameters(0, 0, false, false);
                } else {
                    serverLevel.setWeatherParameters(0, 1000000, true, true);
                }

                ImmutableList<Entity> entities = ImmutableList.copyOf(serverLevel.getAllEntities());
                UnmodifiableIterator d6 = entities.iterator();

                while (d6.hasNext()) {
                    Entity entity = (Entity)d6.next();
                    if (entity != null
                        && entity != this
                        && entity.isAlive()
                        && !(entity instanceof LightningBolt)
                        && !(entity instanceof WitherSkull)
                        && !(entity instanceof EntityWitherTurret)
                        && !(entity instanceof EntityTitan)
                        && !(entity instanceof Player)) {
                        if (entity instanceof EntityWitherzillaMinion) {
                            if (this.getTarget() != null) {
                                EntityWitherzillaMinion witherzillaMinion = (EntityWitherzillaMinion)entity;
                                witherzillaMinion.setTarget(this.getTarget());
                            }
                        } else if (this.getInvulTime() > 1) {
                            if (entity instanceof LivingEntity) {
                                LivingEntity livingEntity = (LivingEntity)entity;
                                if (livingEntity instanceof Mob mob) {
                                    mob.getNavigation().stop();
                                }

                                livingEntity.setDeltaMovement(livingEntity.getDeltaMovement().x, 0.05 - this.getDeltaMovement().y * 0.2, livingEntity.getDeltaMovement().z);
                                livingEntity.xxa = (float)this.random.nextGaussian();
                                livingEntity.zza = (float)this.random.nextGaussian();
                                livingEntity.setYRot(livingEntity.getYRot() + (float)this.random.nextGaussian() * 10.0F);
                                livingEntity.yHeadRot = livingEntity.getYRot();
                                livingEntity.yBodyRot = livingEntity.getYRot();
                                livingEntity.invulnerableTime = (int)this.random.nextGaussian() * 20;
                            } else {
                                entity.setDeltaMovement(this.random.nextGaussian() * 0.5, this.random.nextGaussian() * 0.5, this.random.nextGaussian() * 0.5);
                                entity.setYRot(entity.getYRot() + 10.0F);
                                entity.invulnerableTime = (int)this.random.nextGaussian() * 20;
                            }
                        } else {
                            this.doLightningAttackTo(entity);
                        }
                    }
                }
            }

            if (this.random.nextInt(2) == 0) {
                for (int l = 0; l < 20; l++) {
                    int m = Mth.floor(this.getX());
                    int n = Mth.floor(this.getY());
                    int k = Mth.floor(this.getZ());
                    int i1 = m + Mth.randomBetweenInclusive(this.random, 10, 100) * Mth.randomBetweenInclusive(this.random, -1, 1);
                    int j1 = n + Mth.randomBetweenInclusive(this.random, 10, 100) * Mth.randomBetweenInclusive(this.random, -1, 1);
                    int k2 = k + Mth.randomBetweenInclusive(this.random, 10, 100) * Mth.randomBetweenInclusive(this.random, -1, 1);
                    EntityColorLightningBolt colorLightningBolt = new EntityColorLightningBolt(
                        this.level(), this.random.nextFloat(), this.random.nextFloat(), this.random.nextFloat()
                    );
                    colorLightningBolt.setPos((double)i1, (double)j1, (double)k2);
                    if (this.random.nextInt(5) == 0 && !this.level().isClientSide()) {
                        this.level().addFreshEntity(colorLightningBolt);
                    }
                }
            }
        } else {
            if (this.distanceToSqr(0.0, 200.0, 0.0) > 50000.0) {
                this.setPos(0.0, 200.0, 0.0);
            }

            List<EntityWitherTurret> entities = this.level().getEntitiesOfClass(EntityWitherTurret.class, this.getBoundingBox().inflate(1024.0, 1024.0, 1024.0));
            if (!entities.isEmpty()) {
                for (EntityWitherTurret entity : entities) {
                    if (entity != null && entity.isAlive() && !entity.isPlayerCreated()) {
                        this.setPos(0.0, 200.0, 0.0);
                        this.setYRot(0.0F);
                        this.yHeadRot = 0.0F;
                        this.yBodyRot = 0.0F;
                        this.setTarget(null);

                        for (int i = 0; i < 3; i++) {
                            this.setAlternativeTarget(i, 0);
                        }
                    }
                }
            } else if (this.getY() > 100.0) {
                this.setPos(this.getX(), this.getY() - 1.0, this.getZ());
            }
        }

        this.affectTicks++;
        if (this.affectTicks >= 800) {
            this.setInvisible(true);
        } else {
            this.setInvisible(false);
        }

        if (this.affectTicks >= 1010) {
            this.affectTicks = 0;
        }

        this.omegaCounter--;
        if (!this.level().isClientSide()) {
            ServerLevel serverLevel = (ServerLevel)this.level();
            serverLevel.setDayTime(18000L);
        }

        if (this.getTarget() != null && !this.getTarget().isAlive()) {
            this.setTarget(null);
        }

        if (!this.isArmored()) {
            this.setTitanDeltaMovement(this.getDeltaMovement().x, this.getDeltaMovement().y * 0.1, this.getDeltaMovement().z);
        } else {
            this.setTitanDeltaMovement(this.getDeltaMovement().x, this.getDeltaMovement().y * 0.9, this.getDeltaMovement().z);
        }

        if (!this.level().players().isEmpty() && this.random.nextInt(4) == 0) {
            for (Player player : this.level().players()) {
                if (this.random.nextInt(100) == 0) {
                    this.playAmbientSound();
                    if (this.isInOmegaForm()) {
                        this.attackEntity(player, 10.0F);
                        player.sendSystemMessage(Component.translatable("entity.titan.witherzilla.taunt." + this.random.nextInt(6)));
                    } else {
                        player.sendSystemMessage(Component.translatable("entity.titan.witherzilla.plead." + this.random.nextInt(6)));
                    }
                }
            }
        }

        if (this.getTarget() != null && (this.affectTicks >= 600 || this.getTarget().getBbHeight() > 6.0F && !(this.getTarget() instanceof EntityTitan))) {
            if (this.random.nextInt(120) == 0 && !this.level().isClientSide()) {
                this.level()
                    .explode(this, this.getTarget().getX(), this.getTarget().getY(), this.getTarget().getZ(), 14.0F, true, ExplosionInteraction.MOB);
            }

            this.doLightningAttackTo(this.getTarget());

            for (int i = 0; i < 19; i++) {
                this.doLightningAttackTo(this.getTarget());
                this.getTarget().hurt(this.damageSources().fellOutOfWorld(), 1.0F);
            }
        }

        if (this.getAlternativeTarget(0) > 0) {
            Entity entityx = this.level().getEntity(this.getAlternativeTarget(0));
            if (entityx != null) {
                double d0 = entityx.getX() - this.getX();
                double d1 = entityx.getY() + (this.isArmored() ? 2.0 : 12.0) - this.getY();
                double d2 = entityx.getZ() - this.getZ();
                double d3 = d0 * d0 + d1 * d1 + d2 * d2;
                this.getLookControl().setLookAt(entityx, 180.0F, 40.0F);
                if (entityx instanceof LivingEntity && d3 < 10000.0) {
                    LivingEntity livingEntity = (LivingEntity)entityx;
                    this.performRangedAttack(livingEntity, 0.0F);
                }

                if (d3 > 64.0) {
                    double d4 = Math.sqrt(d3);
                    this.setTitanDeltaMovement(
                        this.getDeltaMovement()
                            .add(
                                d0 / d4 * 1.5 - this.getDeltaMovement().x, d1 / d4 * 1.5 - this.getDeltaMovement().y, d2 / d4 * 1.5 - this.getDeltaMovement().z
                            )
                    );
                    this.setYRot((float)Math.atan2(this.getDeltaMovement().z, this.getDeltaMovement().x) * 180.0F / (float) Math.PI - 90.0F);
                    this.yBodyRot = this.getYRot();
                }
            }
        }

        for (int i = 0; i < 2; i++) {
            this.yRotOHeads[i] = this.yRotHeads[i];
            this.xRotOHeads[i] = this.xRotHeads[i];
        }

        for (int j = 0; j < 2; j++) {
            int k = this.getAlternativeTarget(j + 1);
            Entity entityx = null;
            if (k > 0) {
                entityx = this.level().getEntity(k);
            }

            if (entityx != null) {
                double d6 = this.getHeadX(j + 1);
                double d7 = this.getHeadY(j + 1);
                double d4 = this.getHeadZ(j + 1);
                double d8 = entityx.getX() - d6;
                double d9 = entityx.getEyeY() - d7;
                double d10 = entityx.getZ() - d4;
                double d11 = Math.sqrt(d8 * d8 + d10 * d10);
                float f1 = (float)(Mth.atan2(d10, d8) * 180.0 / (float) Math.PI) - 90.0F;
                float f2 = (float)(-(Mth.atan2(d9, d11) * 180.0 / (float) Math.PI));
                this.xRotHeads[j] = this.rotlerp(this.xRotHeads[j], f2, 5.0F);
                this.yRotHeads[j] = this.rotlerp(this.yRotHeads[j], f1, 5.0F);
            } else {
                if (this.random.nextInt(120) == 0) {
                    for (int var34 = 0; var34 < 36; var34++) {
                        this.xRotHeads[j] = this.rotlerp(this.xRotHeads[j], this.random.nextFloat() * 360.0F - 180.0F, 5.0F);
                    }
                }

                if (this.random.nextInt(120) == 0) {
                    for (int var35 = 0; var35 < 36; var35++) {
                        this.yRotHeads[j] = this.rotlerp(this.yRotHeads[j], this.random.nextFloat() * 360.0F - 180.0F, 5.0F);
                    }
                }
            }
        }

        boolean flag = this.isArmored();

        for (int lx = 0; lx < 100; lx++) {
            double d12 = this.getHeadX(lx);
            double d13 = this.getHeadY(lx);
            double d14 = this.getHeadZ(lx);
            float f = 0.3F * this.getScale();
            this.level()
                .addParticle(
                    ParticleTypes.SMOKE,
                    d12 + this.random.nextGaussian() * (double)f,
                    d13 + this.random.nextGaussian() * (double)f,
                    d14 + this.random.nextGaussian() * (double)f,
                    0.0,
                    0.0,
                    0.0
                );
            if (flag && this.level().random.nextInt(4) == 0) {
                this.level()
                    .addParticle(
                        ParticleTypes.ENTITY_EFFECT,
                        d12 + this.random.nextGaussian() * (double)f,
                        d13 + this.random.nextGaussian() * (double)f,
                        d14 + this.random.nextGaussian() * (double)f,
                        0.7,
                        0.7,
                        0.5
                    );
            }
        }
    }
}
