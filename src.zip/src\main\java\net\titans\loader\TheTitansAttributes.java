package net.titans.loader;

import net.minecraft.core.registries.Registries;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.RangedAttribute;
import net.minecraftforge.event.entity.EntityAttributeModificationEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.RegistryObject;

public class TheTitansAttributes {
    public static final DeferredRegister<Attribute> ATTRIBUTES = DeferredRegister.create(Registries.ATTRIBUTE, "titan");
    public static final RegistryObject<Attribute> TITAN_RESISTANCE = ATTRIBUTES.register(
        "generic.titan_resistance", () -> new RangedAttribute("attribute.name.generic.titan_resistance", 0.0, 0.0, 100.0).setSyncable(true)
    );
    public static final RegistryObject<Attribute> TITAN_KNOCKBACK_RESISTANCE = ATTRIBUTES.register(
        "generic.titan_knockback_resistance", () -> new RangedAttribute("attribute.name.generic.titan_knockback_resistance", 0.0, 0.0, 100.0).setSyncable(true)
    );

    public static void registerAttributes(IEventBus modEventBus) {
        ATTRIBUTES.register(modEventBus);
        modEventBus.addListener(TheTitansAttributes::onEntityAttributeModification);
    }

    @SubscribeEvent
    public static void onEntityAttributeModification(EntityAttributeModificationEvent event) {
        for (EntityType<? extends LivingEntity> entityType : event.getTypes()) {
            event.add(entityType, (Attribute)TITAN_RESISTANCE.get(), 0.0);
            event.add(entityType, (Attribute)TITAN_KNOCKBACK_RESISTANCE.get(), 0.0);
        }
    }
}
