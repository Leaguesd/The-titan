package net.titans.entity.ai.endercolossus;

import net.titans.animation.AIAnimation;
import net.titans.entity.titan.EntityEnderColossus;

public class AnimationEnderColossusChainLightning extends AIAnimation {
    private EntityEnderColossus entity;

    public AnimationEnderColossusChainLightning(EntityEnderColossus entity) {
        super(entity);
        this.entity = entity;
    }

    @Override
    public int getAnimationID() {
        return 3;
    }

    @Override
    public boolean isAutomatic() {
        return true;
    }

    @Override
    public int getDuration() {
        return 110;
    }

    @Override
    public boolean canContinueToUse() {
        return this.entity.getAnimationTick() <= this.getDuration() && !this.entity.isStunned ? super.canContinueToUse() : false;
    }

    public void tick() {
        if (this.entity.getTarget() != null && this.entity.getAnimationTick() < 40) {
            this.entity.getLookControl().setLookAt(this.entity.getTarget(), 5.0F, 40.0F);
        }
    }
}
