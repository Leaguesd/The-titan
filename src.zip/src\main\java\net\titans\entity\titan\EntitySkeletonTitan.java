package net.titans.entity.titan;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.Mth;
import net.minecraft.world.Difficulty;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityDimensions;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.Pose;
import net.minecraft.world.entity.SpawnGroupData;
import net.minecraft.world.entity.Entity.RemovalReason;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier.Builder;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.ItemLike;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.ServerLevelAccessor;
import net.minecraft.world.level.Level.ExplosionInteraction;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;
import net.titans.entity.EntityColorLightningBolt;
import net.titans.entity.IBossBarDisplay;
import net.titans.entity.ai.EntityAINearestTargetTitan;
import net.titans.entity.ai.skeletontitan.AnimationSkeletonTitanAntiTitanAttack;
import net.titans.entity.ai.skeletontitan.AnimationSkeletonTitanAttack1;
import net.titans.entity.ai.skeletontitan.AnimationSkeletonTitanAttack2;
import net.titans.entity.ai.skeletontitan.AnimationSkeletonTitanAttack3;
import net.titans.entity.ai.skeletontitan.AnimationSkeletonTitanAttack4;
import net.titans.entity.ai.skeletontitan.AnimationSkeletonTitanAttack5;
import net.titans.entity.ai.skeletontitan.AnimationSkeletonTitanCreation;
import net.titans.entity.ai.skeletontitan.AnimationSkeletonTitanDeath;
import net.titans.entity.ai.skeletontitan.AnimationSkeletonTitanLightningHand;
import net.titans.entity.ai.skeletontitan.AnimationSkeletonTitanLightningSword;
import net.titans.entity.ai.skeletontitan.AnimationSkeletonTitanRangedAttack1;
import net.titans.entity.ai.skeletontitan.AnimationSkeletonTitanRangedAttack2;
import net.titans.entity.ai.skeletontitan.AnimationSkeletonTitanStun;
import net.titans.entity.minion.EntitySkeletonTitanMinion;
import net.titans.entity.minion.EntityWitherMinion;
import net.titans.entity.minion.EntityWitherSkeletonTitanMinion;
import net.titans.entity.minion.EnumMinionType;
import net.titans.entity.projectile.EntityArrowTitan;
import net.titans.entity.projectile.EntityHarcadiumArrow;
import net.titans.loader.TheTitansEntities;
import net.titans.loader.TheTitansRegistries;
import net.titans.loader.TheTitansMobEffects;
import net.titans.loader.TheTitansPredicateTargets;
import net.titans.loader.TheTitansSounds;
import net.titans.util.AnimationUtils;

public class EntitySkeletonTitan extends EntityTitan implements IEntityMultiPartTitan, IBossBarDisplay {
    public final EntityTitanPart head = new EntityTitanPart(this, "head", 8.0F, 8.0F);
    public final EntityTitanPart pelvis = new EntityTitanPart(this, "pelvis", 8.0F, 6.0F);
    public final EntityTitanPart spine = new EntityTitanPart(this, "spine", 2.0F, 12.0F);
    public final EntityTitanPart ribCage = new EntityTitanPart(this, "ribcage", 8.0F, 8.0F);
    public final EntityTitanPart leftArm = new EntityTitanPart(this, "leftarm", 2.0F, 2.0F);
    public final EntityTitanPart rightArm = new EntityTitanPart(this, "rightarm", 2.0F, 2.0F);
    public final EntityTitanPart leftLeg = new EntityTitanPart(this, "leftleg", 2.0F, 12.0F);
    public final EntityTitanPart rightLeg = new EntityTitanPart(this, "rightleg", 2.0F, 12.0F);
    public boolean isStunned;
    public int attackTimer;

    public EntitySkeletonTitan(EntityType<? extends EntityTitan> entityType, Level level) {
        super(entityType, level);
        this.parts = new EntityTitanPart[]{this.head, this.pelvis, this.spine, this.ribCage, this.leftArm, this.rightArm, this.leftLeg, this.rightLeg};
    }

    public EntitySkeletonTitan(Level level) {
        this((EntityType<? extends EntityTitan>)TheTitansEntities.SKELETON_TITAN.get(), level);
    }

    public static Builder createAttributes() {
        return EntityTitan.createAttributes().add(Attributes.MAX_HEALTH, 40000.0).add(Attributes.ATTACK_DAMAGE, 1200.0);
    }

    @Override
    public ResourceLocation getBossBarTexture() {
        return this.getSkeletonType() == 1
            ? ResourceLocation.tryBuild("titan", "textures/gui/bossbar/wither_skeleton_titan.png")
            : ResourceLocation.tryBuild("titan", "textures/gui/bossbar/skeleton_titan.png");
    }

    @Override
    public int getBossBarNameColor() {
        return this.getSkeletonType() == 1 ? 4802889 : 12698049;
    }

    @Override
    public int getBossBarWidth() {
        return 185;
    }

    @Override
    public int getBossBarHeight() {
        return 24;
    }

    @Override
    public int getBossBarInterval() {
        return 5;
    }

    @Override
    public int getBossBarVOffset() {
        return 0;
    }

    @Override
    public int getBossBarVHeight() {
        return 0;
    }

    @Override
    public int getBossBarTextOffset() {
        return 7;
    }

    @Override
    protected void registerGoals() {
        super.registerGoals();
        this.footID = 1;
        this.goalSelector.addGoal(1, new AnimationSkeletonTitanCreation(this));
        this.goalSelector.addGoal(1, new AnimationSkeletonTitanDeath(this));
        this.goalSelector.addGoal(1, new AnimationSkeletonTitanAntiTitanAttack(this));
        this.goalSelector.addGoal(1, new AnimationSkeletonTitanAttack1(this));
        this.goalSelector.addGoal(1, new AnimationSkeletonTitanAttack2(this));
        this.goalSelector.addGoal(1, new AnimationSkeletonTitanAttack3(this));
        this.goalSelector.addGoal(1, new AnimationSkeletonTitanAttack4(this));
        this.goalSelector.addGoal(1, new AnimationSkeletonTitanAttack5(this));
        this.goalSelector.addGoal(1, new AnimationSkeletonTitanLightningHand(this));
        this.goalSelector.addGoal(1, new AnimationSkeletonTitanLightningSword(this));
        this.goalSelector.addGoal(1, new AnimationSkeletonTitanRangedAttack1(this));
        this.goalSelector.addGoal(1, new AnimationSkeletonTitanRangedAttack2(this));
        this.goalSelector.addGoal(1, new AnimationSkeletonTitanStun(this));
        this.targetSelector.addGoal(0, new EntityAINearestTargetTitan(this, EntitySnowGolemTitan.class, false));
        this.targetSelector.addGoal(0, new EntityAINearestTargetTitan(this, EntityIronGolemTitan.class, false));
        this.targetSelector
            .addGoal(0, new EntityAINearestTargetTitan<LivingEntity>(this, LivingEntity.class, 0, false, false, TheTitansPredicateTargets.SkeletonTitan));
    }

    /**
     * 0 = 普通骷髅泰坦，1 = 凋灵骷髅泰坦。
     *
     * <p>凋灵骷髅泰坦已独立成 {@link EntityWitherSkeletonTitan} 并在子类里覆写为 1。
     * 这样基类构造阶段（{@code EntityTitan} 构造器里的 refreshTitanAttributes()）就能读到正确类型，
     * 直接把最大生命值和当前血量都初始化为凋灵档位。
     */
    public int getSkeletonType() {
        return 0;
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        // 旧存档里的 SkeletonType 字段不再使用：凋灵骷髅泰坦现在是独立的实体类型。
        this.isStunned = tag.getBoolean("IsStunned");
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putBoolean("IsStunned", this.isStunned);
    }

    @Override
    public SpawnGroupData finalizeSpawn(
        ServerLevelAccessor level, DifficultyInstance difficulty, MobSpawnType spawnType, @Nullable SpawnGroupData spawnGroupData, @Nullable CompoundTag tag
    ) {
        SpawnGroupData groupData = super.finalizeSpawn(level, difficulty, spawnType, spawnGroupData, null);
        this.setWaiting(true);
        return groupData;
    }

    public Component getName() {
        return this.getSkeletonType() == 1
            ? Component.translatable("entity.titan.wither_skeleton_titan")
            : Component.translatable("entity.titan.skeleton_titan");
    }

    protected EntityDimensions getDefaultDimensions(Pose pose) {
        float width = this.getSkeletonType() == 1 ? 14.0F : 8.0F;
        float height = this.getSkeletonType() == 1 ? 56.0F : 32.0F;
        float eyeHeight = this.getSkeletonType() == 1 ? 46.68F : 28.0F;
        return EntityDimensions.scalable(width, height);
    }

    @Override
    protected void refreshAttributes() {
        if (this.level().getDifficulty() == Difficulty.HARD) {
            this.getAttribute(Attributes.MAX_HEALTH).setBaseValue(40000.0 + (double)this.getExtraPower() * 2000.0);
            this.getAttribute(Attributes.ATTACK_DAMAGE).setBaseValue(1200.0 + (double)this.getExtraPower() * 60.0);
        } else {
            this.getAttribute(Attributes.MAX_HEALTH).setBaseValue(20000.0 + (double)this.getExtraPower() * 1000.0);
            this.getAttribute(Attributes.ATTACK_DAMAGE).setBaseValue(600.0 + (double)this.getExtraPower() * 30.0);
        }
    }

    @Override
    public boolean canAttack() {
        return false;
    }

    @Override
    public boolean canAttackEntity(Entity entity) {
        return this.getSkeletonType() == 1
            ? super.canAttackEntity(entity) && !(entity instanceof EntityWitherSkeletonTitanMinion) && !(entity instanceof EntityWitherMinion)
            : super.canAttackEntity(entity) && !(entity instanceof EntitySkeletonTitanMinion);
    }

    @Override
    public boolean canBeHurtByPlayer() {
        return !this.isInvulnerable();
    }

    @Override
    public boolean shouldMove() {
        return this.getAnimationID() == 0 && !this.isStunned && !this.getWaiting() && this.getTarget() != null ? super.shouldMove() : false;
    }

    @Override
    public double getMeleeRange() {
        return (double)(
                this.getBbWidth() * this.getBbWidth() + (this.getTarget().getBbWidth() > 48.0F ? 2304.0F : this.getTarget().getBbWidth() * this.getTarget().getBbWidth())
            )
            + (this.getSkeletonType() == 1 ? 2000.0 : 800.0);
    }

    @Override
    public boolean canRegen() {
        return !this.isStunned;
    }

    @Override
    public boolean isArmored() {
        return this.deathTicks <= 0 && this.getTitanHealth() <= this.getTitanMaxHealth() / 4.0F;
    }

    @Override
    public SimpleParticleType getParticles() {
        if (this.getSkeletonType() == 1) {
            this.shouldParticlesBeUpward = true;
            return ParticleTypes.LARGE_SMOKE;
        } else {
            return super.getParticles();
        }
    }

    @Override
    public int getParticleCount() {
        return this.getSkeletonType() == 1 ? 48 : super.getParticleCount();
    }

    @Override
    public int getMinionCap() {
        return this.getSkeletonType() == 1
            ? 160
            : 160;
    }

    @Override
    public int getPriestCap() {
        return this.getSkeletonType() == 1
            ? 90
            : 90;
    }

    @Override
    public int getZealotCap() {
        return this.getSkeletonType() == 1
            ? 40
            : 40;
    }

    @Override
    public int getBishopCap() {
        return this.getSkeletonType() == 1
            ? 20
            : 20;
    }

    @Override
    public int getTemplarCap() {
        return this.getSkeletonType() == 1
            ? 10
            : 10;
    }

    @Override
    public int getSpecialMinionCap() {
        return this.getSkeletonType() == 1 ? 6 : super.getSpecialMinionCap();
    }

    @Override
    public boolean canSpawnMinion() {
        boolean flag = this.getInvulTime() > 1 && this.tickCount % 20 == 0;
        float randomRate = this.random.nextFloat() * 100.0F;
        return this.getSkeletonType() == 1
            ? flag || (double)randomRate < 5.0
            : flag || (double)randomRate < 5.0;
    }

    @Override
    public boolean canSpawnPriest() {
        boolean flag = this.getInvulTime() > 1 && this.tickCount % 20 == 0;
        float randomRate = this.random.nextFloat() * 100.0F;
        return this.getSkeletonType() == 1
            ? flag || (double)randomRate < 2.5
            : flag || (double)randomRate < 2.5;
    }

    @Override
    public boolean canSpawnZealot() {
        boolean flag = this.getInvulTime() > 1 && this.tickCount % 20 == 0;
        float randomRate = this.random.nextFloat() * 100.0F;
        return this.getSkeletonType() == 1
            ? flag || (double)randomRate < 1.25
            : flag || (double)randomRate < 1.25;
    }

    @Override
    public boolean canSpawnBishop() {
        boolean flag = this.getInvulTime() > 1 && this.tickCount % 20 == 0;
        float randomRate = this.random.nextFloat() * 100.0F;
        return this.getSkeletonType() == 1
            ? flag || (double)randomRate < 0.625
            : flag || (double)randomRate < 0.625;
    }

    @Override
    public boolean canSpawnTemplar() {
        boolean flag = this.getInvulTime() > 1 && this.tickCount % 20 == 0;
        float randomRate = this.random.nextFloat() * 100.0F;
        return this.getSkeletonType() == 1
            ? flag || (double)randomRate < 0.3125
            : flag || (double)randomRate < 0.3125;
    }

    @Override
    public boolean canSpawnSpecialMinion() {
        boolean flag = this.getInvulTime() > 1 && this.tickCount % 20 == 0;
        float randomRate = this.random.nextFloat() * 100.0F;
        return this.getSkeletonType() != 1
            ? super.canSpawnSpecialMinion()
            : flag || (double)randomRate < 0.3125;
    }

    @Override
    public EnumTitanStatus getTitanStatus() {
        return this.getSkeletonType() == 1 ? EnumTitanStatus.GREATER : EnumTitanStatus.AVERAGE;
    }

    @Override
    public int getFootStepModifer() {
        return this.getSkeletonType() == 1 ? 2 : 3;
    }

    @Override
    public float getSpeed() {
        return this.getSkeletonType() == 1 ? (float)(0.4 + (double)this.getExtraPower() * 0.001) : (float)(0.3 + (double)this.getExtraPower() * 0.001);
    }

    protected SoundEvent getAmbientSound() {
        if (this.getWaiting() || this.getAnimationID() == 13) {
            return null;
        } else {
            return this.getSkeletonType() == 1
                ? (SoundEvent)TheTitansSounds.TITAN_WITHER_SKELETON_LIVING.get()
                : (SoundEvent)TheTitansSounds.TITAN_SKELETON_LIVING.get();
        }
    }

    protected SoundEvent getHurtSound(DamageSource damageSource) {
        return this.getSkeletonType() == 1
            ? (SoundEvent)TheTitansSounds.TITAN_WITHER_SKELETON_GRUNT.get()
            : (SoundEvent)TheTitansSounds.TITAN_SKELETON_GRUNT.get();
    }

    protected SoundEvent getDeathSound() {
        return this.getSkeletonType() == 1
            ? (SoundEvent)TheTitansSounds.TITAN_WITHER_SKELETON_DEATH.get()
            : (SoundEvent)TheTitansSounds.TITAN_SKELETON_DEATH.get();
    }

    protected void playStepSound(BlockPos pos, BlockState state) {
        this.shakeNearbyPlayerCameras(4000.0);
        this.playSound((SoundEvent)TheTitansSounds.TITAN_STEP.get(), 10.0F, 1.0F);
        this.playSound(SoundEvents.SKELETON_STEP, 10.0F, 0.5F);
        if (!this.getWaiting() && this.getAnimationID() != 13) {
            float f1 = this.getYRot() * (float) Math.PI / 180.0F;
            float f2 = Mth.sin(f1);
            float f3 = Mth.cos(f1);
            if (this.footID == 0) {
                this.collideWithEntities(
                    this.leftLeg,
                    this.level().getEntities(this, this.leftLeg.getBoundingBox().inflate(1.0, 1.0, 1.0).move((double)(f2 * 4.0F), 0.0, (double)(f3 * 4.0F)))
                );
                this.destroyBlocksInAABB(this.leftLeg.getBoundingBox().move(0.0, -1.0, 0.0));
                this.footID++;
            } else {
                this.collideWithEntities(
                    this.rightLeg,
                    this.level().getEntities(this, this.rightLeg.getBoundingBox().inflate(1.0, 1.0, 1.0).move((double)(f2 * 4.0F), 0.0, (double)(f3 * 4.0F)))
                );
                this.destroyBlocksInAABB(this.rightLeg.getBoundingBox().move(0.0, -1.0, 0.0));
                this.footID = 0;
            }
        }
    }

    @Override
    public void attackEntity(LivingEntity entity, float amount) {
        if (this.isArmored()) {
            amount *= 2.0F;
        }

        if (this.getSkeletonType() == 1) {
            entity.addEffect(new MobEffectInstance(MobEffects.WITHER, 800, 3));
            entity.addEffect(new MobEffectInstance((MobEffect)TheTitansMobEffects.ADVANCED_WITHER.get(), 100, 3));
        }

        super.attackEntity(entity, amount);
    }

    @Override
    public boolean attackEntityFromPart(EntityTitanPart entityTitanPart, DamageSource damageSource, float amount) {
        if (entityTitanPart != this.head) {
            amount /= 3.0F;
        }

        this.hurt(damageSource, amount);
        return true;
    }

    @Override
    public boolean hurt(DamageSource damageSource, float amount) {
        if (this.isArmored()) {
            amount /= 2.0F;
        }

        if (this.isStunned) {
            amount *= 3.0F;
        }

        return super.hurt(damageSource, amount);
    }

    @Override
    protected void dropExperienceOrb() {
        for (int x = 0; x < (this.getSkeletonType() == 1 ? 70 : 16); x++) {
            EntityExperienceOrbTitan experienceOrbTitan = new EntityExperienceOrbTitan(
                this.level(),
                this.getX() + (double)(this.random.nextFloat() * 12.0F - 6.0F),
                this.getY() + 4.0,
                this.getZ() + (double)(this.random.nextFloat() * 12.0F - 6.0F),
                this.getSkeletonType() == 1 ? 24000 : 14000
            );
            experienceOrbTitan.push(0.0, 1.0, 0.0);
            this.level().addFreshEntity(experienceOrbTitan);
        }
    }

    @Override
    protected void dropAllItem() {
        Map<ItemStack, Integer> drops = new HashMap<>();
        Map<ItemStack, Integer> rateDrops = new HashMap<>();
        if (this.getSkeletonType() == 1) {
            drops.put(new ItemStack(Items.DIAMOND), 16);
            drops.put(new ItemStack(Items.IRON_INGOT), 32);
            drops.put(new ItemStack(Items.BONE), 128);
            drops.put(new ItemStack(Items.COAL), 128);
            drops.put(new ItemStack(Items.EMERALD), 128);
            drops.put(new ItemStack(Items.DIAMOND), 128);
            drops.put(new ItemStack(Items.BLACK_DYE), 256);
            drops.put(new ItemStack((ItemLike)TheTitansRegistries.HARCADIUM.get()), 64);
            drops.put(new ItemStack((ItemLike)TheTitansRegistries.VOID.get()), 32);
            drops.put(new ItemStack(Blocks.BEDROCK), 16);
            rateDrops.put(new ItemStack(Items.BONE), 128);
            rateDrops.put(new ItemStack(Items.COAL), 128);
            rateDrops.put(new ItemStack(Items.EMERALD), 128);
            rateDrops.put(new ItemStack(Items.DIAMOND), 128);
            rateDrops.put(new ItemStack(Items.BLACK_DYE), 256);
            rateDrops.put(new ItemStack((ItemLike)TheTitansRegistries.HARCADIUM.get()), 64);
            rateDrops.put(new ItemStack((ItemLike)TheTitansRegistries.VOID.get()), 32);
            rateDrops.put(new ItemStack(Blocks.BEDROCK), 16);
        } else {
            drops.put(new ItemStack(Items.STICK), 48);
            drops.put(new ItemStack(Items.STRING), 48);
            drops.put(new ItemStack(Items.ARROW), 128);
            rateDrops.put(new ItemStack(Items.ARROW), 128);
            rateDrops.put(new ItemStack(Items.EMERALD), 16);
            rateDrops.put(new ItemStack(Items.DIAMOND), 16);
            rateDrops.put(new ItemStack((ItemLike)TheTitansRegistries.HARCADIUM.get()), 4);
        }

        for (Entry<ItemStack, Integer> entry : drops.entrySet()) {
            ItemStack itemStack = entry.getKey();
            int count = entry.getValue();
            EntityItemTitan itemTitan = new EntityItemTitan(
                this.level(),
                this.getX() + (double)(this.random.nextFloat() * 12.0F - 6.0F),
                this.getY() + 4.0,
                this.getZ() + (double)(this.random.nextFloat() * 12.0F - 6.0F),
                itemStack,
                count
            );
            itemTitan.setPickUpDelay(40);
            this.level().addFreshEntity(itemTitan);
        }

        for (Entry<ItemStack, Integer> entry : rateDrops.entrySet()) {
            ItemStack itemStack = entry.getKey();
            int count = entry.getValue();
            int randomCount = this.random.nextInt(count) + 1;
            EntityItemTitan itemTitan = new EntityItemTitan(
                this.level(),
                this.getX() + (double)(this.random.nextFloat() * 12.0F - 6.0F),
                this.getY() + 4.0,
                this.getZ() + (double)(this.random.nextFloat() * 12.0F - 6.0F),
                itemStack,
                randomCount
            );
            itemTitan.setPickUpDelay(40);
            this.level().addFreshEntity(itemTitan);
        }
    }

    @Override
    protected void tickTitanDeath() {
        super.tickTitanDeath();
        AnimationUtils.sendPacket(this, 10);
        this.isStunned = false;
        if (this.deathTicks >= 500) {
            this.setInvulTime(this.getInvulTime() + 8);
            this.setAnimationTick(this.getAnimationTick() - 1);
            float f = (this.random.nextFloat() - 0.5F) * 12.0F;
            float f1 = (this.random.nextFloat() - 0.5F) * 3.0F;
            float f2 = (this.random.nextFloat() - 0.5F) * 12.0F;
            this.level()
                .addParticle(ParticleTypes.EXPLOSION, this.getX() + (double)f, this.getY() + 2.0 + (double)f1, this.getZ() + (double)f2, 0.0, 0.0, 0.0);
        }

        if (this.getInvulTime() >= this.getThreashHold()) {
            this.onDeath();
            if (!this.level().isClientSide() && !this.isRemoved()) {
                for (EntityTitanPart part : this.parts) {
                    part.remove(RemovalReason.KILLED);
                }

                this.removeTitan(RemovalReason.KILLED);
            }
        }
    }

    @Override
    public void finalizeMinionSummon(Entity entity, EnumMinionType minionType) {
        if (minionType != EnumMinionType.SPECIAL) {
            if (entity instanceof EntitySkeletonTitanMinion skeletonTitanMinion) {
                skeletonTitanMinion.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 40, 4, true, false));
            } else if (entity instanceof EntityWitherSkeletonTitanMinion witherSkeletonTitanMinion) {
                witherSkeletonTitanMinion.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 40, 4, true, false));
            }
        }
    }

    public void animationTick() {
        if (this.getAnimationID() == 13) {
            this.addDayTime(14000L, 50L);
            if (this.getAnimationTick() == 1) {
                this.playSound((SoundEvent)TheTitansSounds.TITAN_BIRTH.get(), 1000.0F, this.getSkeletonType() == 1 ? 0.875F : 1.0F);
            }

            if (this.getAnimationTick() == 10) {
                this.playSound((SoundEvent)TheTitansSounds.TITAN_SKELETON_AWAKEN.get(), this.getSoundVolume(), 1.0F);
            }

            if (this.getAnimationTick() == 100) {
                this.playSound((SoundEvent)TheTitansSounds.TITAN_RUMBLE.get(), this.getSoundVolume(), 1.0F);
            }

            if (this.getAnimationTick() == 160) {
                this.playSound((SoundEvent)TheTitansSounds.TITAN_SKELETON_BEGIN_MOVE.get(), this.getSoundVolume(), 1.0F);
            }

            if (this.getAnimationTick() == 280) {
                this.playSound((SoundEvent)TheTitansSounds.TITAN_QUAKE.get(), this.getSoundVolume(), 1.0F);
            }

            if (this.getAnimationTick() == 300) {
                this.playSound((SoundEvent)TheTitansSounds.TITAN_RUMBLE.get(), this.getSoundVolume(), 1.0F);
            }

            if (this.getAnimationTick() == 520) {
                this.playSound((SoundEvent)TheTitansSounds.TITAN_SKELETON_GETUP.get(), this.getSoundVolume(), 1.0F);
            }

            if (this.getAnimationTick() == 230 || this.getAnimationTick() == 550 || this.getAnimationTick() == 590 || this.getAnimationTick() == 610) {
                this.playStepSound(new BlockPos(0, 0, 0), Blocks.STONE.defaultBlockState());
                this.playSound((SoundEvent)TheTitansSounds.TITAN_PRESS.get(), this.getSoundVolume(), 1.0F);
            }
        }

        if (this.getAnimationID() == 1 && this.getAnimationTick() == 12 && this.getTarget() != null) {
            this.shakeNearbyPlayerCameras(20000.0);
            if (this.isArmored()) {
                this.playSound((SoundEvent)TheTitansSounds.TITAN_STRIKE.get(), 20.0F, 1.0F);
                this.playSound((SoundEvent)TheTitansSounds.TITAN_STRIKE.get(), 20.0F, 1.05F);
                this.playSound((SoundEvent)TheTitansSounds.TITAN_STRIKE.get(), 20.0F, 1.1F);

                for (int i = 0; i < 3; i++) {
                    this.collideWithEntities(this.pelvis, this.level().getEntities(this, this.pelvis.getBoundingBox().inflate(26.0, 26.0, 26.0)));
                }
            }

            float amount = (float)this.getAttributeBaseValue(Attributes.ATTACK_DAMAGE);
            int knockbackAmount = this.getKnockbackAmount();
            this.collideWithEntities(this.pelvis, this.level().getEntities(this, this.pelvis.getBoundingBox().inflate(48.0, 48.0, 48.0)));

            for (int i = 0; i < (this.getSkeletonType() == 1 ? 8 : 4); i++) {
                this.attackEntity(this.getTarget(), amount);
            }

            this.knockbackEntity(this.getTarget(), (float)knockbackAmount);

            for (Entity entity : this.level().getEntities(this.getTarget(), this.getTarget().getBoundingBox().inflate(8.0, 8.0, 8.0))) {
                if (entity != null && entity != this && entity instanceof LivingEntity && this.canAttackEntity(entity)) {
                    LivingEntity livingEntity = (LivingEntity)entity;

                    for (int i = 0; i < 2; i++) {
                        this.attackEntity(livingEntity, amount);
                    }

                    this.knockbackEntity(livingEntity, (float)knockbackAmount);
                }
            }
        }

        if (this.getAnimationID() == 2) {
            if (this.getAnimationTick() == 24) {
                this.playSound((SoundEvent)TheTitansSounds.TITAN_SWING.get(), 5.0F, 1.0F);
            }

            if (this.getAnimationTick() == 26 && this.getTarget() != null) {
                float amount = (float)this.getAttributeBaseValue(Attributes.ATTACK_DAMAGE);
                int knockbackAmount = this.getKnockbackAmount();
                this.collideWithEntities(this.head, this.level().getEntities(this, this.head.getBoundingBox().inflate(4.0, 2.0, 4.0)));
                this.attackEntity(this.getTarget(), amount);
                this.knockbackEntity(this.getTarget(), (float)knockbackAmount);

                for (Entity entityx : this.level().getEntities(this.getTarget(), this.getTarget().getBoundingBox().inflate(6.0, 2.0, 6.0))) {
                    if (entityx != null && entityx != this && entityx instanceof LivingEntity && this.canAttackEntity(entityx)) {
                        LivingEntity livingEntity = (LivingEntity)entityx;
                        this.attackEntity(livingEntity, amount);
                        this.knockbackEntity(livingEntity, (float)knockbackAmount);
                    }
                }
            }
        }

        if (this.getAnimationID() == 3 && this.getAnimationTick() == 58) {
            this.playSound((SoundEvent)TheTitansSounds.TITAN_STRIKE.get(), 20.0F, this.getSkeletonType() == 1 ? 1.0F : 0.9F);
            float d0 = this.getSkeletonType() == 1 ? 16.0F : 8.0F;
            float f3 = this.yBodyRot * (float) Math.PI / 180.0F;
            float f11 = Mth.sin(f3);
            float f4 = Mth.cos(f3);
            float amount = (float)this.getAttributeBaseValue(Attributes.ATTACK_DAMAGE);
            int knockbackAmount = this.getKnockbackAmount();
            if (!this.level().isClientSide()) {
                this.level()
                    .explode(
                        this, this.getX() - (double)(f11 * d0), this.getY(), this.getZ() + (double)(f4 * d0), 5.0F, false, ExplosionInteraction.MOB
                    );
            }

            this.collideWithEntities(this.pelvis, this.level().getEntities(this, this.pelvis.getBoundingBox().inflate(16.0, 8.0, 16.0)));

            for (Entity entityxx : this.level()
                .getEntities(this, this.getBoundingBox().inflate(32.0, 2.0, 32.0).move((double)(-(f11 * d0)), -8.0, (double)(f4 * d0)))) {
                if (entityxx != null && entityxx instanceof LivingEntity && this.canAttackEntity(entityxx)) {
                    LivingEntity livingEntity = (LivingEntity)entityxx;
                    this.attackEntity(livingEntity, amount);
                    this.knockbackEntity(livingEntity, (float)knockbackAmount);
                }
            }
        }

        if (this.getAnimationID() == 4) {
            if (this.getAnimationTick() == 24) {
                this.playSound((SoundEvent)TheTitansSounds.TITAN_SWING.get(), 5.0F, 1.0F);
            }

            if (this.getAnimationTick() == 26 && this.getTarget() != null) {
                float amount = (float)this.getAttributeBaseValue(Attributes.ATTACK_DAMAGE);
                int knockbackAmount = this.getKnockbackAmount();
                this.collideWithEntities(this.head, this.level().getEntities(this, this.head.getBoundingBox().inflate(4.0, 2.0, 4.0)));

                for (int i = 0; i < 2; i++) {
                    this.attackEntity(this.getTarget(), amount);
                }

                this.knockbackEntity(this.getTarget(), (float)knockbackAmount);

                for (Entity entityxxx : this.level().getEntities(this.getTarget(), this.getTarget().getBoundingBox().inflate(6.0, 2.0, 6.0))) {
                    if (entityxxx != null && entityxxx != this && entityxxx instanceof LivingEntity && this.canAttackEntity(entityxxx)) {
                        LivingEntity livingEntity = (LivingEntity)entityxxx;
                        this.attackEntity(livingEntity, amount);
                        this.knockbackEntity(livingEntity, (float)knockbackAmount);
                    }
                }
            }
        }

        if (this.getAnimationID() == 5) {
            if (this.getAnimationTick() == 230 + this.random.nextInt(100) && this.getTarget() != null) {
                double d8 = 46.0;
                Vec3 vec3 = this.getViewVector(1.0F);
                double dx = vec3.x * d8;
                double dz = vec3.z * d8;
                if (!this.level().isClientSide()) {
                    this.level()
                        .explode(this, this.getTarget().getX(), this.getTarget().getY(), this.getTarget().getZ(), 2.0F, false, ExplosionInteraction.MOB);
                    this.level()
                        .explode(
                            this,
                            this.getX() + dx,
                            this.getY() + (this.getSkeletonType() == 1 ? 32.0 : 16.0) + 4.0,
                            this.getZ() + dz,
                            1.0F,
                            false,
                            ExplosionInteraction.MOB
                        );
                }

                for (int i = 0; i < 5; i++) {
                    EntityColorLightningBolt colorLightningBolt = new EntityColorLightningBolt(
                        this.level(),
                        this.getSkeletonType() == 1 ? 0.0F : 0.5F,
                        this.getSkeletonType() == 1 ? 0.0F : 0.5F,
                        this.getSkeletonType() == 1 ? 0.0F : 0.5F
                    );
                    colorLightningBolt.setPos(this.getX() + dx, this.getY() + (this.getSkeletonType() == 1 ? 32.0 : 16.0) + 4.0, this.getZ() + dz);
                    if (!this.level().isClientSide()) {
                        this.level().addFreshEntity(colorLightningBolt);
                    }
                }

                EntityColorLightningBolt colorLightningBolt1 = new EntityColorLightningBolt(
                    this.level(),
                    this.getSkeletonType() == 1 ? 0.0F : 0.5F,
                    this.getSkeletonType() == 1 ? 0.0F : 0.5F,
                    this.getSkeletonType() == 1 ? 0.0F : 0.5F
                );
                colorLightningBolt1.setPos(this.getTarget().getX(), this.getTarget().getY(), this.getTarget().getZ());
                if (!this.level().isClientSide()) {
                    this.level().addFreshEntity(colorLightningBolt1);
                }

                float amount = (float)this.getAttributeBaseValue(Attributes.ATTACK_DAMAGE);
                int knockbackAmount = this.getKnockbackAmount();
                this.attackEntity(this.getTarget(), amount * 3.0F);
                this.knockbackEntity(this.getTarget(), (float)knockbackAmount);
                this.getTarget().push(0.0, 2.0 + this.random.nextDouble(), 0.0);

                for (Entity entityxxxx : this.level().getEntities(this.getTarget(), this.getTarget().getBoundingBox().inflate(16.0, 16.0, 16.0))) {
                    if (entityxxxx != null && entityxxxx != this && entityxxxx instanceof LivingEntity && this.canAttackEntity(entityxxxx)) {
                        LivingEntity livingEntity = (LivingEntity)entityxxxx;

                        for (int ix = 0; ix < 4; ix++) {
                            EntityColorLightningBolt colorLightningBolt2 = new EntityColorLightningBolt(
                                this.level(),
                                this.getSkeletonType() == 1 ? 0.0F : 0.5F,
                                this.getSkeletonType() == 1 ? 0.0F : 0.5F,
                                this.getSkeletonType() == 1 ? 0.0F : 0.5F
                            );
                            colorLightningBolt2.setPos(livingEntity.getX(), livingEntity.getY(), livingEntity.getZ());
                            if (!this.level().isClientSide()) {
                                this.level().addFreshEntity(colorLightningBolt2);
                            }
                        }

                        this.attackEntity(livingEntity, amount);
                        this.knockbackEntity(livingEntity, (float)knockbackAmount);
                        livingEntity.push(0.0, 2.0 + this.random.nextDouble(), 0.0);
                    }
                }
            }

            if (this.getAnimationTick() >= 100 && this.getAnimationTick() <= 300 && this.getTarget() != null) {
                for (int ixx = 0; ixx < 8; ixx++) {
                    this.playSound(SoundEvents.CROSSBOW_SHOOT, 3.0F, 1.9F / (this.random.nextFloat() * 0.4F + 0.8F));
                    this.lookAt(this.getTarget(), 180.0F, 30.0F);
                    float dis = 10.0F;
                    float xfac = Mth.sin(this.yBodyRot * (float) Math.PI / 180.0F);
                    float zfac = Mth.cos(this.yBodyRot * (float) Math.PI / 180.0F);
                    double dxx = (double)(xfac * dis);
                    double dzx = (double)(zfac * dis);
                    double d0 = this.getX() - dxx;
                    double d1 = this.getY() + 18.0;
                    double d2 = this.getZ() + dzx;
                    double d3 = this.getTarget().getX() - d0;
                    double d4 = this.getTarget().getY() - d1;
                    double d5 = this.getTarget().getZ() - d2;
                    double d6 = Math.sqrt(d3 * d3 + d5 * d5);
                    int knockbackAmount = 5;
                    EntityHarcadiumArrow arrow = new EntityHarcadiumArrow(this.level()) {
                        public void tick() {
                            super.tick();
                            if ((this.inGround || this.onGround()) && !this.level().isClientSide()) {
                                this.discard();
                            }
                        }
                    };
                    arrow.setOwner(this);
                    arrow.setPos(d0, d1, d2);
                    arrow.shoot(d3, d4 + d6, d5, (float)(d6 * (float) Math.PI / 180.0 * 1.6F), 36.0F);
                    arrow.setBaseDamage(90.0);
                    arrow.setCritArrow(true);
                    if (this.getSkeletonType() == 1) {
                        arrow.setRemainingFireTicks(10000);
                    }

                    if (!this.level().isClientSide()) {
                        this.level().addFreshEntity(arrow);
                    }

                    if (this.distanceToSqr(this.getTarget()) <= this.getMeleeRange()) {
                        this.attackEntity(this.getTarget(), 10.0F);
                        this.knockbackEntity(this.getTarget(), (float)knockbackAmount);
                    }
                }
            }
        }

        if (this.getAnimationID() == 6 && (this.getAnimationTick() == 60 || this.getAnimationTick() == 104)) {
            this.shakeNearbyPlayerCameras(20000.0);
            this.playSound((SoundEvent)TheTitansSounds.TITAN_SLAM.get(), 100.0F, 1.0F);
            this.playSound((SoundEvent)TheTitansSounds.TITAN_PRESS.get(), 100.0F, 1.0F);
            float amount = (float)this.getAttributeBaseValue(Attributes.ATTACK_DAMAGE);
            this.collideWithEntities(this.pelvis, this.level().getEntities(this, this.pelvis.getBoundingBox().inflate(16.0, 8.0, 16.0)));

            for (Entity entityxxxxx : this.level().getEntities(this, this.getBoundingBox().inflate(32.0, 8.0, 32.0))) {
                if (entityxxxxx != null && entityxxxxx instanceof LivingEntity && this.canAttackEntity(entityxxxxx)) {
                    LivingEntity livingEntity = (LivingEntity)entityxxxxx;
                    this.attackEntity(livingEntity, amount);
                    livingEntity.push(0.0, 1.0 + this.random.nextDouble() + this.random.nextDouble(), 0.0);
                }
            }
        }

        if (this.getAnimationID() == 7) {
            if (this.getAnimationTick() == 90) {
                this.shakeNearbyPlayerCameras(20000.0);
                this.playSound((SoundEvent)TheTitansSounds.TITAN_SLAM.get(), 100.0F, 1.0F);
                this.playSound((SoundEvent)TheTitansSounds.TITAN_PRESS.get(), 100.0F, 1.0F);
                float d0x = this.getSkeletonType() == 1 ? 64.0F : 32.0F;
                float f3 = this.yBodyRot * (float) Math.PI / 180.0F;
                float f11 = Mth.sin(f3);
                float f4 = Mth.cos(f3);
                float amount = (float)this.getAttributeBaseValue(Attributes.ATTACK_DAMAGE);
                int knockbackAmountx = this.getKnockbackAmount();
                this.collideWithEntities(this.pelvis, this.level().getEntities(this, this.pelvis.getBoundingBox().inflate(16.0, 8.0, 16.0)));

                for (Entity entityxxxxxx : this.level()
                    .getEntities(this, this.getBoundingBox().inflate(32.0, 2.0, 32.0).move((double)(-(f11 * d0x)), -8.0, (double)(f4 * d0x)))) {
                    if (entityxxxxxx != null && entityxxxxxx instanceof LivingEntity && this.canAttackEntity(entityxxxxxx)) {
                        LivingEntity livingEntity = (LivingEntity)entityxxxxxx;
                        this.attackEntity(livingEntity, amount * 15.0F);
                        this.knockbackEntity(livingEntity, (float)knockbackAmountx);
                        livingEntity.push(0.0, 2.0 + this.random.nextDouble(), 0.0);
                    }
                }
            }

            if (this.getAnimationTick() == 92) {
                float disx = this.getSkeletonType() == 1 ? 32.0F : 16.0F;
                float xfacx = Mth.sin(this.yBodyRot * (float) Math.PI / 180.0F);
                float zfacx = Mth.cos(this.yBodyRot * (float) Math.PI / 180.0F);
                int x = Mth.floor(this.getX() - (double)(xfacx * disx * 2.0F));
                int y = Mth.floor(this.getY());
                int z = Mth.floor(this.getZ() + (double)(zfacx * disx * 2.0F));
                BlockPos blockPos = new BlockPos(x, y - 1, z);
                BlockState blockState = this.level().getBlockState(blockPos);
                if (!blockState.isAir()) {
                    this.playSound((SoundEvent)TheTitansSounds.TITAN_STRIKE.get(), 20.0F, 1.0F);
                    this.playSound((SoundEvent)TheTitansSounds.TITAN_SLAM.get(), 20.0F, 1.0F);
                    this.playSound((SoundEvent)TheTitansSounds.TITAN_PRESS.get(), 100.0F, 1.0F);
                }

                for (int rangeX = -4; rangeX <= 4; rangeX++) {
                    for (int rangeY = -1; rangeY <= 1; rangeY++) {
                        for (int rangeZ = -4; rangeZ <= 4; rangeZ++) {
                            int posX = x + rangeX;
                            int posY = y + rangeY;
                            int posZ = z + rangeZ;
                            BlockPos pos = new BlockPos(posX, posY, posZ);
                            BlockState state = this.level().getBlockState(pos);
                            Block block = state.getBlock();
                            if (!state.isAir() && block == Blocks.GRASS_BLOCK) {
                                this.level().setBlockAndUpdate(pos, Blocks.DIRT.defaultBlockState());
                            }

                            if (block.getExplosionResistance() > 500.0F) {
                                this.playSound(SoundEvents.ANVIL_LAND, 20.0F, 0.5F);
                                AnimationUtils.sendPacket(this, 8);
                                this.isStunned = true;
                            }
                        }
                    }
                }
            }
        }

        if (this.getAnimationID() == 8) {
            if (this.getAnimationTick() == 70) {
                this.playSound((SoundEvent)TheTitansSounds.GROUND_SMASH.get(), 8.0F, 0.9F);
                this.playSound((SoundEvent)TheTitansSounds.TITAN_FALL.get(), 10.0F, 1.0F);
            }

            if (this.getAnimationTick() == 74) {
                this.playSound((SoundEvent)TheTitansSounds.DISTANT_LARGE_FALL.get(), 10000.0F, 1.0F);
                this.playSound(this.getHurtSound(null), this.getSoundVolume(), this.getVoicePitch());
            }

            if (this.getAnimationTick() == 480) {
                this.playSound((SoundEvent)TheTitansSounds.TITAN_FALL.get(), 10.0F, 1.0F);
                this.playSound((SoundEvent)TheTitansSounds.TITAN_STEP.get(), 10.0F, 1.0F);
                this.playSound(SoundEvents.SKELETON_STEP, 10.0F, 0.5F);
                this.playSound((SoundEvent)TheTitansSounds.TITAN_STEP.get(), 10.0F, 1.0F);
                this.playSound(SoundEvents.SKELETON_STEP, 10.0F, 0.5F);

                for (int ixx = 0; ixx < 2; ixx++) {
                    this.collideWithEntities(this.leftLeg, this.level().getEntities(this, this.leftLeg.getBoundingBox().inflate(16.0, 1.0, 16.0)));
                    this.collideWithEntities(this.rightLeg, this.level().getEntities(this, this.rightLeg.getBoundingBox().inflate(16.0, 1.0, 16.0)));
                }
            }

            if (this.getAnimationTick() == 450) {
                this.isStunned = false;
            } else {
                this.setTarget(null);
            }
        }

        if (this.getAnimationID() == 9) {
            if (this.getAnimationTick() == 48 && this.getTarget() != null) {
                double d8x = 46.0;
                Vec3 vec3x = this.getViewVector(1.0F);
                double dxxx = vec3x.x * d8x;
                double dzxx = vec3x.z * d8x;
                if (!this.level().isClientSide()) {
                    this.level()
                        .explode(this, this.getTarget().getX(), this.getTarget().getY(), this.getTarget().getZ(), 2.0F, false, ExplosionInteraction.MOB);
                    this.level()
                        .explode(
                            this,
                            this.getX() + dxxx,
                            this.getY() + (this.getSkeletonType() == 1 ? 32.0 : 16.0) + 4.0,
                            this.getZ() + dzxx,
                            1.0F,
                            false,
                            ExplosionInteraction.MOB
                        );
                }

                for (int ixx = 0; ixx < 5; ixx++) {
                    EntityColorLightningBolt colorLightningBolt = new EntityColorLightningBolt(
                        this.level(),
                        this.getSkeletonType() == 1 ? 0.0F : 0.5F,
                        this.getSkeletonType() == 1 ? 0.0F : 0.5F,
                        this.getSkeletonType() == 1 ? 0.0F : 0.5F
                    );
                    colorLightningBolt.setPos(
                        this.getX() + dxxx, this.getY() + (this.getSkeletonType() == 1 ? 32.0 : 16.0) + 4.0, this.getZ() + dzxx
                    );
                    if (!this.level().isClientSide()) {
                        this.level().addFreshEntity(colorLightningBolt);
                    }
                }

                EntityColorLightningBolt colorLightningBolt1 = new EntityColorLightningBolt(
                    this.level(),
                    this.getSkeletonType() == 1 ? 0.0F : 0.5F,
                    this.getSkeletonType() == 1 ? 0.0F : 0.5F,
                    this.getSkeletonType() == 1 ? 0.0F : 0.5F
                );
                colorLightningBolt1.setPos(this.getTarget().getX(), this.getTarget().getY(), this.getTarget().getZ());
                if (!this.level().isClientSide()) {
                    this.level().addFreshEntity(colorLightningBolt1);
                }

                float amount = (float)this.getAttributeBaseValue(Attributes.ATTACK_DAMAGE);
                int knockbackAmountx = this.getKnockbackAmount();
                this.attackEntity(this.getTarget(), amount * 3.0F);
                this.knockbackEntity(this.getTarget(), (float)knockbackAmountx);
                this.getTarget().push(0.0, 2.0 + this.random.nextDouble(), 0.0);

                for (Entity entityxxxxxxx : this.level().getEntities(this.getTarget(), this.getTarget().getBoundingBox().inflate(16.0, 16.0, 16.0))) {
                    if (entityxxxxxxx != null && entityxxxxxxx != this && entityxxxxxxx instanceof LivingEntity && this.canAttackEntity(entityxxxxxxx)) {
                        LivingEntity livingEntity = (LivingEntity)entityxxxxxxx;

                        for (int ixxx = 0; ixxx < 4; ixxx++) {
                            EntityColorLightningBolt colorLightningBolt2 = new EntityColorLightningBolt(
                                this.level(),
                                this.getSkeletonType() == 1 ? 0.0F : 0.5F,
                                this.getSkeletonType() == 1 ? 0.0F : 0.5F,
                                this.getSkeletonType() == 1 ? 0.0F : 0.5F
                            );
                            colorLightningBolt2.setPos(livingEntity.getX(), livingEntity.getY(), livingEntity.getZ());
                            if (!this.level().isClientSide()) {
                                this.level().addFreshEntity(colorLightningBolt2);
                            }
                        }

                        this.attackEntity(livingEntity, amount);
                        this.knockbackEntity(livingEntity, (float)knockbackAmountx);
                        livingEntity.push(0.0, 2.0 + this.random.nextDouble(), 0.0);
                    }
                }
            }

            if (this.getAnimationTick() >= 26 && this.getAnimationTick() <= 50) {
                float disx = this.getSkeletonType() == 1 ? 32.0F : 16.0F;
                double d8xx = (double)(this.getAnimationTick() - 4);
                Vec3 vec3xx = this.getViewVector(1.0F);
                double dxxxx = vec3xx.x * d8xx;
                double dzxxx = vec3xx.z * d8xx;
                EntityColorLightningBolt colorLightningBolt = new EntityColorLightningBolt(
                    this.level(),
                    this.getSkeletonType() == 1 ? 0.0F : 0.5F,
                    this.getSkeletonType() == 1 ? 0.0F : 0.5F,
                    this.getSkeletonType() == 1 ? 0.0F : 0.5F
                );
                colorLightningBolt.setPos(this.getX() - dxxxx, this.getY() + (double)disx + 4.0, this.getZ() + dzxxx);
                if (!this.level().isClientSide()) {
                    this.level().addFreshEntity(colorLightningBolt);
                }
            }
        }

        if (this.getAnimationID() == 10) {
            if (this.getAnimationTick() == 30 || this.getAnimationTick() == 70) {
                this.playSound((SoundEvent)TheTitansSounds.TITAN_STEP.get(), 10.0F, 1.0F);
            }

            if (this.getAnimationTick() == 190) {
                this.playSound((SoundEvent)TheTitansSounds.TITAN_FALL.get(), 20.0F, 1.0F);
                this.collideWithEntities(this.leftLeg, this.level().getEntities(this, this.leftLeg.getBoundingBox().inflate(16.0, 1.0, 16.0)));
                this.collideWithEntities(this.rightLeg, this.level().getEntities(this, this.rightLeg.getBoundingBox().inflate(16.0, 1.0, 16.0)));
            }

            if (this.getAnimationTick() == 200) {
                this.playSound((SoundEvent)TheTitansSounds.DISTANT_LARGE_FALL.get(), 10000.0F, 1.0F);
            }
        }

        if (this.getAnimationID() == 11 && this.getAnimationTick() == 78 && this.getTarget() != null) {
            this.playSound(SoundEvents.CROSSBOW_SHOOT, 10.0F, 1.0F / (this.random.nextFloat() * 0.4F + 0.8F));
            this.lookAt(this.getTarget(), 180.0F, 30.0F);
            float disx = 10.0F;
            float xfacx = Mth.sin(this.yBodyRot * (float) Math.PI / 180.0F);
            float zfacx = Mth.cos(this.yBodyRot * (float) Math.PI / 180.0F);
            double dxxxx = (double)(xfacx * disx);
            double dzxxx = (double)(zfacx * disx);
            double d0x = this.getX() - dxxxx;
            double d1x = this.getY() + 17.0;
            double d2x = this.getZ() + dzxxx;
            double d3x = this.getTarget().getX() - d0x;
            double d4x = this.getTarget().getY() - d1x;
            double d5x = this.getTarget().getZ() - d2x;
            int knockbackAmountx = 5;
            EntityArrowTitan arrowTitan = new EntityArrowTitan(this.level());
            arrowTitan.setOwner(this);
            arrowTitan.setPos(d0x, d1x, d2x);
            arrowTitan.shoot(d3x, d4x, d5x, 10.0F, 0.0F);
            if (!this.level().isClientSide()) {
                this.level().addFreshEntity(arrowTitan);
            }

            if (this.distanceToSqr(this.getTarget()) <= this.getMeleeRange()) {
                this.attackEntity(this.getTarget(), 10.0F);
                this.knockbackEntity(this.getTarget(), (float)knockbackAmountx);
            }
        }

        if (this.getAnimationID() == 12 && this.getAnimationTick() == 40) {
            this.playSound(SoundEvents.GENERIC_EXPLODE, 20.0F, 2.0F);
            this.playSound(SoundEvents.WITHER_SHOOT, 20.0F, 1.0F);
            float disxx = this.getSkeletonType() == 1 ? 32.0F : 16.0F;
            float xfacxx = Mth.sin(this.yBodyRot * (float) Math.PI / 180.0F);
            float zfacxx = Mth.cos(this.yBodyRot * (float) Math.PI / 180.0F);
            float amount = (float)this.getAttributeBaseValue(Attributes.ATTACK_DAMAGE);
            int knockbackAmountxx = this.getKnockbackAmount();
            if (!this.level().isClientSide()) {
                this.level()
                    .explode(
                        this,
                        this.getX() - (double)(xfacxx * disxx) * 0.9,
                        this.getY() + (double)disxx * 1.25,
                        this.getZ() + (double)(zfacxx * disxx) * 0.9,
                        3.0F,
                        false,
                        ExplosionInteraction.MOB
                    );
            }

            EntityColorLightningBolt colorLightningBolt1 = new EntityColorLightningBolt(
                this.level(), this.getSkeletonType() == 1 ? 0.0F : 0.5F, this.getSkeletonType() == 1 ? 0.0F : 0.5F, this.getSkeletonType() == 1 ? 0.0F : 0.5F
            );
            colorLightningBolt1.setPos(
                this.getX() - (double)(xfacxx * disxx) * 0.9, this.getY() + (double)disxx * 1.25, this.getZ() + (double)(zfacxx * disxx) * 0.9
            );
            if (!this.level().isClientSide()) {
                this.level().addFreshEntity(colorLightningBolt1);
            }

            if (this.getTarget() != null) {
                if (!this.level().isClientSide()) {
                    this.level()
                        .explode(this, this.getTarget().getX(), this.getTarget().getY(), this.getTarget().getZ(), 3.0F, false, ExplosionInteraction.MOB);
                }

                EntityColorLightningBolt colorLightningBolt2 = new EntityColorLightningBolt(
                    this.level(),
                    this.getSkeletonType() == 1 ? 0.0F : 0.5F,
                    this.getSkeletonType() == 1 ? 0.0F : 0.5F,
                    this.getSkeletonType() == 1 ? 0.0F : 0.5F
                );
                colorLightningBolt2.setPos(this.getTarget().getX(), this.getTarget().getY(), this.getTarget().getZ());
                if (!this.level().isClientSide()) {
                    this.level().addFreshEntity(colorLightningBolt2);
                }

                this.getTarget().hurt(this.damageSources().lightningBolt(), amount);
                this.attackEntity(this.getTarget(), amount * 5.0F);
                this.knockbackEntity(this.getTarget(), (float)knockbackAmountxx);
                this.getTarget().push(0.0, 1.0 + this.random.nextDouble(), 0.0);
            }
        }
    }

    @Override
    public void tick() {
        super.tick();
        this.refreshDimensions();
        this.checkWaiting(16.0);
        if (this.isPassenger() && this.getVehicle() instanceof EntitySpiderTitan) {
            EntitySpiderTitan spiderTitan = (EntitySpiderTitan)this.getVehicle();
            if (!this.getWaiting() && this.getAnimationID() == 13 && spiderTitan.getAnimationID() == 13) {
                spiderTitan.setYRot(this.getYRot());
                spiderTitan.yHeadRot = this.yHeadRot;
                spiderTitan.yBodyRot = this.yBodyRot;
            }

            if (spiderTitan.getTarget() == this) {
                spiderTitan.setTarget(null);
            }

            if (this.getTarget() != null) {
                if (this.getTarget() == spiderTitan) {
                    this.setTarget(null);
                } else {
                    spiderTitan.setTarget(this.getTarget());
                }
            }
        }

        if (this.getAnimationID() == 0 && !this.isPassenger() && !this.getWaiting() && !this.isStunned) {
            if (this.getTarget() != null && this.distanceToSqr(this.getTarget()) > this.getMeleeRange() + (!this.getTarget().onGround() ? 1000.0 : 8000.0)) {
                if (this.getY() <= this.getTarget().getY() + 12.0 && this.getY() < 256.0 - (double)this.getBbHeight()) {
                    this.fallDistance = 0.0F;
                    this.setTitanDeltaMovement(this.getDeltaMovement().x, this.getDeltaMovement().y + 0.9 - this.getDeltaMovement().y, this.getDeltaMovement().z);
                    if (this.getDeltaMovement().y < 0.0) {
                        this.setTitanDeltaMovement(this.getDeltaMovement().x, 0.0, this.getDeltaMovement().z);
                    }
                }

                this.setTitanDeltaMovement(this.getDeltaMovement().x, this.getDeltaMovement().y * 0.6, this.getDeltaMovement().z);
            }

            if (!this.onGround()) {
                float f3 = (this.random.nextFloat() - 0.5F) * (this.getSkeletonType() == 1 ? 30.0F : 10.0F);
                float f4 = (this.random.nextFloat() - 0.5F) * 1.0F;
                float f5 = (this.random.nextFloat() - 0.5F) * (this.getSkeletonType() == 1 ? 30.0F : 10.0F);
                this.level()
                    .addParticle(
                        ParticleTypes.EXPLOSION, this.getX() + (double)f3, this.getY() + 5.0 + (double)f4, this.getZ() + (double)f5, 0.0, 0.0, 0.0
                    );
            }
        }

        if (this.tickCount > 5) {
            float f = this.yBodyRot * (float) Math.PI / 180.0F;
            float f1 = Mth.sin(f);
            float f2 = Mth.cos(f);
            if (this.getSkeletonType() == 1) {
                this.head.setSize(14.0F, 14.0F);
                this.pelvis.setSize(10.5F, 3.5F);
                this.spine.setSize(2.0F, 21.0F);
                this.ribCage.setSize(12.25F, 8.75F);
                this.leftArm.setSize(3.5F, 21.0F);
                this.rightArm.setSize(3.5F, 21.0F);
                this.leftLeg.setSize(3.5F, 21.0F);
                this.rightLeg.setSize(3.5F, 21.0F);
            } else {
                this.head.setSize(8.0F, 8.0F);
                this.pelvis.setSize(6.0F, 2.0F);
                this.spine.setSize(2.0F, 12.0F);
                this.ribCage.setSize(7.5F, 5.0F);
                this.leftArm.setSize(2.0F, 12.0F);
                this.rightArm.setSize(2.0F, 12.0F);
            }

            this.head.moveTo(this.getX(), this.getY() + (this.getSkeletonType() == 1 ? 42.0 : 24.0), this.getZ());
            this.pelvis.moveTo(this.getX(), this.getY() + (this.getSkeletonType() == 1 ? 21.0 : 12.0), this.getZ());
            this.spine
                .moveTo(
                    this.getX() + (double)f1 * (this.getSkeletonType() == 1 ? 3.5 : 2.0),
                    this.getY() + (this.getSkeletonType() == 1 ? 21.0 : 12.0),
                    this.getZ() - (double)f2 * (this.getSkeletonType() == 1 ? 3.5 : 2.0)
                );
            this.ribCage.moveTo(this.getX(), this.getY() + (this.getSkeletonType() == 1 ? 33.25 : 19.0), this.getZ());
            this.leftArm
                .moveTo(
                    this.getX() - (double)f2 * (this.getSkeletonType() == 1 ? 8.75 : 5.0),
                    this.getY() + (this.getSkeletonType() == 1 ? 20.125 : 11.5),
                    this.getZ() - (double)f1 * (this.getSkeletonType() == 1 ? 8.75 : 5.0)
                );
            this.rightArm
                .moveTo(
                    this.getX() + (double)f2 * (this.getSkeletonType() == 1 ? 8.75 : 5.0),
                    this.getY() + (this.getSkeletonType() == 1 ? 20.125 : 11.5),
                    this.getZ() + (double)f1 * (this.getSkeletonType() == 1 ? 8.75 : 5.0)
                );
            this.leftLeg
                .moveTo(
                    this.getX() - (double)f2 * (this.getSkeletonType() == 1 ? 3.5 : 2.0),
                    this.getY(),
                    this.getZ() - (double)f1 * (this.getSkeletonType() == 1 ? 3.5 : 2.0)
                );
            this.rightLeg
                .moveTo(
                    this.getX() + (double)f2 * (this.getSkeletonType() == 1 ? 3.5 : 2.0),
                    this.getY(),
                    this.getZ() + (double)f1 * (this.getSkeletonType() == 1 ? 3.5 : 2.0)
                );
            if (this.isAlive() && !this.isStunned) {
                this.collideWithEntities(this.head, this.level().getEntities(this, this.head.getBoundingBox().inflate(1.0, 0.0, 1.0)));
                this.collideWithEntities(this.pelvis, this.level().getEntities(this, this.pelvis.getBoundingBox().inflate(1.0, 0.0, 1.0)));
                this.collideWithEntities(this.spine, this.level().getEntities(this, this.spine.getBoundingBox()));
                this.collideWithEntities(this.ribCage, this.level().getEntities(this, this.ribCage.getBoundingBox()));
                this.collideWithEntities(this.leftArm, this.level().getEntities(this, this.leftArm.getBoundingBox().inflate(1.0, 0.0, 1.0)));
                this.collideWithEntities(this.rightArm, this.level().getEntities(this, this.rightArm.getBoundingBox().inflate(1.0, 0.0, 1.0)));
                this.collideWithEntities(this.leftLeg, this.level().getEntities(this, this.leftLeg.getBoundingBox().inflate(1.0, 0.0, 1.0)));
                this.collideWithEntities(this.rightLeg, this.level().getEntities(this, this.rightLeg.getBoundingBox().inflate(1.0, 0.0, 1.0)));
            }

            for (EntityTitanPart part : this.parts) {
                this.destroyBlocksInAABB(part.getBoundingBox());
            }
        }

        if (this.getAnimationID() == 0 && this.getTarget() != null) {
            double d0 = this.distanceToSqr(this.getTarget());
            if (d0 < this.getMeleeRange()) {
                if (!(this.getTarget() instanceof EntityTitan) && !(this.getTarget().getBbHeight() >= 6.0F) && !(this.getTarget().getY() > this.getY() + 6.0)) {
                    switch (this.random.nextInt(5)) {
                        case 0:
                            AnimationUtils.sendPacket(this, 6);
                            break;
                        case 1:
                            AnimationUtils.sendPacket(this, 3);
                            break;
                        case 2:
                            AnimationUtils.sendPacket(this, 7);
                            break;
                        case 3:
                            AnimationUtils.sendPacket(this, 2);
                            break;
                        case 4:
                            AnimationUtils.sendPacket(this, 4);
                    }
                } else {
                    AnimationUtils.sendPacket(this, 1);
                }
            } else if (this.random.nextInt(80) == 0) {
                switch (this.random.nextInt(6)) {
                    case 0:
                        if (this.getSkeletonType() != 1) {
                            AnimationUtils.sendPacket(this, 5);
                        } else {
                            AnimationUtils.sendPacket(this, 9);
                        }
                        break;
                    case 1:
                        AnimationUtils.sendPacket(this, 12);
                        break;
                    case 2:
                        if (this.getSkeletonType() != 1) {
                            AnimationUtils.sendPacket(this, 11);
                        } else {
                            AnimationUtils.sendPacket(this, 12);
                        }
                }
            }
        }

        if (this.isStunned) {
            this.setTarget(null);
            AnimationUtils.sendPacket(this, 8);
        }

        if (this.isStunned || this.deathTicks > 0) {
            this.setDeltaMovement(0.0, this.getDeltaMovement().y, 0.0);
        }

        if (this.getAnimationID() != 5 && this.getAnimationID() != 11) {
            if (this.getAnimationID() != 5 && this.getAnimationID() != 11) {
                this.attackTimer = 0;
            }
        } else if (this.getAnimationTick() >= 40) {
            this.attackTimer++;
        }

        if (this.attackTimer < 0) {
            this.attackTimer = 0;
        }

        this.animationTick();
    }
}
