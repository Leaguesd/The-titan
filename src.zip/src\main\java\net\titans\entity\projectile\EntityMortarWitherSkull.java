package net.titans.entity.projectile;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.Difficulty;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.WitherSkull;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.Level.ExplosionInteraction;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.HitResult.Type;
import net.titans.entity.titan.EntityTitan;
import net.titans.loader.TheTitansEntities;
import net.titans.loader.TheTitansSounds;

public class EntityMortarWitherSkull extends WitherSkull {
    private static final EntityDataAccessor<Boolean> BULLET = SynchedEntityData.defineId(EntityMortarWitherSkull.class, EntityDataSerializers.BOOLEAN);
    public int lifeTime;
    public int explosivePower;
    public int extraDamage;
    public float speedFactor;
    public int titanDamage;

    public EntityMortarWitherSkull(EntityType<? extends EntityMortarWitherSkull> entityType, Level level) {
        super(entityType, level);
    }

    public EntityMortarWitherSkull(Level level, double x, double y, double z, Vec3 movement, float speedFactor) {
        this((EntityType<? extends EntityMortarWitherSkull>)TheTitansEntities.MORTAR_WITHER_SKULL.get(), level);
        this.moveTo(x, y, z, this.getYRot(), this.getXRot());
        this.reapplyPosition();
        this.speedFactor = speedFactor;
        // 初速仍按原来的 0.1 + speedFactor，另外补上原版抛射物的加速度；
        // 否则速度只会被惯性（普通 0.95 / 危险 0.73）一路衰减到停。
        this.assignDirectionalMovement(movement, 0.1D);
    }

    public EntityMortarWitherSkull(Level level, LivingEntity owner, Vec3 movement, float speedFactor) {
        this(level, owner.getX(), owner.getY(), owner.getZ(), movement, speedFactor);
        this.setOwner(owner);
        this.setRot(owner.getYRot(), owner.getXRot());
    }

    public boolean isBullet() {
        return (Boolean)this.entityData.get(BULLET);
    }

    public void setBullet(boolean bullet) {
        this.entityData.set(BULLET, bullet);
    }

    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(BULLET, false);
    }

    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        this.setBullet(tag.getBoolean("Bullet"));
        this.lifeTime = tag.getInt("LifeTime");
        this.explosivePower = tag.getInt("ExplosivePower");
        this.extraDamage = tag.getInt("ExtraDamage");
        this.speedFactor = tag.getFloat("SpeedFactor");
    }

    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putBoolean("Bullet", this.isBullet());
        tag.putInt("LifeTime", this.lifeTime);
        tag.putInt("ExplosivePower", this.explosivePower);
        tag.putInt("ExtraDamage", this.extraDamage);
        tag.putFloat("SpeedFactor", this.speedFactor);
    }

    private void assignDirectionalMovement(Vec3 movement, double accelerationPower) {
        Vec3 direction = movement.normalize();
        this.setDeltaMovement(direction.scale(0.1D + (double)this.speedFactor));
        this.xPower = direction.x * accelerationPower;
        this.yPower = direction.y * accelerationPower;
        this.zPower = direction.z * accelerationPower;
        this.hasImpulse = true;
    }

    protected void onHit(HitResult result) {
        this.playSound(SoundEvents.GENERIC_EXPLODE, 4.0F, (1.0F + (this.random.nextFloat() - this.random.nextFloat()) * 0.2F) * 0.6F);
        this.playSound((SoundEvent)TheTitansSounds.MORTAR_HIT.get(), 0.5F, 1.0F);
        this.playSound((SoundEvent)TheTitansSounds.MORTAR_HIT.get(), 2.0F, 1.0F);
        Type hitResult$type = result.getType();
        if (hitResult$type == Type.ENTITY) {
            EntityHitResult entityHitResult = (EntityHitResult)result;
            Entity entity = entityHitResult.getEntity();
            if (this.getOwner() instanceof LivingEntity) {
                LivingEntity livingEntity = (LivingEntity)this.getOwner();
                if (entity instanceof EntityTitan titan) {
                    titan.playSound((SoundEvent)TheTitansSounds.TITAN_PUNCH.get(), 10.0F, 0.9F);
                    titan.hurt(
                        this.damageSources().witherSkull(this, livingEntity),
                        this.isBullet() ? 100.0F + (float)this.extraDamage : 500.0F + (float)this.extraDamage * 100.0F
                    );
                    if (this.titanDamage > 0) {
                        titan.damageTitanHealth((float)this.titanDamage);
                    }
                } else if (entity.getBbHeight() >= 6.0F) {
                    entity.playSound((SoundEvent)TheTitansSounds.TITAN_PUNCH.get(), 10.0F, 0.9F);
                    entity.hurt(
                        this.damageSources().witherSkull(this, livingEntity),
                        this.isBullet() ? 100.0F + (float)this.extraDamage : 5000.0F + (float)this.extraDamage * 1000.0F
                    );
                } else {
                    entity.hurt(
                        this.damageSources().witherSkull(this, livingEntity),
                        this.isBullet() ? 10.0F + (float)this.extraDamage : 500.0F + (float)this.extraDamage * 100.0F
                    );
                }
            } else {
                entity.hurt(this.damageSources().magic(), this.isBullet() ? 5.0F : 500.0F);
            }

            if (entity instanceof LivingEntity livingEntity) {
                int i = this.isBullet() ? 10 : 30;
                if (this.level().getDifficulty() == Difficulty.NORMAL) {
                    i = this.isBullet() ? 20 : 60;
                } else if (this.level().getDifficulty() == Difficulty.HARD) {
                    i = this.isBullet() ? 40 : 90;
                }

                if (i > 0 && !this.level().isClientSide()) {
                    if (!this.isBullet()) {
                        livingEntity.addEffect(new MobEffectInstance(MobEffects.WITHER, 40 * i, 3), this.getEffectSource());
                        livingEntity.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 120, 3), this.getEffectSource());
                        livingEntity.addEffect(new MobEffectInstance(MobEffects.BLINDNESS, 120, 1), this.getEffectSource());
                        livingEntity.addEffect(new MobEffectInstance(MobEffects.CONFUSION, 120, 1), this.getEffectSource());
                    } else {
                        livingEntity.addEffect(new MobEffectInstance(MobEffects.WITHER, 20 * i, 1), this.getEffectSource());
                        livingEntity.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 40, 3), this.getEffectSource());
                        if (livingEntity.getEyeY() - 0.2 < this.getY()) {
                            livingEntity.addEffect(new MobEffectInstance(MobEffects.BLINDNESS, 40, 0), this.getEffectSource());
                        }
                    }
                }
            }

            if (!this.level().isClientSide()) {
                if (!this.isBullet()) {
                    this.level()
                        .explode(this, this.getX(), this.getY(), this.getZ(), 14.0F + (float)this.explosivePower, false, ExplosionInteraction.MOB);
                }

                this.discard();
            }
        }
    }

    public void tick() {
        // 兜底：旧存档里没有 power 字段的骷髅头会一路衰减到停，这里按当前方向补一次。
        if (!this.level().isClientSide()
            && this.xPower == 0.0
            && this.yPower == 0.0
            && this.zPower == 0.0
            && this.getDeltaMovement().lengthSqr() > 1.0E-9) {
            Vec3 direction = this.getDeltaMovement().normalize();
            this.xPower = direction.x * 0.1D;
            this.yPower = direction.y * 0.1D;
            this.zPower = direction.z * 0.1D;
        }

        super.tick();
        this.lifeTime++;
        if (this.lifeTime >= 1000) {
            this.playSound(SoundEvents.GENERIC_EXPLODE, this.isBullet() ? 2.0F : 4.0F, (1.0F + (this.random.nextFloat() - this.random.nextFloat()) * 0.2F) * 0.6F);
            this.playSound((SoundEvent)TheTitansSounds.MORTAR_HIT.get(), 0.5F, 1.0F);
            this.playSound((SoundEvent)TheTitansSounds.MORTAR_HIT.get(), 2.0F, 1.0F);
            if (!this.level().isClientSide()) {
                if (!this.isBullet()) {
                    this.level()
                        .explode(this, this.getX(), this.getY(), this.getZ(), 14.0F + (float)this.explosivePower, false, ExplosionInteraction.MOB);
                }

                this.discard();
            }
        }
    }
}
