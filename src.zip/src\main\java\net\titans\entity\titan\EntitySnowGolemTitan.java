package net.titans.entity.titan;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.Mth;
import net.minecraft.world.Difficulty;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity.RemovalReason;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier.Builder;
import net.minecraft.world.entity.animal.SnowGolem;
import net.minecraft.world.entity.monster.RangedAttackMob;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.biome.Biome;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.titans.entity.IBossBarDisplay;
import net.titans.entity.ai.EntityAINearestTargetTitan;
import net.titans.entity.ai.snowtitan.EntityAISnowGolemTitanShoot;
import net.titans.entity.projectile.EntitySnowballTitan;
import net.titans.loader.TheTitansEntities;
import net.titans.loader.TheTitansPredicateTargets;

public class EntitySnowGolemTitan extends EntityTitan implements RangedAttackMob, IBossBarDisplay {
    public EntitySnowGolemTitan(EntityType<? extends EntityTitan> entityType, Level level) {
        super(entityType, level);
    }

    public EntitySnowGolemTitan(Level level) {
        this((EntityType<? extends EntityTitan>)TheTitansEntities.SNOW_GOLEM_TITAN.get(), level);
    }

    public static Builder createAttributes() {
        return EntityTitan.createAttributes().add(Attributes.MAX_HEALTH, 4000.0).add(Attributes.ATTACK_DAMAGE, 400.0).add(Attributes.MOVEMENT_SPEED, 0.25);
    }

    @Override
    public ResourceLocation getBossBarTexture() {
        return ResourceLocation.tryBuild("titan", "textures/gui/bossbar/snow_golem_titan.png");
    }

    @Override
    public int getBossBarNameColor() {
        return 12369084;
    }

    @Override
    public int getBossBarWidth() {
        return 185;
    }

    @Override
    public int getBossBarHeight() {
        return 27;
    }

    @Override
    public int getBossBarInterval() {
        return 5;
    }

    @Override
    public int getBossBarVOffset() {
        return 0;
    }

    @Override
    public int getBossBarVHeight() {
        return 0;
    }

    @Override
    public int getBossBarTextOffset() {
        return 7;
    }

    @Override
    protected void registerGoals() {
        super.registerGoals();
        this.goalSelector.addGoal(1, new EntityAISnowGolemTitanShoot(this, 20, 512.0F, 12.0F, 1.25F));
        this.targetSelector
            .addGoal(0, new EntityAINearestTargetTitan<LivingEntity>(this, LivingEntity.class, 0, false, false, TheTitansPredicateTargets.SnowGolemTitan));
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
    }

    @Override
    protected void refreshAttributes() {
        if (this.level().getDifficulty() == Difficulty.HARD) {
            this.getAttribute(Attributes.MAX_HEALTH).setBaseValue(4000.0 + (double)this.getExtraPower() * 200.0);
            this.getAttribute(Attributes.ATTACK_DAMAGE).setBaseValue(400.0 + (double)this.getExtraPower() * 36.0);
        } else {
            this.getAttribute(Attributes.MAX_HEALTH).setBaseValue(2000.0 + (double)this.getExtraPower() * 100.0);
            this.getAttribute(Attributes.ATTACK_DAMAGE).setBaseValue(200.0 + (double)this.getExtraPower() * 18.0);
        }
    }

    @Override
    public boolean canAttackEntity(Entity entity) {
        return super.canAttackEntity(entity) && !(entity instanceof EntitySnowGolemTitan) && !(entity instanceof SnowGolem);
    }

    @Override
    public EnumTitanStatus getTitanStatus() {
        return EnumTitanStatus.LESSER;
    }

    public int getArmorValue() {
        return 15;
    }

    protected SoundEvent getHurtSound(DamageSource damageSource) {
        return SoundEvents.SNOW_STEP;
    }

    protected SoundEvent getDeathSound() {
        return SoundEvents.SNOW_GOLEM_DEATH;
    }

    public void kill() {
        super.kill();
        this.setTitanHealth(0.0F);
    }

    public void performRangedAttack(LivingEntity target, float velocity) {
        this.playSound(SoundEvents.SNOW_GOLEM_SHOOT, 10.0F, 0.4F / (this.random.nextFloat() * 0.4F + 0.8F));
        this.lookAt(target, 180.0F, 30.0F);
        double d0 = this.getX();
        double d1 = this.getEyeY() - 5.0;
        double d2 = this.getZ();
        double d3 = this.getTarget().getX() - d0;
        double d4 = this.getTarget().getEyeY() - d1;
        double d5 = this.getTarget().getZ() - d2;
        EntitySnowballTitan snowballTitan = new EntitySnowballTitan(this.level(), this);
        snowballTitan.setPos(d0, d1, d2);
        snowballTitan.shoot(d3, d4, d5, 1.0F, 0.0F);
        if (!this.level().isClientSide()) {
            this.level().addFreshEntity(snowballTitan);
        }
    }

    @Override
    protected void dropExperienceOrb() {
        for (int x = 0; x < 2; x++) {
            EntityExperienceOrbTitan experienceOrbTitan = new EntityExperienceOrbTitan(
                this.level(),
                this.getX() + (double)(this.random.nextFloat() * 12.0F - 6.0F),
                this.getY() + 4.0,
                this.getZ() + (double)(this.random.nextFloat() * 12.0F - 6.0F),
                1000
            );
            experienceOrbTitan.push(0.0, 1.0, 0.0);
            this.level().addFreshEntity(experienceOrbTitan);
        }
    }

    @Override
    protected void dropAllItem() {
        Map<ItemStack, Integer> drops = new HashMap<>();
        Map<ItemStack, Integer> rateDrops = new HashMap<>();
        drops.put(new ItemStack(Items.SNOWBALL), 256);
        rateDrops.put(new ItemStack(Items.SNOWBALL), 256);
        rateDrops.put(new ItemStack(Items.EMERALD), 4);
        rateDrops.put(new ItemStack(Items.DIAMOND), 4);

        for (Entry<ItemStack, Integer> entry : drops.entrySet()) {
            ItemStack itemStack = entry.getKey();
            int count = entry.getValue();
            EntityItemTitan itemTitan = new EntityItemTitan(
                this.level(),
                this.getX() + (double)(this.random.nextFloat() * 12.0F - 6.0F),
                this.getY() + 4.0,
                this.getZ() + (double)(this.random.nextFloat() * 12.0F - 6.0F),
                itemStack,
                count
            );
            itemTitan.setPickUpDelay(40);
            this.level().addFreshEntity(itemTitan);
        }

        for (Entry<ItemStack, Integer> entry : rateDrops.entrySet()) {
            ItemStack itemStack = entry.getKey();
            int count = entry.getValue();
            int randomCount = this.random.nextInt(count) + 1;
            EntityItemTitan itemTitan = new EntityItemTitan(
                this.level(),
                this.getX() + (double)(this.random.nextFloat() * 12.0F - 6.0F),
                this.getY() + 4.0,
                this.getZ() + (double)(this.random.nextFloat() * 12.0F - 6.0F),
                itemStack,
                randomCount
            );
            itemTitan.setPickUpDelay(40);
            this.level().addFreshEntity(itemTitan);
        }
    }

    @Override
    public void aiStep() {
        super.aiStep();
        if (this.getTarget() != null) {
            if (this.tickCount % 30 == 0) {
                double d0 = this.distanceToSqr(this.getTarget());
                if (d0 <= this.getMeleeRange()) {
                    this.swing(InteractionHand.MAIN_HAND);
                    this.getLookControl().setLookAt(this.getTarget(), 180.0F, 30.0F);
                    float amount = (float)this.getAttributeBaseValue(Attributes.ATTACK_DAMAGE);
                    this.attackEntity(this.getTarget(), amount);
                }
            }

            for (Entity entity : this.level().getEntities(this, this.getBoundingBox().inflate(128.0, 128.0, 128.0))) {
                if (entity != null && entity instanceof SnowGolem) {
                    SnowGolem snowGolem = (SnowGolem)entity;
                    snowGolem.setTarget(this.getTarget());
                    snowGolem.getLookControl().setLookAt(this.getTarget(), 40.0F, 40.0F);
                    if (snowGolem.horizontalCollision) {
                        snowGolem.setDeltaMovement(snowGolem.getDeltaMovement().x, 0.25, snowGolem.getDeltaMovement().y);
                    }

                    if (!this.level().isClientSide() && entity.tickCount % 20 == 0) {
                        snowGolem.performRangedAttack(this.getTarget(), 1.0F);
                    }
                }
            }
        }
    }

    @Override
    protected void tickTitanDeath() {
        super.tickTitanDeath();
        this.animateHurt(180.0F);
        this.destroyBlocksInAABB(this.getBoundingBox());
        if (this.deathTicks >= 20) {
            this.onDeath();
            if (!this.level().isClientSide() && !this.isRemoved()) {
                this.removeTitan(RemovalReason.KILLED);
            }
        }
    }

    @Override
    public void tick() {
        super.tick();

        for (int i = 0; i < 1024; i++) {
            int x = Mth.floor(this.getX() + ((double)this.random.nextFloat() - 0.5) * (double)this.getBbWidth());
            int y = Mth.floor(this.getY());
            int z = Mth.floor(this.getZ() + ((double)this.random.nextFloat() - 0.5) * (double)this.getBbWidth());
            BlockPos blockPos = new BlockPos(x, y, z);
            BlockState blockState = this.level().getBlockState(blockPos);
            if (blockState.isAir()
                && ((Biome)this.level().getBiome(blockPos).value()).getBaseTemperature() < 1.3F
                && Blocks.SNOW.defaultBlockState().canSurvive(this.level(), blockPos)) {
                this.level().setBlockAndUpdate(blockPos, Blocks.SNOW.defaultBlockState());
            }
        }

        float randomRate = this.random.nextFloat() * 100.0F;
        if (this.isAlive() && this.tickCount % 20 == 0 && (double)randomRate < 5.0) {
            SnowGolem snowGolem = new SnowGolem(EntityType.SNOW_GOLEM, this.level());
            snowGolem.setPos(
                this.getX() + ((double)this.random.nextFloat() - 0.5) * (double)this.getBbWidth(),
                this.getY(),
                this.getZ() + ((double)this.random.nextFloat() - 0.5) * (double)this.getBbWidth()
            );
            snowGolem.setYRot(this.getYRot());
            snowGolem.getAttribute(Attributes.MAX_HEALTH).setBaseValue(20.0);
            snowGolem.setHealth(20.0F);
            snowGolem.setCustomName(Component.translatable("entity.titan.reinforced_snow_golem"));
            if (!this.level().isClientSide()) {
                this.level().addFreshEntity(snowGolem);
            }
        }
    }
}
