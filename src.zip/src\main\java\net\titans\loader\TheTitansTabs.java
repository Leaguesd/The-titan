package net.titans.loader;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ItemLike;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.RegistryObject;

public class TheTitansTabs {
    public static final DeferredRegister<CreativeModeTab> TABS = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, "titan");
    public static final List<Item> BLACK_ITEMS = new ArrayList<>();
    public static final RegistryObject<CreativeModeTab> THE_TITANS_TAB = TABS.register(
        "titan",
        () -> CreativeModeTab.builder()
                .title(Component.translatable("itemGroup.titan"))
                .icon(() -> new ItemStack((ItemLike)TheTitansRegistries.GROWTH_SERUM.get()))
                .displayItems((generator, output) -> {
                    // 两个种子注册得最早，会把创造栏开头占掉；这里把它们从原位跳过，统一追加到栏尾
                    Item malgrumSeeds = (Item)TheTitansRegistries.MALGRUM_SEEDS.get();
                    Item pleasantBladeSeed = (Item)TheTitansRegistries.PLEASANT_BLADE_SEED.get();
                    for (RegistryObject<Item> itemHolder : TheTitansRegistries.ITEMS.getEntries()) {
                        Item item = (Item)itemHolder.get();
                        if (item != malgrumSeeds && item != pleasantBladeSeed && !BLACK_ITEMS.contains(item)) {
                            output.accept(new ItemStack(item));
                        }
                    }
                    output.accept(new ItemStack(malgrumSeeds));
                    output.accept(new ItemStack(pleasantBladeSeed));
                })
                .build()
    );

    public static void registerTabs(IEventBus modEventBus) {
        TABS.register(modEventBus);
    }
}
