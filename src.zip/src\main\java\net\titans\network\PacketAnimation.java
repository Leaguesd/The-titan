package net.titans.network;

import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.world.level.Level;
import net.minecraftforge.network.NetworkEvent.Context;
import net.titans.animation.IAnimatedEntity;

public record PacketAnimation(int entityID, int animationID, int animationTick) {
    public static PacketAnimation fromNetwork(FriendlyByteBuf friendlyByteBuf) {
        int entityID = friendlyByteBuf.readInt();
        int animationID = friendlyByteBuf.readInt();
        int animationTick = friendlyByteBuf.readInt();
        return new PacketAnimation(entityID, animationID, animationTick);
    }

    public static void toNetwork(PacketAnimation packet, FriendlyByteBuf friendlyByteBuf) {
        friendlyByteBuf.writeInt(packet.entityID);
        friendlyByteBuf.writeInt(packet.animationID);
        friendlyByteBuf.writeInt(packet.animationTick);
    }

    public static void handle(PacketAnimation packet, Supplier<Context> contextSupplier) {
        Context context = contextSupplier.get();
        context.enqueueWork(() -> handleOnKnownLevel(packet, context));
        context.setPacketHandled(true);
    }

    private static void handleOnKnownLevel(PacketAnimation packet, Context context) {
        if (context.getSender() != null) {
            Level level = context.getSender().level();
            if (level.getEntity(packet.entityID) instanceof IAnimatedEntity animatedEntity) {
                if (packet.animationID != -1) {
                    animatedEntity.setAnimationID(packet.animationID);
                }

                if (packet.animationTick != -1) {
                    animatedEntity.setAnimationTick(packet.animationTick);
                }

                if (packet.animationID == 0) {
                    animatedEntity.setAnimationTick(0);
                }
            }
        }
    }
}
