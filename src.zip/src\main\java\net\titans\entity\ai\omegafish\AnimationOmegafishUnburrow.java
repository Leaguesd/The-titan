package net.titans.entity.ai.omegafish;

import net.titans.animation.AIAnimation;
import net.titans.entity.titan.EntityOmegafish;

public class AnimationOmegafishUnburrow extends AIAnimation {
    private EntityOmegafish entity;

    public AnimationOmegafishUnburrow(EntityOmegafish entity) {
        super(entity);
        this.entity = entity;
    }

    @Override
    public int getAnimationID() {
        return 2;
    }

    @Override
    public boolean isAutomatic() {
        return true;
    }

    @Override
    public int getDuration() {
        return 70;
    }

    @Override
    public boolean canContinueToUse() {
        return this.entity.getAnimationTick() <= this.getDuration() && !this.entity.isStunned ? super.canContinueToUse() : false;
    }
}
