package net.titans.block;

import net.minecraft.core.BlockPos;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.ItemLike;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.CropBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.BlockBehaviour.Properties;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;
import net.titans.loader.TheTitansRegistries;
import net.titans.loader.TheTitansRegistries;

public class BlockPleasantBladeCrop extends CropBlock {
    public BlockPleasantBladeCrop(Properties properties) {
        super(properties);
    }

    public ItemLike getBaseSeedId() {
        return (ItemLike)TheTitansRegistries.MALGRUM_SEEDS.get();
    }

    public VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        return Block.box(6.0, 0.0, 6.0, 10.0, 16.0, 10.0);
    }

    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hitResult) {
        if (this.getAge(state) >= this.getMaxAge()) {
            ItemEntity itemEntity = new ItemEntity(
                level, player.getX(), player.getY() + 1.0, player.getZ(), new ItemStack((ItemLike)TheTitansRegistries.PLEASANT_BLADE_FLOWER.get())
            );
            if (!level.isClientSide()) {
                level.addFreshEntity(itemEntity);
            }

            level.setBlock(pos, this.getStateForAge(this.getAge(state) - 1), 2);
            return InteractionResult.sidedSuccess(level.isClientSide());
        } else {
            return InteractionResult.PASS;
        }
    }
}
