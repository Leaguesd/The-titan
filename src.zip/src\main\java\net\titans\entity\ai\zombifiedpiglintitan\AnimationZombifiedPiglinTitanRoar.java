package net.titans.entity.ai.zombifiedpiglintitan;

import net.titans.animation.AIAnimation;
import net.titans.entity.titan.EntityZombifiedPiglinTitan;

public class AnimationZombifiedPiglinTitanRoar extends AIAnimation {
    private EntityZombifiedPiglinTitan entity;

    public AnimationZombifiedPiglinTitanRoar(EntityZombifiedPiglinTitan entity) {
        super(entity);
        this.entity = entity;
    }

    @Override
    public int getAnimationID() {
        return 11;
    }

    @Override
    public boolean isAutomatic() {
        return true;
    }

    @Override
    public int getDuration() {
        return 200;
    }

    @Override
    public boolean canContinueToUse() {
        return this.entity.getAnimationTick() <= this.getDuration() && !this.entity.isStunned ? super.canContinueToUse() : false;
    }

    public void tick() {
        if (this.entity.getTarget() != null && this.entity.getAnimationTick() < 20) {
            this.entity.getLookControl().setLookAt(this.entity.getTarget(), 5.0F, 40.0F);
        }
    }
}
