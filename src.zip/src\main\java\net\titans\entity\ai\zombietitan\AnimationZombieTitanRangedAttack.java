package net.titans.entity.ai.zombietitan;

import net.titans.animation.AIAnimation;
import net.titans.entity.titan.EntityZombieTitan;

public class AnimationZombieTitanRangedAttack extends AIAnimation {
    private EntityZombieTitan entity;

    public AnimationZombieTitanRangedAttack(EntityZombieTitan entity) {
        super(entity);
        this.entity = entity;
    }

    @Override
    public int getAnimationID() {
        return 12;
    }

    @Override
    public boolean isAutomatic() {
        return true;
    }

    @Override
    public int getDuration() {
        return 110;
    }

    @Override
    public boolean canContinueToUse() {
        return this.entity.getAnimationTick() > this.getDuration() ? false : super.canContinueToUse();
    }

    public void tick() {
        if (this.entity.getTarget() != null) {
            this.entity.getLookControl().setLookAt(this.entity.getTarget(), 5.0F, 40.0F);
        }
    }
}
