package net.titans.entity.ai.spidertitan;

import net.titans.animation.AIAnimation;
import net.titans.entity.titan.EntitySpiderTitan;

public class AnimationSpiderTitanAttack2 extends AIAnimation {
    private EntitySpiderTitan entity;

    public AnimationSpiderTitanAttack2(EntitySpiderTitan entity) {
        super(entity);
        this.entity = entity;
    }

    @Override
    public int getAnimationID() {
        return 5;
    }

    @Override
    public boolean isAutomatic() {
        return true;
    }

    @Override
    public int getDuration() {
        return 50;
    }

    @Override
    public boolean canContinueToUse() {
        return this.entity.getAnimationTick() <= this.getDuration() && !this.entity.isStunned ? super.canContinueToUse() : false;
    }

    public void tick() {
        if (this.entity.getTarget() != null && this.entity.getAnimationTick() < 20) {
            this.entity.getLookControl().setLookAt(this.entity.getTarget(), 180.0F, 180.0F);
        }
    }
}
