package net.titans.event;

import com.mojang.blaze3d.systems.RenderSystem;
import java.text.DecimalFormat;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraftforge.client.event.CustomizeGuiOverlayEvent.BossEventProgress;
import net.minecraftforge.client.event.RenderGuiOverlayEvent.Post;
import net.minecraftforge.client.event.RenderGuiOverlayEvent.Pre;
import net.minecraftforge.client.gui.overlay.VanillaGuiOverlay;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.titans.entity.IBossBarDisplay;
import net.titans.entity.titan.EntityTitan;

public class TheTitansBossBarEvent {
    public void render(GuiGraphics guiGraphics) {
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer player = mc.player;
        if (!mc.options.hideGui) {
            if (player != null) {
                int range = 256;
                int x = mc.getWindow().getGuiScaledWidth() / 2;
                int y = 12;

                for (Entity entity : player.level().getEntities(player, player.getBoundingBox().inflate((double)range, (double)range, (double)range))) {
                    if (entity instanceof IBossBarDisplay && entity instanceof LivingEntity) {
                        IBossBarDisplay bossBarDisplay = (IBossBarDisplay)entity;
                        LivingEntity livingEntity = (LivingEntity)entity;
                        if (bossBarDisplay.getBossBarTexture() != null) {
                            ResourceLocation bossBar = bossBarDisplay.getBossBarTexture();
                            Component name = livingEntity.hasCustomName() ? livingEntity.getCustomName() : livingEntity.getName();
                            int color = bossBarDisplay.getBossBarNameColor();
                            int healthColor = bossBarDisplay.getBossBarHealthColor();
                            float health = livingEntity.getHealth();
                            float maxHealth = livingEntity.getMaxHealth();
                            if (entity instanceof EntityTitan titan) {
                                health = titan.getTitanHealth();
                            }

                            int width = bossBarDisplay.getBossBarWidth();
                            int height = bossBarDisplay.getBossBarHeight();
                            int interval = bossBarDisplay.getBossBarInterval();
                            int vOffset = bossBarDisplay.getBossBarVOffset();
                            int vHeight = bossBarDisplay.getBossBarVHeight();
                            int textOffset = bossBarDisplay.getBossBarTextOffset();
                            int healthWidth = (int)Math.min(health / maxHealth * (float)width, (float)width);
                            x = mc.getWindow().getGuiScaledWidth() / 2 - width / 2;
                            guiGraphics.pose().pushPose();
                            RenderSystem.enableBlend();
                            guiGraphics.blit(bossBar, x, y, 0, 0, width, height);
                            if (healthWidth > 0) {
                                guiGraphics.blit(bossBar, x, y, 0, height + vOffset, healthWidth, height + vHeight);
                            }

                            String healthText = new DecimalFormat("#").format((double)health) + "/" + new DecimalFormat("#").format((double)maxHealth);
                            guiGraphics.drawString(mc.font, name, x + (width / 2 - mc.font.width(name) / 2) + 1, y + height - textOffset, color);
                            guiGraphics.drawString(
                                mc.font, healthText, x + (width / 2 - mc.font.width(healthText) / 2) + 1, y + height - textOffset + 10, healthColor
                            );
                            RenderSystem.disableBlend();
                            guiGraphics.pose().popPose();
                            y += height + interval + 12;
                            if (y >= guiGraphics.guiHeight() / 3) {
                                break;
                            }
                        }
                    }
                }
            }
        }
    }

    @SubscribeEvent
    public void onBossEventProgress(BossEventProgress event) {
        GuiGraphics guiGraphics = event.getGuiGraphics();
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer player = mc.player;
        if (player != null) {
            int range = 256;
            int index = 0;
            int y = 12;

            for (Entity entity : player.level().getEntities(player, player.getBoundingBox().inflate((double)range, (double)range, (double)range))) {
                if (entity instanceof IBossBarDisplay && entity instanceof LivingEntity) {
                    IBossBarDisplay bossBarDisplay = (IBossBarDisplay)entity;
                    if (bossBarDisplay.getBossBarTexture() != null) {
                        int height = bossBarDisplay.getBossBarHeight();
                        int interval = bossBarDisplay.getBossBarInterval();
                        y += height + interval + 12;
                        index++;
                        if (y >= guiGraphics.guiHeight() / 3) {
                            break;
                        }
                    }
                }
            }

            if (index > 0 && event.getY() + y >= guiGraphics.guiHeight() / 3) {
                event.setCanceled(true);
            }
        }
    }

    @SubscribeEvent
    public void onRenderGuiOverlayPre(Pre event) {
        GuiGraphics guiGraphics = event.getGuiGraphics();
        ResourceLocation name = event.getOverlay().id();
        Minecraft mc = Minecraft.getInstance();
        if (name.equals(VanillaGuiOverlay.BOSS_EVENT_PROGRESS.id())) {
            LocalPlayer player = mc.player;
            this.render(guiGraphics);
            guiGraphics.pose().pushPose();
            if (player != null) {
                int range = 256;
                int index = 0;
                int y = 12;

                for (Entity entity : player.level().getEntities(player, player.getBoundingBox().inflate((double)range, (double)range, (double)range))) {
                    if (entity instanceof IBossBarDisplay && entity instanceof LivingEntity) {
                        IBossBarDisplay bossBarDisplay = (IBossBarDisplay)entity;
                        if (bossBarDisplay.getBossBarTexture() != null) {
                            int height = bossBarDisplay.getBossBarHeight();
                            int interval = bossBarDisplay.getBossBarInterval();
                            y += height + interval + 12;
                            index++;
                            if (y >= guiGraphics.guiHeight() / 3) {
                                break;
                            }
                        }
                    }
                }

                if (index > 0) {
                    guiGraphics.pose().translate(0.0, (double)y, 0.0);
                }
            }
        }
    }

    @SubscribeEvent
    public void onRenderGuiOverlayPost(Post event) {
        GuiGraphics guiGraphics = event.getGuiGraphics();
        ResourceLocation name = event.getOverlay().id();
        if (name.equals(VanillaGuiOverlay.BOSS_EVENT_PROGRESS.id())) {
            guiGraphics.pose().popPose();
        }
    }
}
