package net.titans.entity.titan;

import com.google.common.collect.Lists;
import java.lang.reflect.Constructor;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.BlockParticleOption;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.contents.TranslatableContents;
import net.minecraft.network.protocol.game.ClientboundHurtAnimationPacket;
import net.minecraft.network.protocol.game.ClientboundSetTimePacket;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerChunkCache;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.util.Mth;
import net.minecraft.world.Difficulty;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.MoverType;
import net.minecraft.world.entity.SpawnGroupData;
import net.minecraft.world.entity.Entity.RemovalReason;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier.Builder;
import net.minecraft.world.entity.ambient.AmbientCreature;
import net.minecraft.world.entity.item.FallingBlockEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.FishingHook;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.entity.projectile.WitherSkull;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.GameRules;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.ServerLevelAccessor;
import net.minecraft.world.level.ClipContext.Block;
import net.minecraft.world.level.ClipContext.Fluid;
import net.minecraft.world.level.Level.ExplosionInteraction;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.LiquidBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.HitResult.Type;
import net.minecraftforge.entity.PartEntity;
import net.minecraftforge.event.ForgeEventFactory;
import net.titans.util.EntityUtils;
import net.titans.animation.IAnimatedEntity;
import net.titans.damage.DamageSourceTitanAttack;
import net.titans.entity.ai.EntityAITitanLookIdle;
import net.titans.entity.ai.EntityAITitanWatchClosest;
import net.titans.entity.minion.EnumMinionType;
import net.titans.entity.minion.IMinion;
import net.titans.entity.projectile.EntityHarcadiumArrow;
import net.titans.entity.projectile.IEntityProjectileTitan;
import net.titans.loader.TheTitansAttributes;
import net.titans.loader.TheTitansDimensions;
import net.titans.loader.TheTitansRegistries;
import net.titans.loader.TheTitansMinions;
import net.titans.loader.TheTitansPredicateTargets;
import net.titans.loader.TheTitansSounds;
import net.titans.loader.TheTitansTriggers;
import net.titans.util.AnimationUtils;
import net.titans.util.ItemUtils;

public class EntityTitan extends AmbientCreature implements IAnimatedEntity {
    private static final EntityDataAccessor<Integer> ANIMATION_ID = SynchedEntityData.defineId(EntityTitan.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> ANTI_TITAN_ATTACK__ANIMATION_ID = SynchedEntityData.defineId(
        EntityTitan.class, EntityDataSerializers.INT
    );
    private static final EntityDataAccessor<Integer> EXTRAPOWER = SynchedEntityData.defineId(EntityTitan.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> INVULTIME = SynchedEntityData.defineId(EntityTitan.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Boolean> WAITING = SynchedEntityData.defineId(EntityTitan.class, EntityDataSerializers.BOOLEAN);
    private static final EntityDataAccessor<Float> TITAN_HEALTH = SynchedEntityData.defineId(EntityTitan.class, EntityDataSerializers.FLOAT);
    private static final EntityDataAccessor<Integer> MINION_NUMBER = SynchedEntityData.defineId(EntityTitan.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> PRIEST_NUMBER = SynchedEntityData.defineId(EntityTitan.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> ZEALOT_NUMBER = SynchedEntityData.defineId(EntityTitan.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> BISHOP_NUMBER = SynchedEntityData.defineId(EntityTitan.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> TEMPLAR_NUMBER = SynchedEntityData.defineId(EntityTitan.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> SPECIAL_MINION_NUMBER = SynchedEntityData.defineId(EntityTitan.class, EntityDataSerializers.INT);
    public int invulnerableTicks;
    public int deathTicks;
    public boolean shouldParticlesBeUpward;
    public boolean isRejuvinating;
    public int footID;
    public int nextStepDistanceTitan;
    public EntityTitanPart[] parts;
    private boolean titanHealthReady;
    /**
     * 泰坦自身记录的最大生命值。不直接使用 MAX_HEALTH 属性，
     * 防止其他模组通过改动该属性来篡改/压低泰坦血量。
     */
    private float titanMaxHealth = -1.0F;
    private boolean titanMaxHealthReady;
    private boolean allowTitanHealthZero;
    private boolean allowHealthDecrease;
    private int lastInternalHealthWriteTick = -100;
    private float lastKnownTitanHealth = -1.0F;
    private float titanHealthValue = -1.0F;
    private int lastTitanMaxRefreshTick = -100;
    /**
     * 动画播放进度（tick）。
     *
     * <p>不再放进 SynchedEntityData：客户端和服务端各自推进自己的进度，
     * 客户端在同步到新的 {@link #ANIMATION_ID} 时归零。
     * 这样动画渲染不会因为“客户端本地 +1”与“服务端每 tick 同步覆盖”互相打架而抽搐；
     * 服务端仍然用自己的进度执行攻击判定。
     */
    private int animationTick;

    public EntityTitan(EntityType<? extends EntityTitan> entityType, Level level) {
        super(entityType, level);
        // 字段初始化器会在 super() 之后把标志重置为 false，这里重新置位
        this.titanHealthReady = true;
        this.noCulling = true;
        this.refreshTitanAttributes();
        this.setTitanHealth(this.getTitanMaxHealth());
        this.setPersistenceRequired();
    }

    public static Builder createAttributes() {
        return createLivingAttributes()
            .add(Attributes.MAX_HEALTH, Double.MAX_VALUE)
            .add(Attributes.FOLLOW_RANGE, 512.0)
            .add(Attributes.KNOCKBACK_RESISTANCE, 1.0)
            .add(Attributes.KNOCKBACK_RESISTANCE, 1.0);
    }

    protected void registerGoals() {
        this.goalSelector.addGoal(7, new EntityAITitanWatchClosest(this, EntityTitanSpirit.class, 128.0F, 0.25F));
        this.goalSelector.addGoal(8, new EntityAITitanWatchClosest(this, EntityTitan.class, 128.0F, 0.5F));
        this.goalSelector.addGoal(9, new EntityAITitanWatchClosest(this, Player.class, 128.0F));
        this.goalSelector.addGoal(10, new EntityAITitanLookIdle(this));
    }

    @Override
    public int getAnimationID() {
        return (Integer)this.entityData.get(ANIMATION_ID);
    }

    @Override
    public void setAnimationID(int id) {
        if (this.getAnimationID() != id) {
            this.animationTick = 0;
        }

        this.entityData.set(ANIMATION_ID, id);
    }

    @Override
    public int getAnimationTick() {
        return this.animationTick;
    }

    @Override
    public void setAnimationTick(int tick) {
        this.animationTick = tick;
    }

    /**
     * 客户端收到新的动画 ID 时，本地动画进度从 0 开始；
     * 服务端自己的进度不受数据同步影响。
     */
@Override
public void onSyncedDataUpdated(EntityDataAccessor<?> key) {
    super.onSyncedDataUpdated(key);
    if (ANIMATION_ID.equals(key)) {
        this.animationTick = 0;
    }
    // 死亡期间客户端不再本地调 setInvulTime，xRot 由这里跟随服务端同步更新，
    // 避免模型缩放正确但头部朝向滞后 1~2 tick。
    if (INVULTIME.equals(key)) {
        int inv = (Integer)this.entityData.get(INVULTIME);
        if (this instanceof EntityCreeperTitan) {
            this.setXRot((float)inv / (float)this.getThreashHold() * 40.0F);
        } else {
            this.setXRot((float)inv / (float)this.getThreashHold() * 180.0F);
        }
    }
}

    public int getAntiTitanAttackAnimationID() {
        return (Integer)this.entityData.get(ANTI_TITAN_ATTACK__ANIMATION_ID);
    }

    public void setAntiTitanAttackAnimationID(int id) {
        this.entityData.set(ANTI_TITAN_ATTACK__ANIMATION_ID, id);
    }

    public int getExtraPower() {
        return (Integer)this.entityData.get(EXTRAPOWER);
    }

    public void setExtraPower(int extraPower) {
        this.entityData.set(EXTRAPOWER, extraPower);
    }

    public int getInvulTime() {
        return (Integer)this.entityData.get(INVULTIME);
    }

    public void setInvulTime(int invulTime) {
    int clamped = Math.max(invulTime, 0);

    // 死亡期间 invulTime 是渲染端死亡缩小的唯一驱动（RenderXxxTitan.scale()）。
    // 它一旦回落，模型就会反向放大，所以这里必须把它钉成单调不减：
    // - 客户端：死亡期间拒绝一切本地写入，只接受服务端同步（见 onSyncedDataUpdated）；
    // - 服务端：死亡期间只允许增大，拒绝任何写小（外部模组、旧逻辑、子类误调）。
    // tickCount > 0 排除构造/读档阶段；deathTicks > 1 让死亡第一 tick 仍可被重置为 0。
    if (this.tickCount > 0 && this.getTitanHealth() <= 0.0F && this.deathTicks > 1) {
        if (this.level() != null && this.level().isClientSide()) {
            return;
        }
        if (clamped < this.getInvulTime()) {
            return;
        }
    }

    this.forceSetInvulTime(clamped);
}

/**
 * 绕过死亡单调性检查的底层写入。仅用于死亡第一 tick 的重置，
 * 以及 setInvulTime 通过检查后的正常写入。
 */
protected void forceSetInvulTime(int invulTime) {
    int clamped = Math.max(invulTime, 0);
    this.entityData.set(INVULTIME, clamped);
    if (this instanceof EntityCreeperTitan) {
        this.setXRot((float)clamped / (float)this.getThreashHold() * 40.0F);
    } else {
        this.setXRot((float)clamped / (float)this.getThreashHold() * 180.0F);
    }
}

    public boolean getWaiting() {
        return (Boolean)this.entityData.get(WAITING);
    }

    public void setWaiting(boolean waiting) {
        this.entityData.set(WAITING, waiting);
    }

    public float getTitanHealth() {
        if (!this.titanHealthReady) {
            return 1.0F;
        }

        // 客户端读同步数据；服务端读自身字段，避免同步数据被外部清零影响判定
        if (this.level() != null && this.level().isClientSide()) {
            return (Float)this.entityData.get(TITAN_HEALTH);
        }

        if (this.titanHealthValue < 0.0F) {
            this.titanHealthValue = (Float)this.entityData.get(TITAN_HEALTH);
        }

        return this.titanHealthValue;
    }

    public void setTitanHealth(float health) {
    // 任何外部来源把血量写成 0 或负数都视为无效，只有内部死亡路径才允许
    if (health <= 0.0F && !this.allowTitanHealthZero) {
        return;
    }

    // 外部试图降低血量（不是内部扣血入口）时拒绝，防止被一点点磨死
    if (this.titanHealthReady
        && this.titanHealthValue >= 0.0F
        && health < this.titanHealthValue
        && !this.allowHealthDecrease) {
        return;
    }

    this.titanHealthValue = health;
    if (this.titanHealthReady) {
        this.entityData.set(TITAN_HEALTH, health);
    }
}
    /**
     * 内部扣血入口：允许把血量扣到 0（正常击杀）。
     */
    public void damageTitanHealth(float amount) {
    this.allowTitanHealthZero = true;
    this.allowHealthDecrease = true;
    this.lastInternalHealthWriteTick = this.tickCount;
    this.setTitanHealth(Math.max(this.getTitanHealth() - amount, 0.0F));
    this.lastKnownTitanHealth = this.titanHealthValue;
    this.allowHealthDecrease = false;
    this.allowTitanHealthZero = false;
}
    /**
     * 内部强制设置血量（含 0），用于读档与特殊死亡流程。
     */
    protected void setTitanHealthForced(float health) {
    this.allowTitanHealthZero = true;
    this.allowHealthDecrease = true;
    this.lastInternalHealthWriteTick = this.tickCount;
    this.setTitanHealth(health);
    this.lastKnownTitanHealth = health;
    this.allowHealthDecrease = false;
    this.allowTitanHealthZero = false;
}
    /**
     * 拒绝血量未归零时的外部强制死亡（部分模组会直接调用 die()）。
     */
    @Override
    public void die(DamageSource damageSource) {
        if (this.getTitanHealth() > 0.0F) {
            return;
        }

        super.die(damageSource);
    }

    /**
     * 血量完整性守卫：如果有外部代码绕过 setTitanHealth 直接把同步数据里的血量清 0，
     * 在这里回滚到上一 tick 的血量。
     */
    private void guardTitanHealthIntegrity() {
    if (this.level().isClientSide()) {
        return;
    }

    float current = this.getTitanHealth();

    // 关键修复：只要低于“合法快照”，就回滚。
    // 内部入口（damageTitanHealth / setTitanHealthForced）已经同步了快照，
    // 所以正常扣血不会触发；外部反射写字段、setTitanHealth 非法降血都会被抓到。
    if (this.lastKnownTitanHealth > 0.0F && current < this.lastKnownTitanHealth) {
        this.setTitanHealthForced(this.lastKnownTitanHealth);
        current = this.lastKnownTitanHealth;
    }

    if (current > 0.0F) {
        this.lastKnownTitanHealth = current;
    }

    // 服务端把权威血量重新写回同步数据，修复被外部清零的客户端显示
    if (this.titanHealthValue >= 0.0F
        && !this.level().isClientSide()
        && (Float)this.entityData.get(TITAN_HEALTH) != this.titanHealthValue) {
        this.entityData.set(TITAN_HEALTH, this.titanHealthValue);
    }
}

    public float getHealth() {
        return this.getTitanHealth();
    }

    /**
     * 泰坦的最大生命值由自身字段记录，不受 MAX_HEALTH 属性被外部篡改的影响。
     */
    /**
 * 泰坦的最大生命值由自身字段记录，不受 MAX_HEALTH 属性被外部篡改的影响。
 * 但如果缓存字段比当前属性值大（例如 baby/armed 状态切换后未及时同步），
 * 以属性值为准，避免 heal / isArmored 等按过期的缓存值运行。
 */
public float getTitanMaxHealth() {
    float attributeMax = super.getMaxHealth();

    if (this.titanMaxHealth <= 0.0F) {
        this.titanMaxHealth = attributeMax;
    }

    if (attributeMax > 0.0F && this.titanMaxHealth > attributeMax) {
        this.titanMaxHealth = attributeMax;
    }

    return this.titanMaxHealth;
}

    /**
     * 内部刷新属性（婴儿形态、持械、史莱姆尺寸、复活强化等）时统一走这里，
     * 刷新后同步最大生命值基线，避免被误判成外部篡改。
     */
    protected void refreshTitanAttributes() {
        this.refreshAttributes();

        if (this.level() == null || this.level().isClientSide()) {
            return;
        }

        float newMax = super.getMaxHealth();
        if (newMax > 0.0F) {
            this.titanMaxHealth = newMax;
            this.titanMaxHealthReady = true;
            this.lastTitanMaxRefreshTick = this.tickCount;
            if (this.getTitanHealth() > newMax) {
            this.setTitanHealthForced(newMax);
            }
        }
    }

   /**
 * 首次完整 tick（子类构造已完成）时刷新一次属性并记录最大生命值基线；
 * 之后属性与缓存偏差过大（超过 20 tick 未经过内部刷新）时，
 * 统一走 refreshTitanAttributes() 按难度/状态公式重算，既修复外部篡改，
 * 也修复状态切换后遗留的过期缓存。
 */
private void ensureTitanMaxHealth() {
    if (this.level() == null || this.level().isClientSide()) {
        return;
    }

    if (!this.titanMaxHealthReady) {
        this.refreshTitanAttributes();
        return;
    }

    double attributeMax = super.getMaxHealth();

    if (attributeMax <= 0.0) {
        this.refreshTitanAttributes();
        return;
    }

    boolean diverged = Math.abs(attributeMax - (double)this.titanMaxHealth) > 0.5
        && this.tickCount - this.lastTitanMaxRefreshTick > 20;
    if (diverged) {
        // 子类 refreshAttributes 会按公式重设 MAX_HEALTH，
        // refreshTitanAttributes 随后会把 titanMaxHealth 同步为最新属性值
        this.refreshTitanAttributes();
    }
}

    /**
     * 泰坦血量统一由 titanHealth 字段管理，禁止任何外部代码通过 setHealth 直接改血
     * （指令、其他模组、强制秒杀逻辑等一律无效）。
     */
    @Override
    public void setHealth(float health) {
        super.setHealth(this.titanHealthReady ? this.getTitanHealth() : health);
    }

    public int getMinionNumber() {
        return (Integer)this.entityData.get(MINION_NUMBER);
    }

    public void setMinionNumber(int number) {
        this.entityData.set(MINION_NUMBER, number);
    }

    public int getPriestNumber() {
        return (Integer)this.entityData.get(PRIEST_NUMBER);
    }

    public void setPriestNumber(int number) {
        this.entityData.set(PRIEST_NUMBER, number);
    }

    public int getZealotNumber() {
        return (Integer)this.entityData.get(ZEALOT_NUMBER);
    }

    public void setZealotNumber(int number) {
        this.entityData.set(ZEALOT_NUMBER, number);
    }

    public int getBishopNumber() {
        return (Integer)this.entityData.get(BISHOP_NUMBER);
    }

    public void setBishopNumber(int number) {
        this.entityData.set(BISHOP_NUMBER, number);
    }

    public int getTemplarNumber() {
        return (Integer)this.entityData.get(TEMPLAR_NUMBER);
    }

    public void setTemplarNumber(int number) {
        this.entityData.set(TEMPLAR_NUMBER, number);
    }

    public int getSpecialMinionNumber() {
        return (Integer)this.entityData.get(SPECIAL_MINION_NUMBER);
    }

    public void setSpecialMinionNumber(int number) {
        this.entityData.set(SPECIAL_MINION_NUMBER, number);
    }

    public boolean canAttack() {
        return false;
    }

    public boolean canAttack(LivingEntity target) {
        return target.canBeSeenByAnyone() && this.canAttackEntity(target);
    }

    public boolean canAttackType(EntityType<?> type) {
        return true;
    }

    public boolean canAttackEntity(Entity entity, boolean nullable) {
        if ((nullable || entity != null) && entity != this) {
            if (entity != null) {
                // 创造模式 / 旁观模式玩家永远不是攻击目标（硬编码，不读配置项）
                if (entity instanceof Player player && (player.isCreative() || player.isSpectator())) {
                    return false;
                }

                if (this.parts != null) {
                    List<EntityTitanPart> parts = Lists.newArrayList(this.parts);
                    if (parts.contains(entity)) {
                        return false;
                    }
                }

                if (this.getPassengers().contains(entity) || this.getVehicle() == entity) {
                    return false;
                }
            }

            return true;
        } else {
            return false;
        }
    }

    public boolean canAttackEntity(Entity entity) {
        return this.canAttackEntity(entity, false);
    }

    public boolean canBeHurtByPlayer() {
        return !this.isInvulnerable();
    }

    public boolean shouldMove() {
        return this.getTarget() != null && this.distanceToSqr(this.getTarget()) > this.getMeleeRange() + (this.canAttack() ? 0.0 : 10000.0);
    }

    public double getMeleeRange() {
        return (double)(
                this.getBbWidth() * this.getBbWidth() + (this.getTarget().getBbWidth() > 48.0F ? 2304.0F : this.getTarget().getBbWidth() * this.getTarget().getBbWidth())
            )
            + 800.0;
    }

    public int getKnockbackAmount() {
        switch (this.getTitanStatus()) {
            case GOD:
                return 24;
            case GREATER:
                return 16;
            case AVERAGE:
                return 8;
            default:
                return 4;
        }
    }

    public int getFootID() {
        return this.footID;
    }

    public int getFootStepModifer() {
        return 2;
    }

    public boolean canRegen() {
        return true;
    }

    public int getRegenTime() {
        return 20;
    }

    public boolean isArmored() {
        return false;
    }

    public SimpleParticleType getParticles() {
        switch (this.getTitanStatus()) {
            case GOD:
                return ParticleTypes.FIREWORK;
            case GREATER:
                return ParticleTypes.ENCHANTED_HIT;
            case AVERAGE:
                return ParticleTypes.CRIT;
            default:
                return ParticleTypes.ENCHANT;
        }
    }

    public int getParticleCount() {
        return 6;
    }

    public int getMinionCap() {
        return 0;
    }

    public int getPriestCap() {
        return 0;
    }

    public int getZealotCap() {
        return 0;
    }

    public int getBishopCap() {
        return 0;
    }

    public int getTemplarCap() {
        return 0;
    }

    public int getSpecialMinionCap() {
        return 0;
    }

    public boolean canSpawnMinion() {
        return false;
    }

    public boolean canSpawnPriest() {
        return false;
    }

    public boolean canSpawnZealot() {
        return false;
    }

    public boolean canSpawnBishop() {
        return false;
    }

    public boolean canSpawnTemplar() {
        return false;
    }

    public boolean canSpawnSpecialMinion() {
        return false;
    }

    public int getThreashHold() {
        switch (this.getTitanStatus()) {
            case GOD:
                return 7100;
            case GREATER:
                return 1310;
            case AVERAGE:
            default:
                return 850;
            case SIMPLE:
                return 150;
        }
    }

    public EnumTitanStatus getTitanStatus() {
        return EnumTitanStatus.LESSER;
    }

    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(ANIMATION_ID, 0);
        this.entityData.define(ANTI_TITAN_ATTACK__ANIMATION_ID, 0);
        this.entityData.define(EXTRAPOWER, 0);
        this.entityData.define(INVULTIME, 0);
        this.entityData.define(MINION_NUMBER, 0);
        this.entityData.define(PRIEST_NUMBER, 0);
        this.entityData.define(ZEALOT_NUMBER, 0);
        this.entityData.define(BISHOP_NUMBER, 0);
        this.entityData.define(TEMPLAR_NUMBER, 0);
        this.entityData.define(SPECIAL_MINION_NUMBER, 0);
        this.entityData.define(TITAN_HEALTH, 1.0F);
        this.entityData.define(WAITING, false);
    }

    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        // 动画状态（AnimationID/AnimationTick/AntiTitanAttackAnimationID）不读档：
        // AI 的目标、goal 状态并不会一起保存，恢复半截动画会让泰坦读档后卡在旧姿势上
        // （很多逻辑还以 getAnimationID() == 0 判断能否移动）。这里一律从 idle 重新开始。
        this.setExtraPower(tag.getInt("ExtraPower"));
        this.setInvulTime(tag.getInt("InvulTime"));
        this.setMinionNumber(tag.getInt("MinionNumber"));
        this.setPriestNumber(tag.getInt("PriestNumber"));
        this.setZealotNumber(tag.getInt("ZealotNumber"));
        this.setBishopNumber(tag.getInt("BishopNumber"));
        this.setTemplarNumber(tag.getInt("TemplarNumber"));
        this.setSpecialMinionNumber(tag.getInt("SpecialMinionNumber"));
        if (tag.contains("TitanHealth", 5)) {
            this.setTitanHealthForced(tag.getFloat("TitanHealth"));
        }

        this.setWaiting(tag.getBoolean("Waiting"));
        this.deathTicks = tag.getInt("DeathTicks");
    }

    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        // 动画状态不写入 NBT，理由见 readAdditionalSaveData。
        tag.putInt("ExtraPower", this.getExtraPower());
        tag.putInt("InvulTime", this.getInvulTime());
        tag.putBoolean("Waiting", this.getWaiting());
        tag.putFloat("TitanHealth", this.getTitanHealth());
        tag.putInt("MinionNumber", this.getMinionNumber());
        tag.putInt("PriestNumber", this.getPriestNumber());
        tag.putInt("ZealotNumber", this.getZealotNumber());
        tag.putInt("BishopNumber", this.getBishopNumber());
        tag.putInt("TemplarNumber", this.getTemplarNumber());
        tag.putInt("SpecialMinionNumber", this.getSpecialMinionNumber());
        tag.putInt("DeathTicks", this.deathTicks);
    }

    public boolean shouldRender(double pX, double pY, double pZ) {
        return true;
    }

    public boolean shouldRenderAtSqrDistance(double distance) {
        return true;
    }

    public boolean isAlwaysTicking() {
        return true;
    }

    public boolean isPersistenceRequired() {
        return true;
    }

    public boolean canUsePortal(boolean allowPassengers) {
        return false;
    }

    public boolean isMultipartEntity() {
        return this.parts != null;
    }

    public PartEntity<?>[] getParts() {
        return this.parts != null ? this.parts : null;
    }

    public boolean fireImmune() {
        return true;
    }

    public boolean isInvulnerable() {
        return this.getInvulTime() >= 1 || this.getWaiting() || this.getAnimationID() == 13 || this.deathTicks > 0 || super.isInvulnerable();
    }

    public boolean addEffect(MobEffectInstance mobEffectInstance, Entity entity) {
        return false;
    }

    public boolean addTitanEffect(MobEffectInstance mobEffectInstance, Entity entity) {
        return super.addEffect(mobEffectInstance, entity);
    }

    public boolean hasLineOfSight(Entity entity) {
        if (entity.level() != this.level()) {
            return false;
        } else {
            Vec3 vec3 = new Vec3(this.getX(), this.getEyeY(), this.getZ());
            Vec3 vec31 = new Vec3(entity.getX(), entity.getEyeY(), entity.getZ());
            return this.level().clip(new ClipContext(vec3, vec31, Block.COLLIDER, Fluid.NONE, this)).getType() == Type.MISS;
        }
    }

    protected float getSoundVolume() {
        return 100.0F;
    }

@Override
    public boolean isAlive() {
        return !this.isRemoved() && this.getTitanHealth() > 0.0F;
    }

    public boolean isDeadOrDying() {
        return this.getTitanHealth() <= 0.0F;
    }

    public int getMaxSpawnClusterSize() {
        return 1;
    }

    public float maxUpStep() {
        return (float)this.getFootStepModifer();
    }

    public float getSpeed() {
        return 0.3F + (float)this.getExtraPower() * 0.001F;
    }

    public float getScale() {
        return 1.0F;
    }

    protected void tickDeath() {
        this.deathTime = 0;
    }

    public void setTarget(@Nullable LivingEntity target) {
        if (target != this && this.canAttackEntity(target, true)) {
            if (target instanceof EntityTitan titan
                && (
                    this.level().dimension() == TheTitansDimensions.THE_VOID
                        || titan.getInvulTime() > 0
                        || titan.getWaiting()
                        || titan.getAnimationID() == 13
                )
                && !(titan instanceof EntityWitherzilla)) {
                super.setTarget(null);
                return;
            }

            super.setTarget(target);
        }
    }

    public void heal(float healAmount) {
        if (!(healAmount <= 0.0F)) {
            float f = this.getTitanHealth();
            if (f > 0.0F) {
                this.setTitanHealth(Math.min(f + healAmount, this.getTitanMaxHealth()));
            }
        }
    }

    public void updateFluidHeightAndDoFluidPushing() {
    }

    public void knockback(double strength, double x, double z) {
    }

    public void push(Vec3 vector) {
    }

    public void push(double x, double y, double z) {
    }

    public void push(Entity entity) {
        if (entity != null
            && this.isAlive()
            && !this.getWaiting()
            && this.getAnimationID() != 13
            && this.canAttackEntity(entity)
            && !this.hasPassenger(entity)
            && this.getVehicle() != entity
            && !(entity instanceof EntityTitanPart)
            && !(entity instanceof IEntityProjectileTitan)
            && !(entity instanceof EntityExperienceOrbTitan)
            && !(entity instanceof EntityItemTitan)) {
            double d0 = entity.getX() - this.getX();
            double d1 = entity.getZ() - this.getZ();
            double d2 = Mth.absMax(d0, d1);
            if (d2 >= 0.01) {
                d2 = Math.sqrt(d2);
                d0 /= d2;
                d1 /= d2;
                double d3 = 1.0 / d2;
                if (d3 > 1.0) {
                    d3 = 1.0;
                }

                d0 *= d3;
                d1 *= d3;
                d0 *= 0.25;
                d1 *= 0.25;
                if (entity.getBbHeight() >= 6.0F || entity instanceof EntityTitan) {
                    this.setTitanDeltaMovement(this.getDeltaMovement().add(-d0, 0.0, -d1));
                }

                d0 *= 4.0;
                d1 *= 4.0;
                entity.push(d0, 0.75, d1);
            }
        }
    }

    protected void pushEntities() {
        List<Entity> entities = this.level().getEntities(this, this.getBoundingBox().inflate(0.1, 0.1, 0.1));
        if (!this.getWaiting() && this.getAnimationID() != 13) {
            for (Entity entity : entities) {
                if (this.isAlive()
                    && entity.isAlive()
                    && (entity.isPushable() || entity instanceof EntityTitan || entity instanceof Projectile && ((Projectile)entity).getOwner() != this)
                    && entity.getBbHeight() > 6.0F
                    && !(entity instanceof Player)) {
                    this.doPush(entity);
                }
            }
        }
    }

    public void jumpFromGround() {
        super.jumpFromGround();
        this.playSound((SoundEvent)TheTitansSounds.TITAN_SWING.get(), 5.0F, 2.0F);
        this.setTitanDeltaMovement(this.getDeltaMovement().add(0.0, 2.0, 0.0));
    }

    protected void jumpAtEntity(LivingEntity entity) {
        this.setTitanDeltaMovement(this.getDeltaMovement().add(0.0, 1.25, 0.0));
        this.setPos(this.getX(), this.getY() + 1.55F, this.getZ());
        double d0 = entity.getX() - this.getX();
        double d1 = entity.getZ() - this.getZ();
        double d2 = Math.sqrt(d0 * d0 + d1 * d1);
        float f0 = (float)Math.atan2(d1, d0);
        float f1 = (float)((double)f0 * 180.0 / Math.PI) - 90.0F;
        this.setYRot(f1);
        this.setTitanDeltaMovement(this.getDeltaMovement().add(d2 * 0.05 * Math.cos((double)f0), 0.0, d2 * 0.05 * Math.sin((double)f0)));
        this.hasImpulse = true;
    }

    public void addDeltaMovement(Vec3 addend) {
        this.setTitanDeltaMovement(this.getDeltaMovement().add(addend));
    }

    public void setTitanDeltaMovement(Vec3 deltaMovement) {
        super.setDeltaMovement(deltaMovement);
    }

    public void setTitanDeltaMovement(double x, double y, double z) {
        this.setTitanDeltaMovement(new Vec3(x, y, z));
    }

    public boolean canRemove() {
        return this.getTitanHealth() <= 0.0F && this.deathTicks > 0;
    }

    public void remove(RemovalReason reason) {
    }

    public void removeTitan(RemovalReason reason) {
        if (this.canRemove()) {
            super.remove(reason);
        }
    }

    public void move(MoverType type, Vec3 pos) {
        super.move(type, pos);
    }

    public void retractMinionNumFromType(EnumMinionType minionType) {
        switch (minionType) {
            case LOYALIST:
                this.setMinionNumber(this.getMinionNumber() - 1);
                break;
            case PRIEST:
                this.setPriestNumber(this.getPriestNumber() - 1);
                break;
            case ZEALOT:
                this.setZealotNumber(this.getZealotNumber() - 1);
                break;
            case BISHOP:
                this.setBishopNumber(this.getBishopNumber() - 1);
                break;
            case TEMPLAR:
                this.setTemplarNumber(this.getTemplarNumber() - 1);
                break;
            case SPECIAL:
                this.setSpecialMinionNumber(this.getSpecialMinionNumber() - 1);
        }
    }

    protected void refreshAttributes() {
    }

    public void finalizeMinionSummon(Entity entity, EnumMinionType minionType) {
    }

    protected void dropExperienceOrb() {
    }

    protected void dropRateItem() {
    }

    protected void dropAllItem() {
    }

    protected void onDeath() {
        if (!this.level().isClientSide()) {
            this.dropExperienceOrb();
            if (this.level().getGameRules().getBoolean(GameRules.RULE_DOMOBLOOT)) {
                this.dropRateItem();
                this.dropAllItem();
            }
        }

        if (this.getName().getContents() instanceof TranslatableContents translatableContents
            && TheTitansMinions.MINIONS.containsKey(translatableContents.getKey())) {
            EntityTitanSpirit titanSpirit = new EntityTitanSpirit(this.level(), translatableContents.getKey());
            titanSpirit.setPos(this.getX(), this.getY(), this.getZ());
            titanSpirit.setYRot(this.getYRot());
            titanSpirit.setVesselHunting(false);
            if (!this.level().isClientSide()) {
                this.level().addFreshEntity(titanSpirit);
            }
        }
    }

    protected void tickTitanDeath() {
    this.deathTicks++;

    // 死亡开始第一 tick：把 invulTime 重置为干净的 0。
    // 否则重生中/读档死亡状态可能带着几百的 invulTime 进入死亡，
    // Slime/MagmaCube 的 /10 公式会算出负缩放，模型翻转。
    // 重置后死亡流程统一从 0 开始，子类 deathTicks >= 500 的 +8 也会从 0 起算。
    // 只在服务端重置，客户端由服务端同步驱动。
    if (this.deathTicks == 1 && !this.level().isClientSide()) {
        this.forceSetInvulTime(0);
    }

    if (this.deathTicks == 1) {
        this.playSound(this.getDeathSound(), this.getSoundVolume(), this.getVoicePitch());
        if (!this.level().isClientSide()) {
            ServerLevel serverLevel = (ServerLevel)this.level();

            for (ServerPlayer serverPlayer : serverLevel.players()) {
                TheTitansTriggers.TITAN_DEATH.trigger(serverPlayer, this);
            }
        }
    }

    if (this.deathTicks < this.getThreashHold() && !(this instanceof EntityWitherzilla)) {
        for (int i = 0; i < this.getParticleCount(); i++) {
            if (this.shouldParticlesBeUpward) {
                this.level()
                    .addParticle(
                        this.getParticles(),
                        this.getX() + (this.random.nextDouble() - 0.5) * (double)this.getBbWidth(),
                        this.getY() + this.random.nextDouble() * (double)this.getBbHeight(),
                        this.getZ() + (this.random.nextDouble() - 0.5) * (double)this.getBbWidth(),
                        0.0,
                        0.25,
                        0.0
                    );
            } else {
                this.level()
                    .addParticle(
                        this.getParticles(),
                        this.getX() + (this.random.nextDouble() - 0.5) * (double)this.getBbWidth(),
                        this.getY() + this.random.nextDouble() * (double)this.getBbHeight(),
                        this.getZ() + (this.random.nextDouble() - 0.5) * (double)this.getBbWidth(),
                        0.0,
                        0.0,
                        0.0
                    );
            }
        }
    }

    this.setTitanDeltaMovement(0.0, this.getDeltaMovement().y, 0.0);
    this.setTarget(null);
}

    public void destroyBlocksInAABB(AABB aabb, boolean topless) {
        if (!this.getWaiting() && aabb != null && !this.level().isClientSide() && ForgeEventFactory.getMobGriefingEvent(this.level(), this)) {
            int minX = Mth.floor(aabb.minX);
            int minY = Mth.floor(aabb.minY);
            int minZ = Mth.floor(aabb.minZ);
            int maxX = Mth.floor(aabb.maxX);
            int maxY = Mth.floor(aabb.maxY);
            int maxZ = Mth.floor(aabb.maxZ);
            List<BlockPos> fallBlocks = new ArrayList<>();

            for (int y = minY; y <= maxY; y++) {
                for (int x = minX; x <= maxX; x++) {
                    for (int z = minZ; z <= maxZ; z++) {
                        BlockPos blockPos = new BlockPos(x, y, z);
                        BlockState blockState = this.level().getBlockState(blockPos);
                        net.minecraft.world.level.block.Block block = blockState.getBlock();
                        if (this.tickCount > 5
                            && this.level().hasChunkAt(blockPos)
                            && !blockState.isAir()
                            && (!topless || this.level().isEmptyBlock(blockPos.above()))
                            && blockState.getDestroySpeed(this.level(), blockPos) >= 0.0F) {
                            if (block instanceof LiquidBlock || block == Blocks.FIRE || block == Blocks.COBWEB) {
                                this.level().setBlockAndUpdate(blockPos, Blocks.AIR.defaultBlockState());
                            } else if (this.random.nextInt(3) == 0) {
                                fallBlocks.add(blockPos.immutable());
                            } else if (this.level().getNearestPlayer(this, 16.0) != null) {
                                this.level().destroyBlock(blockPos, true);
                            } else {
                                this.level().setBlockAndUpdate(blockPos, Blocks.AIR.defaultBlockState());
                            }
                        }
                    }
                }
            }

            for (BlockPos blockPos : fallBlocks) {
                BlockState blockState = this.level().getBlockState(blockPos);
                if (!blockState.isAir() && blockState.getDestroySpeed(this.level(), blockPos) >= 0.0F) {
                    double decayFactor = 0.5;
                    if (this.random.nextDouble() < (1.0 - decayFactor) * Math.exp(-Math.log((double)(fallBlocks.size() + 1)) * decayFactor * decayFactor)) {
                        FallingBlockEntity fallingBlock = FallingBlockEntity.fall(this.level(), blockPos, blockState);
                        double d0 = (this.getBoundingBox().minX + this.getBoundingBox().maxX) / 2.0;
                        double d1 = (this.getBoundingBox().minZ + this.getBoundingBox().maxZ) / 2.0;
                        double d2 = fallingBlock.getX() - d0;
                        double d3 = fallingBlock.getZ() - d1;
                        double d4 = d2 * d2 + d3 * d3;
                        fallingBlock.setRemainingFireTicks(10);
                        if (d4 >= 0.01) {
                            double d5 = d2 / d4 * 10.0;
                            double d6 = 2.0 + this.random.nextGaussian();
                            double d7 = d3 / d4 * 10.0;
                            fallingBlock.push(d5, d6, d7);
                        }
                    }
                }
            }

            fallBlocks.clear();
        }
    }

    public void destroyBlocksInAABB(AABB aabb) {
        this.destroyBlocksInAABB(aabb, false);
    }

    public void destroyBlocksInAABBTopless(AABB aabb) {
        this.destroyBlocksInAABB(aabb, true);
    }

    public boolean destroyBlocksInAABBGriefingBypass(AABB aabb) {
        if (!this.getWaiting() && aabb != null && !this.level().isClientSide() && ForgeEventFactory.getMobGriefingEvent(this.level(), this)) {
            int minX = Mth.floor(aabb.minX);
            int minY = Mth.floor(aabb.minY);
            int minZ = Mth.floor(aabb.minZ);
            int maxX = Mth.floor(aabb.maxX);
            int maxY = Mth.floor(aabb.maxY);
            int maxZ = Mth.floor(aabb.maxZ);
            boolean flag = false;

            for (int y = minY; y <= maxY; y++) {
                for (int x = minX; x <= maxX; x++) {
                    for (int z = minZ; z <= maxZ; z++) {
                        BlockPos blockPos = new BlockPos(x, y, z);
                        BlockState blockState = this.level().getBlockState(blockPos);
                        if (!blockState.isAir() && blockState.getDestroySpeed(this.level(), blockPos) >= 0.0F) {
                            flag = this.level().setBlock(blockPos, Blocks.AIR.defaultBlockState(), 2) || flag;
                        }
                    }
                }
            }

            return false;
        } else {
            return false;
        }
    }

    public void destroyBlocksInAABBGriefingBypassAsync(AABB aabb) {
        if (!this.getWaiting() && aabb != null && !this.level().isClientSide() && ForgeEventFactory.getMobGriefingEvent(this.level(), this)) {
            int minX = Mth.floor(aabb.minX);
            int minY = Mth.floor(aabb.minY);
            int minZ = Mth.floor(aabb.minZ);
            int maxX = Mth.floor(aabb.maxX);
            int maxY = Mth.floor(aabb.maxY);
            int maxZ = Mth.floor(aabb.maxZ);
            List<BlockPos> destroyBlocks = new ArrayList<>();

            for (int y = maxY; y > minY; y--) {
                for (int x = minX; x <= maxX; x++) {
                    for (int z = minZ; z <= maxZ; z++) {
                        BlockPos blockPos = new BlockPos(x, y, z);
                        BlockState blockState = this.level().getBlockState(blockPos);
                        if (!blockState.isAir() && blockState.getDestroySpeed(this.level(), blockPos) >= 0.0F) {
                            destroyBlocks.add(blockPos.immutable());
                        }
                    }
                }
            }

            CompletableFuture.runAsync(() -> {
                for (BlockPos blockPosx : destroyBlocks) {
                    BlockState blockStatex = this.level().getBlockState(blockPosx);
                    if (!blockStatex.isAir() && blockStatex.getDestroySpeed(this.level(), blockPosx) >= 0.0F) {
                        this.level().setBlock(blockPosx, Blocks.AIR.defaultBlockState(), 2);
                    }
                }
            });
        }
    }

    public void collideWithEntities(EntityTitanPart part, List<Entity> entities) {
        if (!this.getWaiting()) {
            if (part != null && part.level() != null) {
                double d0 = (part.getBoundingBox().minX + part.getBoundingBox().maxX) / 2.0;
                double d1 = (part.getBoundingBox().minZ + part.getBoundingBox().maxZ) / 2.0;

                for (Entity entity : entities) {
                    boolean leg = part.getPartName() == "rightleg"
                        || part.getPartName() == "leftleg"
                        || part.getPartName() == "leg1"
                        || part.getPartName() == "leg2"
                        || part.getPartName() == "leg3"
                        || part.getPartName() == "leg4";
                    if (entity != null
                        && this.canAttackEntity(entity)
                        && !(entity instanceof WitherSkull)
                        && !(entity instanceof IEntityProjectileTitan)
                        && !(entity instanceof EntityHarcadiumArrow)
                        && !(entity instanceof EntityExperienceOrbTitan)
                        && !(entity instanceof EntityItemTitan)
                        && !(entity instanceof EntityTitan)
                        && !(entity instanceof EntityTitanPart)
                        && !(entity instanceof EntityTitanSpirit)) {
                        double d2 = entity.getX() - d0;
                        double d3 = entity.getZ() - d1;
                        double d4 = d2 * d2 + d3 * d3;
                        if (d4 >= 0.01) {
                            double d5 = d2 / d4 * (leg ? 5.0 : 1.5);
                            double d6 = leg ? 1.75 : 0.5;
                            double d7 = d3 / d4 * (leg ? 5.0 : 1.5);
                            entity.push(d5, d6, d7);
                        }

                        if (entity.getY() <= part.getY() - (double)part.getBbHeight() - 0.01) {
                            entity.hurt(this.damageSources().thorns(this), 20.0F);
                        }

                        if (entity instanceof LivingEntity) {
                            LivingEntity livingEntity = (LivingEntity)entity;
                            if (this instanceof EntitySkeletonTitan) {
                                EntitySkeletonTitan skeletonTitan = (EntitySkeletonTitan)this;
                                if (skeletonTitan.getSkeletonType() == 1) {
                                    livingEntity.addEffect(new MobEffectInstance(MobEffects.WITHER, 1200, 3));
                                }
                            }
                        }

                        if (entity instanceof FishingHook) {
                            FishingHook fishingHook = (FishingHook)entity;
                            if (fishingHook.getHookedIn() != null && !this.level().isClientSide()) {
                                fishingHook.remove(RemovalReason.KILLED);
                            }
                        }
                    }
                }
            }
        }
    }

    public void summomMinions() {
        if (this.getName().getContents() instanceof TranslatableContents translatableContents) {
            if (TheTitansMinions.MINIONS.containsKey(translatableContents.getKey())) {
                try {
                    Class<? extends Entity> clazz = TheTitansMinions.MINIONS.get(translatableContents.getKey());
                    if (this.getMinionNumber() < this.getMinionCap() && this.canSpawnMinion()) {
                        Constructor<? extends Entity> constructor = clazz.getDeclaredConstructor(Level.class);
                        Entity entity = constructor.newInstance(this.level());
                        double d0 = this.getX() + (this.random.nextDouble() - 0.5) * (72.0 + (double)this.getBbWidth());
                        double d1 = this.getY();
                        double d2 = this.getZ() + (this.random.nextDouble() - 0.5) * (72.0 + (double)this.getBbWidth());
                        if (entity instanceof Mob && entity instanceof IMinion) {
                            Mob mob = (Mob)entity;
                            IMinion minion = (IMinion)entity;
                            mob.setPos(d0, d1, d2);
                            mob.finalizeSpawn((ServerLevelAccessor)this.level(), this.level().getCurrentDifficultyAt(entity.blockPosition()), MobSpawnType.SPAWNER, null, null);
                            minion.setMaster(this);
                            minion.setMinionType(0);
                            this.finalizeMinionSummon(mob, minion.getMinionType());
                            mob.setHealth(mob.getMaxHealth());
                            mob.push(0.0, (double)mob.getBbHeight() / 4.0, 0.0);
                            EntityUtils.addMinion(this.level(), mob);
                            mob.playSound((SoundEvent)TheTitansSounds.TITAN_SUMMON_MINION.get(), 10.0F, 0.5F);
                            this.setMinionNumber(this.getMinionNumber() + 1);
                        }
                    }

                    if (this.getPriestNumber() < this.getPriestCap() && this.canSpawnPriest()) {
                        Constructor<? extends Entity> constructor = clazz.getDeclaredConstructor(Level.class);
                        Entity entity = constructor.newInstance(this.level());
                        double d0 = this.getX() + (this.random.nextDouble() - 0.5) * (72.0 + (double)this.getBbWidth());
                        double d1 = this.getY();
                        double d2 = this.getZ() + (this.random.nextDouble() - 0.5) * (72.0 + (double)this.getBbWidth());
                        if (entity instanceof Mob && entity instanceof IMinion) {
                            Mob mob = (Mob)entity;
                            IMinion minion = (IMinion)entity;
                            mob.setPos(d0, d1, d2);
                            mob.finalizeSpawn((ServerLevelAccessor)this.level(), this.level().getCurrentDifficultyAt(entity.blockPosition()), MobSpawnType.SPAWNER, null, null);
                            minion.setMaster(this);
                            minion.setMinionType(1);
                            this.finalizeMinionSummon(mob, minion.getMinionType());
                            mob.setHealth(mob.getMaxHealth());
                            mob.push(0.0, (double)mob.getBbHeight() / 4.0, 0.0);
                            EntityUtils.addMinion(this.level(), mob);
                            mob.playSound((SoundEvent)TheTitansSounds.TITAN_SUMMON_MINION.get(), 10.0F, 0.5F);
                            this.setPriestNumber(this.getPriestNumber() + 1);
                        }
                    }

                    if (this.getZealotNumber() < this.getZealotCap() && this.canSpawnZealot()) {
                        Constructor<? extends Entity> constructor = clazz.getDeclaredConstructor(Level.class);
                        Entity entity = constructor.newInstance(this.level());
                        double d0 = this.getX() + (this.random.nextDouble() - 0.5) * (72.0 + (double)this.getBbWidth());
                        double d1 = this.getY();
                        double d2 = this.getZ() + (this.random.nextDouble() - 0.5) * (72.0 + (double)this.getBbWidth());
                        if (entity instanceof Mob && entity instanceof IMinion) {
                            Mob mob = (Mob)entity;
                            IMinion minion = (IMinion)entity;
                            mob.setPos(d0, d1, d2);
                            mob.finalizeSpawn((ServerLevelAccessor)this.level(), this.level().getCurrentDifficultyAt(entity.blockPosition()), MobSpawnType.SPAWNER, null, null);
                            minion.setMaster(this);
                            minion.setMinionType(2);
                            this.finalizeMinionSummon(mob, minion.getMinionType());
                            mob.setHealth(mob.getMaxHealth());
                            mob.push(0.0, (double)mob.getBbHeight() / 4.0, 0.0);
                            EntityUtils.addMinion(this.level(), mob);
                            mob.playSound((SoundEvent)TheTitansSounds.TITAN_SUMMON_MINION.get(), 10.0F, 0.5F);
                            this.setZealotNumber(this.getZealotNumber() + 1);
                        }
                    }

                    if (this.getBishopNumber() < this.getBishopCap() && this.canSpawnBishop()) {
                        Constructor<? extends Entity> constructor = clazz.getDeclaredConstructor(Level.class);
                        Entity entity = constructor.newInstance(this.level());
                        double d0 = this.getX() + (this.random.nextDouble() - 0.5) * (72.0 + (double)this.getBbWidth());
                        double d1 = this.getY();
                        double d2 = this.getZ() + (this.random.nextDouble() - 0.5) * (72.0 + (double)this.getBbWidth());
                        if (entity instanceof Mob && entity instanceof IMinion) {
                            Mob mob = (Mob)entity;
                            IMinion minion = (IMinion)entity;
                            mob.setPos(d0, d1, d2);
                            mob.finalizeSpawn((ServerLevelAccessor)this.level(), this.level().getCurrentDifficultyAt(entity.blockPosition()), MobSpawnType.SPAWNER, null, null);
                            minion.setMaster(this);
                            minion.setMinionType(3);
                            this.finalizeMinionSummon(mob, minion.getMinionType());
                            mob.setHealth(mob.getMaxHealth());
                            mob.push(0.0, (double)mob.getBbHeight() / 4.0, 0.0);
                            EntityUtils.addMinion(this.level(), mob);
                            mob.playSound((SoundEvent)TheTitansSounds.TITAN_SUMMON_MINION.get(), 10.0F, 0.5F);
                            this.setBishopNumber(this.getBishopNumber() + 1);
                        }
                    }

                    if (this.getTemplarNumber() < this.getTemplarCap() && this.canSpawnTemplar()) {
                        Constructor<? extends Entity> constructor = clazz.getDeclaredConstructor(Level.class);
                        Entity entity = constructor.newInstance(this.level());
                        double d0 = this.getX() + (this.random.nextDouble() - 0.5) * (72.0 + (double)this.getBbWidth());
                        double d1 = this.getY();
                        double d2 = this.getZ() + (this.random.nextDouble() - 0.5) * (72.0 + (double)this.getBbWidth());
                        if (entity instanceof Mob && entity instanceof IMinion) {
                            Mob mob = (Mob)entity;
                            IMinion minion = (IMinion)entity;
                            mob.setPos(d0, d1, d2);
                            mob.finalizeSpawn((ServerLevelAccessor)this.level(), this.level().getCurrentDifficultyAt(entity.blockPosition()), MobSpawnType.SPAWNER, null, null);
                            minion.setMaster(this);
                            minion.setMinionType(4);
                            this.finalizeMinionSummon(mob, minion.getMinionType());
                            mob.setHealth(mob.getMaxHealth());
                            mob.push(0.0, (double)mob.getBbHeight() / 4.0, 0.0);
                            EntityUtils.addMinion(this.level(), mob);
                            mob.playSound((SoundEvent)TheTitansSounds.TITAN_SUMMON_MINION.get(), 10.0F, 0.5F);
                            this.setTemplarNumber(this.getTemplarNumber() + 1);
                        }
                    }
                } catch (Exception var14) {
                    var14.printStackTrace();
                }
            }

            if (TheTitansMinions.SPECIAL_MINIONS.containsKey(translatableContents.getKey())) {
                try {
                    Class<? extends Entity> clazzx = TheTitansMinions.SPECIAL_MINIONS.get(translatableContents.getKey());
                    if (this.getSpecialMinionNumber() < this.getSpecialMinionCap() && this.canSpawnSpecialMinion()) {
                        Constructor<? extends Entity> constructor = clazzx.getDeclaredConstructor(Level.class);
                        Entity entity = constructor.newInstance(this.level());
                        double d0 = this.getX() + (this.random.nextDouble() - 0.5) * (72.0 + (double)this.getBbWidth());
                        double d1 = this.getY();
                        double d2 = this.getZ() + (this.random.nextDouble() - 0.5) * (72.0 + (double)this.getBbWidth());
                        if (entity instanceof Mob && entity instanceof IMinion) {
                            Mob mob = (Mob)entity;
                            IMinion minion = (IMinion)entity;
                            mob.setPos(d0, d1, d2);
                            mob.finalizeSpawn((ServerLevelAccessor)this.level(), this.level().getCurrentDifficultyAt(entity.blockPosition()), MobSpawnType.SPAWNER, null, null);
                            minion.setMaster(this);
                            minion.setMinionType(0);
                            this.finalizeMinionSummon(mob, minion.getMinionType());
                            mob.setHealth(mob.getMaxHealth());
                            mob.push(0.0, (double)mob.getBbHeight() / 4.0, 0.0);
                            EntityUtils.addMinion(this.level(), mob);
                            mob.playSound((SoundEvent)TheTitansSounds.TITAN_SUMMON_MINION.get(), 10.0F, 0.5F);
                            this.setSpecialMinionNumber(this.getSpecialMinionNumber() + 1);
                        }
                    }
                } catch (Exception var13) {
                    var13.printStackTrace();
                }
            }
        }
    }

    public void checkWaiting(double distance) {
        if (this.getWaiting()) {
            AnimationUtils.sendPacket(this, 13);
            Player player = this.level().getNearestPlayer(this, distance);
            if (player != null) {
                this.setWaiting(false);
                this.lookAt(player, 180.0F, 0.0F);
                if (player instanceof ServerPlayer serverPlayer) {
                    TheTitansTriggers.TITAN_WAKE.trigger(serverPlayer, this);
                }
            }
        } else if (this.getAnimationID() == 13) {
            this.setTitanDeltaMovement(0.0, 0.0, 0.0);
            this.setOnGround(true);
        }
    }

    public void grow() {
        if (!(this instanceof EntitySnowGolemTitan) && !(this instanceof EntitySlimeTitan)) {
            this.setInvulTime(this.getThreashHold());
        } else {
            this.setInvulTime(150);
        }

        this.setWaiting(false);
    }

    public void shakeNearbyPlayerCameras(double distance) {
        if (!this.level().isClientSide()) {
            ServerLevel serverLevel = (ServerLevel)this.level();
            ServerChunkCache serverChunkCache = serverLevel.getChunkSource();

            for (Entity entity : this.level().getEntities(this, this.getBoundingBox().inflate(distance, distance, distance))) {
                if (entity != null && entity instanceof LivingEntity && !(entity instanceof EntityTitan) && this.canAttackEntity(entity)) {
                    LivingEntity livingEntity = (LivingEntity)entity;
                    livingEntity.animateHurt(180.0F);

                    for (ServerPlayer player : serverLevel.players()) {
                        serverChunkCache.broadcastAndSend(player, new ClientboundHurtAnimationPacket(livingEntity));
                    }
                }
            }
        }
    }

    public void addDayTime(long maxDayTime, long addTime) {
        if (!this.getWaiting()) {
            if (!this.level().isClientSide()) {
                ServerLevel serverLevel = (ServerLevel)this.level();
                ServerChunkCache serverChunkCache = serverLevel.getChunkSource();
                if (serverLevel.getDayTime() < maxDayTime) {
                    serverLevel.setDayTime(serverLevel.getDayTime() + 50L);
                }

                for (ServerPlayer player : serverLevel.players()) {
                    serverChunkCache.broadcastAndSend(
                        player,
                        new ClientboundSetTimePacket(serverLevel.getGameTime(), serverLevel.getDayTime(), serverLevel.getGameRules().getBoolean(GameRules.RULE_DAYLIGHT))
                    );
                }
            }
        }
    }

    public void removeEntity(Entity entity) {
        if (entity != null && entity != this) {
            if (entity.getBbHeight() >= 6.0F) {
                for (int i = 0; i < 1000; i++) {
                    float f = (this.random.nextFloat() - 0.5F) * entity.getBbWidth();
                    float f1 = (this.random.nextFloat() - 0.5F) * entity.getBbHeight();
                    float f2 = (this.random.nextFloat() - 0.5F) * entity.getBbWidth();
                    this.level()
                        .addParticle(
                            ParticleTypes.EXPLOSION,
                            this.getX() + (double)f,
                            this.getY() + (double)f1,
                            this.getZ() + (double)f2,
                            this.random.nextDouble() - 0.5,
                            0.0,
                            this.random.nextDouble() - 0.5
                        );
                }
            }

            if (!entity.level().isClientSide()) {
                entity.level().broadcastEntityEvent(entity, (byte)60);
                entity.remove(RemovalReason.KILLED);
            }
        }
    }

    public void knockbackEntity(LivingEntity entity, float amount, boolean onlyXZ) {
        if (entity != null && entity != this && TheTitansPredicateTargets.All.test(entity)) {
            double knockbackResistance = entity.getAttributeValue((Attribute)TheTitansAttributes.TITAN_KNOCKBACK_RESISTANCE.get());
            if (knockbackResistance > 0.0) {
                double knockbackResistanceValue = Math.min(knockbackResistance, 100.0) / 100.0;
                amount *= (float)(1.0 - knockbackResistanceValue);
            }

            if (amount < 1.0F) {
                amount = 1.0F;
            }

            double d1 = -Math.sin((double)this.getYRot() * Math.PI / 180.0) * (double)amount * 0.2;
            double d2 = onlyXZ ? 0.0 : (double)amount * 0.2;
            double d3 = Math.cos((double)this.getYRot() * Math.PI / 180.0) * (double)amount * 0.2;
            entity.push(d1, d2, d3);
        }
    }

    public void knockbackEntity(LivingEntity entity, float amount) {
        this.knockbackEntity(entity, amount, false);
    }

    public void attackEntity(LivingEntity entity, float amount) {
        if (!this.level().isClientSide()) {
            if (entity != null && entity != this && TheTitansPredicateTargets.All.test(entity) && this.canAttackEntity(entity)) {
                DamageSourceTitanAttack damageSource = new DamageSourceTitanAttack(this);
                if (entity instanceof Player player) {
                    // 对玩家只造成普通伤害：伤害量固定取该泰坦的攻击力（ATTACK_DAMAGE），
                    // 各种强制秒杀伤害（Float.MAX_VALUE、强制 setHealth(0) 等）对玩家不再生效。
                    amount = (float)this.getAttributeValue(Attributes.ATTACK_DAMAGE);
                    if (ItemUtils.hasItem(player.getInventory(), (Item)TheTitansRegistries.ULTIMA_BLADE.get())
                        || ItemUtils.hasItem(player.getInventory(), (Item)TheTitansRegistries.OPTIMA_AXE.get())) {
                        if (amount <= 2000.0F) {
                            amount *= 1.0F;
                        } else {
                            amount *= 0.5F;
                        }
                    }

                    double titanResistance = player.getAttributeValue((Attribute)TheTitansAttributes.TITAN_RESISTANCE.get());
                    if (titanResistance > 0.0) {
                        double titanResistanceValue = Math.min(titanResistance, 100.0) / 100.0;
                        float newAmount = amount * (float)(1.0 - titanResistanceValue);
                        if (newAmount > 100.0F) {
                            amount = newAmount;
                        }
                    }

                    for (ItemStack itemStack : player.getArmorSlots()) {
                        if (!itemStack.isEmpty() && itemStack.isDamaged()) {
                            itemStack.setDamageValue(itemStack.getDamageValue() + (int)amount);
                        }
                    }
                }

                if (entity instanceof EntityTitan titan) {
                    if (titan.getInvulTime() <= 0) {
                        this.playSound((SoundEvent)TheTitansSounds.TITAN_PUNCH.get(), 10.0F, 1.0F);
                        titan.hurt(damageSource, amount);
                    }
                } else {
                    float health = entity.getHealth();
                    float absorptionAmount = entity.getAbsorptionAmount();
                    if (health + absorptionAmount <= 0.0F) {
                        return;
                    }

                    boolean isInvulnerable = false;
                    entity.invulnerableTime = 0;
                    // 玩家只走标准 hurt 流程（护甲/附魔/抗性都由原版处理），
                    // 不走下面这套"hurt 没吃掉伤害就强制扣血"的逻辑
                    if (amount >= 0.0F && !entity.hurt(damageSource, amount) && !(entity instanceof Player)) {
                        entity.setAbsorptionAmount(0.0F);
                        if (entity.invulnerableTime <= 0) {
                            isInvulnerable = true;
                            float afterHealth = Math.max(health - amount, 0.0F);
                            if (entity.getHealth() > afterHealth) {
                                entity.setHealth(afterHealth);
                            }
                        }

                        if (entity.getHealth() <= 0.0F) {
                            entity.die(damageSource);
                        }
                    }

                    if ((
                            entity.getHealth() + entity.getAbsorptionAmount() > 0.0F
                                    && health + absorptionAmount - amount <= 0.0F
                                    && entity.invulnerableTime == 0
                                    && entity.deathTime == 0
                                    && isInvulnerable
                                || entity.deathTime > 0
                        )
                        && !(entity instanceof Player)) {
                        entity.getAttribute(Attributes.MAX_HEALTH).setBaseValue(0.0);
                        entity.setAbsorptionAmount(0.0F);
                        entity.setHealth(0.0F);
                        this.removeEntity(entity);
                    }
                }
            }
        }
    }

    public SpawnGroupData finalizeSpawn(
        ServerLevelAccessor level, DifficultyInstance difficulty, MobSpawnType spawnType, @Nullable SpawnGroupData spawnGroupData, @Nullable CompoundTag tag
    ) {
        return super.finalizeSpawn(level, difficulty, spawnType, spawnGroupData, tag);
    }

    public void handleDamageEvent(DamageSource damageSource) {
        super.handleDamageEvent(damageSource);
        this.invulnerableTicks = 30;
    }

    public boolean baseHurt(DamageSource damageSource, float amount) {
        return super.hurt(damageSource, amount);
    }

    /**
     * 泰坦受击白名单：只有模组武器、模组内部生物（泰坦互殴/随从等）能造成伤害，
     * 其余一切来源（原版武器、附魔超高伤害、爆炸、火焰、摔落、其他模组伤害、
     * /kill 与 /damage 等指令伤害）一律取消。
     */
    public boolean isTitanDamageAllowed(DamageSource damageSource) {
        if (damageSource instanceof DamageSourceTitanAttack) {
            return true;
        }

        Entity attacker = damageSource.getEntity();
        if (attacker instanceof EntityTitan) {
            return true;
        }

        // 模组内部生物（随从、泰坦之灵、末影巨人水晶等）造成的伤害放行，避免破坏模组自身机制
        if (attacker != null && attacker.getClass().getName().startsWith("net.titans.entity.")) {
            return true;
        }

        if (attacker instanceof Player player) {
            return ItemUtils.isTitanWeapon(player.getMainHandItem()) || ItemUtils.isTitanWeapon(player.getOffhandItem());
        }

        return false;
    }

    public boolean hurt(DamageSource damageSource, float amount) {
        // 白名单外的伤害直接忽略，原版血量与 titanHealth 都不做任何变更
        if (!this.isTitanDamageAllowed(damageSource)) {
            return false;
        }

        Entity entity = damageSource.getEntity();

        if (entity == null || this.isInvulnerable() || amount <= 20.0F) {
            return false;
        } else if (damageSource.is(DamageTypes.MAGIC)
            || damageSource.is(DamageTypes.INDIRECT_MAGIC)
            || damageSource.is(DamageTypes.EXPLOSION)
            || damageSource.is(DamageTypes.PLAYER_EXPLOSION)
            || damageSource.is(DamageTypes.IN_FIRE)
            || damageSource.is(DamageTypes.ON_FIRE)
            || damageSource.is(DamageTypes.LAVA)
            || damageSource.is(DamageTypes.IN_WALL)
            || damageSource.is(DamageTypes.DROWN)
            || damageSource.is(DamageTypes.STARVE)
            || damageSource.is(DamageTypes.CACTUS)
            || damageSource.is(DamageTypes.FALL)
            || damageSource.is(DamageTypes.GENERIC)
            || damageSource.is(DamageTypes.FELL_OUT_OF_WORLD)
            || damageSource.is(DamageTypes.WITHER)
            || damageSource.is(DamageTypes.FALLING_BLOCK)
            || damageSource.is(DamageTypes.FALLING_ANVIL)) {
            return false;
        } else if (entity instanceof Player && !this.canBeHurtByPlayer()) {
            return false;
        } else {
            // baseHurt 只用于原版受击反馈（音效、闪红、无敌帧判定），血量结算完全走 titanHealth
            if (!this.baseHurt(damageSource, amount)) {
                return false;
            }

            if (entity instanceof LivingEntity livingEntity && this.getAnimationTick() <= 12) {
                this.setTarget(livingEntity);
            }

            this.damageTitanHealth(amount);
            // 覆盖 baseHurt 对原版血量的修改，保证原版血量始终等于 titanHealth
            this.setHealth(this.getTitanHealth());
            return true;
        }
    }

    public boolean causeFallDamage(float fallDistance, float multiplier, DamageSource damageSource) {
        this.setOnGround(true);
        this.hasImpulse = false;
        if (fallDistance <= 0.0F) {
            return false;
        } else {
            MobEffectInstance mobEffectInstance = this.getEffect(MobEffects.JUMP);
            float f1 = mobEffectInstance != null ? (float)(mobEffectInstance.getAmplifier() + 1) : 0.0F;
            int i = Mth.ceil(fallDistance - 24.0F - f1);
            if (i > 0) {
                this.shakeNearbyPlayerCameras(400000.0);
                this.playSound((SoundEvent)TheTitansSounds.GROUND_SMASH.get(), 20.0F, 1.0F);
                this.playSound((SoundEvent)TheTitansSounds.TITAN_LAND.get(), 10000.0F, 1.0F);

                for (Entity entity : this.level().getEntities(this, this.getBoundingBox().inflate(48.0, 4.0, 48.0))) {
                    if (entity != null && entity instanceof LivingEntity && !(entity instanceof EntityTitan) && this.canAttackEntity(entity)) {
                        LivingEntity livingEntity = (LivingEntity)entity;
                        float smash = 50.0F - this.distanceTo(livingEntity);
                        if (smash <= 1.0F) {
                            smash = 1.0F;
                        }

                        this.attackEntity(livingEntity, smash);
                        double d0 = this.getBoundingBox().minX + this.getBoundingBox().maxX;
                        double d1 = this.getBoundingBox().minZ + this.getBoundingBox().maxZ;
                        double d2 = entity.getX() - d0;
                        double d3 = entity.getZ() - d1;
                        double d4 = d2 * d2 + d3 * d3;
                        if (d4 >= 0.01) {
                            double d5 = d2 / d4 * 8.0;
                            double d6 = 1.0;
                            double d7 = d3 / d4 * 8.0;
                            livingEntity.push(d5, d6, d7);
                        }
                    }
                }
            }

            return super.causeFallDamage(fallDistance, multiplier, damageSource);
        }
    }

    public void aiStep() {
        for (Entity entity : this.level().getEntities(this, this.getBoundingBox())) {
            this.push(entity);
        }

        if (this.random.nextInt(1000) == 0 && this.getHealth() < this.getTitanMaxHealth() / 20.0F && this.deathTicks <= 0
            || this.getHealth() < this.getTitanMaxHealth() / 2.0F
                && this.deathTicks <= 0
                && this.getTarget() != null
                && this.getTarget() instanceof EntityTitan
                && !this.isRejuvinating
                && ((EntityTitan)this.getTarget()).isRejuvinating
                && !(this instanceof EntitySlimeTitan)
                && !(this instanceof EntitySnowGolemTitan)
                && !(this instanceof EntityIronGolemTitan)) {
            this.isRejuvinating = true;
            if (!this.isSilent()) {
                this.level().globalLevelEvent(1023, this.blockPosition(), 0);
            }

            this.setExtraPower(this.getExtraPower() + 1);
            this.refreshTitanAttributes();
            this.jumpFromGround();
        }

        this.updateRejuvenation();

        if (this.getWaiting()) {
            this.setOnGround(true);
            this.setTitanDeltaMovement(0.0, 0.0, 0.0);
            } else if (this.getInvulTime() > 0 && this.getTitanHealth() > 0.0F) {
            this.setOnGround(true);
            this.setDeltaMovement(0.0, this.getDeltaMovement().y, 0.0);
            int i = this.getInvulTime() - 1;
            if (i <= 0) {
                if (!(this instanceof EntitySnowGolemTitan) && !(this instanceof EntityIronGolemTitan) && !this.level().isClientSide()) {
                    this.level()
                        .explode(
                            this,
                            this.getX(),
                            this.getY() + (double)(this.getBbHeight() / 2.0F),
                            this.getZ(),
                            this.getBbHeight(),
                            false,
                            ExplosionInteraction.MOB
                        );
                }

                this.destroyBlocksInAABB(this.getBoundingBox());
                if (this instanceof EntityZombieTitan && !((EntityZombieTitan)this).isArmed()) {
                    AnimationUtils.sendPacket(this, 2);
                }
            }

            this.setInvulTime(i);
            if (this.tickCount % 1 == 0) {
                if (!(this instanceof EntitySnowGolemTitan) && !(this instanceof EntitySlimeTitan)) {
                    this.heal(this.getTitanMaxHealth() / (float)this.getThreashHold());
                } else {
                    this.heal(this.getTitanMaxHealth() / 150.0F);
                }
            }
        } else {
            super.aiStep();
            if (this.canRegen()) {
                float healAmount = 0.0F;
                if (this.getTitanStatus() == EnumTitanStatus.AVERAGE) {
                    healAmount = 3.0F;
                } else if (this.getTitanStatus() == EnumTitanStatus.GREATER) {
                    healAmount = 6.0F;
                } else if (this.getTitanStatus() == EnumTitanStatus.GOD) {
                    healAmount = 20.0F;
                } else {
                    healAmount = 1.0F;
                }

                if ((this instanceof EntityZombieTitan || this instanceof EntitySkeletonTitan) && this.level().isDay()) {
                    healAmount /= 3.0F;
                }

                if (this instanceof EntitySnowGolemTitan || this instanceof EntityIronGolemTitan) {
                    healAmount = 0.1F;
                }

                for (int ix = 0; ix < 2 + this.random.nextInt(10); ix++) {
                    this.heal(healAmount);
                }
            }
        }
    }

    /**
     * 重生状态的维持逻辑：只要还在重生，就每 tick 把无敌时间顶高 5 点，
     * 直到 invulTime 超过阈值才结束重生（随后 invulTime 逐 tick 递减并持续回血）。
     * 基类的 aiStep 每 tick 都会调用它；重写 aiStep 并会跳过基类调用的子类
     * （目前只有凋零斯拉）必须自己在无敌分支里调用，否则重生状态永远无法结束。
     */
    protected void updateRejuvenation() {
        if (this.isAlive() && this.isRejuvinating) {
            this.setTarget(null);
            this.setInvulTime(this.getInvulTime() + 5);
            this.animateHurt(180.0F);
            if (this.getInvulTime() > this.getThreashHold()) {
                this.isRejuvinating = false;
            }
        }
    }

    public void tick() {
        // 血量完整性与上限校验必须放在最前面，早于任何死亡判定
        this.ensureTitanMaxHealth();
        this.guardTitanHealthIntegrity();
        if (this.getTitanHealth() > this.getTitanMaxHealth()) {
            this.setTitanHealth(this.getTitanMaxHealth());
        }

        if (this.getAnimationID() == 13 && this.getAnimationTick() == 4 && this.level().getNearestPlayer(this, 32.0) != null) {
            this.getLookControl().setLookAt(this.level().getNearestPlayer(this, 32.0), 180.0F, 0.0F);
        }

        if (this.getAnimationID() == 0) {
            this.setAnimationTick(0);
            if (!(this instanceof EntityGhastTitan) && !(this instanceof EntityWitherzilla) && this.getTarget() != null) {
                this.getLookControl().setLookAt(this.getTarget(), 5.0F, (float)this.getMaxHeadXRot());
            }
        } else if (!(this instanceof EntityGhastTitan) && !(this instanceof EntityWitherzilla)) {
            if (this.getAnimationID() != 13) {
                this.setYRot(this.yHeadRot);
                this.yBodyRot = this.yHeadRot;
            } else {
                this.yHeadRot = this.getYRot();
            }
        }

        if (!this.getWaiting() && this.getAnimationID() != 0 && this.deathTicks < this.getThreashHold()) {
            int animationSteps = 1;
            if (this.isBaby()) {
                animationSteps++;
            }

            if (this.isArmored()) {
                animationSteps++;
            }

            if (animationSteps > 1 && this.deathTicks <= 0) {
                for (int i = 0; i < animationSteps; i++) {
                    this.setAnimationTick(this.getAnimationTick() + 1);
                }
            } else {
                this.setAnimationTick(this.getAnimationTick() + 1);
            }
        }

        if (this.shouldMove() && this.getAnimationID() == 0 && this.getTarget() != null) {
            double d0 = this.getTarget().getX() - this.getX();
            double d1 = this.getTarget().getZ() - this.getZ();
            double d2 = Math.sqrt(d0 * d0 + d1 * d1);
            this.setYRot(this.yHeadRot);
            this.yBodyRot = this.yHeadRot;
            this.setTitanDeltaMovement(
                d0 / d2 * (double)this.getSpeed() * (double)this.getSpeed() + this.getDeltaMovement().x,
                this.getDeltaMovement().y,
                d1 / d2 * (double)this.getSpeed() * (double)this.getSpeed() + this.getDeltaMovement().z
            );
        }

        if (this.invulnerableTicks > 0) {
            this.invulnerableTicks--;
        }

        if (this.getTitanHealth() <= 0.0F) {
            this.setTitanHealthForced(0.0F);
            this.tickTitanDeath();
        } else {
            this.deathTicks = 0;
            if (this.getAnimationID() == 10) {
                AnimationUtils.sendPacket(this, 0);
            }
        }

        if (this.getY() <= -64.0) {
            this.setPos(this.getX(), -64.0, this.getZ());
            this.setOnGround(true);
            this.hasImpulse = false;
            this.fallDistance = 0.0F;
            if (this.getDeltaMovement().y < 0.0) {
                this.setTitanDeltaMovement(this.getDeltaMovement().x, 0.0, this.getDeltaMovement().z);
            }
        }

        if (this.onGround() && this.getDeltaMovement().x != 0.0 && this.getDeltaMovement().z != 0.0) {
            for (int u = 0; u < 30; u++) {
                int i = Mth.floor(this.getX());
                int j = Mth.floor(this.getY() - 0.2F);
                int k = Mth.floor(this.getZ());
                BlockPos blockPos = new BlockPos(i, j, k);
                BlockState blockState = this.level().getBlockState(blockPos);
                if (!blockState.isAir()) {
                    this.level()
                        .addParticle(
                            new BlockParticleOption(ParticleTypes.BLOCK, blockState),
                            this.getX() + ((double)this.random.nextFloat() - 0.5) * (double)this.getBbWidth(),
                            this.getBoundingBox().minY + 0.1,
                            this.getZ() + ((double)this.random.nextFloat() - 0.5) * (double)this.getBbWidth(),
                            4.0 * ((double)this.random.nextFloat() - 0.5),
                            0.5,
                            ((double)this.random.nextFloat() - 0.5) * 4.0
                        );
                }
            }
        }

        if (this.isAlive()
            && !this.getWaiting()
            && this.getAnimationID() != 13
            && !this.level().isClientSide()
            && this.level().getDifficulty() != Difficulty.PEACEFUL) {
            if (!(this instanceof EntityWitherzilla)) {
                if (this.level().dimension() != TheTitansDimensions.THE_VOID) {
                    this.summomMinions();
                }
            } else {
                this.summomMinions();
            }
        }

        if (!this.canRemove()) {
        }

        if (this.goalSelector.getAvailableGoals().isEmpty() || this.targetSelector.getAvailableGoals().isEmpty()) {
            this.registerGoals();
        }

        this.setHealth(this.getTitanHealth());
        super.tick();
    }
}
