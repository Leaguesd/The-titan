package net.titans.loader;

import net.minecraft.core.registries.Registries;
import net.minecraft.world.level.levelgen.feature.Feature;
import net.minecraft.world.level.levelgen.feature.configurations.NoneFeatureConfiguration;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.RegistryObject;
import net.titans.feature.FeatureNowhere;
import net.titans.feature.FeatureTitanSpawn;
import net.titans.feature.FeatureVoid;

public class TheTitansFeatures {
    public static final DeferredRegister<Feature<?>> FEATURES = DeferredRegister.create(Registries.FEATURE, "titan");
    public static final RegistryObject<FeatureTitanSpawn> TITAN_SPAWN = FEATURES.register(
        "titan_spawn", () -> new FeatureTitanSpawn(NoneFeatureConfiguration.CODEC)
    );
    public static final RegistryObject<FeatureVoid> THE_VOID = FEATURES.register("the_void", () -> new FeatureVoid(NoneFeatureConfiguration.CODEC));
    public static final RegistryObject<FeatureNowhere> THE_NOWHERE = FEATURES.register(
        "the_nowhere", () -> new FeatureNowhere(NoneFeatureConfiguration.CODEC)
    );

    public static void registerFeatures(IEventBus modEventBus) {
        FEATURES.register(modEventBus);
    }
}
