package net.titans.item;

import java.util.List;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.UseAnim;
import net.minecraft.world.item.Item.Properties;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.ForgeEventFactory;
import net.titans.damage.DamageSourceTitanAttack;
import net.titans.entity.titan.EntityTitan;
import net.titans.loader.TheTitansSounds;
import net.titans.loader.TheTitansTiers;
import net.titans.util.EntityUtils;

public class ItemVoidSword extends SwordItem {
    public ItemVoidSword(Properties properties) {
        super(TheTitansTiers.VOID, 1500, -2.4F, properties);
    }

    public int getUseDuration(ItemStack pStack) {
        return 72000;
    }

    public UseAnim getUseAnimation(ItemStack pStack) {
        return UseAnim.BOW;
    }

    public boolean hurtEnemy(ItemStack stack, LivingEntity entity, LivingEntity attacker) {
        if (entity != null) {
            entity.playSound((SoundEvent)TheTitansSounds.SLASH_FLESH.get(), 2.0F, 1.3F + entity.level().random.nextFloat() * 0.5F);
            if (entity.getBbHeight() >= 6.0F || entity instanceof EntityTitan || !entity.onGround()) {
                entity.playSound((SoundEvent)TheTitansSounds.TITAN_PUNCH.get(), 10.0F, 1.0F);
                entity.hurt(new DamageSourceTitanAttack(attacker), 1500.0F);
            }
        }

        return super.hurtEnemy(stack, entity, attacker);
    }

    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        InteractionResultHolder<ItemStack> ret = ForgeEventFactory.onArrowNock(stack, level, player, hand, true);
        if (ret != null) {
            return ret;
        } else {
            player.startUsingItem(hand);
            return InteractionResultHolder.consume(stack);
        }
    }

    public void releaseUsing(ItemStack stack, Level level, LivingEntity livingEntity, int time) {
        Player player = (Player)livingEntity;
        int max = this.getUseDuration(stack);
        int j = max - time;
        float f = (float)j / 60.0F;
        f = (f * f + f * 2.0F) / 3.0F;
        if (!((double)f < 0.1)) {
            if ((double)f > 1.0) {
                f = 1.0F;
            }

            player.playSound((SoundEvent)TheTitansSounds.TITAN_SWING.get(), 1.0F, 2.0F);
            stack.hurtAndBreak(1, player, p -> p.broadcastBreakEvent(player.getUsedItemHand()));
            player.swing(player.getUsedItemHand());
            double d8 = 4.0;
            Vec3 vec3 = player.getViewVector(1.0F);
            double dx = vec3.x * d8;
            double dy = vec3.y * d8 + (double)player.getEyeHeight();
            double dz = vec3.z * d8;
            List<Entity> entities = player.level().getEntities(player, player.getBoundingBox().inflate(d8, d8, d8).move(dx, dy, dz));
            List<Entity> bigEntities = EntityUtils.getEntities(entities, player, d8, d8, d8, dx, dy, dz);
            if (!bigEntities.isEmpty()) {
                entities.addAll(bigEntities);
            }

            for (Entity entity : entities) {
                if (entity != null && entity instanceof LivingEntity) {
                    entity.playSound((SoundEvent)TheTitansSounds.TITAN_PUNCH.get(), 10.0F, 1.0F);
                    entity.playSound((SoundEvent)TheTitansSounds.SLASH_FLESH.get(), 2.0F, 1.25F);
                    entity.hurt(new DamageSourceTitanAttack(player), 2000.0F * Math.max(f, 0.5F));
                }
            }
        }
    }
}
