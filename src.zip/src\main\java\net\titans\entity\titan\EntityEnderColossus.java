package net.titans.entity.titan;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.Difficulty;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityDimensions;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.Pose;
import net.minecraft.world.entity.SpawnGroupData;
import net.minecraft.world.entity.Entity.RemovalReason;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier.Builder;
import net.minecraft.world.entity.boss.EnderDragonPart;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.ItemLike;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.ServerLevelAccessor;
import net.minecraft.world.level.Level.ExplosionInteraction;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;
import net.titans.entity.EntityColorLightningBolt;
import net.titans.entity.IBossBarDisplay;
import net.titans.entity.ai.EntityAINearestTargetTitan;
import net.titans.entity.ai.endercolossus.AnimationEnderColossusAntiTitanAttack;
import net.titans.entity.ai.endercolossus.AnimationEnderColossusAttack1;
import net.titans.entity.ai.endercolossus.AnimationEnderColossusAttack2;
import net.titans.entity.ai.endercolossus.AnimationEnderColossusAttack3;
import net.titans.entity.ai.endercolossus.AnimationEnderColossusChainLightning;
import net.titans.entity.ai.endercolossus.AnimationEnderColossusDeath;
import net.titans.entity.ai.endercolossus.AnimationEnderColossusDragonLightningBall;
import net.titans.entity.ai.endercolossus.AnimationEnderColossusLightningAttack;
import net.titans.entity.ai.endercolossus.AnimationEnderColossusLightningBall;
import net.titans.entity.ai.endercolossus.AnimationEnderColossusMeteorRain;
import net.titans.entity.ai.endercolossus.AnimationEnderColossusScream;
import net.titans.entity.ai.endercolossus.AnimationEnderColossusStun;
import net.titans.entity.minion.EntityDragonMinion;
import net.titans.entity.minion.EntityEnderColossusMinion;
import net.titans.entity.projectile.EntityEnderPearlTitan;
import net.titans.entity.projectile.EntityLightningBall;
import net.titans.loader.TheTitansDimensions;
import net.titans.loader.TheTitansEntities;
import net.titans.loader.TheTitansRegistries;
import net.titans.loader.TheTitansPredicateTargets;
import net.titans.loader.TheTitansSounds;
import net.titans.util.AnimationUtils;
import net.titans.util.ItemUtils;

public class EntityEnderColossus extends EntityTitan implements IEntityMultiPartTitan, IBossBarDisplay {
    private static final EntityDataAccessor<Integer> EYE_LASER_TIME = SynchedEntityData.defineId(EntityEnderColossus.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Boolean> CAN_CALL_BACK_UP = SynchedEntityData.defineId(EntityEnderColossus.class, EntityDataSerializers.BOOLEAN);
    private static final EntityDataAccessor<Boolean> SCREAMING = SynchedEntityData.defineId(EntityEnderColossus.class, EntityDataSerializers.BOOLEAN);
    public EntityTitanPart head;
    public EntityTitanPart body;
    public EntityTitanPart leftEye;
    public EntityTitanPart rightEye;
    public EntityTitanPart leftArm;
    public EntityTitanPart rightArm;
    public EntityTitanPart leftLeg;
    public EntityTitanPart rightLeg;
    private int roarcooldownTimer;
    public int numOfCrystals;
    public int maxNumOfCrystals = 20;
    public int destroyedCrystals;
    public boolean healCrystals;
    public boolean isStunned;

    public EntityEnderColossus(EntityType<? extends EntityTitan> entityType, Level level) {
        super(entityType, level);
        this.head = new EntityTitanPart(this, "head", 12.0F, 12.0F);
        this.body = new EntityTitanPart(this, "body", 10.0F, 18.0F);
        this.leftEye = new EntityTitanPart(this, "lefteye", 3.0F, 2.0F);
        this.rightEye = new EntityTitanPart(this, "righteye", 3.0F, 2.0F);
        this.leftArm = new EntityTitanPart(this, "leftarm", 4.0F, 4.0F);
        this.rightArm = new EntityTitanPart(this, "rightarm", 4.0F, 4.0F);
        this.leftLeg = new EntityTitanPart(this, "leftleg", 4.0F, 42.0F);
        this.rightLeg = new EntityTitanPart(this, "rightleg", 4.0F, 42.0F);
        this.parts = new EntityTitanPart[]{this.head, this.body, this.leftEye, this.rightEye, this.leftArm, this.rightArm, this.leftLeg, this.rightLeg};
    }

    public EntityEnderColossus(Level level) {
        this((EntityType<? extends EntityTitan>)TheTitansEntities.ENDER_COLOSSUS.get(), level);
    }

    public static Builder createAttributes() {
        return EntityTitan.createAttributes().add(Attributes.MAX_HEALTH, 600000.0).add(Attributes.ATTACK_DAMAGE, 5000.0);
    }

    @Override
    public ResourceLocation getBossBarTexture() {
        return ResourceLocation.tryBuild("titan", "textures/gui/bossbar/ender_colossus.png");
    }

    @Override
    public int getBossBarNameColor() {
        return 13369594;
    }

    @Override
    public int getBossBarWidth() {
        return 193;
    }

    @Override
    public int getBossBarHeight() {
        return 23;
    }

    @Override
    public int getBossBarInterval() {
        return 5;
    }

    @Override
    public int getBossBarVOffset() {
        return 0;
    }

    @Override
    public int getBossBarVHeight() {
        return 0;
    }

    @Override
    public int getBossBarTextOffset() {
        return 7;
    }

    @Override
    protected void registerGoals() {
        super.registerGoals();
        this.goalSelector.addGoal(0, new AnimationEnderColossusDeath(this));
        this.goalSelector.addGoal(0, new AnimationEnderColossusAntiTitanAttack(this));
        this.goalSelector.addGoal(0, new AnimationEnderColossusAttack1(this));
        this.goalSelector.addGoal(0, new AnimationEnderColossusAttack2(this));
        this.goalSelector.addGoal(0, new AnimationEnderColossusAttack3(this));
        this.goalSelector.addGoal(0, new AnimationEnderColossusChainLightning(this));
        this.goalSelector.addGoal(0, new AnimationEnderColossusDragonLightningBall(this));
        this.goalSelector.addGoal(0, new AnimationEnderColossusLightningAttack(this));
        this.goalSelector.addGoal(0, new AnimationEnderColossusLightningBall(this));
        this.goalSelector.addGoal(0, new AnimationEnderColossusMeteorRain(this));
        this.goalSelector.addGoal(0, new AnimationEnderColossusScream(this));
        this.goalSelector.addGoal(0, new AnimationEnderColossusStun(this));
        this.targetSelector.addGoal(0, new EntityAINearestTargetTitan(this, EntitySnowGolemTitan.class, false));
        this.targetSelector.addGoal(0, new EntityAINearestTargetTitan(this, EntityIronGolemTitan.class, false));
        this.targetSelector
            .addGoal(0, new EntityAINearestTargetTitan<LivingEntity>(this, LivingEntity.class, 0, false, false, TheTitansPredicateTargets.EnderColossus));
    }

    public int getEyeLaserTime() {
        return (Integer)this.entityData.get(EYE_LASER_TIME);
    }

    public void setEyeLaserTime(int eyeLaserTime) {
        this.entityData.set(EYE_LASER_TIME, eyeLaserTime);
    }

    public int getRoarCooldownTimer() {
        return this.roarcooldownTimer;
    }

    public void setRoarCooldownTimer(int roarcooldownTimer) {
        this.roarcooldownTimer = roarcooldownTimer;
    }

    public boolean getCanCallBackUp() {
        return (Boolean)this.entityData.get(CAN_CALL_BACK_UP);
    }

    public void setCanCallBackUp(boolean canCallBackUp) {
        this.entityData.set(CAN_CALL_BACK_UP, canCallBackUp);
    }

    public boolean isScreaming() {
        return (Boolean)this.entityData.get(SCREAMING);
    }

    public void setScreaming(boolean screaming) {
        if (screaming) {
            this.playSound(this.getRoarSound(), this.getSoundVolume(), 1.0F);
        }

        if (!this.level().isClientSide()) {
            this.entityData.set(SCREAMING, screaming);
        }
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(EYE_LASER_TIME, 0);
        this.entityData.define(CAN_CALL_BACK_UP, false);
        this.entityData.define(SCREAMING, false);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        this.setEyeLaserTime(tag.getInt("EyeLaserTime"));
        this.setRoarCooldownTimer(tag.getInt("RoarCooldownTimer"));
        this.setCanCallBackUp(tag.getBoolean("CanCallBackUp"));
        this.setScreaming(tag.getBoolean("Screaming"));
        this.destroyedCrystals = tag.getInt("DestroyedCrystals");
        this.healCrystals = tag.getBoolean("HealCrystals");
        this.isStunned = tag.getBoolean("IsStunned");
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putInt("EyeLaserTime", this.getEyeLaserTime());
        tag.putInt("RoarCooldownTimer", this.getRoarCooldownTimer());
        tag.putBoolean("CanCallBackUp", this.getCanCallBackUp());
        tag.putBoolean("Screaming", this.isScreaming());
        tag.putInt("DestroyedCrystals", this.destroyedCrystals);
        tag.putBoolean("HealCrystals", this.healCrystals);
        tag.putBoolean("IsStunned", this.isStunned);
    }

    protected boolean isLookingAtMe(Player player, EntityTitanPart entityTitanPart) {
        Vec3 vec3 = player.getViewVector(1.0F).normalize();
        Vec3 vec31 = new Vec3(
            entityTitanPart.getX()
                + this.random.nextDouble() * (double)entityTitanPart.getBbWidth()
                - (double)entityTitanPart.getBbWidth() * 0.5
                - player.getX(),
            entityTitanPart.getBoundingBox().minY
                + this.random.nextDouble() * (double)entityTitanPart.getBbHeight()
                - player.getY()
                + (double)player.getEyeHeight(),
            entityTitanPart.getZ()
                + this.random.nextDouble() * (double)entityTitanPart.getBbWidth()
                - (double)entityTitanPart.getBbWidth() * 0.5
                - player.getZ()
        );
        double d0 = vec31.length();
        vec31 = vec31.normalize();
        double d1 = vec3.dot(vec31);
        return d1 > 1.0 - 0.025 / d0 ? player.hasLineOfSight(this) : false;
    }

    protected Player findPlayerToLookAt() {
        Player player = this.level().getNearestPlayer(this, -1.0);
        if (player != null && player.isAlive() && this.isAlive() && (this.isLookingAtMe(player, this.leftEye) || this.isLookingAtMe(player, this.rightEye))) {
            this.getLookControl().setLookAt(player, 180.0F, 30.0F);
            this.setTarget(player);
            this.attackEntity(player, 20.0F);
            if (!ItemUtils.hasItem(player.getInventory(), (Item)TheTitansRegistries.ULTIMA_BLADE.get())
                && !ItemUtils.hasItem(player.getInventory(), (Item)TheTitansRegistries.OPTIMA_AXE.get())) {
                this.playSound((SoundEvent)TheTitansSounds.TITAN_ENDER_COLOSUS_STARE.get(), Float.MAX_VALUE, 1.0F);
                player.setPos(player.getX(), player.getY() + 20000.0, player.getZ());
                if (!this.level().isClientSide()) {
                    this.level().explode(this, player.getX(), player.getY(), player.getZ(), 8.0F, true, ExplosionInteraction.MOB);
                    player.addEffect(new MobEffectInstance(MobEffects.CONFUSION, 400, 1));
                    player.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 400, 99));
                    player.addEffect(new MobEffectInstance(MobEffects.BLINDNESS, 400, 1));
                }
            }

            return player;
        } else {
            return null;
        }
    }

    @Override
    public SpawnGroupData finalizeSpawn(
        ServerLevelAccessor level, DifficultyInstance difficulty, MobSpawnType spawnType, @Nullable SpawnGroupData spawnGroupData, @Nullable CompoundTag tag
    ) {
        SpawnGroupData groupData = super.finalizeSpawn(level, difficulty, spawnType, spawnGroupData, null);
        this.setScreaming(true);
        this.setCanCallBackUp(true);
        this.setRoarCooldownTimer(-20 - this.random.nextInt(20));
        return groupData;
    }

    protected EntityDimensions getDefaultDimensions(Pose pose) {
        float width = 12.0F;
        float height = this.isScreaming() ? 82.0F : 72.0F;
        float eyeHeight = this.isScreaming() ? 76.0F : 65.0F;
        return EntityDimensions.scalable(width, height);
    }

    @Override
    protected void refreshAttributes() {
        if (this.level().getDifficulty() == Difficulty.HARD) {
            this.getAttribute(Attributes.MAX_HEALTH).setBaseValue(600000.0 + (double)this.getExtraPower() * 2500.0);
            this.getAttribute(Attributes.ATTACK_DAMAGE).setBaseValue(5000.0 + (double)this.getExtraPower() * 3000.0);
        } else {
            this.getAttribute(Attributes.MAX_HEALTH).setBaseValue(300000.0 + (double)this.getExtraPower() * 1250.0);
            this.getAttribute(Attributes.ATTACK_DAMAGE).setBaseValue(2500.0 + (double)this.getExtraPower() * 1500.0);
        }
    }

    @Override
    public boolean canAttack() {
        return true;
    }

    @Override
    public boolean canAttackEntity(Entity entity) {
        return super.canAttackEntity(entity)
            && !(entity instanceof EntityEnderColossusCrystal)
            && !(entity instanceof EntityEnderColossusMinion)
            && !(entity instanceof EntityDragonMinion);
    }

    @Override
    public boolean canBeHurtByPlayer() {
        return !this.isInvulnerable() && this.getAnimationID() != 5;
    }

    @Override
    public boolean shouldMove() {
        return this.getAnimationID() == 0 && !this.isStunned && this.getTarget() != null ? super.shouldMove() : false;
    }

    @Override
    public double getMeleeRange() {
        return (double)(
                this.getBbWidth() * this.getBbWidth() + (this.getTarget().getBbWidth() > 48.0F ? 2304.0F : this.getTarget().getBbWidth() * this.getTarget().getBbWidth())
            )
            + 2000.0;
    }

    @Override
    public boolean canRegen() {
        return !this.isStunned;
    }

    @Override
    public SimpleParticleType getParticles() {
        return ParticleTypes.PORTAL;
    }

    @Override
    public int getParticleCount() {
        return 60;
    }

    @Override
    public int getMinionCap() {
        return 160;
    }

    @Override
    public int getPriestCap() {
        return 80;
    }

    @Override
    public int getZealotCap() {
        return 40;
    }

    @Override
    public int getBishopCap() {
        return 30;
    }

    @Override
    public int getTemplarCap() {
        return 20;
    }

    @Override
    public int getSpecialMinionCap() {
        return 10;
    }

    @Override
    public boolean canSpawnMinion() {
        boolean flag = this.getInvulTime() > 1 && this.tickCount % 20 == 0;
        float randomRate = this.random.nextFloat() * 100.0F;
        return flag || (double)randomRate < 5.0;
    }

    @Override
    public boolean canSpawnPriest() {
        boolean flag = this.getInvulTime() > 1 && this.tickCount % 20 == 0;
        float randomRate = this.random.nextFloat() * 100.0F;
        return flag || (double)randomRate < 2.5;
    }

    @Override
    public boolean canSpawnZealot() {
        boolean flag = this.getInvulTime() > 1 && this.tickCount % 20 == 0;
        float randomRate = this.random.nextFloat() * 100.0F;
        return flag || (double)randomRate < 1.25;
    }

    @Override
    public boolean canSpawnBishop() {
        boolean flag = this.getInvulTime() > 1 && this.tickCount % 20 == 0;
        float randomRate = this.random.nextFloat() * 100.0F;
        return flag || (double)randomRate < 0.625;
    }

    @Override
    public boolean canSpawnTemplar() {
        boolean flag = this.getInvulTime() > 1 && this.tickCount % 20 == 0;
        float randomRate = this.random.nextFloat() * 100.0F;
        return flag || (double)randomRate < 0.3125;
    }

    @Override
    public boolean canSpawnSpecialMinion() {
        boolean flag = this.getInvulTime() > 1 && this.tickCount % 20 == 0;
        float randomRate = this.random.nextFloat() * 100.0F;
        return flag || (double)randomRate < 0.3125;
    }

    @Override
    public EnumTitanStatus getTitanStatus() {
        return EnumTitanStatus.GREATER;
    }

    @Override
    public float getSpeed() {
        return (float)(0.4 + (double)this.getExtraPower() * 0.001);
    }

    public float getLightLevelDependentMagicValue() {
        return 1.0F;
    }

    public int getMaxHeadXRot() {
        return this.getEyeLaserTime() >= 0 ? 180 : 40;
    }

    protected SoundEvent getAmbientSound() {
        return null;
    }

    protected SoundEvent getHurtSound(DamageSource damageSource) {
        return (SoundEvent)TheTitansSounds.TITAN_ENDER_COLOSUS_GRUNT.get();
    }

    protected SoundEvent getDeathSound() {
        return (SoundEvent)TheTitansSounds.TITAN_ENDER_COLOSUS_DEATH.get();
    }

    protected SoundEvent getRoarSound() {
        return (SoundEvent)TheTitansSounds.TITAN_ENDER_COLOSUS_ROAR.get();
    }

    protected void playStepSound(BlockPos pos, BlockState state) {
        this.shakeNearbyPlayerCameras(6000.0);
        this.playSound((SoundEvent)TheTitansSounds.TITAN_STEP.get(), 10.0F, 0.85F);
        float f1 = this.getYRot() * (float) Math.PI / 180.0F;
        float f2 = Mth.sin(f1);
        float f3 = Mth.cos(f1);
        this.collideWithEntities(
            this.leftLeg,
            this.level().getEntities(this, this.leftLeg.getBoundingBox().inflate(1.0, 1.0, 1.0).move((double)(f2 * 10.0F), 0.0, (double)(f3 * 10.0F)))
        );
        this.collideWithEntities(
            this.rightLeg,
            this.level().getEntities(this, this.rightLeg.getBoundingBox().inflate(1.0, 1.0, 1.0).move((double)(f2 * 10.0F), 0.0, (double)(f3 * 10.0F)))
        );
    }

    @Override
    public boolean attackEntityFromPart(EntityTitanPart entityTitanPart, DamageSource damageSource, float amount) {
        this.hurt(damageSource, amount);
        return true;
    }

    @Override
    public boolean hurt(DamageSource damageSource, float amount) {
        if (this.isStunned) {
            amount *= 2.0F;
        }

        return super.hurt(damageSource, amount);
    }

    @Override
    public boolean causeFallDamage(float fallDistance, float multiplier, DamageSource damageSource) {
        this.setOnGround(true);
        this.hasImpulse = false;
        if (fallDistance <= 0.0F) {
            return false;
        } else {
            MobEffectInstance mobEffectInstance = this.getEffect(MobEffects.JUMP);
            float f1 = mobEffectInstance != null ? (float)(mobEffectInstance.getAmplifier() + 1) : 0.0F;
            int i = Mth.ceil(fallDistance - 24.0F - f1);
            if (i > 0) {
                this.shakeNearbyPlayerCameras(400000.0);
                this.playSound((SoundEvent)TheTitansSounds.GROUND_SMASH.get(), 20.0F, 1.0F);
                this.playSound((SoundEvent)TheTitansSounds.TITAN_LAND.get(), 10000.0F, 1.0F);
                this.destroyBlocksInAABBTopless(this.getBoundingBox().inflate(24.0, 1.0, 24.0));

                for (Entity entity : this.level().getEntities(this, this.getBoundingBox().inflate(48.0, 4.0, 48.0))) {
                    if (entity != null
                        && entity instanceof LivingEntity
                        && !(entity instanceof EntityTitan)
                        && this.canAttackEntity(entity)
                        && !(entity instanceof EnderDragonPart)) {
                        LivingEntity livingEntity = (LivingEntity)entity;
                        float smash = 100.0F - this.distanceTo(livingEntity);
                        if (smash <= 1.0F) {
                            smash = 1.0F;
                        }

                        this.attackEntity(livingEntity, smash * 4.0F);
                        double d0 = this.getBoundingBox().minX + this.getBoundingBox().maxX;
                        double d1 = this.getBoundingBox().minZ + this.getBoundingBox().maxZ;
                        double d2 = entity.getX() - d0;
                        double d3 = entity.getZ() - d1;
                        double d4 = d2 * d2 + d3 * d3;
                        if (d4 >= 0.01) {
                            double d5 = d2 / d4 * 8.0;
                            double d6 = 1.0;
                            double d7 = d3 / d4 * 8.0;
                            livingEntity.push(d5, d6, d7);
                        }
                    }
                }
            }

            return true;
        }
    }

    public void kill() {
        this.playSound(SoundEvents.ENDERMAN_TELEPORT, 100.0F, 0.6F);
        if (this.level().dimension() != Level.END && this.level().dimension() != TheTitansDimensions.THE_VOID) {
            this.setPos(this.getX() + (this.random.nextDouble() - 0.5) * 48.0, 128.0, this.getZ() + (this.random.nextDouble() - 0.5) * 48.0);
        } else {
            this.setPos(0.0, 128.0, 0.0);
        }
    }

    @Override
    public void aiStep() {
        super.aiStep();
        if (this.getEyeLaserTime() >= 0 && this.tickCount % 5 == 0 && !this.isStunned) {
            double d8 = 300.0;
            Vec3 vec3 = this.getViewVector(1.0F);
            double dx = vec3.x * d8;
            double dy = vec3.y * d8;
            double dz = vec3.z * d8;
            float amount = (float)this.getAttributeBaseValue(Attributes.ATTACK_DAMAGE);

            for (Entity entity : this.level().getEntities(this, this.getBoundingBox().inflate(d8, d8, d8).move(dx, dy, dz))) {
                if (entity != null && entity instanceof LivingEntity && entity.isAlive() && this.canAttackEntity(entity)) {
                    LivingEntity livingEntity = (LivingEntity)entity;
                    this.attackEntity(livingEntity, amount);
                }
            }
        }

        if (this.isAlive() && !this.isStunned) {
            if (this.healCrystals) {
                if (this.numOfCrystals < this.maxNumOfCrystals) {
                    if (this.tickCount % 20 == 0) {
                        EntityEnderColossusCrystal enderColossusCrystal = new EntityEnderColossusCrystal(this.level());
                        enderColossusCrystal.owner = this;
                        enderColossusCrystal.setPos(this.getX(), this.getY() + 92.0, this.getZ());
                        enderColossusCrystal.push(0.0, 2.0, 0.0);
                        if (!this.level().isClientSide()) {
                            this.level().addFreshEntity(enderColossusCrystal);
                        }

                        this.numOfCrystals++;
                    }
                } else {
                    this.healCrystals = false;
                }
            } else if (this.destroyedCrystals == 0 && this.numOfCrystals < this.maxNumOfCrystals) {
                this.healCrystals = true;
            }
        }
    }

    @Override
    protected void dropExperienceOrb() {
        for (int x = 0; x < 90; x++) {
            EntityExperienceOrbTitan experienceOrbTitan = new EntityExperienceOrbTitan(
                this.level(),
                this.getX() + (double)(this.random.nextFloat() * 12.0F - 6.0F),
                this.getY() + 4.0,
                this.getZ() + (double)(this.random.nextFloat() * 12.0F - 6.0F),
                26000
            );
            experienceOrbTitan.push(0.0, 1.0, 0.0);
            this.level().addFreshEntity(experienceOrbTitan);
        }
    }

    @Override
    protected void dropRateItem() {
        Map<ItemStack, Integer> drops = new HashMap<>();
        drops.put(new ItemStack(Items.GOLDEN_APPLE), 64);
        drops.put(new ItemStack(Items.DIAMOND_SWORD), 64);
        drops.put(new ItemStack(Items.NAME_TAG), 64);
        Entry<ItemStack, Integer> entry = drops.entrySet().stream().toList().get(this.random.nextInt(drops.entrySet().size()));
        ItemStack itemStack = entry.getKey();
        int count = entry.getValue();
        EntityItemTitan itemTitan = new EntityItemTitan(
            this.level(),
            this.getX() + (double)(this.random.nextFloat() * 12.0F - 6.0F),
            this.getY() + 4.0,
            this.getZ() + (double)(this.random.nextFloat() * 12.0F - 6.0F),
            itemStack,
            count
        );
        itemTitan.setPickUpDelay(40);
        this.level().addFreshEntity(itemTitan);
    }

    @Override
    protected void dropAllItem() {
        Map<ItemStack, Integer> drops = new HashMap<>();
        Map<ItemStack, Integer> rateDrops = new HashMap<>();
        drops.put(new ItemStack(Items.ENDER_EYE), 512);
        drops.put(new ItemStack(Items.ENDER_PEARL), 128);
        drops.put(new ItemStack(Blocks.COAL_BLOCK), 256);
        drops.put(new ItemStack(Blocks.IRON_BLOCK), 256);
        drops.put(new ItemStack(Blocks.EMERALD_BLOCK), 128);
        drops.put(new ItemStack(Blocks.DIAMOND_BLOCK), 128);
        drops.put(new ItemStack(Blocks.DRAGON_EGG), 64);
        drops.put(new ItemStack(Blocks.BEDROCK), 16);
        drops.put(new ItemStack((ItemLike)TheTitansRegistries.HARCADIUM.get()), 64);
        drops.put(new ItemStack((ItemLike)TheTitansRegistries.VOID.get()), 32);
        drops.put(new ItemStack(Blocks.END_PORTAL_FRAME), 60);
        rateDrops.put(new ItemStack(Items.ENDER_EYE), 512);
        rateDrops.put(new ItemStack(Items.ENDER_PEARL), 128);
        rateDrops.put(new ItemStack(Blocks.COAL_BLOCK), 256);
        rateDrops.put(new ItemStack(Blocks.IRON_BLOCK), 256);
        rateDrops.put(new ItemStack(Blocks.EMERALD_BLOCK), 128);
        rateDrops.put(new ItemStack(Blocks.DIAMOND_BLOCK), 128);
        rateDrops.put(new ItemStack(Blocks.DRAGON_EGG), 64);
        rateDrops.put(new ItemStack(Blocks.BEDROCK), 16);
        rateDrops.put(new ItemStack((ItemLike)TheTitansRegistries.HARCADIUM.get()), 64);
        rateDrops.put(new ItemStack((ItemLike)TheTitansRegistries.VOID.get()), 32);

        for (Entry<ItemStack, Integer> entry : drops.entrySet()) {
            ItemStack itemStack = entry.getKey();
            int count = entry.getValue();
            EntityItemTitan itemTitan = new EntityItemTitan(
                this.level(),
                this.getX() + (double)(this.random.nextFloat() * 12.0F - 6.0F),
                this.getY() + 4.0,
                this.getZ() + (double)(this.random.nextFloat() * 12.0F - 6.0F),
                itemStack,
                count
            );
            itemTitan.setPickUpDelay(40);
            this.level().addFreshEntity(itemTitan);
        }

        for (Entry<ItemStack, Integer> entry : rateDrops.entrySet()) {
            ItemStack itemStack = entry.getKey();
            int count = entry.getValue();
            int randomCount = this.random.nextInt(count) + 1;
            EntityItemTitan itemTitan = new EntityItemTitan(
                this.level(),
                this.getX() + (double)(this.random.nextFloat() * 12.0F - 6.0F),
                this.getY() + 4.0,
                this.getZ() + (double)(this.random.nextFloat() * 12.0F - 6.0F),
                itemStack,
                randomCount
            );
            itemTitan.setPickUpDelay(40);
            this.level().addFreshEntity(itemTitan);
        }

        ItemEntity itemEntity = new ItemEntity(
            this.level(),
            this.getX() + (double)(this.random.nextFloat() * 12.0F - 6.0F),
            this.getY() + 4.0,
            this.getZ() + (double)(this.random.nextFloat() * 12.0F - 6.0F),
            new ItemStack((ItemLike)TheTitansRegistries.VOID_SWORD.get())
        );
        itemEntity.setPickUpDelay(40);
        this.level().addFreshEntity(itemEntity);
    }

    @Override
    protected void tickTitanDeath() {
        super.tickTitanDeath();
        AnimationUtils.sendPacket(this, 10);
        this.isStunned = false;
        if (this.deathTicks >= 500) {
            this.setInvulTime(this.getInvulTime() + 8);
            this.setAnimationTick(this.getAnimationTick() - 1);
            float f = (this.random.nextFloat() - 0.5F) * 12.0F;
            float f1 = (this.random.nextFloat() - 0.5F) * 3.0F;
            float f2 = (this.random.nextFloat() - 0.5F) * 12.0F;
            this.level()
                .addParticle(ParticleTypes.EXPLOSION, this.getX() + (double)f, this.getY() + 2.0 + (double)f1, this.getZ() + (double)f2, 0.0, 0.0, 0.0);
        }

        if (this.getInvulTime() >= this.getThreashHold()) {
            this.onDeath();
            if (!this.level().isClientSide() && !this.isRemoved()) {
                for (EntityTitanPart part : this.parts) {
                    part.remove(RemovalReason.KILLED);
                }

                this.removeTitan(RemovalReason.KILLED);
            }
        }
    }

    public void animationTick() {
        if (this.getAnimationID() == 1) {
            if (this.getAnimationTick() == 4 && this.getAntiTitanAttackAnimationID() == 0) {
                this.playSound((SoundEvent)TheTitansSounds.TITAN_ENDER_COLOSUS_CHOMP.get(), 100.0F, 1.0F);
            }

            if (this.getAnimationTick() == 12 && this.getTarget() != null) {
                this.shakeNearbyPlayerCameras(20000.0);
                float amount = (float)this.getAttributeBaseValue(Attributes.ATTACK_DAMAGE);
                int knockbackAmount = this.getKnockbackAmount();
                this.collideWithEntities(this.body, this.level().getEntities(this, this.body.getBoundingBox().inflate(48.0, 48.0, 48.0)));

                for (int i = 0; i < 16; i++) {
                    this.attackEntity(this.getTarget(), amount);
                }

                this.knockbackEntity(this.getTarget(), (float)knockbackAmount);

                for (Entity entity : this.level().getEntities(this.getTarget(), this.getTarget().getBoundingBox().inflate(8.0, 8.0, 8.0))) {
                    if (entity != null && entity != this && entity instanceof LivingEntity && this.canAttackEntity(entity)) {
                        LivingEntity livingEntity = (LivingEntity)entity;

                        for (int i = 0; i < 4; i++) {
                            this.attackEntity(livingEntity, amount);
                        }

                        this.knockbackEntity(livingEntity, (float)knockbackAmount);
                    }
                }
            }
        }

        if (this.getAnimationID() == 2 && this.getAnimationTick() >= 40 && this.getAnimationTick() <= 80 && this.getTarget() != null) {
            for (int i = 0; i < 3; i++) {
                for (int it = 0; it < 2; it++) {
                    double d0 = this.random.nextGaussian() * 64.0;
                    double d1 = this.random.nextGaussian() * 32.0;
                    double d2 = this.random.nextGaussian() * 64.0;
                    double d3 = this.getTarget().getX() + d0;
                    double d4 = this.getTarget().getY() + 150.0 + d1;
                    double d5 = this.getTarget().getZ() + d2;
                    double d6 = this.getTarget().getX() - d3;
                    double d7 = this.getTarget().getY() - d4;
                    double d8 = this.getTarget().getZ() - d5;
                    EntityEnderPearlTitan enderPearlTitan = new EntityEnderPearlTitan(this.level(), this);
                    enderPearlTitan.setOwner(this);
                    enderPearlTitan.setPos(d3, d4, d5);
                    enderPearlTitan.shoot(d6, d7, d8, 1.0F, 4.0F);
                    if (!this.level().isClientSide()) {
                        this.level().addFreshEntity(enderPearlTitan);
                    }
                }
            }
        }

        if (this.getAnimationID() == 3) {
            if (this.getAnimationTick() == 20) {
                this.playSound((SoundEvent)TheTitansSounds.LIGHTNING_CHARGE.get(), 100.0F, 1.0F);
            }

            if (this.getAnimationTick() == 64) {
                this.playSound((SoundEvent)TheTitansSounds.LIGHTNING_CHARGE.get(), 100.0F, 1.0F);
                double d8 = 24.0;
                Vec3 vec3 = this.getViewVector(1.0F);
                double dx = vec3.x * d8;
                double dz = vec3.z * d8;
                float amount = (float)this.getAttributeBaseValue(Attributes.ATTACK_DAMAGE);
                int knockbackAmount = this.getKnockbackAmount();
                EntityColorLightningBolt colorLightningBolt1 = new EntityColorLightningBolt(this.level(), 1.0F, 0.0F, 1.0F);
                colorLightningBolt1.setPos(this.getX() + dx, this.getY() + (this.isBaby() ? 9.0 : 18.0), this.getZ() + dz);
                if (!this.level().isClientSide()) {
                    this.level().addFreshEntity(colorLightningBolt1);
                }

                if (this.getTarget() != null) {
                    EntityColorLightningBolt colorLightningBolt2 = new EntityColorLightningBolt(this.level(), 1.0F, 0.0F, 1.0F);
                    colorLightningBolt2.setPos(this.getTarget().getX(), this.getTarget().getY(), this.getTarget().getZ());
                    if (!this.level().isClientSide()) {
                        this.level().addFreshEntity(colorLightningBolt2);
                    }

                    this.attackEntity(this.getTarget(), amount * 3.0F);
                    this.knockbackEntity(this.getTarget(), (float)knockbackAmount);
                    this.getTarget().push(0.0, 1.0 + this.random.nextDouble(), 0.0);
                    if (!this.level().isClientSide()) {
                        this.level()
                            .explode(
                                this, this.getTarget().getX(), this.getTarget().getY(), this.getTarget().getZ(), 2.0F, false, ExplosionInteraction.MOB
                            );
                        this.level()
                            .explode(this, this.getX() + dx, this.getY() + 26.0, this.getZ() + dz, 1.0F, false, ExplosionInteraction.MOB);
                    }

                    for (Entity entityx : this.level().getEntities(this.getTarget(), this.getTarget().getBoundingBox().inflate(4.0, 4.0, 4.0))) {
                        if (entityx != null && entityx != this && entityx instanceof LivingEntity && this.canAttackEntity(entityx)) {
                            LivingEntity livingEntity = (LivingEntity)entityx;
                            EntityColorLightningBolt colorLightningBolt3 = new EntityColorLightningBolt(this.level(), 1.0F, 0.0F, 1.0F);
                            colorLightningBolt3.setPos(livingEntity.getX(), livingEntity.getY(), livingEntity.getZ());
                            if (!this.level().isClientSide()) {
                                this.level().addFreshEntity(colorLightningBolt3);
                            }

                            this.attackEntity(livingEntity, amount);
                            livingEntity.push(0.0, 1.0 + this.random.nextDouble(), 0.0);

                            for (Entity entity1 : this.level().getEntities(livingEntity, livingEntity.getBoundingBox().inflate(4.0, 4.0, 4.0))) {
                                if (entity1 != null && entity1 != this && entity1 instanceof LivingEntity && this.canAttackEntity(entity1)) {
                                    LivingEntity livingEntity1 = (LivingEntity)entity1;
                                    EntityColorLightningBolt colorLightningBolt4 = new EntityColorLightningBolt(this.level(), 1.0F, 0.0F, 1.0F);
                                    colorLightningBolt4.setPos(livingEntity1.getX(), livingEntity1.getY(), livingEntity1.getZ());
                                    if (!this.level().isClientSide()) {
                                        this.level().addFreshEntity(colorLightningBolt4);
                                    }

                                    this.attackEntity(livingEntity1, amount);
                                    livingEntity1.push(0.0, 1.0 + this.random.nextDouble(), 0.0);

                                    for (Entity entity2 : this.level().getEntities(livingEntity1, livingEntity1.getBoundingBox().inflate(4.0, 4.0, 4.0))) {
                                        if (entity2 != null
                                            && entity2 != this
                                            && entity2 != livingEntity
                                            && entity2 instanceof LivingEntity
                                            && this.canAttackEntity(entity2)) {
                                            LivingEntity livingEntity2 = (LivingEntity)entity2;
                                            EntityColorLightningBolt colorLightningBolt5 = new EntityColorLightningBolt(this.level(), 1.0F, 0.0F, 1.0F);
                                            colorLightningBolt5.setPos(livingEntity2.getX(), livingEntity2.getY(), livingEntity2.getZ());
                                            if (!this.level().isClientSide()) {
                                                this.level().addFreshEntity(colorLightningBolt5);
                                            }

                                            this.attackEntity(livingEntity2, amount);
                                            livingEntity2.push(0.0, 1.0 + this.random.nextDouble(), 0.0);

                                            for (Entity entity3 : this.level().getEntities(livingEntity2, livingEntity2.getBoundingBox().inflate(4.0, 4.0, 4.0))) {
                                                if (entity3 != null
                                                    && entity3 != this
                                                    && entity3 != livingEntity
                                                    && entity3 != livingEntity1
                                                    && entity3 instanceof LivingEntity
                                                    && this.canAttackEntity(entity3)) {
                                                    LivingEntity livingEntity3 = (LivingEntity)entity3;
                                                    EntityColorLightningBolt colorLightningBolt6 = new EntityColorLightningBolt(
                                                        this.level(), 1.0F, 0.0F, 1.0F
                                                    );
                                                    colorLightningBolt6.setPos(livingEntity3.getX(), livingEntity3.getY(), livingEntity3.getZ());
                                                    if (!this.level().isClientSide()) {
                                                        this.level().addFreshEntity(colorLightningBolt6);
                                                    }

                                                    this.attackEntity(livingEntity3, amount);
                                                    livingEntity3.push(0.0, 1.0 + this.random.nextDouble(), 0.0);
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        if (this.getAnimationID() == 4 && this.getAnimationTick() == 50 && this.getTarget() != null) {
            this.playSound((SoundEvent)TheTitansSounds.LIGHTNING_THROW.get(), 100.0F, 1.0F);
            double d8x = 24.0;
            Vec3 vec3x = this.getViewVector(1.0F);
            double dxx = vec3x.x * d8x;
            double dzx = vec3x.z * d8x;
            double d0 = this.getX() + dxx;
            double d1 = this.getY() + d8x;
            double d2 = this.getZ() + dzx;
            double d3 = this.getTarget().getX() - d0;
            double d4 = this.getTarget().getY() - d1;
            double d5 = this.getTarget().getZ() - d2;
            if (!this.level().isClientSide()) {
                this.level()
                    .explode(this, this.getTarget().getX(), this.getTarget().getY(), this.getTarget().getZ(), 2.0F, false, ExplosionInteraction.MOB);
                this.level().explode(this, this.getX() + dxx, this.getY() + 24.0, this.getZ() + dzx, 1.0F, false, ExplosionInteraction.MOB);
            }

            EntityColorLightningBolt colorLightningBolt = new EntityColorLightningBolt(this.level(), 1.0F, 0.0F, 1.0F);
            colorLightningBolt.setPos(this.getTarget().getX(), this.getTarget().getY(), this.getTarget().getZ());
            if (!this.level().isClientSide()) {
                this.level().addFreshEntity(colorLightningBolt);
            }

            this.getTarget().hurt(this.damageSources().lightningBolt(), 100.0F);
            EntityLightningBall lightningBall = new EntityLightningBall(this.level(), this);
            lightningBall.setOwner(this);
            lightningBall.setPos(d0, d1, d2);
            lightningBall.shoot(d3, d4, d5, 1.0F, 0.0F);
            if (!this.level().isClientSide()) {
                this.level().addFreshEntity(lightningBall);
            }
        }

        if (this.getAnimationID() == 5) {
            if (this.getAnimationTick() == 80) {
                this.playSound((SoundEvent)TheTitansSounds.TITAN_ENDER_COLOSUS_SCREAM_LONG.get(), Float.MAX_VALUE, 1.0F);
            }

            if (this.getAnimationTick() > 80) {
                if (!this.level().isClientSide()) {
                    ServerLevel serverLevel = (ServerLevel)this.level();
                    serverLevel.setWeatherParameters(0, 0, false, false);
                }

                this.setScreaming(false);
                float amountx = 1.0E7F;
                this.collideWithEntities(this.body, this.level().getEntities(this, this.body.getBoundingBox().inflate(16.0, 8.0, 16.0)));

                for (Entity entityxx : this.level().getEntities(this, this.body.getBoundingBox().inflate(256.0, 256.0, 256.0))) {
                    if (entityxx != null && entityxx instanceof LivingEntity && this.canAttackEntity(entityxx)) {
                        LivingEntity livingEntity = (LivingEntity)entityxx;

                        for (int i = 0; i < 3; i++) {
                            this.attackEntity(livingEntity, (float)this.getAnimationTick());
                        }

                        this.attackEntity(livingEntity, amountx);
                        livingEntity.setDeltaMovement(0.0, livingEntity.getDeltaMovement().y, 0.0);
                        livingEntity.setXRot(livingEntity.getXRot() + 1.0F);
                        if (!this.level().isClientSide()) {
                            livingEntity.addEffect(new MobEffectInstance(MobEffects.CONFUSION, 400, 1));
                            livingEntity.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 400, 99));
                            livingEntity.addEffect(new MobEffectInstance(MobEffects.BLINDNESS, 400, 1));
                        }
                    }
                }
            }
        }

        if (this.getAnimationID() == 6) {
            if (this.getAnimationTick() == 10) {
                this.playSound(
                    (SoundEvent)TheTitansSounds.TITAN_ENDER_COLOSUS_SCREAM.get(),
                    100.0F,
                    (this.random.nextFloat() - this.random.nextFloat()) * 0.2F + 1.1F
                );
            }

            if (this.getAnimationTick() == 32) {
                this.playSound((SoundEvent)TheTitansSounds.TITAN_SWING.get(), 10.0F, 1.0F);
            }

            if (this.getAnimationTick() == 36) {
                this.playSound((SoundEvent)TheTitansSounds.TITAN_STRIKE.get(), 20.0F, 1.0F);
                this.playSound((SoundEvent)TheTitansSounds.TITAN_SLAM.get(), 20.0F, 1.0F);
                double d8xx = 24.0;
                Vec3 vec3xx = this.getViewVector(1.0F);
                double dxxx = vec3xx.x * d8xx;
                double dzxx = vec3xx.z * d8xx;
                float amountx = (float)this.getAttributeBaseValue(Attributes.ATTACK_DAMAGE);
                int knockbackAmountx = this.getKnockbackAmount();
                this.collideWithEntities(this.body, this.level().getEntities(this, this.body.getBoundingBox().inflate(48.0, 12.0, 48.0).move(dxxx, -6.0, dzxx)));

                for (Entity entityxxx : this.level().getEntities(this, this.getBoundingBox().inflate(32.0, 8.0, 32.0).move(dxxx, -4.0, dzxx))) {
                    if (entityxxx != null && entityxxx instanceof LivingEntity && this.canAttackEntity(entityxxx)) {
                        LivingEntity livingEntity = (LivingEntity)entityxxx;
                        this.attackEntity(livingEntity, amountx);
                        this.knockbackEntity(livingEntity, (float)knockbackAmountx);
                    }
                }

                this.collideWithEntities(this.body, this.level().getEntities(this, this.body.getBoundingBox().inflate(64.0, 8.0, 64.0)));

                for (Entity entityxxxx : this.level().getEntities(this, this.getBoundingBox().inflate(64.0, 8.0, 64.0))) {
                    if (entityxxxx != null && entityxxxx instanceof LivingEntity && this.canAttackEntity(entityxxxx)) {
                        LivingEntity livingEntity = (LivingEntity)entityxxxx;
                        livingEntity.push(0.0, 2.0 + this.random.nextDouble() + this.random.nextDouble(), 0.0);
                    }
                }
            }
        }

        if (this.getAnimationID() == 7 && (this.getAnimationTick() == 60 || this.getAnimationTick() == 104)) {
            this.playSound((SoundEvent)TheTitansSounds.TITAN_SLAM.get(), 20.0F, 1.0F);
            this.playSound(
                (SoundEvent)TheTitansSounds.TITAN_ENDER_COLOSUS_SCREAM.get(), 100.0F, (this.random.nextFloat() - this.random.nextFloat()) * 0.2F + 1.0F
            );
            float amountx = (float)this.getAttributeBaseValue(Attributes.ATTACK_DAMAGE);
            this.collideWithEntities(this.body, this.level().getEntities(this, this.body.getBoundingBox().inflate(36.0, 8.0, 32.0)));

            for (Entity entityxxxxx : this.level().getEntities(this, this.getBoundingBox().inflate(32.0, 8.0, 32.0))) {
                if (entityxxxxx != null && entityxxxxx instanceof LivingEntity && this.canAttackEntity(entityxxxxx)) {
                    LivingEntity livingEntity = (LivingEntity)entityxxxxx;
                    this.attackEntity(livingEntity, amountx);
                    livingEntity.push(0.0, 2.0 + this.random.nextDouble() + this.random.nextDouble(), 0.0);
                }
            }
        }

        if (this.getAnimationID() == 8) {
            if (this.getAnimationTick() == 15) {
                this.level()
                    .playSound(
                        this,
                        this.head.blockPosition(),
                        SoundEvents.GENERIC_EXPLODE,
                        SoundSource.MASTER,
                        10.0F,
                        (1.0F + (this.random.nextFloat() - this.random.nextFloat()) * 0.2F) * 0.7F
                    );

                for (int i = 0; i < 50; i++) {
                    this.level()
                        .addParticle(
                            ParticleTypes.EXPLOSION,
                            this.head.getX() + (this.random.nextDouble() - 0.5) * (double)this.head.getBbWidth(),
                            this.head.getY() + this.random.nextDouble() * (double)this.head.getBbHeight(),
                            this.head.getZ() + (this.random.nextDouble() - 0.5) * (double)this.head.getBbWidth(),
                            0.0,
                            0.0,
                            0.0
                        );
                    this.level()
                        .addParticle(
                            ParticleTypes.POOF,
                            this.head.getX() + (this.random.nextDouble() - 0.5) * (double)this.head.getBbWidth(),
                            this.head.getY() + this.random.nextDouble() * (double)this.head.getBbHeight(),
                            this.head.getZ() + (this.random.nextDouble() - 0.5) * (double)this.head.getBbWidth(),
                            0.0,
                            0.0,
                            0.0
                        );
                }
            }

            if (this.getAnimationTick() == 20) {
                this.playSound((SoundEvent)TheTitansSounds.TITAN_ENDER_COLOSUS_SCREAM.get(), this.getSoundVolume(), 1.25F);
            }

            if (this.getAnimationTick() == 90) {
                this.shakeNearbyPlayerCameras(10000.0);
                this.playSound((SoundEvent)TheTitansSounds.TITAN_FALL.get(), 20.0F, 1.0F);
                this.playSound((SoundEvent)TheTitansSounds.GROUND_SMASH.get(), 20.0F, 1.0F);

                for (int i = 0; i < 2; i++) {
                    this.collideWithEntities(this.leftLeg, this.level().getEntities(this, this.leftLeg.getBoundingBox().inflate(48.0, 48.0, 48.0)));
                    this.collideWithEntities(this.rightLeg, this.level().getEntities(this, this.rightLeg.getBoundingBox().inflate(48.0, 48.0, 48.0)));
                }
            }

            if (this.getAnimationTick() >= 360) {
                this.isStunned = false;
            } else {
                this.setTarget(null);
                this.isStunned = true;
            }
        }

        if (this.getAnimationID() == 9) {
            if (this.getAnimationTick() == 26) {
                this.playSound((SoundEvent)TheTitansSounds.TITAN_SWING.get(), 10.0F, 1.0F);
            }

            if (this.getAnimationTick() == 28 && this.getTarget() != null) {
                float amountx = (float)this.getAttributeBaseValue(Attributes.ATTACK_DAMAGE);
                int knockbackAmountx = this.getKnockbackAmount();
                this.collideWithEntities(this.head, this.level().getEntities(this, this.head.getBoundingBox().inflate(4.0, 2.0, 4.0)));
                this.attackEntity(this.getTarget(), amountx);
                this.knockbackEntity(this.getTarget(), (float)knockbackAmountx);

                for (Entity entityxxxxxx : this.level().getEntities(this.getTarget(), this.getTarget().getBoundingBox().inflate(8.0, 8.0, 8.0))) {
                    if (entityxxxxxx != null && entityxxxxxx != this && entityxxxxxx instanceof LivingEntity livingEntity) {
                        this.attackEntity(livingEntity, amountx);
                        this.knockbackEntity(livingEntity, (float)knockbackAmountx);
                    }
                }
            }
        }

        if (this.getAnimationID() == 10) {
            if (this.getAnimationTick() == 30 || this.getAnimationTick() == 70) {
                this.playStepSound(new BlockPos(0, 0, 0), Blocks.STONE.defaultBlockState());
            }

            if (this.getAnimationTick() == 150 || this.getAnimationTick() == 230) {
                this.shakeNearbyPlayerCameras(10000.0);
                this.playSound((SoundEvent)TheTitansSounds.TITAN_FALL.get(), 20.0F, 1.0F);
                this.playSound((SoundEvent)TheTitansSounds.GROUND_SMASH.get(), 20.0F, 1.0F);

                for (int i = 0; i < 4; i++) {
                    this.collideWithEntities(this.leftLeg, this.level().getEntities(this, this.leftLeg.getBoundingBox().inflate(48.0, 48.0, 48.0)));
                    this.collideWithEntities(this.rightLeg, this.level().getEntities(this, this.rightLeg.getBoundingBox().inflate(48.0, 48.0, 48.0)));
                }
            }

            if (this.getAnimationTick() == 240) {
                this.playSound((SoundEvent)TheTitansSounds.DISTANT_LARGE_FALL.get(), 10000.0F, 1.0F);
            }
        }

        if (this.getAnimationID() == 11) {
            if (this.getAnimationTick() == 10) {
                this.playSound((SoundEvent)TheTitansSounds.LIGHTNING_CHARGE.get(), 100.0F, 1.0F);
            }

            if (this.getAnimationTick() == 50 && this.getTarget() != null) {
                this.playSound((SoundEvent)TheTitansSounds.LIGHTNING_THROW.get(), 100.0F, 1.0F);
                double d8xx = 24.0;
                Vec3 vec3xx = this.getViewVector(1.0F);
                double dxxx = vec3xx.x * d8xx;
                double dzxx = vec3xx.z * d8xx;
                if (!this.level().isClientSide()) {
                    this.level()
                        .explode(this, this.getTarget().getX(), this.getTarget().getY(), this.getTarget().getZ(), 2.0F, false, ExplosionInteraction.MOB);
                    this.level()
                        .explode(this, this.getX() + dxxx, this.getY() + 24.0, this.getZ() + dzxx, 1.0F, false, ExplosionInteraction.MOB);
                }

                for (int i = 0; i < 5; i++) {
                    EntityColorLightningBolt colorLightningBoltx = new EntityColorLightningBolt(this.level(), 1.0F, 0.0F, 1.0F);
                    colorLightningBoltx.setPos(this.getX() + dxxx, this.getY() + 24.0, this.getZ() + dzxx);
                    if (!this.level().isClientSide()) {
                        this.level().addFreshEntity(colorLightningBoltx);
                    }
                }

                this.getTarget().hurt(this.damageSources().lightningBolt(), 100.0F);
            }
        }

        if (this.getAnimationID() == 13 && this.getAnimationTick() == 50 && this.getTarget() != null) {
            float amountx = (float)this.getAttributeBaseValue(Attributes.ATTACK_DAMAGE);
            int knockbackAmountx = this.getKnockbackAmount();
            if (!this.level().isClientSide()) {
                this.level()
                    .explode(this, this.getTarget().getX(), this.getTarget().getY(), this.getTarget().getZ(), 2.0F, false, ExplosionInteraction.MOB);
            }

            EntityColorLightningBolt colorLightningBolt1x = new EntityColorLightningBolt(this.level(), 1.0F, 0.0F, 1.0F);
            colorLightningBolt1x.setPos(this.getTarget().getX(), this.getTarget().getY(), this.getTarget().getZ());
            if (!this.level().isClientSide()) {
                this.level().addFreshEntity(colorLightningBolt1x);
            }

            this.attackEntity(this.getTarget(), amountx);
            this.knockbackEntity(this.getTarget(), (float)knockbackAmountx);

            for (Entity entityxxxxxxx : this.level().getEntities(this.getTarget(), this.getTarget().getBoundingBox().inflate(12.0, 12.0, 12.0))) {
                if (entityxxxxxxx != null && entityxxxxxxx != this && entityxxxxxxx instanceof LivingEntity && this.canAttackEntity(entityxxxxxxx)) {
                    LivingEntity livingEntity = (LivingEntity)entityxxxxxxx;

                    for (int ix = 0; ix < 4; ix++) {
                        EntityColorLightningBolt colorLightningBolt2x = new EntityColorLightningBolt(this.level(), 1.0F, 0.0F, 1.0F);
                        colorLightningBolt2x.setPos(livingEntity.getX(), livingEntity.getY(), livingEntity.getZ());
                        if (!this.level().isClientSide()) {
                            this.level().addFreshEntity(colorLightningBolt2x);
                        }
                    }

                    this.attackEntity(livingEntity, amountx);
                    livingEntity.push(0.0, 1.0 + this.random.nextDouble(), 0.0);
                }
            }
        }
    }

    @Override
    public void tick() {
        super.tick();
        this.refreshDimensions();
        if (this.getCanCallBackUp() && this.getTarget() != null && this.getTarget() instanceof EntityWitherzilla) {
            this.setCanCallBackUp(false);
        }

        this.setEyeLaserTime(this.getEyeLaserTime() - 1);
        if (this.destroyedCrystals < 0) {
            this.destroyedCrystals = 0;
        }

        if (this.destroyedCrystals > 12) {
            this.destroyedCrystals = 0;
            if (this.isAlive()) {
                this.isStunned = true;
            }
        }

        if (this.numOfCrystals < 0) {
            this.numOfCrystals = 0;
        }

        if (this.isAlive()) {
            if (this.tickCount % 120 == 0) {
                this.playSound((SoundEvent)TheTitansSounds.TITAN_ENDER_COLOSUS_LIVING.get(), this.getSoundVolume(), this.getVoicePitch());
            }

            this.roarcooldownTimer++;
        }

        if (this.roarcooldownTimer == 0) {
            this.setScreaming(true);
            if (!this.level().isClientSide()) {
                ServerLevel level = (ServerLevel)this.level();
                if (level.dimensionType().hasSkyLight() && level.isDay()) {
                    level.setDayTime(level.getDayTime() + 14000L);
                }
            }
        }

        if (this.roarcooldownTimer >= 60 || !this.isAlive()) {
            this.roarcooldownTimer = -(400 - this.random.nextInt(200));
            this.setScreaming(false);
        }

        float fl = this.getLightLevelDependentMagicValue();
        if (fl > 0.5F && !this.level().isClientSide() && this.level().dimensionType().hasSkyLight() && this.level().isDay() && this.tickCount % 1 == 0) {
            this.setXRot(this.yHeadRot / 6.0F);
            this.yHeadRot = -90.0F;
        }

        if (this.getAnimationID() == 0 && !this.isPassenger() && !this.getWaiting() && !this.isStunned) {
            if (this.getTarget() != null && this.distanceToSqr(this.getTarget()) > this.getMeleeRange() + (!this.getTarget().onGround() ? 1000.0 : 8000.0)) {
                if (this.getY() <= this.getTarget().getY() + 12.0 && this.getY() < 256.0 - (double)this.getBbHeight()) {
                    this.fallDistance = 0.0F;
                    this.setTitanDeltaMovement(this.getDeltaMovement().x, this.getDeltaMovement().y + 0.9 - this.getDeltaMovement().y, this.getDeltaMovement().z);
                    if (this.getDeltaMovement().y < 0.0) {
                        this.setTitanDeltaMovement(this.getDeltaMovement().x, 0.0, this.getDeltaMovement().z);
                    }
                }

                this.setTitanDeltaMovement(this.getDeltaMovement().x, this.getDeltaMovement().y * 0.6, this.getDeltaMovement().z);
            }

            if (!this.onGround()) {
                float f3 = (this.random.nextFloat() - 0.5F) * 16.0F;
                float f4 = (this.random.nextFloat() - 0.5F) * 5.0F;
                float f5 = (this.random.nextFloat() - 0.5F) * 16.0F;
                this.level()
                    .addParticle(
                        ParticleTypes.EXPLOSION, this.getX() + (double)f3, this.getY() + 15.0 + (double)f4, this.getZ() + (double)f5, 0.0, 0.0, 0.0
                    );
            }
        }

        if (this.tickCount > 5) {
            float f = this.yBodyRot * (float) Math.PI / 180.0F;
            float f1 = Mth.sin(f);
            float f2 = Mth.cos(f);
            this.head.moveTo(this.getX(), this.getY() + 60.0, this.getZ());
            this.body.moveTo(this.getX(), this.getY() + 42.0, this.getZ());
            this.leftEye
                .moveTo(
                    this.getX()
                        - (double)(Mth.cos(this.yHeadRot * (float) Math.PI / 180.0F) * 4.0F)
                        - (double)(Mth.sin(this.yHeadRot * (float) Math.PI / 180.0F) * 7.0F),
                    this.getY() + (double)this.getEyeHeight() - 1.0,
                    this.getZ()
                        - (double)(Mth.sin(this.yHeadRot * (float) Math.PI / 180.0F) * 4.0F)
                        + (double)(Mth.cos(this.yHeadRot * (float) Math.PI / 180.0F) * 8.0F)
                );
            this.rightEye
                .moveTo(
                    this.getX()
                        + (double)(Mth.cos(this.yHeadRot * (float) Math.PI / 180.0F) * 4.0F)
                        - (double)(Mth.sin(this.yHeadRot * (float) Math.PI / 180.0F) * 7.0F),
                    this.getY() + (double)this.getEyeHeight() - 1.0,
                    this.getZ()
                        + (double)(Mth.sin(this.yHeadRot * (float) Math.PI / 180.0F) * 4.0F)
                        + (double)(Mth.cos(this.yHeadRot * (float) Math.PI / 180.0F) * 8.0F)
                );
            this.leftArm.moveTo(this.getX() - (double)(f2 * 8.0F), this.getY() + 56.0, this.getZ() - (double)(f1 * 8.0F));
            this.rightArm.moveTo(this.getX() + (double)(f2 * 8.0F), this.getY() + 56.0, this.getZ() + (double)(f1 * 8.0F));
            this.leftLeg.moveTo(this.getX() - (double)(f2 * 3.0F), this.getY(), this.getZ() - (double)(f1 * 3.0F));
            this.rightLeg.moveTo(this.getX() + (double)(f2 * 3.0F), this.getY(), this.getZ() + (double)(f1 * 3.0F));

            for (EntityTitanPart part : this.parts) {
                if (this.isAlive() && !this.isStunned) {
                    this.collideWithEntities(part, this.level().getEntities(this, part.getBoundingBox().inflate(1.0, 0.0, 1.0)));
                }

                this.destroyBlocksInAABB(part.getBoundingBox());
            }
        }

        if (this.getAnimationID() == 0 && this.getTarget() != null && !this.isStunned) {
            if (this.getEyeLaserTime() < 0) {
                double d0 = this.distanceToSqr(this.getTarget());
                if (d0 < this.getMeleeRange()) {
                    if (!(this.getTarget() instanceof EntityTitan)
                        && !(this.getTarget().getBbHeight() >= 6.0F)
                        && !(this.getTarget().getY() > this.getY() + 6.0)) {
                        switch (this.random.nextInt(3)) {
                            case 0:
                                AnimationUtils.sendPacket(this, 6);
                                break;
                            case 1:
                                AnimationUtils.sendPacket(this, 7);
                                break;
                            case 2:
                                AnimationUtils.sendPacket(this, 9);
                        }
                    } else {
                        AnimationUtils.sendPacket(this, 1);
                    }
                } else if (this.random.nextInt(80) == 0) {
                    switch (this.random.nextInt(6)) {
                        case 0:
                            AnimationUtils.sendPacket(this, 4);
                            break;
                        case 1:
                            if (this.random.nextInt(25) == 0) {
                                AnimationUtils.sendPacket(this, 5);
                            } else {
                                AnimationUtils.sendPacket(this, 2);
                            }
                            break;
                        case 2:
                            AnimationUtils.sendPacket(this, 3);
                            break;
                        case 3:
                            AnimationUtils.sendPacket(this, 11);
                            break;
                        case 4:
                            AnimationUtils.sendPacket(this, 13);
                            break;
                        case 5:
                            AnimationUtils.sendPacket(this, 2);
                    }
                }
            }

            if (!this.getWaiting() && this.getEyeLaserTime() <= -400 && this.random.nextInt(40) == 0) {
                this.setEyeLaserTime(200);
            }
        }

        if (this.isStunned) {
            this.setTarget(null);
            AnimationUtils.sendPacket(this, 8);
        }

        if (this.isInWaterOrRain() && !this.isInWater() && this.getAnimationID() != 13 && this.getAnimationID() != 10) {
            AnimationUtils.sendPacket(this, 5);
        }

        for (int i = 0; i < this.getParticleCount() * 5; i++) {
            if (!this.isStunned) {
                this.findPlayerToLookAt();
            }

            this.level()
                .addParticle(
                    this.getParticles(),
                    this.getX() + (this.random.nextDouble() - 0.5) * (double)this.getBbWidth() * 3.0,
                    this.getY() + this.random.nextDouble() * (double)this.getBbHeight(),
                    this.getZ() + (this.random.nextDouble() - 0.5) * (double)this.getBbWidth() * 3.0,
                    0.0,
                    0.25,
                    0.0
                );
        }

        this.animationTick();
    }
}
