package net.titans.data;

import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.world.level.saveddata.SavedData;

public class SavedDataSpawnedPos extends SavedData {
    private List<BlockPos> spawnedPos = new CopyOnWriteArrayList<>();

    public List<BlockPos> getSpawnedPos() {
        return this.spawnedPos;
    }

    public static SavedDataSpawnedPos load(CompoundTag tag) {
        SavedDataSpawnedPos savedData = new SavedDataSpawnedPos();
        if (tag.contains("TitanSpawnedPos", 9)) {
            ListTag tagList = tag.getList("TitanSpawnedPos", 10);

            for (int i = 0; i < tagList.size(); i++) {
                CompoundTag compoundTag = tagList.getCompound(i);
                int x = compoundTag.getInt("x");
                int y = compoundTag.getInt("y");
                int z = compoundTag.getInt("z");
                savedData.getSpawnedPos().add(new BlockPos(x, y, z));
            }
        }

        return savedData;
    }

    public CompoundTag save(CompoundTag tag) {
        ListTag tagList = new ListTag();

        for (int i = 0; i < this.getSpawnedPos().size(); i++) {
            BlockPos blockPos = this.getSpawnedPos().get(i);
            CompoundTag compoundTag = new CompoundTag();
            compoundTag.putInt("x", blockPos.getX());
            compoundTag.putInt("y", blockPos.getY());
            compoundTag.putInt("z", blockPos.getZ());
            tagList.add(compoundTag);
        }

        if (!tagList.isEmpty()) {
            tag.put("TitanSpawnedPos", tagList);
        }

        return tag;
    }
}
