package net.titans.item;

import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item.Properties;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.item.enchantment.Enchantments;
import net.minecraft.world.level.Level;
import net.titans.entity.EntityWitherTurret;

public class ItemWitherTurret extends Item {
    public ItemWitherTurret(Properties properties) {
        super(properties.stacksTo(1));
    }

    public boolean isEnchantable(ItemStack stack) {
        return true;
    }

    public int getEnchantmentValue() {
        return 50;
    }

    public EntityWitherTurret getEntity(Level level) {
        return new EntityWitherTurret(level);
    }

    public InteractionResult useOn(UseOnContext context) {
        Level level = context.getLevel();
        Player player = context.getPlayer();
        ItemStack itemStack = context.getItemInHand();
        BlockPos blockPos = context.getClickedPos();
        EntityWitherTurret entity = this.getEntity(level);
        entity.setPos((double)blockPos.getX() + 0.5, (double)blockPos.getY() + 1.0, (double)blockPos.getZ() + 0.5);
        entity.setPlayerCreated(true);
        int a = 0;
        if (a > 0) {
            entity.durabilityLevel = a;
        }

        int b = 0;
        if (b > 0) {
            entity.ferocityLevel = b;
        }

        int c = 0;
        if (c > 0) {
            entity.maniacLevel = c;
        }

        int d = 0;
        if (d > 0) {
            entity.unstabilityLevel = d;
        }

        int e = 0;
        if (e > 0) {
            entity.shurakinLevel = e;
        }

        int f = EnchantmentHelper.getItemEnchantmentLevel(Enchantments.UNBREAKING, itemStack);
        if (f > 0) {
            entity.unbreakingLevel = f;
        }

        int g = 0;
        if (g > 0) {
            entity.titanKillerLevel = g;
        }

        for (int i = 0; i < 500; i++) {
            level.addParticle(
                ParticleTypes.SMOKE,
                entity.getX() + (entity.level().random.nextDouble() - 0.5) * (double)entity.getBbWidth() * 3.0,
                entity.getY() + entity.level().random.nextDouble() * ((double)entity.getBbHeight() + 1.0),
                entity.getZ() + (entity.level().random.nextDouble() - 0.5) * (double)entity.getBbWidth() * 3.0,
                0.0,
                0.0,
                0.0
            );
        }

        if (!level.isClientSide()) {
            level.addFreshEntity(entity);
        }

        if (!player.isCreative()) {
            itemStack.shrink(1);
        }

        return InteractionResult.SUCCESS;
    }
}
