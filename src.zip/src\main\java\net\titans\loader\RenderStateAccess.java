package net.titans.loader;

import net.minecraft.client.renderer.RenderStateShard;

/**
 * 辅助类：RenderStateShard 的 protected 静态字段无法从外部包直接访问，
 * 通过继承拿到访问权，再以 public 方法暴露出去。
 */
public final class RenderStateAccess extends RenderStateShard {

    private RenderStateAccess() {
        super("titans_access", () -> {}, () -> {});
    }

    public static ShaderStateShard positionColorShader() {
        return POSITION_COLOR_SHADER;
    }

    public static TransparencyStateShard lightningTransparency() {
        return LIGHTNING_TRANSPARENCY;
    }

    public static CullStateShard noCull() {
        return NO_CULL;
    }

    public static WriteMaskStateShard colorWrite() {
        return COLOR_WRITE;
    }
}