package net.titans.entity.ai.irongolemtitan;

import net.titans.animation.AIAnimation;
import net.titans.entity.titan.EntityIronGolemTitan;

public class AnimationIronGolemTitanAttack4 extends AIAnimation {
    private EntityIronGolemTitan entity;

    public AnimationIronGolemTitanAttack4(EntityIronGolemTitan entity) {
        super(entity);
        this.entity = entity;
    }

    @Override
    public int getAnimationID() {
        return 9;
    }

    @Override
    public boolean isAutomatic() {
        return true;
    }

    @Override
    public int getDuration() {
        return 90;
    }

    @Override
    public boolean canContinueToUse() {
        return this.entity.getAnimationTick() > this.getDuration() ? false : super.canContinueToUse();
    }

    public void tick() {
        if (this.entity.getTarget() != null && this.entity.getAnimationTick() < 40) {
            this.entity.getLookControl().setLookAt(this.entity.getTarget(), 5.0F, 40.0F);
        }
    }
}
