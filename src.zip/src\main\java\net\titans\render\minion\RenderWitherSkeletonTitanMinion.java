package net.titans.render.minion;

import net.minecraft.client.renderer.entity.WitherSkeletonRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider.Context;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.monster.AbstractSkeleton;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.titans.entity.minion.IMinion;

@OnlyIn(Dist.CLIENT)
public class RenderWitherSkeletonTitanMinion extends WitherSkeletonRenderer {
    public static final ResourceLocation WITHER_SKELETON = new ResourceLocation("minecraft", "textures/entity/skeleton/wither_skeleton.png");
    public static final ResourceLocation WITHER_SKELETON_PRIEST = ResourceLocation.tryBuild(
        "titan", "textures/entity/minions/skeleton/wither_skeleton_priest.png"
    );
    public static final ResourceLocation WITHER_SKELETON_ZEALOT = ResourceLocation.tryBuild(
        "titan", "textures/entity/minions/skeleton/wither_skeleton_zealot.png"
    );
    public static final ResourceLocation WITHER_SKELETON_BISHOP = ResourceLocation.tryBuild(
        "titan", "textures/entity/minions/skeleton/wither_skeleton_bishop.png"
    );
    public static final ResourceLocation WITHER_SKELETON_TEMPLAR = ResourceLocation.tryBuild(
        "titan", "textures/entity/minions/skeleton/wither_skeleton_templar.png"
    );

    public RenderWitherSkeletonTitanMinion(Context context) {
        super(context);
    }

    public ResourceLocation getTextureLocation(AbstractSkeleton entity) {
        if (entity instanceof IMinion minion) {
            switch (minion.getMinionType()) {
                case PRIEST:
                    return WITHER_SKELETON_PRIEST;
                case ZEALOT:
                    return WITHER_SKELETON_ZEALOT;
                case BISHOP:
                    return WITHER_SKELETON_BISHOP;
                case TEMPLAR:
                    return WITHER_SKELETON_TEMPLAR;
                default:
                    return WITHER_SKELETON;
            }
        } else {
            return super.getTextureLocation(entity);
        }
    }
}
