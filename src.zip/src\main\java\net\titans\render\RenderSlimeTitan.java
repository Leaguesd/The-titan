package net.titans.render;

import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.LivingEntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider.Context;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.titans.entity.titan.EntitySlimeTitan;
import net.titans.model.ModelSlimeTitan;
import net.titans.render.layer.LayerSlimeTitanOuter;

@OnlyIn(Dist.CLIENT)
public class RenderSlimeTitan extends LivingEntityRenderer<EntitySlimeTitan, ModelSlimeTitan> {
    public static final ResourceLocation SLIME_TITAN = new ResourceLocation("minecraft", "textures/entity/slime/slime.png");

    public RenderSlimeTitan(Context context) {
        super(context, new ModelSlimeTitan(16), 0.25F);
        this.addLayer(new LayerSlimeTitanOuter(this));
    }

    public void render(EntitySlimeTitan entity, float entityYaw, float partialTicks, PoseStack poseStack, MultiBufferSource multiBufferSource, int packedLight) {
        this.shadowRadius = 0.25F * (float)entity.getSlimeSize();
        super.render(entity, entityYaw, partialTicks, poseStack, multiBufferSource, packedLight);
    }

    protected void scale(EntitySlimeTitan entity, PoseStack poseStack, float partialTick) {
        float f1 = (float)entity.getSlimeSize();
        float f2 = Mth.lerp(partialTick, entity.prevSquishFactor, entity.squishFactor) / (f1 * 0.5F + 1.0F);
        float f3 = 1.0F / (f2 + 1.0F);
        poseStack.scale(f3 * f1, 1.0F / f3 * f1, f3 * f1);
        float fl = 16.0F;
        int i = entity.getInvulTime();
        if (i > 0) {
            fl -= ((float)i - partialTick) / 10.0F;
        }

        poseStack.scale(fl, fl, fl);
        poseStack.translate(0.0F, 0.0075F, 0.0F);
    }

    protected void setupRotations(EntitySlimeTitan entity, PoseStack poseStack, float bob, float yBodyRot, float partialTicks) {
        super.setupRotations(entity, poseStack, bob, yBodyRot, partialTicks);
        if (entity.deathTicks > 0) {
            float f = ((float)entity.deathTicks + partialTicks - 1.0F) / 20.0F * 1.6F;
            f = (float)Math.sqrt((double)f);
            if (f > 1.0F) {
                f = 1.0F;
            }

            poseStack.scale(1.0F + f * 2.0F, 1.0F - f * 0.99F, 1.0F + f * 2.0F);
        }
    }

    protected float getShadowRadius(EntitySlimeTitan entity) {
        return this.shadowRadius * entity.getBbWidth();
    }

    protected boolean shouldShowName(EntitySlimeTitan entity) {
        return false;
    }

    public ResourceLocation getTextureLocation(EntitySlimeTitan entity) {
        return SLIME_TITAN;
    }
}
