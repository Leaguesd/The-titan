package net.titans.damage;

import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.titans.entity.titan.EntityEnderColossus;
import net.titans.loader.TheTitansDamageTypes;

public class DamageSourceTitanAttack extends DamageSource {
    public DamageSourceTitanAttack(Entity attacker) {
        super(attacker.level().registryAccess().registryOrThrow(Registries.DAMAGE_TYPE).getHolderOrThrow(TheTitansDamageTypes.TITAN_ATTACK), attacker);
    }

    public Component getLocalizedDeathMessage(LivingEntity entity) {
        Entity attacker = this.getEntity();
        if (entity.level().getRandom().nextInt(2) == 1) {
            return Component.translatable("death.attack.mob", new Object[]{entity.getDisplayName(), attacker.getDisplayName()});
        } else {
            return (Component)(attacker instanceof EntityEnderColossus && entity.level().getRandom().nextInt(2) == 1
                ? Component.translatable("death.attack.mindcrush", new Object[]{entity.getDisplayName(), attacker.getDisplayName()})
                : super.getLocalizedDeathMessage(entity));
        }
    }
}
