package net.titans.entity.ai.creepertitan;

import java.util.EnumSet;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.goal.Goal.Flag;
import net.titans.entity.titan.EntityCreeperTitan;

public class EntityAICreeperTitanSwell extends Goal {
    private EntityCreeperTitan entity;
    private LivingEntity target;

    public EntityAICreeperTitanSwell(EntityCreeperTitan entity) {
        this.entity = entity;
        this.setFlags(EnumSet.of(Flag.MOVE));
    }

    public boolean canUse() {
        LivingEntity entity = this.entity.getTarget();
        return this.entity.getCreeperState() > 0 || entity != null && this.entity.distanceToSqr(entity) < 1.0;
    }

    public void start() {
        this.entity.getNavigation().stop();
        this.target = this.entity.getTarget();
    }

    public void stop() {
        this.target = null;
    }

    public boolean requiresUpdateEveryTick() {
        return true;
    }

    public void tick() {
        if (this.target == null) {
            this.entity.setCreeperState(-1);
        } else if (this.entity.distanceToSqr(this.target) > 1.0) {
            this.entity.setCreeperState(-1);
        } else if (!this.entity.getSensing().hasLineOfSight(this.target)) {
            this.entity.setCreeperState(-1);
        } else {
            this.entity.setCreeperState(1);
        }
    }
}
