package net.titans.entity.ai.skeletontitan;

import net.titans.animation.AIAnimation;
import net.titans.entity.titan.EntitySkeletonTitan;

public class AnimationSkeletonTitanLightningSword extends AIAnimation {
    private EntitySkeletonTitan entity;

    public AnimationSkeletonTitanLightningSword(EntitySkeletonTitan entity) {
        super(entity);
        this.entity = entity;
    }

    @Override
    public int getAnimationID() {
        return 9;
    }

    @Override
    public boolean isAutomatic() {
        return true;
    }

    @Override
    public int getDuration() {
        return 80;
    }

    @Override
    public boolean canContinueToUse() {
        return this.entity.getAnimationTick() <= this.getDuration() && !this.entity.isStunned ? super.canContinueToUse() : false;
    }

    public void tick() {
        if (this.entity.getTarget() != null) {
            this.entity.getLookControl().setLookAt(this.entity.getTarget(), 5.0F, 40.0F);
        }
    }
}
