package net.titans.render.layer;

import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.titans.entity.titan.EntitySkeletonTitan;
import net.titans.model.ModelSkeletonTitan;

@OnlyIn(Dist.CLIENT)
public class LayerSkeletonTitanItemInHand extends RenderLayer<EntitySkeletonTitan, ModelSkeletonTitan> {
    public LayerSkeletonTitanItemInHand(RenderLayerParent<EntitySkeletonTitan, ModelSkeletonTitan> renderer) {
        super(renderer);
    }

    public void render(
        PoseStack poseStack,
        MultiBufferSource multiBufferSource,
        int packedLight,
        EntitySkeletonTitan entity,
        float limbSwing,
        float limbSwingAmount,
        float partialTicks,
        float ageInTicks,
        float netHeadYaw,
        float headPitch
    ) {
        // 武器都是直接画在实体贴图里的，位置天然正确：
        //  - 普通骨骼泰坦：heldItem 是 texOffs(32,-16) 的 0×16×16 平面，
        //    侧面 UV (32,0)-(48,16) 画着弓；拉弓三个阶段和断弓各有一张贴图
        //    （skeleton_titan_pulling_0/1/2、skeleton_titan_broken_bow），
        //    由 RenderSkeletonTitan#getTextureLocation 按 attackTimer 切换，
        //    所以拉弓动作照常显示；
        //  - 凋灵骷髅变种：heldItem2 是 texOffs(32,17) 的平面，
        //    侧面 UV (32,33)-(48,49) 画着石剑。
        //
        // 原实现是隐藏平面后自己烘焙四边形（bakeItem 在原始 jar 里是空实现），
        // 而且四边形的摆位与模型平面不一致，会出现"武器跑到手外面"的问题。
        ModelSkeletonTitan model = (ModelSkeletonTitan)this.getParentModel();
        boolean wither = entity.getSkeletonType() == 1;
        model.heldItem.visible = !wither;
        model.heldItem2.visible = wither;
    }
}
