package net.titans.mixin;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.commands.data.EntityDataAccessor;
import net.titans.entity.titan.EntityTitan;
import net.titans.util.DataAccessorHelper;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({EntityDataAccessor.class})
public class MixinEntityDataAccessor {
    @Inject(
        method = {"setData"},
        at = {@At("HEAD")},
        cancellable = true
    )
    public void setData(CompoundTag tag, CallbackInfo callbackInfo) {
        if (DataAccessorHelper.getEntity((EntityDataAccessor)(Object)this) instanceof EntityTitan) {
            callbackInfo.cancel();
        }
    }
}
