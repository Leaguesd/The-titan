package net.titans.render;

import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.model.SnowGolemModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.LivingEntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider.Context;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.titans.entity.titan.EntitySnowGolemTitan;
import net.titans.render.layer.LayerSnowGolemTitanHead;

@OnlyIn(Dist.CLIENT)
public class RenderSnowGolemTitan extends LivingEntityRenderer<EntitySnowGolemTitan, SnowGolemModel<EntitySnowGolemTitan>> {
    private static final ResourceLocation SNOW_GOLEM_TTIAN = new ResourceLocation("minecraft", "textures/entity/snow_golem.png");

    public RenderSnowGolemTitan(Context context) {
        super(context, new SnowGolemModel(context.bakeLayer(ModelLayers.SNOW_GOLEM)), 0.5F);
        this.addLayer(new LayerSnowGolemTitanHead(this, context.getBlockRenderDispatcher()));
    }

    public void render(
        EntitySnowGolemTitan entity, float entityYaw, float partialTicks, PoseStack poseStack, MultiBufferSource multiBufferSource, int packedLight
    ) {
        super.render(entity, entityYaw, partialTicks, poseStack, multiBufferSource, packedLight);
    }

    protected void scale(EntitySnowGolemTitan entity, PoseStack poseStack, float partialTick) {
        float f1 = 16.0F;
        int i = entity.getInvulTime();
        if (i > 0) {
            f1 -= ((float)i - partialTick) / 10.0F;
        }

        poseStack.scale(f1, f1, f1);
        poseStack.translate(0.0F, 0.0275F, 0.0F);
    }

    protected void setupRotations(EntitySnowGolemTitan entity, PoseStack poseStack, float bob, float yBodyRot, float partialTicks) {
        super.setupRotations(entity, poseStack, bob, yBodyRot, partialTicks);
        if (entity.deathTicks > 0) {
            float f = ((float)entity.deathTicks + partialTicks - 1.0F) / 20.0F * 1.6F;
            f = (float)Math.sqrt((double)f);
            if (f > 1.0F) {
                f = 1.0F;
            }

            poseStack.scale(1.0F + f * 1.05F, 1.0F - f * 0.5F, 1.0F + f * 1.05F);
        }
    }

    protected float getShadowRadius(EntitySnowGolemTitan entity) {
        return this.shadowRadius * entity.getBbWidth();
    }

    protected boolean shouldShowName(EntitySnowGolemTitan entity) {
        return false;
    }

    public ResourceLocation getTextureLocation(EntitySnowGolemTitan pEntity) {
        return SNOW_GOLEM_TTIAN;
    }
}
