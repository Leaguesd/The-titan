package net.titans.entity.titan;

import net.minecraft.world.damagesource.DamageSource;

public interface IEntityMultiPartTitan {
    boolean attackEntityFromPart(EntityTitanPart var1, DamageSource var2, float var3);
}
