package net.titans.loader;

import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.damagesource.DamageType;

public class TheTitansDamageTypes {
    public static final ResourceKey<DamageType> TITAN_ATTACK = ResourceKey.create(
        Registries.DAMAGE_TYPE, ResourceLocation.tryBuild("titan", "titan_attack")
    );
    public static final ResourceKey<DamageType> TITAN_SPIRIT_ATTACK = ResourceKey.create(
        Registries.DAMAGE_TYPE, ResourceLocation.tryBuild("titan", "titan_spirit_attack")
    );
    public static final ResourceKey<DamageType> RADIATION = ResourceKey.create(Registries.DAMAGE_TYPE, ResourceLocation.tryBuild("titan", "radiation"));
    public static final ResourceKey<DamageType> ADVANCED_WITHER = ResourceKey.create(
        Registries.DAMAGE_TYPE, ResourceLocation.tryBuild("titan", "advanced_wither")
    );
}
