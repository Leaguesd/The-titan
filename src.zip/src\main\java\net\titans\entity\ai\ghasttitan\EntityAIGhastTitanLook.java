package net.titans.entity.ai.ghasttitan;

import java.util.EnumSet;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.goal.Goal.Flag;
import net.minecraft.world.phys.Vec3;
import net.titans.entity.titan.EntityGhastTitan;

public class EntityAIGhastTitanLook extends Goal {
    private EntityGhastTitan entity;

    public EntityAIGhastTitanLook(EntityGhastTitan entity) {
        this.entity = entity;
        this.setFlags(EnumSet.of(Flag.LOOK));
    }

    public boolean canUse() {
        return this.entity.getTarget() == null;
    }

    public boolean requiresUpdateEveryTick() {
        return true;
    }

    public void tick() {
        Vec3 vec3 = this.entity.getDeltaMovement();
        float f1 = -((float)Mth.atan2(vec3.x, vec3.z) * (float) Math.PI / 180.0F);
        this.entity.setXRot(this.entity.rotlerp(this.entity.getXRot(), 0.0F, 180.0F));
        this.entity.setYRot(this.entity.rotlerp(this.entity.getYRot(), f1, 180.0F));
        this.entity.yBodyRot = this.entity.getYRot();
    }
}
