package net.titans.entity.ai.zombifiedpiglintitan;

import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.state.BlockState;
import net.titans.animation.AIAnimation;
import net.titans.entity.titan.EntityZombifiedPiglinTitan;

public class AnimationZombifiedPiglinTitanAttack3 extends AIAnimation {
    private EntityZombifiedPiglinTitan entity;

    public AnimationZombifiedPiglinTitanAttack3(EntityZombifiedPiglinTitan entity) {
        super(entity);
        this.entity = entity;
    }

    @Override
    public int getAnimationID() {
        return 7;
    }

    @Override
    public boolean isAutomatic() {
        return true;
    }

    @Override
    public int getDuration() {
        return 230;
    }

    @Override
    public boolean canContinueToUse() {
        BlockPos blockPos = this.entity.blockPosition().below();
        BlockState blockState = this.entity.level().getBlockState(blockPos);
        float explosionResistance = blockState.getBlock().getExplosionResistance();
        return this.entity.getAnimationTick() <= this.getDuration() && !this.entity.isStunned && !(explosionResistance <= 1.5F) ? super.canContinueToUse() : false;
    }
}
