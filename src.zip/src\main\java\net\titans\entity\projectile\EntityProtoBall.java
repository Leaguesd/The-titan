package net.titans.entity.projectile;

import java.lang.reflect.Constructor;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.contents.TranslatableContents;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.world.Difficulty;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.projectile.ThrowableProjectile;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.ServerLevelAccessor;
import net.minecraft.world.level.Level.ExplosionInteraction;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;
import net.titans.util.EntityUtils;
import net.titans.entity.minion.IMinion;
import net.titans.entity.titan.EntityTitan;
import net.titans.loader.TheTitansEntities;
import net.titans.loader.TheTitansMinions;
import net.titans.loader.TheTitansSounds;

public class EntityProtoBall extends ThrowableProjectile {
    public EntityProtoBall(EntityType<? extends EntityProtoBall> entityType, Level level) {
        super(entityType, level);
    }

    public EntityProtoBall(Level level) {
        super((EntityType)TheTitansEntities.PROTO_BALL.get(), level);
    }

    public void summomMinions(EntityTitan titan, int minionNumber, int priestNumber, int zealotNumber, int bishopNumber) {
        if (titan.getName().getContents() instanceof TranslatableContents translatableContents) {
            if (TheTitansMinions.SPECIAL_MINIONS.containsKey(translatableContents.getKey()) && this.random.nextInt(5) == 0) {
                try {
                    Class<? extends Entity> clazz = TheTitansMinions.SPECIAL_MINIONS.get(translatableContents.getKey());
                    Constructor<? extends Entity> constructor = clazz.getDeclaredConstructor(Level.class);
                    Entity entity = constructor.newInstance(this.level());
                    if (entity instanceof Mob && entity instanceof IMinion) {
                        Mob mob = (Mob)entity;
                        IMinion minion = (IMinion)entity;
                        mob.setPos(this.getX(), this.getY(), this.getZ());
                        mob.setXRot(-this.getXRot());
                        mob.setYRot(-this.getYRot());
                        mob.finalizeSpawn((ServerLevelAccessor)this.level(), this.level().getCurrentDifficultyAt(entity.blockPosition()), MobSpawnType.SPAWNER, null, null);
                        minion.setMaster(titan);
                        minion.setMinionType(0);
                        titan.finalizeMinionSummon(mob, minion.getMinionType());
                        mob.setHealth(mob.getMaxHealth());
                        mob.push(0.0, 1.0, 0.0);
                        EntityUtils.addMinion(this.level(), mob);
                        this.level().explode(mob, mob.getX(), mob.getY() + 6.0, mob.getZ(), 12.0F, false, ExplosionInteraction.MOB);
                    }
                } catch (Exception var14) {
                    var14.printStackTrace();
                }
            } else if (TheTitansMinions.MINIONS.containsKey(translatableContents.getKey())) {
                try {
                    Class<? extends Entity> clazz = TheTitansMinions.MINIONS.get(translatableContents.getKey());
                    int randomInt = this.random.nextInt(4);
                    if (randomInt == 0) {
                        for (int i = 0; i <= minionNumber; i++) {
                            Constructor<? extends Entity> constructor = clazz.getDeclaredConstructor(Level.class);
                            Entity entity = constructor.newInstance(this.level());
                            if (entity instanceof Mob && entity instanceof IMinion) {
                                Mob mob = (Mob)entity;
                                IMinion minion = (IMinion)entity;
                                mob.setPos(this.getX(), this.getY(), this.getZ());
                                mob.setXRot(-this.getXRot());
                                mob.setYRot(-this.getYRot());
                                mob.finalizeSpawn((ServerLevelAccessor)this.level(), this.level().getCurrentDifficultyAt(entity.blockPosition()), MobSpawnType.SPAWNER, null, null);
                                minion.setMaster(titan);
                                minion.setMinionType(0);
                                titan.finalizeMinionSummon(mob, minion.getMinionType());
                                mob.setHealth(mob.getMaxHealth());
                                EntityUtils.addMinion(this.level(), mob);
                                this.level().explode(mob, mob.getX(), mob.getY() + 6.0, mob.getZ(), 2.0F, false, ExplosionInteraction.MOB);
                            }
                        }
                    } else if (randomInt == 1) {
                        for (int ix = 0; ix <= priestNumber; ix++) {
                            Constructor<? extends Entity> constructor = clazz.getDeclaredConstructor(Level.class);
                            Entity entity = constructor.newInstance(this.level());
                            if (entity instanceof Mob && entity instanceof IMinion) {
                                Mob mob = (Mob)entity;
                                IMinion minion = (IMinion)entity;
                                mob.setPos(this.getX(), this.getY(), this.getZ());
                                mob.setXRot(-this.getXRot());
                                mob.setYRot(-this.getYRot());
                                mob.finalizeSpawn((ServerLevelAccessor)this.level(), this.level().getCurrentDifficultyAt(entity.blockPosition()), MobSpawnType.SPAWNER, null, null);
                                minion.setMaster(titan);
                                minion.setMinionType(1);
                                titan.finalizeMinionSummon(mob, minion.getMinionType());
                                mob.setHealth(mob.getMaxHealth());
                                EntityUtils.addMinion(this.level(), mob);
                                this.level().explode(mob, mob.getX(), mob.getY() + 6.0, mob.getZ(), 2.0F, false, ExplosionInteraction.MOB);
                            }
                        }
                    } else if (randomInt == 2) {
                        for (int ixx = 0; ixx <= zealotNumber; ixx++) {
                            Constructor<? extends Entity> constructor = clazz.getDeclaredConstructor(Level.class);
                            Entity entity = constructor.newInstance(this.level());
                            if (entity instanceof Mob && entity instanceof IMinion) {
                                Mob mob = (Mob)entity;
                                IMinion minion = (IMinion)entity;
                                mob.setPos(this.getX(), this.getY(), this.getZ());
                                mob.setXRot(-this.getXRot());
                                mob.setYRot(-this.getYRot());
                                mob.finalizeSpawn((ServerLevelAccessor)this.level(), this.level().getCurrentDifficultyAt(entity.blockPosition()), MobSpawnType.SPAWNER, null, null);
                                minion.setMaster(titan);
                                minion.setMinionType(2);
                                titan.finalizeMinionSummon(mob, minion.getMinionType());
                                mob.setHealth(mob.getMaxHealth());
                                EntityUtils.addMinion(this.level(), mob);
                                this.level().explode(mob, mob.getX(), mob.getY() + 6.0, mob.getZ(), 2.0F, false, ExplosionInteraction.MOB);
                            }
                        }
                    } else if (randomInt == 3) {
                        for (int ixxx = 0; ixxx <= bishopNumber; ixxx++) {
                            Constructor<? extends Entity> constructor = clazz.getDeclaredConstructor(Level.class);
                            Entity entity = constructor.newInstance(this.level());
                            if (entity instanceof Mob && entity instanceof IMinion) {
                                Mob mob = (Mob)entity;
                                IMinion minion = (IMinion)entity;
                                mob.setPos(this.getX(), this.getY(), this.getZ());
                                mob.setXRot(-this.getXRot());
                                mob.setYRot(-this.getYRot());
                                mob.finalizeSpawn((ServerLevelAccessor)this.level(), this.level().getCurrentDifficultyAt(entity.blockPosition()), MobSpawnType.SPAWNER, null, null);
                                minion.setMaster(titan);
                                minion.setMinionType(3);
                                titan.finalizeMinionSummon(mob, minion.getMinionType());
                                mob.setHealth(mob.getMaxHealth());
                                EntityUtils.addMinion(this.level(), mob);
                                this.level().explode(mob, mob.getX(), mob.getY() + 6.0, mob.getZ(), 2.0F, false, ExplosionInteraction.MOB);
                            }
                        }
                    }
                } catch (Exception var15) {
                    var15.printStackTrace();
                }
            }
        }
    }

    protected void defineSynchedData() {
    }

    protected boolean canHitEntity(Entity entity) {
        return this.getOwner() != null && entity == this.getOwner() ? false : super.canHitEntity(entity);
    }

    protected void onHitEntity(EntityHitResult result) {
        Entity entity = result.getEntity();
        if (entity instanceof LivingEntity && this.getOwner() instanceof EntityTitan) {
            LivingEntity livingEntity = (LivingEntity)entity;
            EntityTitan titan = (EntityTitan)this.getOwner();
            titan.playSound((SoundEvent)TheTitansSounds.TITAN_PUNCH.get(), 10.0F, 1.0F);
            float amount = 75.0F;
            int knockbackAmount = 1;
            titan.attackEntity(livingEntity, amount);
            titan.knockbackEntity(livingEntity, (float)knockbackAmount);
            if (!this.level().isClientSide()) {
                this.discard();
            }
        }

        super.onHitEntity(result);
    }

    protected void onHitBlock(BlockHitResult result) {
        if (!this.level().isClientSide()) {
            if (this.level().getDifficulty() != Difficulty.PEACEFUL && this.getOwner() instanceof EntityTitan) {
                EntityTitan titan = (EntityTitan)this.getOwner();
                this.summomMinions(
                    titan,
                    40,
                    20,
                    10,
                    5
                );
            }

            this.discard();
        }
    }

    public void tick() {
        super.tick();

        for (int i = 0; i < 15; i++) {
            float f = (this.random.nextFloat() - 0.5F) * this.getBbWidth();
            float f1 = (this.random.nextFloat() - 0.5F) * this.getBbHeight();
            float f2 = (this.random.nextFloat() - 0.5F) * this.getBbWidth();
            this.level()
                .addParticle(ParticleTypes.EXPLOSION, this.getX() + (double)f, this.getY() + (double)f1, this.getZ() + (double)f2, 0.0, 0.0, 0.0);
            this.level()
                .addParticle(ParticleTypes.POOF, this.getX() + (double)f, this.getY() + (double)f1, this.getZ() + (double)f2, 0.0, 0.0, 0.0);
            this.level()
                .addParticle(ParticleTypes.SMOKE, this.getX() + (double)f, this.getY() + (double)f1, this.getZ() + (double)f2, 0.0, 0.0, 0.0);
            this.level()
                .addParticle(ParticleTypes.LAVA, this.getX() + (double)f, this.getY() + (double)f1, this.getZ() + (double)f2, 0.0, 0.0, 0.0);
        }
    }
}
