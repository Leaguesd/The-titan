package net.titans.entity.ai.minion;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.goal.Goal;
import net.titans.entity.minion.IMinion;

public class EntityAIRandomDoHurtTarget extends Goal {
    private IMinion entity;

    public EntityAIRandomDoHurtTarget(IMinion entity) {
        this.entity = entity;
    }

    public boolean canUse() {
        Mob mob = (Mob)this.entity;
        return mob.getTarget() != null;
    }

    public void tick() {
        Mob mob = (Mob)this.entity;
        LivingEntity target = mob.getTarget();
        if (target != null
            && mob.level().getRandom().nextInt(5) == 1
            && mob.distanceToSqr(target) < (double)(mob.getBbWidth() * mob.getBbWidth() + target.getBbWidth() * target.getBbWidth()) + 16.0
            && (mob.level().getRandom().nextInt(3) == 0 || mob.level().getRandom().nextInt(2) == 1)) {
            mob.doHurtTarget(target);
        }
    }
}
