package net.titans.render;

import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.LivingEntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider.Context;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.titans.entity.titan.EntityZombifiedPiglinTitan;
import net.titans.model.ModelZombifiedPiglinTitan;
import net.titans.render.layer.LayerZombifiedPiglinTitanArmor;
import net.titans.render.layer.LayerZombifiedPiglinTitanItemInHand;

@OnlyIn(Dist.CLIENT)
public class RenderZombifiedPiglinTitan extends LivingEntityRenderer<EntityZombifiedPiglinTitan, ModelZombifiedPiglinTitan> {
    public static final ResourceLocation ZOMBIFIED_PIGLIN_TITAN = ResourceLocation.tryBuild("titan", "textures/entity/titans/zombified_piglin_titan.png");

    public RenderZombifiedPiglinTitan(Context context) {
        super(context, new ModelZombifiedPiglinTitan(0.0F), 0.5F);
        this.addLayer(new LayerZombifiedPiglinTitanItemInHand(this));
        this.addLayer(new LayerZombifiedPiglinTitanArmor(this));
    }

    public void render(
        EntityZombifiedPiglinTitan entity, float entityYaw, float partialTicks, PoseStack poseStack, MultiBufferSource multiBufferSource, int packedLight
    ) {
        super.render(entity, entityYaw, partialTicks, poseStack, multiBufferSource, packedLight);
    }

    protected void scale(EntityZombifiedPiglinTitan entity, PoseStack poseStack, float partialTick) {
        float f1 = 16.0F;
        int i = entity.getInvulTime();
        if (i > 0) {
            f1 -= ((float)i - partialTick) / 440.0F * 7.75F;
        }

        int i2 = entity.getExtraPower();
        if (i2 > 0) {
            f1 += (float)i2 * 0.5F;
        }

        poseStack.scale(f1, f1, f1);
        poseStack.translate(0.0F, 0.01F, 0.0F);
    }

    protected float getShadowRadius(EntityZombifiedPiglinTitan entity) {
        return this.shadowRadius * entity.getBbWidth();
    }

    protected boolean shouldShowName(EntityZombifiedPiglinTitan entity) {
        return false;
    }

    public ResourceLocation getTextureLocation(EntityZombifiedPiglinTitan entity) {
        return ZOMBIFIED_PIGLIN_TITAN;
    }
}
