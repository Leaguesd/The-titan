package net.titans.entity.minion;

import java.util.List;
import java.util.Optional;
import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.Mth;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity.RemovalReason;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier.Builder;
import net.minecraft.world.entity.boss.enderdragon.EnderDragon;
import net.minecraft.world.entity.boss.enderdragon.phases.EnderDragonPhase;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.dimension.end.EndDragonFight;
import net.minecraft.world.level.dimension.end.EndDragonFight.Data;
import net.minecraft.world.level.levelgen.Heightmap.Types;
import net.titans.entity.ai.EntityAINearestTargetTitan;
import net.titans.entity.titan.EntityEnderColossus;
import net.titans.entity.titan.EntityTitan;
import net.titans.loader.TheTitansEntities;
import net.titans.loader.TheTitansPredicateTargets;

public class EntityDragonMinion extends EnderDragon implements IMinion {
    private static final EntityDataAccessor<Integer> MINION_TYPE = SynchedEntityData.defineId(EntityDragonMinion.class, EntityDataSerializers.INT);
    public EntityTitan master;

    public EntityDragonMinion(EntityType<? extends EntityDragonMinion> entityType, Level level) {
        super(entityType, level);
        this.setHealth(this.getMaxHealth());
        this.getPhaseManager().setPhase(EnderDragonPhase.getById(0));
    }

    public EntityDragonMinion(Level level) {
        this((EntityType<? extends EntityDragonMinion>)TheTitansEntities.DRAGON_MINION.get(), level);
    }

    public static Builder createAttributes() {
        return EnderDragon.createAttributes().add(Attributes.MAX_HEALTH, 4000.0);
    }

    protected void registerGoals() {
        super.registerGoals();
        this.targetSelector
            .addGoal(0, new EntityAINearestTargetTitan<LivingEntity>(this, LivingEntity.class, 0, false, false, TheTitansPredicateTargets.EnderColossus));
    }

    @Override
    public int getMinionTypeInt() {
        return (Integer)this.getEntityData().get(MINION_TYPE);
    }

    @Override
    public void setMinionType(int minionType) {
        this.getEntityData().set(MINION_TYPE, minionType);
        this.refreshAttributes();
    }

    @Override
    public EntityTitan getMaster() {
        return this.master;
    }

    @Override
    public void setMaster(EntityTitan master) {
        this.master = master;
    }

    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(MINION_TYPE, 0);
    }

    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        this.setMinionType(tag.getInt("MinionType"));
    }

    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putInt("MinionType", this.getMinionTypeInt());
    }

    @Override
    public EnumMinionType getMinionType() {
        return EnumMinionType.SPECIAL;
    }

    public boolean canAttack(LivingEntity target) {
        return this.getMaster() != null ? this.getMaster().canAttack(target) : target.canBeSeenByAnyone() && this.canAttackEntity(target);
    }

    public boolean canAttackType(EntityType<?> entityType) {
        return entityType != TheTitansEntities.ENDER_COLOSSUS.get()
            && entityType != TheTitansEntities.ENDER_COLOSSUS_MINION.get()
            && entityType != TheTitansEntities.DRAGON_MINION.get();
    }

    public boolean fireImmune() {
        return true;
    }

    protected SoundEvent getAmbientSound() {
        return SoundEvents.ENDER_DRAGON_AMBIENT;
    }

    protected SoundEvent getHurtSound(DamageSource damageSource) {
        return SoundEvents.ENDER_DRAGON_HURT;
    }

    protected SoundEvent getDeathSound() {
        return SoundEvents.ENDER_DRAGON_DEATH;
    }

    public void remove(RemovalReason reason) {
        super.remove(reason);
        if (this.getMaster() != null) {
            this.getMaster().retractMinionNumFromType(this.getMinionType());
        }
    }

    public void setTarget(@Nullable LivingEntity target) {
        if (target != this) {
            if (this.getMaster() != null) {
                if (!this.getMaster().canAttackEntity(target, true)) {
                    return;
                }
            } else if (!this.canAttackEntity(target, true)) {
                return;
            }

            super.setTarget(target);
        }
    }

    public boolean hurt(DamageSource damageSource, float amount) {
        Entity entity = damageSource.getEntity();
        if (this.isInvulnerable()) {
            return false;
        } else if (!(entity instanceof EntityZombieTitanMinion)
            && !(entity instanceof EntityEnderColossus)
            && !(entity instanceof EnderDragon)
            && !(entity instanceof EntityDragonMinion)) {
            if (entity instanceof LivingEntity livingEntity && this.canAttack(livingEntity)) {
                for (Entity minionEntity : this.level().getEntities(this, this.getBoundingBox().inflate(256.0, 256.0, 256.0))) {
                    if (minionEntity instanceof EntityDragonMinion dragonMinion) {
                        dragonMinion.setTarget(livingEntity);
                    }

                    this.setTarget(livingEntity);
                }
            }

            return super.hurt(damageSource, amount);
        } else {
            return false;
        }
    }

    public void hurt(List<Entity> entities) {
        for (Entity entity : entities) {
            if (entity instanceof LivingEntity) {
                this.flapTime++;
                this.playAmbientSound();
                DamageSource damageSource = this.damageSources().mobAttack(this);
                entity.hurt(damageSource, 200.0F);
                entity.invulnerableTime = 0;
                if (this.level() instanceof ServerLevel var5) {
                    ;
                }
            }
        }
    }

    public void aiStep() {
        super.aiStep();
        if (this.getMaster() != null) {
            if (this.getMaster().getTarget() != null) {
                this.setTarget(this.getMaster().getTarget());
            } else if (this.distanceToSqr(this.getMaster()) > 10000.0) {
                this.getPhaseManager().setPhase(EnderDragonPhase.TAKEOFF);
            }
        } else {
            List<EntityTitan> entities = this.level().getEntitiesOfClass(EntityTitan.class, this.getBoundingBox().inflate(256.0, 256.0, 256.0));
            if (!entities.isEmpty()) {
                for (EntityTitan entity : entities) {
                    if (entity != null && entity instanceof EntityEnderColossus) {
                        this.setMaster(entity);
                    }
                }
            }
        }
    }

    protected void tickDeath() {
        if (!this.level().isClientSide()) {
            ServerLevel serverLevel = (ServerLevel)this.level();
            int x = Mth.floor(this.getX());
            int z = Mth.floor(this.getZ());
            int y = serverLevel.getHeight(Types.WORLD_SURFACE, x, z);
            BlockPos blockPos = new BlockPos(x, y, z);
            this.setDragonFight(
                new EndDragonFight(
                    serverLevel,
                    serverLevel.getServer().getWorldData().worldGenOptions().seed(),
                    new Data(true, false, false, false, Optional.of(this.getUUID()), Optional.of(blockPos), Optional.empty()),
                    blockPos
                )
            );
        }

        super.tickDeath();
    }
}
