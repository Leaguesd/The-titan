package net.titans.loader;

import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.dimension.DimensionType;

public class TheTitansDimensionTypes {
    public static final ResourceKey<DimensionType> THE_VOID = ResourceKey.create(Registries.DIMENSION_TYPE, ResourceLocation.tryBuild("titan", "the_void"));
    public static final ResourceKey<DimensionType> THE_NOWHERE = ResourceKey.create(
        Registries.DIMENSION_TYPE, ResourceLocation.tryBuild("titan", "the_nowhere")
    );
}
