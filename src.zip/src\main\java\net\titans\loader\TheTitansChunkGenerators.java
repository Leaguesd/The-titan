package net.titans.loader;

import com.mojang.serialization.Codec;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.level.chunk.ChunkGenerator;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.RegistryObject;
import net.titans.gen.ChunkGeneratorNowhere;
import net.titans.gen.ChunkGeneratorVoid;

public class TheTitansChunkGenerators {
    public static final DeferredRegister<Codec<? extends ChunkGenerator>> CHUNK_GENERATORS = DeferredRegister.create(Registries.CHUNK_GENERATOR, "titan");
    public static final RegistryObject<Codec<ChunkGeneratorVoid>> THE_VOID = CHUNK_GENERATORS.register("the_void", () -> ChunkGeneratorVoid.CODEC.codec());
    public static final RegistryObject<Codec<ChunkGeneratorNowhere>> THE_NOWHERE = CHUNK_GENERATORS.register(
        "the_nowhere", () -> ChunkGeneratorNowhere.CODEC.codec()
    );

    public static void registerChunkGenerators(IEventBus modEventBus) {
        CHUNK_GENERATORS.register(modEventBus);
    }
}
