package net.titans.render;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.LivingEntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider.Context;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.titans.entity.titan.EntityEnderColossus;
import net.titans.model.ModelEnderColossus;
import net.titans.render.layer.LayerEnderColossusEyes;
import net.titans.render.layer.LayerEnderColossusEyesLaser;

@OnlyIn(Dist.CLIENT)
public class RenderEnderColossus extends LivingEntityRenderer<EntityEnderColossus, ModelEnderColossus> {
    public static final ResourceLocation ENDER_COLOSSUS = ResourceLocation.tryBuild("titan", "textures/entity/titans/ender_colossus.png");
    public static final ResourceLocation ENDER_COLOSSUS_DEAD = ResourceLocation.tryBuild("titan", "textures/entity/titans/ender_colossus_dead.png");
    public static final ResourceLocation ENDER_COLOSSUS_EYES = ResourceLocation.tryBuild("titan", "textures/entity/titans/ender_colossus_eyes.png");
    public static final ResourceLocation ENDER_COLOSSUS_EYES_DEAD = ResourceLocation.tryBuild(
        "titan", "textures/entity/titans/ender_colossus_eyes_dead.png"
    );
    public static final ResourceLocation ENDER_COLOSSUS_EYES_BEAM = ResourceLocation.tryBuild("titan", "textures/entity/titans/ender_colossus_beam.png");

    public RenderEnderColossus(Context context) {
        super(context, new ModelEnderColossus(), 0.5F);
        this.addLayer(new LayerEnderColossusEyes(this));
        this.addLayer(new LayerEnderColossusEyesLaser(this));
    }

    public void render(
        EntityEnderColossus entity, float entityYaw, float partialTicks, PoseStack poseStack, MultiBufferSource multiBufferSource, int packedLight
    ) {
        ((ModelEnderColossus)this.model).isAttacking = entity.isScreaming();
        super.render(entity, entityYaw, partialTicks, poseStack, multiBufferSource, packedLight);
    }

    protected void scale(EntityEnderColossus entity, PoseStack poseStack, float partialTick) {
        float f1 = 24.0F;
        int i = entity.getInvulTime();
        if (i > 0) {
            f1 -= ((float)i - partialTick) / 440.0F * 7.75F;
        }

        int i2 = entity.getExtraPower();
        if (i2 > 0) {
            f1 += (float)i2 * 0.5F;
        }

        poseStack.scale(f1, f1, f1);
        poseStack.translate(0.0F, 0.015F, 0.0F);
        if (entity.isPassenger()) {
            poseStack.translate(0.0F, 0.1F, 0.0F);
            poseStack.mulPose(Axis.YP.rotationDegrees(180.0F));
        }
    }

    protected float getShadowRadius(EntityEnderColossus entity) {
        return this.shadowRadius * entity.getBbWidth();
    }

    protected boolean shouldShowName(EntityEnderColossus entity) {
        return false;
    }

    public ResourceLocation getTextureLocation(EntityEnderColossus entity) {
        return entity.getAnimationID() == 10 && entity.deathTicks > 200 ? ENDER_COLOSSUS_DEAD : ENDER_COLOSSUS;
    }
}
