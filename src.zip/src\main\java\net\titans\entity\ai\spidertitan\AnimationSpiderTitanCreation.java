package net.titans.entity.ai.spidertitan;

import net.titans.animation.AIAnimation;
import net.titans.entity.titan.EntitySpiderTitan;

public class AnimationSpiderTitanCreation extends AIAnimation {
    private EntitySpiderTitan entity;

    public AnimationSpiderTitanCreation(EntitySpiderTitan entity) {
        super(entity);
        this.entity = entity;
    }

    @Override
    public int getAnimationID() {
        return 13;
    }

    @Override
    public boolean isAutomatic() {
        return true;
    }

    @Override
    public int getDuration() {
        return 260;
    }

    @Override
    public boolean canContinueToUse() {
        return this.entity.getAnimationTick() > this.getDuration() ? false : super.canContinueToUse();
    }
}
