package net.titans.entity.projectile;

import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.ItemSupplier;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.Level.ExplosionInteraction;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;
import net.titans.entity.titan.EntityTitan;
import net.titans.loader.TheTitansEntities;

public class EntityFireballTitan extends EntityTitanProjectile implements ItemSupplier {
    public EntityFireballTitan(EntityType<? extends EntityFireballTitan> entityType, Level level) {
        super(entityType, level);
    }

    public EntityFireballTitan(Level level, LivingEntity shooter) {
        this((EntityType<? extends EntityFireballTitan>)TheTitansEntities.FIREBALL_TITAN.get(), level);
        this.setOwner(shooter);
    }

    public ItemStack getItem() {
        return new ItemStack(Items.FIRE_CHARGE);
    }

    protected boolean shouldBurn() {
        return true;
    }

    protected boolean canHitEntity(Entity entity) {
        return this.getOwner() != null && entity == this.getOwner() ? false : super.canHitEntity(entity);
    }

    public boolean hurt(DamageSource damageSource, float amount) {
        return false;
    }

    protected void onHitEntity(EntityHitResult result) {
        Entity entity = result.getEntity();
        if (entity instanceof LivingEntity && this.getOwner() instanceof EntityTitan) {
            LivingEntity LivingEntity = (LivingEntity)entity;
            EntityTitan titan = (EntityTitan)this.getOwner();
            float amount = 2000.0F;
            titan.attackEntity(LivingEntity, amount);
            if (!this.level().isClientSide()) {
                this.discard();
            }
        }

        super.onHitEntity(result);
    }

    protected void onHitBlock(BlockHitResult result) {
        if (!this.level().isClientSide()) {
            this.level()
                .explode(
                    (Entity)(this.getOwner() != null ? this.getOwner() : this),
                    this.getX(),
                    this.getY(),
                    this.getZ(),
                    3.0F,
                    true,
                    ExplosionInteraction.MOB
                );
            this.discard();
        }
    }

    public void tick() {
        super.tick();

        for (Entity entity : this.level().getEntities(this, this.getBoundingBox())) {
            if (this.canHitEntity(entity)) {
                this.onHitEntity(new EntityHitResult(entity));
            }
        }
    }
}
