package net.titans.trigger;

import com.google.gson.JsonObject;
import net.minecraft.advancements.critereon.AbstractCriterionTriggerInstance;
import net.minecraft.advancements.critereon.ContextAwarePredicate;
import net.minecraft.advancements.critereon.DeserializationContext;
import net.minecraft.advancements.critereon.SimpleCriterionTrigger;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;

public class TriggerRoot extends SimpleCriterionTrigger<TriggerRoot.Instance> {
    private static final ResourceLocation ID = new ResourceLocation("titan", "root");

    public ResourceLocation getId() {
        return ID;
    }

    protected TriggerRoot.Instance createInstance(JsonObject jsonObject, ContextAwarePredicate player, DeserializationContext context) {
        return new TriggerRoot.Instance(player);
    }

    public void trigger(ServerPlayer player) {
        this.trigger(player, instance -> true);
    }

    public static class Instance extends AbstractCriterionTriggerInstance {
        public Instance(ContextAwarePredicate player) {
            super(TriggerRoot.ID, player);
        }
    }
}
