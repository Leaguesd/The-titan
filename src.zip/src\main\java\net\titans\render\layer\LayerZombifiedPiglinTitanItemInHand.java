package net.titans.render.layer;

import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.titans.entity.titan.EntityZombifiedPiglinTitan;
import net.titans.model.ModelZombifiedPiglinTitan;

@OnlyIn(Dist.CLIENT)
public class LayerZombifiedPiglinTitanItemInHand extends RenderLayer<EntityZombifiedPiglinTitan, ModelZombifiedPiglinTitan> {
    public LayerZombifiedPiglinTitanItemInHand(RenderLayerParent<EntityZombifiedPiglinTitan, ModelZombifiedPiglinTitan> renderer) {
        super(renderer);
    }

    public void render(
        PoseStack poseStack,
        MultiBufferSource multiBufferSource,
        int packedLight,
        EntityZombifiedPiglinTitan entity,
        float limbSwing,
        float limbSwingAmount,
        float partialTicks,
        float ageInTicks,
        float netHeadYaw,
        float headPitch
    ) {
        // 金剑是直接画在实体贴图里的：heldItem 是 texOffs(32,32) 的 0×16×16 平面，
        // 它侧面 UV (32,48)-(48,64) 那 16×16 格子里画的就是金剑，
        // 与 item/gold_sword_256.png 像素完全一致（已比对）。
        //
        // 原实现是隐藏该平面后自己烘焙四边形，但 bakeItem 在原始 jar 里是空实现；
        // 而且四边形是在手臂坐标系里另外摆位的，位置对不上，所以这里直接用模型平面。
        ((ModelZombifiedPiglinTitan)this.getParentModel()).heldItem.visible = true;
    }
}
