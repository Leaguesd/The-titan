package net.titans.loader;

import java.util.HashMap;
import java.util.Map;
import net.minecraft.world.entity.Entity;
import net.titans.entity.minion.EntityBlazeTitanMinion;
import net.titans.entity.minion.EntityCaveSpiderTitanMinion;
import net.titans.entity.minion.EntityCreeperTitanMinion;
import net.titans.entity.minion.EntityDragonMinion;
import net.titans.entity.minion.EntityEnderColossusMinion;
import net.titans.entity.minion.EntityGhastGuardMinion;
import net.titans.entity.minion.EntityGhastTitanMinion;
import net.titans.entity.minion.EntityOmegafishMinion;
import net.titans.entity.minion.EntitySkeletonTitanMinion;
import net.titans.entity.minion.EntitySpiderTitanMinion;
import net.titans.entity.minion.EntityWitherMinion;
import net.titans.entity.minion.EntityWitherSkeletonTitanMinion;
import net.titans.entity.minion.EntityWitherzillaMinion;
import net.titans.entity.minion.EntityZombieTitanGiantMinion;
import net.titans.entity.minion.EntityZombieTitanMinion;
import net.titans.entity.minion.EntityZombifiedPiglinTitanMinion;

public class TheTitansMinions {
    public static final Map<String, Class<? extends Entity>> MINIONS = new HashMap<>();
    public static final Map<String, Class<? extends Entity>> SPECIAL_MINIONS = new HashMap<>();

    public static void registerMinions() {
        MINIONS.put("entity.titan.omegafish", EntityOmegafishMinion.class);
        MINIONS.put("entity.titan.zombie_titan", EntityZombieTitanMinion.class);
        MINIONS.put("entity.titan.zombie_baby_titan", EntityZombieTitanMinion.class);
        MINIONS.put("entity.titan.zombie_villager_titan", EntityZombieTitanMinion.class);
        MINIONS.put("entity.titan.zombie_villager_baby_titan", EntityZombieTitanMinion.class);
        MINIONS.put("entity.titan.skeleton_titan", EntitySkeletonTitanMinion.class);
        MINIONS.put("entity.titan.wither_skeleton_titan", EntityWitherSkeletonTitanMinion.class);
        MINIONS.put("entity.titan.creeper_titan", EntityCreeperTitanMinion.class);
        MINIONS.put("entity.titan.charged_creeper_titan", EntityCreeperTitanMinion.class);
        MINIONS.put("entity.titan.spider_titan", EntitySpiderTitanMinion.class);
        MINIONS.put("entity.titan.cave_spider_titan", EntityCaveSpiderTitanMinion.class);
        MINIONS.put("entity.titan.zombified_piglin_titan", EntityZombifiedPiglinTitanMinion.class);
        MINIONS.put("entity.titan.zombified_piglin_baby_titan", EntityZombifiedPiglinTitanMinion.class);
        MINIONS.put("entity.titan.blaze_titan", EntityBlazeTitanMinion.class);
        MINIONS.put("entity.titan.ender_colossus", EntityEnderColossusMinion.class);
        MINIONS.put("entity.titan.ghast_titan", EntityGhastTitanMinion.class);
        MINIONS.put("entity.titan.witherzilla", EntityWitherzillaMinion.class);
        SPECIAL_MINIONS.put("entity.titan.zombie_titan", EntityZombieTitanGiantMinion.class);
        SPECIAL_MINIONS.put("entity.titan.zombie_baby_titan", EntityZombieTitanGiantMinion.class);
        SPECIAL_MINIONS.put("entity.titan.zombie_villager_titan", EntityZombieTitanGiantMinion.class);
        SPECIAL_MINIONS.put("entity.titan.zombie_villager_baby_titan", EntityZombieTitanGiantMinion.class);
        SPECIAL_MINIONS.put("entity.titan.zombified_piglin_titan", EntityGhastGuardMinion.class);
        SPECIAL_MINIONS.put("entity.titan.zombified_piglin_baby_titan", EntityGhastGuardMinion.class);
        SPECIAL_MINIONS.put("entity.titan.wither_skeleton_titan", EntityWitherMinion.class);
        SPECIAL_MINIONS.put("entity.titan.ender_colossus", EntityDragonMinion.class);
    }
}
