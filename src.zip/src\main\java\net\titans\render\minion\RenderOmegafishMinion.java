package net.titans.render.minion;

import net.minecraft.client.renderer.entity.SilverfishRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider.Context;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.monster.Silverfish;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.titans.entity.minion.IMinion;

@OnlyIn(Dist.CLIENT)
public class RenderOmegafishMinion extends SilverfishRenderer {
    public static final ResourceLocation SILVERFISH = new ResourceLocation("minecraft", "textures/entity/silverfish.png");
    public static final ResourceLocation SILVERFISH_PRIEST = ResourceLocation.tryBuild("titan", "textures/entity/minions/silverfish/silverfish_priest.png");
    public static final ResourceLocation SILVERFISH_ZEALOT = ResourceLocation.tryBuild("titan", "textures/entity/minions/silverfish/silverfish_zealot.png");
    public static final ResourceLocation SILVERFISH_BISHOP = ResourceLocation.tryBuild("titan", "textures/entity/minions/silverfish/silverfish_bishop.png");
    public static final ResourceLocation SILVERFISH_TEMPLAR = ResourceLocation.tryBuild(
        "titan", "textures/entity/minions/silverfish/silverfish_templar.png"
    );

    public RenderOmegafishMinion(Context context) {
        super(context);
    }

    public ResourceLocation getTextureLocation(Silverfish entity) {
        if (entity instanceof IMinion minion) {
            switch (minion.getMinionType()) {
                case PRIEST:
                    return SILVERFISH_PRIEST;
                case ZEALOT:
                    return SILVERFISH_ZEALOT;
                case BISHOP:
                    return SILVERFISH_BISHOP;
                case TEMPLAR:
                    return SILVERFISH_TEMPLAR;
                default:
                    return SILVERFISH;
            }
        } else {
            return super.getTextureLocation(entity);
        }
    }
}
