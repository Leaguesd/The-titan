package net.titans.entity.ai.minion.ghast;

import net.minecraft.util.Mth;
import net.minecraft.world.entity.ai.control.MoveControl;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.titans.entity.minion.EntityGhastTitanMinion;
import net.titans.entity.minion.EnumMinionType;

public class EntityAIGhastTitanMinionMoveControl extends MoveControl {
    private EntityGhastTitanMinion entity;
    private int floatDuration;

    public EntityAIGhastTitanMinionMoveControl(EntityGhastTitanMinion entity) {
        super(entity);
        this.entity = entity;
    }

    public void tick() {
        if (this.operation == Operation.MOVE_TO && this.floatDuration-- <= 0) {
            this.floatDuration = this.floatDuration + this.entity.level().random.nextInt(5) + 2;
            Vec3 vec3 = new Vec3(this.wantedX - this.entity.getX(), this.wantedY - this.entity.getY(), this.wantedZ - this.entity.getZ());
            double d0 = vec3.length();
            vec3 = vec3.normalize();
            if (this.canReach(vec3, Mth.ceil(d0))) {
                double scale = this.entity.getMinionType() == EnumMinionType.ZEALOT ? 0.8 : 0.2;
                if (this.entity.master != null && this.entity.distanceToSqr(this.entity.master) > 4096.0) {
                    scale = this.entity.getMinionType() == EnumMinionType.ZEALOT ? 0.8 : 0.2;
                } else {
                    scale = this.entity.getMinionType() == EnumMinionType.ZEALOT ? 0.4 : 0.1;
                }

                this.entity.setDeltaMovement(this.entity.getDeltaMovement().add(vec3.scale(scale)));
            } else {
                this.operation = Operation.WAIT;
            }
        }
    }

    private boolean canReach(Vec3 pos, int length) {
        AABB aabb = this.entity.getBoundingBox();

        for (int i = 1; i < length; i++) {
            aabb = aabb.move(pos);
            if (!this.entity.level().noCollision(this.entity, aabb)) {
                return false;
            }
        }

        return true;
    }
}
