package net.titans.entity.minion;

import java.util.List;
import javax.annotation.Nullable;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.Mth;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity.RemovalReason;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier.Builder;
import net.minecraft.world.entity.monster.Ghast;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.titans.entity.ai.EntityAINearestTargetTitan;
import net.titans.entity.ai.minion.ghast.EntityAIGhastGuardMinionShoot;
import net.titans.entity.titan.EntityTitan;
import net.titans.entity.titan.EntityZombifiedPiglinTitan;
import net.titans.loader.TheTitansEntities;
import net.titans.loader.TheTitansPredicateTargets;

public class EntityGhastGuardMinion extends Ghast implements IMinion {
    private static final EntityDataAccessor<Integer> MINION_TYPE = SynchedEntityData.defineId(EntityGhastGuardMinion.class, EntityDataSerializers.INT);
    public EntityTitan master;

    public EntityGhastGuardMinion(EntityType<? extends EntityGhastGuardMinion> entityType, Level level) {
        super(entityType, level);
        this.xpReward = 20;
        this.setPersistenceRequired();
    }

    public EntityGhastGuardMinion(Level level) {
        this((EntityType<? extends EntityGhastGuardMinion>)TheTitansEntities.GHAST_GUARD_MINION.get(), level);
    }

    public static Builder createAttributes() {
        return Ghast.createAttributes()
            .add(Attributes.MAX_HEALTH, 40.0)
            .add(Attributes.FOLLOW_RANGE, 100.0)
            .add(Attributes.MOVEMENT_SPEED, 1.0)
            .add(Attributes.KNOCKBACK_RESISTANCE, 1.0);
    }

    protected void registerGoals() {
        super.registerGoals();
        this.goalSelector.addGoal(7, new EntityAIGhastGuardMinionShoot(this));
        this.targetSelector
            .addGoal(
                0, new EntityAINearestTargetTitan<LivingEntity>(this, LivingEntity.class, 0, false, false, TheTitansPredicateTargets.ZombifiedPiglinTitan)
            );
    }

    @Override
    public int getMinionTypeInt() {
        return (Integer)this.getEntityData().get(MINION_TYPE);
    }

    @Override
    public void setMinionType(int minionType) {
        this.getEntityData().set(MINION_TYPE, minionType);
        this.refreshAttributes();
    }

    @Override
    public EntityTitan getMaster() {
        return this.master;
    }

    @Override
    public void setMaster(EntityTitan master) {
        this.master = master;
    }

    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(MINION_TYPE, 0);
    }

    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        this.setMinionType(tag.getInt("MinionType"));
    }

    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putInt("MinionType", this.getMinionTypeInt());
    }

    public float rotlerp(float angle, float targetAngle, float maxIncrease) {
        float f = Mth.wrapDegrees(targetAngle - angle);
        if (f > maxIncrease) {
            f = maxIncrease;
        }

        if (f < -maxIncrease) {
            f = -maxIncrease;
        }

        return angle + f;
    }

    protected void dropRareDrop(int count) {
    }

    protected void dropFewItems(boolean attackedRecently, int loottingLevel) {
        int j = this.random.nextInt(2) + this.random.nextInt(1 + loottingLevel);

        for (int k = 0; k < j; k++) {
            this.spawnAtLocation(Items.GHAST_TEAR, 1);
        }

        j = this.random.nextInt(3) + this.random.nextInt(1 + loottingLevel);

        for (int var6 = 0; var6 < j; var6++) {
            this.spawnAtLocation(Items.GUNPOWDER, 1);
        }
    }

    @Override
    public EnumMinionType getMinionType() {
        return EnumMinionType.SPECIAL;
    }

    public boolean canAttack(LivingEntity target) {
        return this.getMaster() != null ? this.getMaster().canAttack(target) : target.canBeSeenByAnyone() && this.canAttackEntity(target);
    }

    public boolean canAttackType(EntityType<?> entityType) {
        return entityType != TheTitansEntities.ZOMBIFIED_PIGLIN_TITAN.get()
            && entityType != TheTitansEntities.ZOMBIFIED_PIGLIN_TITAN_MINION.get()
            && entityType != TheTitansEntities.GHAST_GUARD_MINION.get();
    }

    public int getExplosionPower() {
        return 3;
    }

    protected SoundEvent getAmbientSound() {
        return SoundEvents.GHAST_AMBIENT;
    }

    protected SoundEvent getHurtSound(DamageSource damageSource) {
        return SoundEvents.GHAST_HURT;
    }

    protected SoundEvent getDeathSound() {
        return SoundEvents.GHAST_DEATH;
    }

    public float getSoundVolume() {
        return 10.0F;
    }

    public void remove(RemovalReason reason) {
        super.remove(reason);
        if (this.getMaster() != null) {
            this.getMaster().retractMinionNumFromType(this.getMinionType());
        }
    }

    public void setTarget(@Nullable LivingEntity target) {
        if (target != this) {
            if (this.getMaster() != null) {
                if (!this.getMaster().canAttackEntity(target, true)) {
                    return;
                }
            } else if (!this.canAttackEntity(target, true)) {
                return;
            }

            super.setTarget(target);
        }
    }

    public boolean hurt(DamageSource damageSource, float amount) {
        Entity entity = damageSource.getEntity();
        if (this.isInvulnerable()) {
            return false;
        } else if (!(entity instanceof EntityGhastGuardMinion) && !(entity instanceof EntityZombifiedPiglinTitan)) {
            if (entity instanceof LivingEntity livingEntity && this.canAttack(livingEntity)) {
                this.setTarget(livingEntity);
            }

            return super.hurt(damageSource, amount);
        } else {
            return false;
        }
    }

    public boolean causeFallDamage(float fallDistance, float multiplier, DamageSource damageSource) {
        return false;
    }

    public void aiStep() {
        super.aiStep();
        if (this.getTarget() != null) {
            double d1 = this.getTarget().getX() - this.getX();
            double d2 = this.getTarget().getEyeY() - this.getEyeY();
            double d3 = this.getTarget().getZ() - this.getZ();
            double d4 = Math.sqrt(d1 * d1 + d3 * d3);
            float f1 = -((float)Mth.atan2(d2, d4) * 180.0F / (float) Math.PI);
            float f2 = -((float)Mth.atan2(d1, d3) * 180.0F / (float) Math.PI);
            this.setXRot(this.rotlerp(this.getXRot(), f1, 180.0F));
            if (!this.level().isClientSide()) {
                this.setYRot(this.rotlerp(this.getYRot(), f2, 180.0F));
                this.yBodyRot = this.getYRot();
            }
        }

        if (this.getMaster() != null) {
            if (this.getMaster().getTarget() != null) {
                this.setTarget(this.getMaster().getTarget());
            }
        } else {
            List<EntityTitan> entities = this.level().getEntitiesOfClass(EntityTitan.class, this.getBoundingBox().inflate(100.0, 100.0, 100.0));
            if (!entities.isEmpty()) {
                for (EntityTitan entity : entities) {
                    if (entity != null && entity instanceof EntityZombifiedPiglinTitan) {
                        this.setMaster(entity);
                    }
                }
            }
        }
    }

    protected void dropAllDeathLoot(DamageSource damageSource) {
        super.dropAllDeathLoot(damageSource);
    }
}
