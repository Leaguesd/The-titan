package net.titans.render;

import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.EntityRendererProvider.Context;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.titans.entity.titan.EntitySpiderTitan;

@OnlyIn(Dist.CLIENT)
public class RenderCaveSpiderTitan extends RenderSpiderTitan {
    public static final ResourceLocation CAVE_SPIDER_TITAN = ResourceLocation.tryBuild("titan", "textures/entity/titans/cave_spider_titan.png");

    public RenderCaveSpiderTitan(Context context) {
        super(context);
    }

    @Override
    public void render(EntitySpiderTitan entity, float entityYaw, float partialTicks, PoseStack poseStack, MultiBufferSource multiBufferSource, int packedLight) {
        super.render(entity, entityYaw, partialTicks, poseStack, multiBufferSource, packedLight);
    }

    @Override
    protected void scale(EntitySpiderTitan entity, PoseStack poseStack, float partialTick) {
        float f1 = 16.0F;
        int i = entity.getInvulTime();
        if (i > 0) {
            f1 -= ((float)i - partialTick) / 440.0F * 7.75F;
        }

        int i2 = entity.getExtraPower();
        if (i2 > 0) {
            f1 += (float)i2 * 0.5F;
        }

        poseStack.scale(0.7F, 0.7F, 0.7F);
        poseStack.scale(f1, f1, f1);
        poseStack.translate(0.0F, 0.01F, 0.0F);
    }

    @Override
    protected float getShadowRadius(EntitySpiderTitan entity) {
        return this.shadowRadius * entity.getBbWidth();
    }

    @Override
    protected boolean shouldShowName(EntitySpiderTitan entity) {
        return false;
    }

    @Override
    public ResourceLocation getTextureLocation(EntitySpiderTitan entity) {
        return CAVE_SPIDER_TITAN;
    }
}
