package net.titans.mixin;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.renderer.LevelRenderer;
import net.minecraft.client.renderer.entity.EntityRenderDispatcher;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.AABB;
import net.minecraftforge.entity.PartEntity;
import net.titans.entity.titan.EntityTitanPart;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({EntityRenderDispatcher.class})
public class MixinEntityRenderDispatcher {
    @Inject(
        method = {"renderHitbox"},
        at = {@At("TAIL")}
    )
    private static void renderHitbox(
        PoseStack poseStack, VertexConsumer vertexConsumer, Entity entity, float partialTick, CallbackInfo callbackInfo
    ) {
        if (entity.isMultipartEntity()) {
            for (PartEntity<?> partEntity : entity.getParts()) {
                if (partEntity instanceof EntityTitanPart) {
                    poseStack.pushPose();
                    AABB aabb = partEntity.getBoundingBox().move(-partEntity.getX(), -partEntity.getY(), -partEntity.getZ());
                    double d0 = -Mth.lerp((double)partialTick, entity.xOld, entity.getX());
                    double d1 = -Mth.lerp((double)partialTick, entity.yOld, entity.getY());
                    double d2 = -Mth.lerp((double)partialTick, entity.zOld, entity.getZ());
                    double d3 = d0 + Mth.lerp((double)partialTick, partEntity.xOld, partEntity.getX());
                    double d4 = d1 + Mth.lerp((double)partialTick, partEntity.yOld, partEntity.getY());
                    double d5 = d2 + Mth.lerp((double)partialTick, partEntity.zOld, partEntity.getZ());
                    int boxRed = 64;
                    int boxGreen = 255;
                    int boxBlue = 0;
                    poseStack.translate(d3, d4, d5);
                    LevelRenderer.renderLineBox(poseStack, vertexConsumer, aabb, (float)boxRed / 255.0F, (float)boxGreen / 255.0F, (float)boxBlue / 255.0F, 1.0F);
                    poseStack.popPose();
                }
            }
        }
    }
}
