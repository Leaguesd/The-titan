package net.titans.entity.projectile;

import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.projectile.LargeFireball;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.Level.ExplosionInteraction;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.ForgeEventFactory;
import net.titans.entity.minion.EntityGhastTitanMinion;
import net.titans.loader.TheTitansEntities;

public class EntityGhastTitanMinionFireball extends LargeFireball {
    private int explosionPower = 1;

    public EntityGhastTitanMinionFireball(EntityType<? extends EntityGhastTitanMinionFireball> entityType, Level level) {
        super(entityType, level);
    }

    public EntityGhastTitanMinionFireball(Level level, LivingEntity shooter, Vec3 movement, int explosionPower) {
        super(level, shooter, movement.x, movement.y, movement.z, explosionPower);
        this.explosionPower = explosionPower;
        this.setOwner(shooter);
    }

    public EntityGhastTitanMinionFireball(Level level) {
        this((EntityType<? extends EntityGhastTitanMinionFireball>)TheTitansEntities.GHAST_TITAN_MINION_FIREBALL.get(), level);
    }

    protected boolean canHitEntity(Entity entity) {
        return this.getOwner() != null && entity == this.getOwner() ? false : super.canHitEntity(entity);
    }

    protected void onHitEntity(EntityHitResult result) {
        Entity entity = result.getEntity();
        if (entity instanceof LivingEntity && this.getOwner() instanceof LivingEntity) {
            LivingEntity livingEntity = (LivingEntity)entity;
            LivingEntity owner = (LivingEntity)this.getOwner();
            if (owner instanceof EntityGhastTitanMinion) {
                float amount = (float)owner.getAttribute(Attributes.ATTACK_DAMAGE).getBaseValue();
                livingEntity.invulnerableTime = 0;
                livingEntity.setRemainingFireTicks((int)amount);
                owner.doHurtTarget(livingEntity);
            } else {
                livingEntity.hurt(this.damageSources().fireball(this, owner), 17.0F);
            }

            if (!this.level().isClientSide()) {
                boolean flag = ForgeEventFactory.getMobGriefingEvent(this.level(), this.getOwner());
                this.level().explode(this, this.getX(), this.getY(), this.getZ(), (float)this.explosionPower, flag, ExplosionInteraction.MOB);
                this.discard();
            }
        }

        super.onHitEntity(result);
    }
}
