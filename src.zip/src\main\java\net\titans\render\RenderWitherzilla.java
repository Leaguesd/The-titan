package net.titans.render;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.blaze3d.vertex.PoseStack.Pose;
import com.mojang.math.Axis;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.block.BlockRenderDispatcher;
import net.minecraft.client.renderer.culling.Frustum;
import net.minecraft.client.renderer.entity.LivingEntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider.Context;
import net.minecraft.client.renderer.texture.TextureAtlas;
import net.minecraft.client.resources.model.BakedModel;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.util.FastColor.ARGB32;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.titans.entity.titan.EntityWitherzilla;
import net.titans.loader.TheTitansRenderTypes;
import net.titans.model.ModelWitherzilla;
import net.titans.render.layer.LayerWitherzillaArmor;
import net.titans.render.layer.LayerWitherzillaFaceGlow;
import org.joml.Vector3f;

@OnlyIn(Dist.CLIENT)
public class RenderWitherzilla extends LivingEntityRenderer<EntityWitherzilla, ModelWitherzilla> {
    public static final ResourceLocation WITHERZILLA = ResourceLocation.tryBuild("titan", "textures/entity/titans/witherzilla.png");
    public static final ResourceLocation WITHERZILLA_OMEGA = ResourceLocation.tryBuild("titan", "textures/entity/titans/witherzilla_omega.png");
    private final BlockRenderDispatcher blockRenderer;

    public RenderWitherzilla(Context context) {
        super(context, new ModelWitherzilla(0.0F), 1.0F);
        this.blockRenderer = context.getBlockRenderDispatcher();
        this.addLayer(new LayerWitherzillaArmor(this));
        this.addLayer(new LayerWitherzillaFaceGlow(this));
    }

    /**
     * 忠实还原 1.7.10 RenderWitherzilla.renderEquippedItems 中的光锥绘制。
     *
     * 原版逻辑：
     * - 位于模型渲染之后（renderEquippedItems 回调）
     * - TRIANGLE_FAN 锥体：中心顶点高 alpha，底面 4 个顶点 alpha = 0
     * - additive 混合，glDepthMask(false) 不写深度
     * - 6 次 glRotatef 直接累积（不是 bug，原版末影龙光效就这样）
     * - 锥高 f3 = rand*10 + 5 + 20*f2
     * - 底半径 f4 = rand*2 + 1 + 2*f2
     * - 中心颜色 14809319 (0xE1F8E7)，底面同色 alpha=0
     * - 无额外缩放
     *
     * @param dragonDeathCompletion 进度 f（affectTicks 归一化）
     * @param f2 进度超过 0.8 后的收尾系数，0~1
     */
    private static void renderRays(PoseStack poseStack, float dragonDeathCompletion, float f2, VertexConsumer vertexConsumer) {
        RandomSource randomSource = RandomSource.create(432L);
        Vector3f center = new Vector3f();
        Vector3f v1 = new Vector3f();
        Vector3f v2 = new Vector3f();
        Vector3f v3 = new Vector3f();

        int count = Mth.floor(((dragonDeathCompletion * dragonDeathCompletion) + dragonDeathCompletion) / 2.0F * 100.0F);
        int centerColor = color(Mth.floor(255.0F * (1.0F - f2)), 14809319);
        int edgeColor = color(0, 14809319);

        poseStack.pushPose();
        for (int l = 0; l < count; l++) {
            poseStack.mulPose(Axis.XP.rotationDegrees(randomSource.nextFloat() * 360.0F));
            poseStack.mulPose(Axis.YP.rotationDegrees(randomSource.nextFloat() * 360.0F));
            poseStack.mulPose(Axis.ZP.rotationDegrees(randomSource.nextFloat() * 360.0F));
            poseStack.mulPose(Axis.XP.rotationDegrees(randomSource.nextFloat() * 360.0F));
            poseStack.mulPose(Axis.YP.rotationDegrees(randomSource.nextFloat() * 360.0F));
            poseStack.mulPose(Axis.ZP.rotationDegrees(randomSource.nextFloat() * 360.0F + 90.0F * dragonDeathCompletion));

            float f3 = randomSource.nextFloat() * 10.0F + 5.0F + 20.0F * f2;
            float f4 = randomSource.nextFloat() * 2.0F + 1.0F + 2.0F * f2;

            center.set(0.0F, 0.0F, 0.0F);
            v1.set(-0.866F * f4, f3, -0.5F * f4);
            v2.set( 0.866F * f4, f3, -0.5F * f4);
            v3.set( 0.0F,        f3,  f4);

            Pose pose = poseStack.last();
            // TRIANGLE_FAN 展开为 TRIANGLES：(v0,v1,v2), (v0,v2,v3), (v0,v3,v1)
            vertex(vertexConsumer, pose, center, centerColor);
            vertex(vertexConsumer, pose, v1, edgeColor);
            vertex(vertexConsumer, pose, v2, edgeColor);

            vertex(vertexConsumer, pose, center, centerColor);
            vertex(vertexConsumer, pose, v2, edgeColor);
            vertex(vertexConsumer, pose, v3, edgeColor);

            vertex(vertexConsumer, pose, center, centerColor);
            vertex(vertexConsumer, pose, v3, edgeColor);
            vertex(vertexConsumer, pose, v1, edgeColor);
        }
        poseStack.popPose();
    }

    private static void vertex(VertexConsumer vertexConsumer, Pose pose, Vector3f position, int color) {
        vertexConsumer.vertex(pose.pose(), position.x(), position.y(), position.z())
            .color(color >> 16 & 0xFF, color >> 8 & 0xFF, color & 0xFF, color >> 24 & 0xFF)
            .endVertex();
    }

    private static int color(int alpha, int rgb) {
        return ARGB32.color(alpha, rgb >> 16 & 0xFF, rgb >> 8 & 0xFF, rgb & 0xFF);
    }
        @Override
    public void render(EntityWitherzilla entity, float entityYaw, float partialTicks, PoseStack poseStack, MultiBufferSource multiBufferSource, int packedLight) {
        float f8 = entity.getScale();

        // ===== 1. GLOWSTONE 方块（保留原逻辑，在 super.render 之前独立画） =====
        poseStack.pushPose();
        poseStack.scale(f8, f8, f8);
        poseStack.scale(-1.0F, -1.0F, 1.0F);
        this.scale(entity, poseStack, partialTicks);
        poseStack.translate(0.0F, -1.501F, 0.0F);
        poseStack.translate(0.0F, -2.0F, 0.0F);
        poseStack.scale(0.15F, 0.15F, 0.15F);
        Minecraft mc = Minecraft.getInstance();
        Block block = Blocks.GLOWSTONE;
        BlockState blockState = block.defaultBlockState();
        BakedModel bakedModel = this.blockRenderer.getBlockModel(blockState);
        int i = LivingEntityRenderer.getOverlayCoords(entity, 0.0F);
        poseStack.translate(-0.5F, -0.5F, -0.5F);
        mc.gameRenderer.lightTexture().turnOnLightLayer();
        this.blockRenderer
            .getModelRenderer()
            .renderModel(
                poseStack.last(),
                multiBufferSource.getBuffer(RenderType.entityTranslucentCull(TextureAtlas.LOCATION_BLOCKS)),
                blockState,
                bakedModel,
                1.0F,
                1.0F,
                1.0F,
                LightTexture.pack(blockState.getLightBlock(entity.level(), entity.blockPosition()), this.getSkyLightLevel(entity, entity.blockPosition())),
                i
            );
        mc.gameRenderer.lightTexture().turnOffLightLayer();
        poseStack.popPose();

        // ===== 2. 本体模型 + Layer =====
        super.render(entity, entityYaw, partialTicks, poseStack, multiBufferSource, packedLight);

        // ===== 3. 光锥（1.7.10 原版：模型之后画 + 不写深度 + additive） =====
        if (entity.affectTicks > 0 && entity.getInvulTime() < 1) {
            poseStack.pushPose();
            poseStack.scale(f8, f8, f8);
            poseStack.scale(-1.0F, -1.0F, 1.0F);
            this.scale(entity, poseStack, partialTicks);
            poseStack.translate(0.0F, -1.501F, 0.0F);
            poseStack.translate(0.0F, -2.0F, 0.0F);
            // 原版没有 scale(0.15)，光锥直接画在模型空间里

            float f = ((float)entity.affectTicks + partialTicks) / 1000.0F;
            float f2 = f > 0.8F ? (f - 0.8F) / 0.2F : 0.0F;
            renderRays(poseStack, f, f2, multiBufferSource.getBuffer(TheTitansRenderTypes.WITHERZILLA_RAYS));

            poseStack.popPose();
        }
    }

    @Override
    protected void scale(EntityWitherzilla entity, PoseStack poseStack, float partialTick) {
        float f1 = entity.isInOmegaForm() ? 256.0F : 128.0F;
        int i = entity.getInvulTime();
        if (i > 0) {
            f1 -= ((float)i - partialTick) / 440.0F * 7.75F;
        }
        int i2 = entity.getExtraPower();
        if (i2 > 0) {
            f1 += (float)i2 * 0.5F;
        }
        poseStack.scale(f1, f1, f1);
        poseStack.translate(0.0F, 0.01F, 0.0F);
    }

    @Override
    protected boolean shouldShowName(EntityWitherzilla entity) {
        return false;
    }

    @Override
    public boolean shouldRender(EntityWitherzilla livingEntity, Frustum camera, double cameraX, double cameraY, double cameraZ) {
        return true;
    }

    @Override
    public ResourceLocation getTextureLocation(EntityWitherzilla entity) {
        return WITHERZILLA;
    }
}