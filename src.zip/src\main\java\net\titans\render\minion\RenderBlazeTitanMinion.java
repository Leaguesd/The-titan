package net.titans.render.minion;

import net.minecraft.client.renderer.entity.BlazeRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider.Context;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.monster.Blaze;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.titans.entity.minion.IMinion;

@OnlyIn(Dist.CLIENT)
public class RenderBlazeTitanMinion extends BlazeRenderer {
    public static final ResourceLocation BLAZE = new ResourceLocation("minecraft", "textures/entity/blaze.png");
    public static final ResourceLocation BLAZE_PRIEST = ResourceLocation.tryBuild("titan", "textures/entity/minions/blaze/blaze_priest.png");
    public static final ResourceLocation BLAZE_ZEALOT = ResourceLocation.tryBuild("titan", "textures/entity/minions/blaze/blaze_zealot.png");
    public static final ResourceLocation BLAZE_BISHOP = ResourceLocation.tryBuild("titan", "textures/entity/minions/blaze/blaze_bishop.png");
    public static final ResourceLocation BLAZE_TEMPLAR = ResourceLocation.tryBuild("titan", "textures/entity/minions/blaze/blaze_templar.png");

    public RenderBlazeTitanMinion(Context context) {
        super(context);
    }

    public ResourceLocation getTextureLocation(Blaze entity) {
        if (entity instanceof IMinion minion) {
            switch (minion.getMinionType()) {
                case PRIEST:
                    return BLAZE_PRIEST;
                case ZEALOT:
                    return BLAZE_ZEALOT;
                case BISHOP:
                    return BLAZE_BISHOP;
                case TEMPLAR:
                    return BLAZE_TEMPLAR;
                default:
                    return BLAZE;
            }
        } else {
            return super.getTextureLocation(entity);
        }
    }
}
