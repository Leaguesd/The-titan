package net.titans.render.minion;

import net.minecraft.client.renderer.entity.SpiderRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider.Context;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.monster.Spider;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.titans.entity.minion.IMinion;

@OnlyIn(Dist.CLIENT)
public class RenderSpiderTitanMinion extends SpiderRenderer<Spider> {
    public static final ResourceLocation SPIDER = new ResourceLocation("minecraft", "textures/entity/spider/spider.png");
    public static final ResourceLocation SPIDER_PRIEST = ResourceLocation.tryBuild("titan", "textures/entity/minions/spider/spider_priest.png");
    public static final ResourceLocation SPIDER_ZEALOT = ResourceLocation.tryBuild("titan", "textures/entity/minions/spider/spider_zealot.png");
    public static final ResourceLocation SPIDER_BISHOP = ResourceLocation.tryBuild("titan", "textures/entity/minions/spider/spider_bishop.png");
    public static final ResourceLocation SPIDER_TEMPLAR = ResourceLocation.tryBuild("titan", "textures/entity/minions/spider/spider_templar.png");

    public RenderSpiderTitanMinion(Context context) {
        super(context);
    }

    public ResourceLocation getTextureLocation(Spider entity) {
        if (entity instanceof IMinion minion) {
            switch (minion.getMinionType()) {
                case PRIEST:
                    return SPIDER_PRIEST;
                case ZEALOT:
                    return SPIDER_ZEALOT;
                case BISHOP:
                    return SPIDER_BISHOP;
                case TEMPLAR:
                    return SPIDER_TEMPLAR;
                default:
                    return SPIDER;
            }
        } else {
            return super.getTextureLocation(entity);
        }
    }
}
