package net.titans.render;

import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.LivingEntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider.Context;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.titans.entity.titan.EntitySpiderTitan;
import net.titans.model.ModelSpiderTitan;
import net.titans.render.layer.LayerSpiderTitanArmor;
import net.titans.render.layer.LayerSpiderTitanEyes;

@OnlyIn(Dist.CLIENT)
public class RenderSpiderTitan extends LivingEntityRenderer<EntitySpiderTitan, ModelSpiderTitan> {
    public static final ResourceLocation SPIDER_TITAN = ResourceLocation.tryBuild("titan", "textures/entity/titans/spider_titan.png");
    public static final ResourceLocation SPIDER_TITAN_EYE = ResourceLocation.tryBuild("titan", "textures/entity/titans/spider_titan_eyes.png");

    public RenderSpiderTitan(Context context) {
        super(context, new ModelSpiderTitan(0.0F), 1.0F);
        this.addLayer(new LayerSpiderTitanEyes(this));
        this.addLayer(new LayerSpiderTitanArmor(this));
    }

    public void render(EntitySpiderTitan entity, float entityYaw, float partialTicks, PoseStack poseStack, MultiBufferSource multiBufferSource, int packedLight) {
        super.render(entity, entityYaw, partialTicks, poseStack, multiBufferSource, packedLight);
    }

    protected void scale(EntitySpiderTitan entity, PoseStack poseStack, float partialTick) {
        float f1 = 16.0F;
        int i = entity.getInvulTime();
        if (i > 0) {
            f1 -= ((float)i - partialTick) / 440.0F * 7.75F;
        }

        int i2 = entity.getExtraPower();
        if (i2 > 0) {
            f1 += (float)i2 * 0.5F;
        }

        poseStack.scale(f1, f1, f1);
        poseStack.translate(0.0F, 0.01F, 0.0F);
    }

    protected float getFlipDegrees(EntitySpiderTitan entity) {
        return 180.0F;
    }

    protected boolean isBodyVisible(EntitySpiderTitan entity) {
        return !entity.isInvisible();
    }

    protected float getShadowRadius(EntitySpiderTitan entity) {
        return this.shadowRadius * entity.getBbWidth();
    }

    protected boolean shouldShowName(EntitySpiderTitan entity) {
        return false;
    }

    public ResourceLocation getTextureLocation(EntitySpiderTitan entity) {
        return SPIDER_TITAN;
    }
}
