package net.titans.loader;

import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.RegistryObject;

public class TheTitansSounds {
    public static final DeferredRegister<SoundEvent> SOUNDS = DeferredRegister.create(Registries.SOUND_EVENT, "titan");
    public static final RegistryObject<SoundEvent> TITAN_CRUSH_WOOD = SOUNDS.register(
        "titancrushwood", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.tryBuild("titan", "titancrushwood"))
    );
    public static final RegistryObject<SoundEvent> TITAN_HIT_METAL = SOUNDS.register(
        "titanhitmetal", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.tryBuild("titan", "titanhitmetal"))
    );
    public static final RegistryObject<SoundEvent> TITAN_PRESS = SOUNDS.register(
        "titanpress", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.tryBuild("titan", "titanpress"))
    );
    public static final RegistryObject<SoundEvent> SWORD_DRAG = SOUNDS.register(
        "sworddrag", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.tryBuild("titan", "sworddrag"))
    );
    public static final RegistryObject<SoundEvent> TITAN_SWING = SOUNDS.register(
        "titanswing", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.tryBuild("titan", "titanswing"))
    );
    public static final RegistryObject<SoundEvent> SLASH_FLESH = SOUNDS.register(
        "slashflesh", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.tryBuild("titan", "slashflesh"))
    );
    public static final RegistryObject<SoundEvent> HARCACADIUM_HUM = SOUNDS.register(
        "harcadiumhum", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.tryBuild("titan", "harcadiumhum"))
    );
    public static final RegistryObject<SoundEvent> HARCACADIUM_BLOCK_HUM = SOUNDS.register(
        "harcadiumblockhum", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.tryBuild("titan", "harcadiumblockhum"))
    );
    public static final RegistryObject<SoundEvent> LARGE_FALL = SOUNDS.register(
        "largefall", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.tryBuild("titan", "largefall"))
    );
    public static final RegistryObject<SoundEvent> QUICK_APPERENCE = SOUNDS.register(
        "quickapperence", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.tryBuild("titan", "quickapperence"))
    );
    public static final RegistryObject<SoundEvent> TITAN_BIRTH = SOUNDS.register(
        "titanbirth", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.tryBuild("titan", "titanbirth"))
    );
    public static final RegistryObject<SoundEvent> TITAN_QUAKE = SOUNDS.register(
        "titanquake", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.tryBuild("titan", "titanquake"))
    );
    public static final RegistryObject<SoundEvent> TITAN_RUMBLE = SOUNDS.register(
        "titanrumble", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.tryBuild("titan", "titanrumble"))
    );
    public static final RegistryObject<SoundEvent> DISTANT_LARGE_FALL = SOUNDS.register(
        "distantlargefall", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.tryBuild("titan", "distantlargefall"))
    );
    public static final RegistryObject<SoundEvent> TITAN_FALL = SOUNDS.register(
        "titanfall", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.tryBuild("titan", "titanfall"))
    );
    public static final RegistryObject<SoundEvent> TITAN_SLAM = SOUNDS.register(
        "titanslam", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.tryBuild("titan", "titanslam"))
    );
    public static final RegistryObject<SoundEvent> TITAN_STRIKE = SOUNDS.register(
        "titanstrike", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.tryBuild("titan", "titanstrike"))
    );
    public static final RegistryObject<SoundEvent> GROUND_SMASH = SOUNDS.register(
        "groundsmash", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.tryBuild("titan", "groundsmash"))
    );
    public static final RegistryObject<SoundEvent> TITAN_PUNCH = SOUNDS.register(
        "titanpunch", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.tryBuild("titan", "titanpunch"))
    );
    public static final RegistryObject<SoundEvent> TITAN_LAND = SOUNDS.register(
        "titanland", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.tryBuild("titan", "titanland"))
    );
    public static final RegistryObject<SoundEvent> TITAN_STEP = SOUNDS.register(
        "titanstep", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.tryBuild("titan", "titanstep"))
    );
    public static final RegistryObject<SoundEvent> TITAN_SUMMON_MINION = SOUNDS.register(
        "titansummonminion", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.tryBuild("titan", "titansummonminion"))
    );
    public static final RegistryObject<SoundEvent> TURRET_SHOOT = SOUNDS.register(
        "turretshoot", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.tryBuild("titan", "turretshoot"))
    );
    public static final RegistryObject<SoundEvent> TURRET_DEATH = SOUNDS.register(
        "turretdeath", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.tryBuild("titan", "turretdeath"))
    );
    public static final RegistryObject<SoundEvent> TURRET_SHOOT_2 = SOUNDS.register(
        "turretshoot2", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.tryBuild("titan", "turretshoot2"))
    );
    public static final RegistryObject<SoundEvent> TURRET_DEATH_2 = SOUNDS.register(
        "turretdeath2", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.tryBuild("titan", "turretdeath2"))
    );
    public static final RegistryObject<SoundEvent> TURRET_SHOOT_3 = SOUNDS.register(
        "turretshoot3", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.tryBuild("titan", "turretshoot3"))
    );
    public static final RegistryObject<SoundEvent> TURRET_DEATH_3 = SOUNDS.register(
        "turretdeath3", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.tryBuild("titan", "turretdeath3"))
    );
    public static final RegistryObject<SoundEvent> MORTAR_SHOOT = SOUNDS.register(
        "mortarshoot", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.tryBuild("titan", "mortarshoot"))
    );
    public static final RegistryObject<SoundEvent> MORTAR_HIT = SOUNDS.register(
        "mortarhit", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.tryBuild("titan", "mortarhit"))
    );
    public static final RegistryObject<SoundEvent> LIGHTNING_THROW = SOUNDS.register(
        "lightningthrow", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.tryBuild("titan", "lightningthrow"))
    );
    public static final RegistryObject<SoundEvent> LIGHTNING_CHARGE = SOUNDS.register(
        "lightningcharge", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.tryBuild("titan", "lightningcharge"))
    );
    public static final RegistryObject<SoundEvent> TITAN_ZOMBIE_LIVING = SOUNDS.register(
        "titanzombieliving", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.tryBuild("titan", "titanzombieliving"))
    );
    public static final RegistryObject<SoundEvent> TITAN_ZOMBIE_GRUNT = SOUNDS.register(
        "titanzombiegrunt", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.tryBuild("titan", "titanzombiegrunt"))
    );
    public static final RegistryObject<SoundEvent> TITAN_ZOMBIE_ROAR = SOUNDS.register(
        "titanzombieroar", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.tryBuild("titan", "titanzombieroar"))
    );
    public static final RegistryObject<SoundEvent> TITAN_ZOMBIE_DEATH = SOUNDS.register(
        "titanzombiedeath", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.tryBuild("titan", "titanzombiedeath"))
    );
    public static final RegistryObject<SoundEvent> TITAN_ZOMBIE_CREATION = SOUNDS.register(
        "titanzombiecreation", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.tryBuild("titan", "titanzombiecreation"))
    );
    public static final RegistryObject<SoundEvent> TITAN_SILVERFISH_LIVING = SOUNDS.register(
        "titansilverfishliving", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.tryBuild("titan", "titansilverfishliving"))
    );
    public static final RegistryObject<SoundEvent> TITAN_SILVERFISH_GRUNT = SOUNDS.register(
        "titansilverfishgrunt", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.tryBuild("titan", "titansilverfishgrunt"))
    );
    public static final RegistryObject<SoundEvent> TITAN_SILVERFISH_DEATH = SOUNDS.register(
        "titansilverfishdeath", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.tryBuild("titan", "titansilverfishdeath"))
    );
    public static final RegistryObject<SoundEvent> TITAN_SKELETON_LIVING = SOUNDS.register(
        "titanskeletonliving", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.tryBuild("titan", "titanskeletonliving"))
    );
    public static final RegistryObject<SoundEvent> TITAN_SKELETON_GRUNT = SOUNDS.register(
        "titanskeletongrunt", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.tryBuild("titan", "titanskeletongrunt"))
    );
    public static final RegistryObject<SoundEvent> TITAN_SKELETON_DEATH = SOUNDS.register(
        "titanskeletondeath", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.tryBuild("titan", "titanskeletondeath"))
    );
    public static final RegistryObject<SoundEvent> TITAN_SKELETON_AWAKEN = SOUNDS.register(
        "titanskeletonawaken", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.tryBuild("titan", "titanskeletonawaken"))
    );
    public static final RegistryObject<SoundEvent> TITAN_SKELETON_BEGIN_MOVE = SOUNDS.register(
        "titanskeletonbeginmove", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.tryBuild("titan", "titanskeletonbeginmove"))
    );
    public static final RegistryObject<SoundEvent> TITAN_SKELETON_GETUP = SOUNDS.register(
        "titanskeletongetup", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.tryBuild("titan", "titanskeletongetup"))
    );
    public static final RegistryObject<SoundEvent> TITAN_SKELETON_BONE_CRUNCH = SOUNDS.register(
        "titanskeletonbonecrunch", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.tryBuild("titan", "titanskeletonbonecrunch"))
    );
    public static final RegistryObject<SoundEvent> TITAN_WITHER_SKELETON_LIVING = SOUNDS.register(
        "titanwitherskeletonliving", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.tryBuild("titan", "titanwitherskeletonliving"))
    );
    public static final RegistryObject<SoundEvent> TITAN_WITHER_SKELETON_GRUNT = SOUNDS.register(
        "titanwitherskeletongrunt", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.tryBuild("titan", "titanwitherskeletongrunt"))
    );
    public static final RegistryObject<SoundEvent> TITAN_WITHER_SKELETON_DEATH = SOUNDS.register(
        "titanwitherskeletondeath", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.tryBuild("titan", "titanwitherskeletondeath"))
    );
    public static final RegistryObject<SoundEvent> TITAN_CREEPER_LIVING = SOUNDS.register(
        "titancreeperliving", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.tryBuild("titan", "titancreeperliving"))
    );
    public static final RegistryObject<SoundEvent> TITAN_CREEPER_GRUNT = SOUNDS.register(
        "titancreepergrunt", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.tryBuild("titan", "titancreepergrunt"))
    );
    public static final RegistryObject<SoundEvent> TITAN_CREEPER_DEATH = SOUNDS.register(
        "titancreeperdeath", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.tryBuild("titan", "titancreeperdeath"))
    );
    public static final RegistryObject<SoundEvent> TITAN_CREEPER_STUN = SOUNDS.register(
        "titancreeperstun", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.tryBuild("titan", "titancreeperstun"))
    );
    public static final RegistryObject<SoundEvent> TITAN_CREEPER_WARNING = SOUNDS.register(
        "titancreeperwarning", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.tryBuild("titan", "titancreeperwarning"))
    );
    public static final RegistryObject<SoundEvent> TITAN_CREEPER_EXPLOSION = SOUNDS.register(
        "titancreeperexplosion", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.tryBuild("titan", "titancreeperexplosion"))
    );
    public static final RegistryObject<SoundEvent> TITAN_CREEPER_AWAKEN = SOUNDS.register(
        "titancreeperawaken", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.tryBuild("titan", "titancreeperawaken"))
    );
    public static final RegistryObject<SoundEvent> TITAN_CREEPER_BEGINMOVE = SOUNDS.register(
        "titancreeperbeginmove", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.tryBuild("titan", "titancreeperbeginmove"))
    );
    public static final RegistryObject<SoundEvent> TITAN_SPIDER_LIVING = SOUNDS.register(
        "titanspiderliving", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.tryBuild("titan", "titanspiderliving"))
    );
    public static final RegistryObject<SoundEvent> TITAN_SPIDER_GRUNT = SOUNDS.register(
        "titanspidergrunt", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.tryBuild("titan", "titanspidergrunt"))
    );
    public static final RegistryObject<SoundEvent> TITAN_SPIDER_DEATH = SOUNDS.register(
        "titanspiderdeath", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.tryBuild("titan", "titanspiderdeath"))
    );
    public static final RegistryObject<SoundEvent> TITAN_ZOMBIFIED_PIGLIN_LIVING = SOUNDS.register(
        "titanpigzombieliving", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.tryBuild("titan", "titanpigzombieliving"))
    );
    public static final RegistryObject<SoundEvent> TITAN_ZOMBIFIED_PIGLIN_GRUNT = SOUNDS.register(
        "titanpigzombiegrunt", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.tryBuild("titan", "titanpigzombiegrunt"))
    );
    public static final RegistryObject<SoundEvent> TITAN_ZOMBIFIED_PIGLIN_DEATH = SOUNDS.register(
        "titanpigzombiedeath", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.tryBuild("titan", "titanpigzombiedeath"))
    );
    public static final RegistryObject<SoundEvent> TITAN_BLAZE_BREATHE = SOUNDS.register(
        "titanblazebreathe", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.tryBuild("titan", "titanblazebreathe"))
    );
    public static final RegistryObject<SoundEvent> TITAN_BLAZE_GRUNT = SOUNDS.register(
        "titanblazegrunt", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.tryBuild("titan", "titanblazegrunt"))
    );
    public static final RegistryObject<SoundEvent> TITAN_BLAZE_DEATH = SOUNDS.register(
        "titanblazedeath", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.tryBuild("titan", "titanblazedeath"))
    );
    public static final RegistryObject<SoundEvent> TITAN_ENDER_COLOSUS_SCREAM = SOUNDS.register(
        "titanendercolossusscream", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.tryBuild("titan", "titanendercolossusscream"))
    );
    public static final RegistryObject<SoundEvent> TITAN_ENDER_COLOSUS_SCREAM_LONG = SOUNDS.register(
        "titanendercolossusscreamlong", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.tryBuild("titan", "titanendercolossusscreamlong"))
    );
    public static final RegistryObject<SoundEvent> TITAN_ENDER_COLOSUS_CHOMP = SOUNDS.register(
        "titanendercolossuschomp", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.tryBuild("titan", "titanendercolossuschomp"))
    );
    public static final RegistryObject<SoundEvent> TITAN_ENDER_COLOSUS_STARE = SOUNDS.register(
        "titanendercolossusstare", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.tryBuild("titan", "titanendercolossusstare"))
    );
    public static final RegistryObject<SoundEvent> TITAN_ENDER_COLOSUS_ROAR = SOUNDS.register(
        "titanendercolossusroar", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.tryBuild("titan", "titanendercolossusroar"))
    );
    public static final RegistryObject<SoundEvent> TITAN_ENDER_COLOSUS_LIVING = SOUNDS.register(
        "titanendercolossusliving", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.tryBuild("titan", "titanendercolossusliving"))
    );
    public static final RegistryObject<SoundEvent> TITAN_ENDER_COLOSUS_GRUNT = SOUNDS.register(
        "titanendercolossusgrunt", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.tryBuild("titan", "titanendercolossusgrunt"))
    );
    public static final RegistryObject<SoundEvent> TITAN_ENDER_COLOSUS_DEATH = SOUNDS.register(
        "titanendercolossusdeath", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.tryBuild("titan", "titanendercolossusdeath"))
    );
    public static final RegistryObject<SoundEvent> TITAN_GHAST_FIREBALL = SOUNDS.register(
        "titanghastfireball", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.tryBuild("titan", "titanghastfireball"))
    );
    public static final RegistryObject<SoundEvent> TITAN_GHAST_CHARGE = SOUNDS.register(
        "titanghastcharge", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.tryBuild("titan", "titanghastcharge"))
    );
    public static final RegistryObject<SoundEvent> TITAN_GHAST_LIVING = SOUNDS.register(
        "titanghastliving", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.tryBuild("titan", "titanghastliving"))
    );
    public static final RegistryObject<SoundEvent> TITAN_GHAST_GRUNT = SOUNDS.register(
        "titanghastgrunt", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.tryBuild("titan", "titanghastgrunt"))
    );
    public static final RegistryObject<SoundEvent> TITAN_GHAST_DEATH = SOUNDS.register(
        "titanghastdeath", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.tryBuild("titan", "titanghastdeath"))
    );
    public static final RegistryObject<SoundEvent> WITHERZILLA_SPAWN = SOUNDS.register(
        "witherzillaspawn", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.tryBuild("titan", "witherzillaspawn"))
    );
    public static final RegistryObject<SoundEvent> WITHERZILLA_LIVING = SOUNDS.register(
        "witherzillaliving", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.tryBuild("titan", "witherzillaliving"))
    );
    public static final RegistryObject<SoundEvent> WITHERZILLA_GRUNT = SOUNDS.register(
        "witherzillagrunt", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.tryBuild("titan", "witherzillagrunt"))
    );
    public static final RegistryObject<SoundEvent> WITHERZILLA_DEATH = SOUNDS.register(
        "witherzilladeath", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.tryBuild("titan", "witherzilladeath"))
    );

    public static void registerSounds(IEventBus modEventBus) {
        SOUNDS.register(modEventBus);
    }
}
