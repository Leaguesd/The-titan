package net.titans.entity;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.level.Level;
import net.titans.loader.TheTitansEntities;

public class EntityColorLightningBolt extends LightningBolt {
    private static final EntityDataAccessor<Float> DATA_EFFECT_RED_ID = SynchedEntityData.defineId(
        EntityColorLightningBolt.class, EntityDataSerializers.FLOAT
    );
    private static final EntityDataAccessor<Float> DATA_EFFECT_GREEN_ID = SynchedEntityData.defineId(
        EntityColorLightningBolt.class, EntityDataSerializers.FLOAT
    );
    private static final EntityDataAccessor<Float> DATA_EFFECT_BLUE_ID = SynchedEntityData.defineId(
        EntityColorLightningBolt.class, EntityDataSerializers.FLOAT
    );

    public EntityColorLightningBolt(EntityType<? extends EntityColorLightningBolt> entityType, Level level) {
        super(entityType, level);
    }

    public EntityColorLightningBolt(Level level, float red, float green, float blue) {
    super((EntityType)TheTitansEntities.COLOR_LIGHTNING_BLOT.get(), level);
    // 只保留视觉/音效：跳过原版 LightningBolt.tick() 里 !visualOnly 分支的
    // 范围伤害、spawnFire 点火、目标位置放火、避雷针/铜块触发。
    // 凋灵斯拉的伤害由 EntityWitherzilla 自己结算，不依赖这道闪电。
    this.setVisualOnly(true);
    this.setRed(red);
    this.setGreen(green);
    this.setBlue(blue);
    this.setDamage(50.0F);
    }
    
    public float getRed() {
        return (Float)this.entityData.get(DATA_EFFECT_RED_ID);
    }

    public void setRed(float red) {
        this.entityData.set(DATA_EFFECT_RED_ID, red);
    }

    public float getGreen() {
        return (Float)this.entityData.get(DATA_EFFECT_GREEN_ID);
    }

    public void setGreen(float green) {
        this.entityData.set(DATA_EFFECT_GREEN_ID, green);
    }

    public float getBlue() {
        return (Float)this.entityData.get(DATA_EFFECT_BLUE_ID);
    }

    public void setBlue(float blue) {
        this.entityData.set(DATA_EFFECT_BLUE_ID, blue);
    }

    protected void defineSynchedData() {
        this.entityData.define(DATA_EFFECT_RED_ID, 1.0F);
        this.entityData.define(DATA_EFFECT_GREEN_ID, 1.0F);
        this.entityData.define(DATA_EFFECT_BLUE_ID, 1.0F);
    }

    protected void readAdditionalSaveData(CompoundTag tag) {
        this.setRed(tag.getFloat("red"));
        this.setGreen(tag.getFloat("green"));
        this.setBlue(tag.getFloat("blue"));
    }

    protected void addAdditionalSaveData(CompoundTag tag) {
        tag.putFloat("red", this.getRed());
        tag.putFloat("green", this.getGreen());
        tag.putFloat("blue", this.getBlue());
    }

    public boolean shouldRenderAtSqrDistance(double distance) {
        double d0 = 64.0 * getViewScale();
        return distance < d0 * d0;
    }
}
