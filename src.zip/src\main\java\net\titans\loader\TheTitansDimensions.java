package net.titans.loader;

import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.Level;

public class TheTitansDimensions {
    public static final ResourceKey<Level> THE_VOID = ResourceKey.create(Registries.DIMENSION, ResourceLocation.tryBuild("titan", "the_void"));
    public static final ResourceKey<Level> THE_NOWHERE = ResourceKey.create(Registries.DIMENSION, ResourceLocation.tryBuild("titan", "the_nowhere"));
}
