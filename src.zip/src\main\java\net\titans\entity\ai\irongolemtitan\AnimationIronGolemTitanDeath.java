package net.titans.entity.ai.irongolemtitan;

import net.titans.animation.AIAnimation;
import net.titans.entity.titan.EntityIronGolemTitan;

public class AnimationIronGolemTitanDeath extends AIAnimation {
    private EntityIronGolemTitan entity;

    public AnimationIronGolemTitanDeath(EntityIronGolemTitan entity) {
        super(entity);
        this.entity = entity;
    }

    @Override
    public int getAnimationID() {
        return 10;
    }

    @Override
    public boolean isAutomatic() {
        return true;
    }

    @Override
    public int getDuration() {
        return 2000;
    }

    @Override
    public boolean canUse() {
        return this.entity.deathTicks > 0 && !this.entity.isAlive() ? super.canUse() : false;
    }

    @Override
    public boolean canContinueToUse() {
        return this.entity.deathTicks > 0 && !this.entity.isAlive() ? super.canContinueToUse() : false;
    }
}
