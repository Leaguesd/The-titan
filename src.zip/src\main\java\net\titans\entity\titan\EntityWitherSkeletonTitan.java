package net.titans.entity.titan;

import net.minecraft.world.Difficulty;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier.Builder;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.level.Level;
import net.titans.loader.TheTitansEntities;

/**
 * 凋灵骷髅泰坦。
 *
 * <p>以前它是 {@code titan:skeleton_titan} 的一个 {@code SkeletonType=1} 变体：实体先按普通骷髅泰坦
 * 构造（当前血量写入 2 万/4 万），之后 {@code setSkeletonType(1)} 只把 MAX_HEALTH 改成 20 万/40 万，
 * 当前血量不会跟着变，于是出现“最大生命值正确、血量还是骷髅泰坦的”问题。
 *
 * <p>现在它是独立实体类型 {@code titan:wither_skeleton_titan}：类型在类上固定为 1，
 * 基类构造阶段 {@link #refreshAttributes()} 就会直接算出凋灵档位的上限，
 * {@code EntityTitan} 构造器随后把当前血量初始化为同一个值，不再需要任何事后修补。
 */
public class EntityWitherSkeletonTitan extends EntitySkeletonTitan {
    public EntityWitherSkeletonTitan(EntityType<? extends EntityTitan> entityType, Level level) {
        super(entityType, level);
    }

    public EntityWitherSkeletonTitan(Level level) {
        this(TheTitansEntities.WITHER_SKELETON_TITAN.get(), level);
    }

    public static Builder createAttributes() {
        return EntityTitan.createAttributes().add(Attributes.MAX_HEALTH, 400000.0).add(Attributes.ATTACK_DAMAGE, 3000.0);
    }

    @Override
    public int getSkeletonType() {
        return 1;
    }

    @Override
    protected void refreshAttributes() {
        if (this.level().getDifficulty() == Difficulty.HARD) {
            this.getAttribute(Attributes.MAX_HEALTH).setBaseValue(400000.0 + (double)this.getExtraPower() * 5000.0);
            this.getAttribute(Attributes.ATTACK_DAMAGE).setBaseValue(3000.0 + (double)this.getExtraPower() * 3000.0);
        } else {
            this.getAttribute(Attributes.MAX_HEALTH).setBaseValue(200000.0 + (double)this.getExtraPower() * 3000.0);
            this.getAttribute(Attributes.ATTACK_DAMAGE).setBaseValue(1500.0 + (double)this.getExtraPower() * 1500.0);
        }
    }
}
