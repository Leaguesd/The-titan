package net.titans.item;

import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.stats.Stats;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.AbstractArrow;
import net.minecraft.world.entity.projectile.AbstractArrow.Pickup;
import net.minecraft.world.item.BowItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item.Properties;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.item.enchantment.Enchantments;
import net.minecraft.world.level.Level;
import net.minecraftforge.event.ForgeEventFactory;
import net.titans.entity.projectile.EntityHarcadiumArrow;
import net.titans.loader.TheTitansRegistries;
import net.titans.util.ItemUtils;

public class ItemHarcadiumBow extends BowItem {
    public ItemHarcadiumBow(Properties properties) {
        super(properties.durability(12001));
    }

    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        InteractionResultHolder<ItemStack> ret = ForgeEventFactory.onArrowNock(stack, level, player, hand, true);
        if (ret != null) {
            return ret;
        } else {
            boolean flag = player.isCreative() || EnchantmentHelper.getItemEnchantmentLevel(Enchantments.INFINITY_ARROWS, stack) > 0;
            if (!flag
                && !ItemUtils.hasItem(player.getInventory().items, (Item)TheTitansRegistries.HARCADIUM_ARROW.get())
                && !ItemUtils.hasItem(player.getInventory().offhand, (Item)TheTitansRegistries.HARCADIUM_ARROW.get())) {
                return InteractionResultHolder.pass(stack);
            } else {
                player.startUsingItem(hand);
                return InteractionResultHolder.consume(stack);
            }
        }
    }

    public void releaseUsing(ItemStack stack, Level level, LivingEntity entity, int time) {
        Player player = (Player)entity;
        boolean flag = player.isCreative() || EnchantmentHelper.getItemEnchantmentLevel(Enchantments.INFINITY_ARROWS, stack) > 0;
        if (flag
            || ItemUtils.hasItem(player.getInventory().items, (Item)TheTitansRegistries.HARCADIUM_ARROW.get())
            || ItemUtils.hasItem(player.getInventory().offhand, (Item)TheTitansRegistries.HARCADIUM_ARROW.get())) {
            int max = this.getUseDuration(stack);
            int j = max - time;
            float f = (float)j / 20.0F;
            f = (f * f + f * 2.0F) / 3.0F;
            if ((double)f < 0.1) {
                return;
            }

            if ((double)f > 1.0) {
                f = 1.0F;
            }

            EntityHarcadiumArrow arrow = new EntityHarcadiumArrow(level);
            arrow.setPos(player.getX(), player.getEyeY(), player.getZ());
            arrow.shootFromRotation(player, player.getXRot(), player.getYRot(), 0.0F, f * 3.0F, 1.0F);
            arrow.setBaseDamage(30.0);
            arrow.setOwner(player);
            if (f == 1.0F) {
                arrow.setCritArrow(true);
            }

            int k = EnchantmentHelper.getItemEnchantmentLevel(Enchantments.POWER_ARROWS, stack);
            if (k > 0) {
                arrow.setBaseDamage(arrow.getBaseDamage() + (double)k * 100.0);
            }

            int l = EnchantmentHelper.getItemEnchantmentLevel(Enchantments.PUNCH_ARROWS, stack);
            if (l > 0) {
                arrow.setKnockback(l * 3);
            }

            if (EnchantmentHelper.getItemEnchantmentLevel(Enchantments.FLAMING_ARROWS, stack) > 0) {
                arrow.setSecondsOnFire(500);
            }

            stack.hurtAndBreak(1, player, p -> {
            });
            if (flag) {
                arrow.pickup = Pickup.CREATIVE_ONLY;
            } else if (ItemUtils.hasItem(player.getInventory().offhand, (Item)TheTitansRegistries.HARCADIUM_ARROW.get())) {
                for (ItemStack itemStack : player.getInventory().offhand) {
                    if (itemStack.is((Item)TheTitansRegistries.HARCADIUM_ARROW.get())) {
                        itemStack.shrink(1);
                        break;
                    }
                }
            } else {
                for (ItemStack itemStackx : player.getInventory().items) {
                    if (itemStackx.is((Item)TheTitansRegistries.HARCADIUM_ARROW.get())) {
                        itemStackx.shrink(1);
                        break;
                    }
                }
            }

            if (!level.isClientSide()) {
                level.addFreshEntity(arrow);
            }

            level.playSound(
                player,
                player.getX(),
                player.getY(),
                player.getZ(),
                SoundEvents.ARROW_SHOOT,
                SoundSource.PLAYERS,
                1.0F,
                1.0F / (level.random.nextFloat() * 0.4F + 1.2F) + 0.5F
            );
            player.awardStat(Stats.ITEM_USED.get(this));
        }
    }

    public AbstractArrow customArrow(AbstractArrow arrow) {
        return new EntityHarcadiumArrow(arrow.level());
    }
}
