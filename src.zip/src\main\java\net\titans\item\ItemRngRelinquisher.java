package net.titans.item;

import java.util.List;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.boss.enderdragon.EnderDragon;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item.Properties;
import net.minecraft.world.level.Level;
import net.titans.loader.TheTitansDimensions;

public class ItemRngRelinquisher extends Item {
    public ItemRngRelinquisher(Properties properties) {
        super(properties.stacksTo(1));
    }

    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (!player.level().isClientSide()) {
            if (player.level().dimension() == Level.END) {
                List<EnderDragon> entities = player.level().getEntitiesOfClass(EnderDragon.class, player.getBoundingBox().inflate(1024.0, 1024.0, 1024.0));
                if (!entities.isEmpty()) {
                    player.sendSystemMessage(Component.translatable("item.titan.rng_relinquisher.end.killdragon"));
                } else {
                    if (player.getX() < 5.0 && player.getX() > -5.0 && player.getZ() < 5.0 && player.getZ() > -5.0) {
                        player.sendSystemMessage(Component.translatable("item.titan.rng_relinquisher.end.to"));
                        player.push(0.0, 3.0, 0.0);
                        ServerLevel serverLevel = (ServerLevel)player.level();
                        MinecraftServer server = serverLevel.getServer();
                        ServerLevel voidLevel = server.getLevel(TheTitansDimensions.THE_NOWHERE);
                        BlockPos spawnPos = voidLevel.getSharedSpawnPos();
                        ((ServerPlayer)player)
                            .teleportTo(voidLevel, (double)spawnPos.getX(), 128.0, (double)spawnPos.getZ(), player.getYRot(), player.getXRot());
                        return InteractionResultHolder.success(stack);
                    }

                    player.sendSystemMessage(Component.translatable("item.titan.rng_relinquisher.end.pos"));
                }
            } else if (player.level().dimension() == TheTitansDimensions.THE_NOWHERE) {
                player.sendSystemMessage(Component.translatable("item.titan.rng_relinquisher.nowhere"));
            } else {
                player.sendSystemMessage(Component.translatable("item.titan.rng_relinquisher.other"));
            }
        }

        return InteractionResultHolder.consume(stack);
    }
}
