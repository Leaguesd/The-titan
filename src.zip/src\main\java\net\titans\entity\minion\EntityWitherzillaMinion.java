package net.titans.entity.minion;

import java.util.List;
import javax.annotation.Nullable;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.Mth;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity.RemovalReason;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier.Builder;
import net.minecraft.world.entity.ai.goal.RangedAttackGoal;
import net.minecraft.world.entity.boss.wither.WitherBoss;
import net.minecraft.world.entity.projectile.WitherSkull;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import net.titans.entity.ai.EntityAINearestTargetTitan;
import net.titans.entity.titan.EntityTitan;
import net.titans.entity.titan.EntityWitherzilla;
import net.titans.loader.TheTitansEntities;
import net.titans.loader.TheTitansPredicateTargets;

public class EntityWitherzillaMinion extends WitherBoss implements IMinion {
    private static final EntityDataAccessor<Integer> MINION_TYPE = SynchedEntityData.defineId(EntityWitherzillaMinion.class, EntityDataSerializers.INT);
    public EntityTitan master;

    public EntityWitherzillaMinion(EntityType<? extends EntityWitherzillaMinion> entityType, Level level) {
        super(entityType, level);
        this.xpReward = 20;
    }

    public EntityWitherzillaMinion(Level level) {
        this((EntityType<? extends EntityWitherzillaMinion>)TheTitansEntities.WITHERZILLA_MINION.get(), level);
    }

    public static Builder createAttributes() {
        return WitherBoss.createAttributes().add(Attributes.MAX_HEALTH, 300.0).add(Attributes.MOVEMENT_SPEED, 0.6).add(Attributes.FOLLOW_RANGE, 64.0);
    }

    protected void registerGoals() {
        super.registerGoals();
        this.goalSelector.addGoal(2, new RangedAttackGoal(this, 1.0, 40, 64.0F));
        this.targetSelector
            .addGoal(0, new EntityAINearestTargetTitan<LivingEntity>(this, LivingEntity.class, 0, false, false, TheTitansPredicateTargets.Witherzilla));
    }

    @Override
    public int getMinionTypeInt() {
        return (Integer)this.getEntityData().get(MINION_TYPE);
    }

    @Override
    public void setMinionType(int minionType) {
        this.getEntityData().set(MINION_TYPE, minionType);
        this.refreshAttributes();
    }

    @Override
    public EntityTitan getMaster() {
        return this.master;
    }

    @Override
    public void setMaster(EntityTitan master) {
        this.master = master;
    }

    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(MINION_TYPE, 0);
    }

    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        this.setMinionType(tag.getInt("MinionType"));
    }

    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putInt("MinionType", this.getMinionTypeInt());
    }

    private double getHeadX(int head) {
        if (head <= 0) {
            return this.getX();
        } else {
            float f = (this.yBodyRot + (float)(180 * (head - 1))) * (float) (Math.PI / 180.0);
            float f1 = Mth.cos(f);
            return this.getX() + (double)f1 * 1.3 * (double)this.getScale();
        }
    }

    private double getHeadY(int head) {
        float f = head <= 0 ? 3.0F : 2.2F;
        return this.getY() + (double)(f * this.getScale());
    }

    private double getHeadZ(int head) {
        if (head <= 0) {
            return this.getZ();
        } else {
            float f = (this.yBodyRot + (float)(180 * (head - 1))) * (float) (Math.PI / 180.0);
            float f1 = Mth.sin(f);
            return this.getZ() + (double)f1 * 1.3 * (double)this.getScale();
        }
    }

    @Override
    public EnumMinionType getMinionType() {
        return EnumMinionType.LOYALIST;
    }

    public boolean canAttack(LivingEntity target) {
        return this.getMaster() != null ? this.getMaster().canAttack(target) : target.canBeSeenByAnyone() && this.canAttackEntity(target);
    }

    public boolean canAttackType(EntityType<?> entityType) {
        return entityType != TheTitansEntities.WITHERZILLA.get()
            && entityType != TheTitansEntities.WITHER_SKELETON_TITAN_MINION.get()
            && entityType != TheTitansEntities.WITHER_TURRET.get()
            && entityType != TheTitansEntities.WITHER_TURRET_GROUND.get()
            && entityType != TheTitansEntities.WITHER_TURRET_MORTAR.get();
    }

    public boolean fireImmune() {
        return true;
    }

    protected SoundEvent getAmbientSound() {
        return SoundEvents.WITHER_AMBIENT;
    }

    protected SoundEvent getHurtSound(DamageSource damageSource) {
        return SoundEvents.WITHER_HURT;
    }

    protected SoundEvent getDeathSound() {
        return SoundEvents.WITHER_DEATH;
    }

    public void remove(RemovalReason reason) {
        super.remove(reason);
        if (this.getMaster() != null) {
            this.getMaster().retractMinionNumFromType(this.getMinionType());
        }
    }

    public void setTarget(@Nullable LivingEntity target) {
        if (target != this) {
            if (this.getMaster() != null) {
                if (!this.getMaster().canAttackEntity(target, true)) {
                    return;
                }
            } else if (!this.canAttackEntity(target, true)) {
                return;
            }

            super.setTarget(target);
        }
    }

    public boolean hurt(DamageSource damageSource, float amount) {
        Entity entity = damageSource.getEntity();
        if (this.isInvulnerable()) {
            return false;
        } else if (!(entity instanceof EntityWitherzillaMinion) && !(entity instanceof EntityWitherzilla)) {
            if (entity instanceof LivingEntity livingEntity && this.canAttack(livingEntity)) {
                for (Entity minionEntity : this.level().getEntities(this, this.getBoundingBox().inflate(32.0, 32.0, 32.0))) {
                    if (minionEntity instanceof EntityWitherzillaMinion witherzillaMinion) {
                        witherzillaMinion.setTarget(livingEntity);

                        for (int i = 0; i < 3; i++) {
                            witherzillaMinion.setAlternativeTarget(i, livingEntity.getId());
                        }
                    }

                    this.setTarget(livingEntity);

                    for (int i = 0; i < 3; i++) {
                        this.setAlternativeTarget(i, livingEntity.getId());
                    }
                }
            }

            return super.hurt(damageSource, amount);
        } else {
            return false;
        }
    }

    public void performRangedAttack(int head, double x, double y, double z, boolean isDangerous) {
        if (!this.isSilent()) {
            this.level().levelEvent(null, 1024, this.blockPosition(), 0);
        }

        double d0 = this.getHeadX(head);
        double d1 = this.getHeadY(head);
        double d2 = this.getHeadZ(head);
        double d3 = x - d0;
        double d4 = y - d1;
        double d5 = z - d2;
        Vec3 vec3 = new Vec3(d3, d4, d5);
        WitherSkull witherskull = new WitherSkull(this.level(), this, vec3.x, vec3.y, vec3.z);
        witherskull.setOwner(this);
        if (isDangerous) {
            witherskull.setDangerous(true);
        }

        witherskull.setPosRaw(d0, d1, d2);
        this.level().addFreshEntity(witherskull);
    }

    public void performRangedAttack(int head, LivingEntity target) {
        this.performRangedAttack(
            head, target.getX(), target.getY() + (double)target.getEyeHeight() * 0.5, target.getZ(), head == 0 && this.random.nextFloat() < 0.001F
        );
    }

    public void performRangedAttack(LivingEntity target, float velocity) {
        this.performRangedAttack(0, target);
    }

    public void aiStep() {
        super.aiStep();
        if (this.getMaster() != null) {
            if (this.getMaster().getTarget() != null) {
                this.setTarget(this.getMaster().getTarget());
            } else if (this.distanceToSqr(this.getMaster()) > 10000.0) {
                this.getMoveControl().setWantedPosition(this.getMaster().getX(), this.getMaster().getY(), this.getMaster().getZ(), 2.0);
            }
        } else {
            List<EntityTitan> entities = this.level().getEntitiesOfClass(EntityTitan.class, this.getBoundingBox().inflate(256.0, 256.0, 256.0));
            if (!entities.isEmpty()) {
                for (EntityTitan entity : entities) {
                    if (entity != null && entity instanceof EntityWitherzilla) {
                        this.setMaster(entity);
                    }
                }
            }
        }
    }
}
