package net.titans.render.layer;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.titans.entity.titan.EntityWitherzilla;
import net.titans.model.ModelWitherzilla;

@OnlyIn(Dist.CLIENT)
public class LayerWitherzillaArmor extends RenderLayer<EntityWitherzilla, ModelWitherzilla> {
    private static final ResourceLocation DISINTIGRATION = ResourceLocation.tryBuild("titan", "textures/entity/disintigration.png");
    private static final ResourceLocation WITHERZILLA_AURA = ResourceLocation.tryBuild("titan", "textures/entity/titans/witherzilla_aura.png");
    public ModelWitherzilla model = new ModelWitherzilla(0.0F);

    public LayerWitherzillaArmor(RenderLayerParent<EntityWitherzilla, ModelWitherzilla> renderer) {
        super(renderer);
    }

    public void render(
        PoseStack poseStack,
        MultiBufferSource multiBufferSource,
        int packedLight,
        EntityWitherzilla entity,
        float limbSwing,
        float limbSwingAmount,
        float partialTicks,
        float ageInTicks,
        float netHeadYaw,
        float headPitch
    ) {
        int i = entity.getInvulTime();
        // 和原版一致的 aura 判定：正常状态，或重生闪烁的高亮半周期
        boolean usingAura = i <= 0 || (i <= 300 && i / 10 % 2 == 1);

        // 非 Omega 形态（虚空维度）不绘制 aura，但保留 DISINTIGRATION 的
        // 重生闪烁 / 死亡崩解效果，所以只跳过 aura 那一支
        if (usingAura && !entity.isInOmegaForm()) {
            return;
        }

        float f = (float)entity.tickCount + partialTicks;
        this.model.prepareMobModel(entity, limbSwing, limbSwingAmount, partialTicks);
        ((ModelWitherzilla)this.getParentModel()).copyPropertiesTo(this.model);
        VertexConsumer vertexconsumer = multiBufferSource.getBuffer(
            RenderType.energySwirl(usingAura ? WITHERZILLA_AURA : DISINTIGRATION, f * 0.015F % 1.0F, f * 0.01F % 1.0F)
        );
        this.model.setupAnim(entity, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch);
        this.model.renderToBuffer(poseStack, vertexconsumer, packedLight, OverlayTexture.NO_OVERLAY, 1.0F, 1.0F, 1.0F, 1.0F);
    }

    protected float xOffset(float tickCount) {
        return Mth.cos(tickCount * 0.02F) * 5.0F;
    }
}