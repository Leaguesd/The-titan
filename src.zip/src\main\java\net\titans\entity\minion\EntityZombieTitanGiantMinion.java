package net.titans.entity.minion;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.BlockParticleOption;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.Entity.RemovalReason;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier.Builder;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.monster.Creeper;
import net.minecraft.world.entity.monster.Giant;
import net.minecraft.world.entity.monster.Zombie.ZombieGroupData;
import net.minecraft.world.entity.npc.Villager;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraftforge.event.ForgeEventFactory;
import net.titans.entity.ai.EntityAINearestTargetTitan;
import net.titans.entity.titan.EntityTitan;
import net.titans.entity.titan.EntityZombieTitan;
import net.titans.entity.titan.EntityZombifiedPiglinTitan;
import net.titans.loader.TheTitansEntities;
import net.titans.loader.TheTitansPredicateTargets;

public class EntityZombieTitanGiantMinion extends Giant implements IMinion {
    private static final EntityDataAccessor<Integer> MINION_TYPE = SynchedEntityData.defineId(
        EntityZombieTitanGiantMinion.class, EntityDataSerializers.INT
    );
    public EntityTitan master;

    public EntityZombieTitanGiantMinion(EntityType<? extends EntityZombieTitanGiantMinion> entityType, Level level) {
        super(entityType, level);
        this.xpReward = 1000;
        this.setPersistenceRequired();
    }

    public EntityZombieTitanGiantMinion(Level level) {
        this((EntityType<? extends EntityZombieTitanGiantMinion>)TheTitansEntities.ZOMBIE_TITAN_GIANT_MINION.get(), level);
    }

    public static Builder createAttributes() {
        return Giant.createAttributes()
            .add(Attributes.MAX_HEALTH, 2000.0)
            .add(Attributes.FOLLOW_RANGE, 48.0)
            .add(Attributes.KNOCKBACK_RESISTANCE, 1.0)
            .add(Attributes.KNOCKBACK_RESISTANCE, 1.0);
    }

    protected void registerGoals() {
        super.registerGoals();
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.targetSelector.addGoal(1, new HurtByTargetGoal(this, new Class[0]));
        this.targetSelector
            .addGoal(0, new EntityAINearestTargetTitan<LivingEntity>(this, LivingEntity.class, 0, false, false, TheTitansPredicateTargets.ZombieTitan));
    }

    @Override
    public int getMinionTypeInt() {
        return (Integer)this.getEntityData().get(MINION_TYPE);
    }

    @Override
    public void setMinionType(int minionType) {
        this.getEntityData().set(MINION_TYPE, minionType);
        this.refreshAttributes();
    }

    @Override
    public EntityTitan getMaster() {
        return this.master;
    }

    @Override
    public void setMaster(EntityTitan master) {
        this.master = master;
    }

    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(MINION_TYPE, 0);
    }

    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        this.setMinionType(tag.getInt("MinionType"));
    }

    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putInt("MinionType", this.getMinionTypeInt());
    }

    private LivingEntity doJumpDamage(double x, double y, double z, double distance, double damage, int knockback) {
        AABB aabb = new AABB(x - distance, y - 10.0, z - distance, x + distance, y + 10.0, z + distance);
        List<LivingEntity> entities = this.level().getEntitiesOfClass(LivingEntity.class, aabb, TheTitansPredicateTargets.ZombieTitan);
        Collections.sort(entities, new EntityZombieTitanGiantMinion.TargetingSorter(this));

        for (LivingEntity entity : entities) {
            if (entity != null
                && entity != this
                && entity.isAlive()
                && !(entity instanceof EntityZombieTitan)
                && !(entity instanceof EntityZombieTitanMinion)
                && !(entity instanceof EntityZombieTitanGiantMinion)) {
                entity.hurt(this.damageSources().explosion(null), (float)damage);
                entity.hurt(this.damageSources().fall(), (float)damage / 4.0F);
                this.level()
                    .playSound(
                        entity,
                        entity.blockPosition(),
                        SoundEvents.GENERIC_EXPLODE,
                        SoundSource.MASTER,
                        0.85F,
                        1.0F + (this.random.nextFloat() - this.random.nextFloat()) * 0.5F
                    );
                if (knockback != 0) {
                    double ks = 0.75 + this.random.nextDouble() + this.random.nextDouble();
                    double inair = 0.75;
                    float f3 = (float)Math.atan2(entity.getZ() - this.getZ(), entity.getX() - this.getX());
                    entity.push(Math.cos((double)f3) * ks, inair, Math.sin((double)f3) * ks);
                    if (this.random.nextInt(5) == 0) {
                        entity.invulnerableTime = 0;
                    }
                }
            }
        }

        return null;
    }

    protected void dropRareDrop(int count) {
    }

    protected void dropFewItems(boolean attackedRecently, int loottingLevel) {
        int j = this.random.nextInt(13) + this.random.nextInt(1 + loottingLevel);

        for (int k = 0; k < j; k++) {
            this.spawnAtLocation(Items.FEATHER, 1);
        }

        j = this.random.nextInt(13) + this.random.nextInt(2 + loottingLevel);

        for (int var6 = 0; var6 < j; var6++) {
            this.spawnAtLocation(Items.ROTTEN_FLESH, 1);
        }

        if (attackedRecently) {
            if (this.random.nextInt(5) == 0 || this.random.nextInt(1 + loottingLevel) > 0) {
                this.spawnAtLocation(Items.IRON_INGOT, 1);
            }

            if (this.random.nextInt(5) == 0 || this.random.nextInt(1 + loottingLevel) > 0) {
                this.spawnAtLocation(Items.CARROT, 1);
            }

            if (this.random.nextInt(5) == 0 || this.random.nextInt(1 + loottingLevel) > 0) {
                this.spawnAtLocation(Items.POTATO, 1);
            }
        }
    }

    @Override
    public EnumMinionType getMinionType() {
        return EnumMinionType.SPECIAL;
    }

    public boolean fireImmune() {
        return true;
    }

    public boolean canAttack(LivingEntity target) {
        return this.getMaster() != null ? this.getMaster().canAttack(target) : target.canBeSeenByAnyone() && this.canAttackEntity(target);
    }

    public boolean canAttackType(EntityType<?> entityType) {
        return entityType != TheTitansEntities.ZOMBIE_TITAN.get()
            && entityType != TheTitansEntities.ZOMBIE_TITAN_MINION.get()
            && entityType != TheTitansEntities.ZOMBIE_TITAN_GIANT_MINION.get();
    }

    public int getArmorValue() {
        return 20;
    }

    public float getWalkTargetValue(BlockPos pos, LevelReader level) {
        return -this.level().getPathfindingCostFromLightLevels(pos);
    }

    public int getMaxSpawnClusterSize() {
        return 1;
    }

    protected SoundEvent getAmbientSound() {
        return SoundEvents.ZOMBIE_AMBIENT;
    }

    protected SoundEvent getHurtSound(DamageSource damageSource) {
        return SoundEvents.ZOMBIE_HURT;
    }

    protected SoundEvent getDeathSound() {
        return SoundEvents.ZOMBIE_DEATH;
    }

    public float getSoundVolume() {
        return 7.0F;
    }

    public float getVoicePitch() {
        return this.isBaby()
            ? (this.random.nextFloat() - this.random.nextFloat()) * 0.1F + 1.0F
            : (this.random.nextFloat() - this.random.nextFloat()) * 0.1F + 0.5F;
    }

    protected void playStepSound(BlockPos pos, BlockState state) {
        this.playSound(SoundEvents.IRON_GOLEM_STEP, 2.0F, 0.9F);
        double dx = this.getX() + 4.0 * -Math.sin(Math.toRadians((double)this.yBodyRot));
        double dz = this.getZ() - 4.0 * -Math.cos(Math.toRadians((double)this.yBodyRot));
        this.doJumpDamage(dx, this.getY(), dz, 6.0, (double)(10 + this.random.nextInt(90)), 1);
    }

    public void remove(RemovalReason reason) {
        super.remove(reason);
        if (this.getMaster() != null) {
            this.getMaster().retractMinionNumFromType(this.getMinionType());
        }
    }

    public void setTarget(@Nullable LivingEntity target) {
        if (target != this) {
            if (this.getMaster() != null) {
                if (!this.getMaster().canAttackEntity(target, true)) {
                    return;
                }
            } else if (!this.canAttackEntity(target, true)) {
                return;
            }

            super.setTarget(target);
        }
    }

    public boolean killedEntity(ServerLevel level, LivingEntity entity) {
        if ((double)entity.getMaxHealth() <= 100.0) {
            entity.push(0.0, 15.0, 0.0);
        }

        this.heal(this.level().isDay() ? 5.0F + this.random.nextFloat() * 15.0F : 15.0F + this.random.nextFloat() * 30.0F);
        if (entity instanceof Villager villager) {
            EntityZombieTitanMinion zombieVillager = new EntityZombieTitanMinion(level);
            zombieVillager.copyPosition(villager);
            zombieVillager.setBaby(villager.isBaby());
            zombieVillager.setNoAi(villager.isNoAi());
            if (villager.hasCustomName()) {
                zombieVillager.setCustomName(villager.getCustomName());
                zombieVillager.setCustomNameVisible(villager.isCustomNameVisible());
            }

            if (villager.isPersistenceRequired()) {
                zombieVillager.setPersistenceRequired();
            }

            zombieVillager.setInvulnerable(villager.isInvulnerable());
            this.level().addFreshEntity(zombieVillager);
            if (villager.isPassenger()) {
                Entity vehicle = villager.getVehicle();
                villager.stopRiding();
                zombieVillager.startRiding(vehicle, true);
            }

            if (!villager.isRemoved()) {
                villager.discard();
            }

            if (zombieVillager != null) {
                zombieVillager.finalizeSpawn(level, level.getCurrentDifficultyAt(zombieVillager.blockPosition()), MobSpawnType.CONVERSION, new ZombieGroupData(false, true), null);
                zombieVillager.setVillager(true);
                ForgeEventFactory.onLivingConvert(entity, zombieVillager);
                if (!this.isSilent()) {
                    level.levelEvent(null, 1026, this.blockPosition(), 0);
                }

                return false;
            }
        }

        return super.killedEntity(level, entity);
    }

    public boolean doHurtTarget(Entity entity) {
        boolean flag = super.doHurtTarget(entity);
        if (flag && entity instanceof LivingEntity livingEntity) {
            if (livingEntity.onGround()) {
                double ks = 1.25;
                double inair = 1.25;
                float f3 = (float)Math.atan2(livingEntity.getZ() - this.getZ(), livingEntity.getX() - this.getX());
                livingEntity.push(Math.cos((double)f3) * ks, inair, Math.sin((double)f3) * ks);
            } else {
                double ks = 3.0;
                double inair = 0.25;
                float f3 = (float)Math.atan2(livingEntity.getZ() - this.getZ(), livingEntity.getX() - this.getX());
                livingEntity.push(Math.cos((double)f3) * ks, inair, Math.sin((double)f3) * ks);
            }

            return true;
        } else {
            return false;
        }
    }

    public boolean hurt(DamageSource damageSource, float amount) {
        Entity entity = damageSource.getEntity();
        if (this.isInvulnerable()) {
            return false;
        } else if (!(entity instanceof EntityZombieTitanMinion) && (!(entity instanceof EntityZombieTitan) || entity instanceof EntityZombifiedPiglinTitan)) {
            if (entity instanceof LivingEntity livingEntity && this.canAttack(livingEntity)) {
                this.setTarget(livingEntity);
                this.setYRot(this.yHeadRot);
                this.setYBodyRot(this.yHeadRot);
                this.push(0.0, 1.25, 0.0);
                this.setPos(this.getX(), this.getY() + 1.55F, this.getZ());
                double d1 = this.getTarget().getX() - this.getX();
                double d2 = this.getTarget().getZ() - this.getZ();
                float d = (float)Math.atan2(d2, d1);
                this.lookAt(this.getTarget(), 10.0F, (float)this.getHeadRotSpeed());
                d1 = Math.sqrt(d1 * d1 + d2 * d2);
                if (this.distanceToSqr(this.getTarget()) > (double)((10.0F + this.getTarget().getBbWidth() / 2.0F) * (10.0F + this.getTarget().getBbWidth() / 2.0F)) + 45.0) {
                    this.push(d1 * 0.05 * Math.cos((double)d), 0.0, d1 * 0.05 * Math.sin((double)d));
                }
            }

            return super.hurt(damageSource, amount);
        } else {
            return false;
        }
    }

    public boolean causeFallDamage(float fallDistance, float multiplier, DamageSource damageSource) {
        return false;
    }

    public void aiStep() {
        super.aiStep();
        if (this.getDeltaMovement().y < -0.95) {
            double df = 1.0;
            if (this.getDeltaMovement().y < -1.5) {
                df = 1.5;
            }

            this.doJumpDamage(this.getX(), this.getY(), this.getZ(), 12.0, 100.0 * df, 0);
            this.doJumpDamage(this.getX(), this.getY(), this.getZ(), 14.0, 50.0 * df, 0);
            this.doJumpDamage(this.getX(), this.getY(), this.getZ(), 16.0, 25.0 * df, 0);
        }

        if (this.getTarget() != null) {
            this.getLookControl().setLookAt(this.getTarget(), 10.0F, 40.0F);
            if (this.onGround()) {
                this.getMoveControl().setWantedPosition(this.getTarget().getX(), this.getTarget().getY(), this.getTarget().getZ(), 1.0);
            }

            if (this.tickCount % 30 == 0 && this.level().getRandom().nextInt(3) == 0) {
                this.setYRot(this.yHeadRot);
                this.setYBodyRot(this.yHeadRot);
                this.push(0.0, 1.25, 0.0);
                this.setPos(this.getX(), this.getY() + 1.55F, this.getZ());
                double d1 = this.getTarget().getX() - this.getX();
                double d2 = this.getTarget().getZ() - this.getZ();
                float d = (float)Math.atan2(d2, d1);
                this.lookAt(this.getTarget(), 10.0F, (float)this.getHeadRotSpeed());
                d1 = Math.sqrt(d1 * d1 + d2 * d2);
                if (this.distanceToSqr(this.getTarget()) > (double)((10.0F + this.getTarget().getBbWidth() / 2.0F) * (10.0F + this.getTarget().getBbWidth() / 2.0F)) + 45.0) {
                    this.push(d1 * 0.05 * Math.cos((double)d), 0.0, d1 * 0.05 * Math.sin((double)d));
                }
            }

            if (this.tickCount % 20 == 0
                && this.distanceToSqr(this.getTarget()) <= (double)((14.0F + this.getTarget().getBbWidth() / 2.0F) * (14.0F + this.getTarget().getBbWidth() / 2.0F))) {
                this.doHurtTarget(this.getTarget());
            }
        }

        if (this.getMaster() != null) {
            if (this.horizontalCollision) {
                this.setDeltaMovement(this.getDeltaMovement().x, 0.2, this.getDeltaMovement().z);
            }

            if (this.getMaster().getTarget() != null) {
                this.setTarget(this.getMaster().getTarget());
            } else if (this.distanceToSqr(this.getMaster()) > 5000.0) {
                this.getMoveControl().setWantedPosition(this.getMaster().getX(), this.getMaster().getY(), this.getMaster().getZ(), 2.0);
            }
        } else {
            List<EntityTitan> entities = this.level().getEntitiesOfClass(EntityTitan.class, this.getBoundingBox().inflate(100.0, 100.0, 100.0));
            if (!entities.isEmpty()) {
                for (EntityTitan entity : entities) {
                    if (entity != null && entity instanceof EntityZombieTitan) {
                        this.setMaster(entity);
                    }
                }
            }
        }
    }

    protected void dropAllDeathLoot(DamageSource damageSource) {
        super.dropAllDeathLoot(damageSource);
    }

    public void tick() {
        super.tick();
        this.noCulling = true;
        if (this.tickCount % 20 == 0 && (!this.level().isDay() || this.random.nextInt(5) == 0)) {
            this.heal(this.level().isDay() ? 1.0F + this.random.nextFloat() * 4.0F : 5.0F + this.random.nextFloat() * 15.0F);
        }

        if (this.getDeltaMovement().x != 0.0 && this.getDeltaMovement().z != 0.0 && this.random.nextInt(5) == 0) {
            int i = Mth.floor(this.getX());
            int j = Mth.floor(this.getY() - 0.2F);
            int k = Mth.floor(this.getZ());
            BlockPos blockPos = new BlockPos(i, j, k);
            BlockState blockState = this.level().getBlockState(blockPos);
            if (!blockState.isAir()) {
                this.level()
                    .addParticle(
                        new BlockParticleOption(ParticleTypes.BLOCK, blockState),
                        this.getX() + ((double)this.random.nextFloat() - 0.5) * (double)this.getBbWidth(),
                        this.getBoundingBox().minY + 0.1,
                        this.getZ() + ((double)this.random.nextFloat() - 0.5) * (double)this.getBbWidth(),
                        4.0 * ((double)this.random.nextFloat() - 0.5),
                        0.5,
                        ((double)this.random.nextFloat() - 0.5) * 4.0
                    );
            }
        }
    }

    public class TargetingSorter implements Comparator<Entity> {
        private Entity entity;

        public TargetingSorter(Entity entity) {
            this.entity = entity;
        }

        public int compare(Entity entity1, Entity entity2) {
            double weight = 0.0;
            double var3 = this.entity.distanceToSqr(entity1);
            if (entity1 instanceof Creeper) {
                var3 /= 2.0;
            }

            weight = (double)(entity1.getBbHeight() * entity1.getBbWidth());
            if (weight > 1.0) {
                var3 /= weight;
            }

            double var5 = this.entity.distanceToSqr(entity2);
            if (entity2 instanceof Creeper) {
                var5 /= 2.0;
            }

            weight = (double)(entity2.getBbHeight() * entity2.getBbWidth());
            if (weight > 1.0) {
                var5 /= weight;
            }

            return var3 > var5 ? 1 : (var3 < var5 ? -1 : 0);
        }
    }
}
