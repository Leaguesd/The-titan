package net.titans.gen;

public interface IChunkGeneratorGenStructures {
    default IChunkGeneratorGenStructures.GenStructuresBoolean shouldGenerateStructures() {
        return IChunkGeneratorGenStructures.GenStructuresBoolean.DEFAULT;
    }

    public static enum GenStructuresBoolean {
        DEFAULT,
        TRUE,
        FALSE;
    }
}
