package net.titans.effect;

import java.awt.Color;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity.RemovalReason;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level.ExplosionInteraction;
import net.titans.entity.titan.EntityTitan;
import net.titans.entity.titan.EntityTitanSpirit;

public class MobEffectDeath extends MobEffect {
    public MobEffectDeath() {
        super(MobEffectCategory.HARMFUL, new Color(0.0F, 0.0F, 0.0F, 1.0F).getRGB());
    }

    public boolean isDurationEffectTick(int duration, int amplifier) {
        int k = 40 >> amplifier;
        return k > 0 ? duration % k == 0 : true;
    }

    public void applyEffectTick(LivingEntity entity, int amplifier) {
        if (entity.isAlive()) {
            entity.setRemainingFireTicks(20);
            entity.hurt(entity.damageSources().fellOutOfWorld(), 4.0F * (float)(amplifier + 1));
            if (entity.deathTime > 0) {
                entity.deathTime++;
                if (entity.deathTime > 20 && !entity.level().isClientSide()) {
                    entity.level().broadcastEntityEvent(entity, (byte)60);
                    entity.remove(RemovalReason.KILLED);
                }
            }

            if (entity.getMaxHealth() > 1.0E9F && !(entity instanceof EntityTitan) && !(entity instanceof EntityTitanSpirit) && !(entity instanceof Player)) {
                entity.playSound(SoundEvents.GENERIC_EXPLODE, 2.0F, 1.0F + entity.level().random.nextFloat());
                entity.setHealth(entity.getHealth() / 2.0F);
                if (entity.getHealth() <= 1.0F) {
                    entity.level().explode(null, entity.getX(), entity.getY(), entity.getZ(), 7.0F, false, ExplosionInteraction.MOB);
                    if (!entity.level().isClientSide()) {
                        entity.level().broadcastEntityEvent(entity, (byte)60);
                        entity.remove(RemovalReason.KILLED);
                    }
                }
            }
        }
    }
}
