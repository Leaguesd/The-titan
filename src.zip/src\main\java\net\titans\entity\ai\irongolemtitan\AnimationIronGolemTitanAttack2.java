package net.titans.entity.ai.irongolemtitan;

import net.titans.animation.AIAnimation;
import net.titans.entity.titan.EntityIronGolemTitan;

public class AnimationIronGolemTitanAttack2 extends AIAnimation {
    private EntityIronGolemTitan entity;

    public AnimationIronGolemTitanAttack2(EntityIronGolemTitan entity) {
        super(entity);
        this.entity = entity;
    }

    @Override
    public int getAnimationID() {
        return 7;
    }

    @Override
    public boolean isAutomatic() {
        return true;
    }

    @Override
    public int getDuration() {
        return 150;
    }

    @Override
    public boolean canContinueToUse() {
        return this.entity.getAnimationTick() > this.getDuration() ? false : super.canContinueToUse();
    }

    public void tick() {
        if (this.entity.getTarget() != null && this.entity.getAnimationTick() < 60) {
            this.entity.getLookControl().setLookAt(this.entity.getTarget(), 5.0F, 40.0F);
        }
    }
}
