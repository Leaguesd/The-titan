package net.titans.render.minion;

import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider.Context;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.monster.Ghast;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.titans.entity.minion.IMinion;
import net.titans.model.ModelGhastGuard;

@OnlyIn(Dist.CLIENT)
public class RenderGhastTitanMinion extends MobRenderer<Ghast, ModelGhastGuard<Ghast>> {
    public static final ResourceLocation GHAST = new ResourceLocation("minecraft", "textures/entity/ghast/ghast.png");
    public static final ResourceLocation GHAST_SHOOTING = new ResourceLocation("minecraft", "textures/entity/ghast/ghast_shooting.png");
    public static final ResourceLocation GHAST_PRIEST = ResourceLocation.tryBuild("titan", "textures/entity/minions/ghast/ghast_priest.png");
    public static final ResourceLocation GHAST_PRIEST_SHOOTING = ResourceLocation.tryBuild(
        "titan", "textures/entity/minions/ghast/ghast_priest_shooting.png"
    );
    public static final ResourceLocation GHAST_ZEALOT = ResourceLocation.tryBuild("titan", "textures/entity/minions/ghast/ghast_zealot.png");
    public static final ResourceLocation GHAST_ZEALOT_SHOOTING = ResourceLocation.tryBuild(
        "titan", "textures/entity/minions/ghast/ghast_zealot_shooting.png"
    );
    public static final ResourceLocation GHAST_BISHOP = ResourceLocation.tryBuild("titan", "textures/entity/minions/ghast/ghast_bishop.png");
    public static final ResourceLocation GHAST_BISHOP_SHOOTING = ResourceLocation.tryBuild(
        "titan", "textures/entity/minions/ghast/ghast_bishop_shooting.png"
    );
    public static final ResourceLocation GHAST_TEMPLAR = ResourceLocation.tryBuild("titan", "textures/entity/minions/ghast/ghast_templar.png");
    public static final ResourceLocation GHAST_TEMPLAR_SHOOTING = ResourceLocation.tryBuild(
        "titan", "textures/entity/minions/ghast/ghast_templar_shooting.png"
    );

    public RenderGhastTitanMinion(Context context) {
        super(context, new ModelGhastGuard(), 3.0F);
    }

    protected void scale(Ghast entity, PoseStack poseStack, float partialTicks) {
        poseStack.scale(4.5F, 4.5F, 4.5F);
    }

    public ResourceLocation getTextureLocation(Ghast entity) {
        if (entity instanceof IMinion minion) {
            switch (minion.getMinionType()) {
                case PRIEST:
                    return entity.isCharging() ? GHAST_PRIEST_SHOOTING : GHAST_PRIEST;
                case ZEALOT:
                    return entity.isCharging() ? GHAST_ZEALOT_SHOOTING : GHAST_ZEALOT;
                case BISHOP:
                    return entity.isCharging() ? GHAST_BISHOP_SHOOTING : GHAST_BISHOP;
                case TEMPLAR:
                    return entity.isCharging() ? GHAST_TEMPLAR_SHOOTING : GHAST_TEMPLAR;
                default:
                    return entity.isCharging() ? GHAST_SHOOTING : GHAST;
            }
        } else {
            return entity.isCharging() ? GHAST_SHOOTING : GHAST;
        }
    }
}
