package net.titans.loader;

import net.minecraft.world.item.Tier;
import net.minecraft.world.item.crafting.Ingredient;

public enum TheTitansTiers implements Tier {
    HARCADIUM(4, 75000, 120.0F, -1.0F, 30, Ingredient.EMPTY),
    VOID(4, 1000000, 4000.0F, -1.0F, 40, Ingredient.EMPTY),
    ADMINIUM(4, Integer.MAX_VALUE, 1.0E9F, -1.0F, 60, Ingredient.EMPTY),
    ULTIMA(5, Integer.MAX_VALUE, 9999.0F, -1.0F, 0, Ingredient.EMPTY);

    private final int level;
    private final int uses;
    private final float speed;
    private final float damage;
    private final int enchantmentValue;
    private Ingredient repairIngredient;

    private TheTitansTiers(int level, int uses, float speed, float damage, int enchantmentValue, Ingredient repairIngredient) {
        this.level = level;
        this.uses = uses;
        this.speed = speed;
        this.damage = damage;
        this.enchantmentValue = enchantmentValue;
        this.repairIngredient = repairIngredient;
    }

    public int getLevel() {
        return this.level;
    }

    public int getUses() {
        return this.uses;
    }

    public float getSpeed() {
        return this.speed;
    }

    public float getAttackDamageBonus() {
        return this.damage;
    }

    public int getEnchantmentValue() {
        return this.enchantmentValue;
    }

    public Ingredient getRepairIngredient() {
        return this.repairIngredient;
    }

    public void setRepairIngredient(Ingredient repairIngredient) {
        this.repairIngredient = repairIngredient;
    }
}
