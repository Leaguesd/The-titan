package net.titans.item;

import net.minecraft.core.BlockPos;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.HoeItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item.Properties;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.titans.entity.titan.EntityTitan;
import net.titans.loader.TheTitansSounds;
import net.titans.loader.TheTitansTiers;

public class ItemAdminiumHoe extends HoeItem {
    public ItemAdminiumHoe(Properties properties) {
        super(TheTitansTiers.ADMINIUM, 1000000000, Float.MAX_VALUE, properties);
    }

    public boolean isFoil(ItemStack stack) {
        return true;
    }

    public boolean hurtEnemy(ItemStack stack, LivingEntity entity, LivingEntity attacker) {
        if (entity != null && (entity.getBbHeight() >= 6.0F || entity instanceof EntityTitan || !entity.onGround())) {
            entity.playSound((SoundEvent)TheTitansSounds.TITAN_PUNCH.get(), 10.0F, 1.0F);
            entity.hurt(entity.damageSources().mobAttack(attacker), 1.0E9F);
        }

        return super.hurtEnemy(stack, entity, attacker);
    }

    public InteractionResult useOn(UseOnContext context) {
        Level level = context.getLevel();
        Player player = context.getPlayer();
        BlockPos blockPos = context.getClickedPos();
        BlockState blockState = level.getBlockState(blockPos);
        Block block = blockState.getBlock();
        if (level.getBlockState(blockPos.atY(blockPos.getY() + 1)).isAir()
            && (block == Blocks.SPONGE || block == Blocks.WET_SPONGE || block == Blocks.GRAVEL)) {
            level.playSound(player, blockPos, SoundEvents.HOE_TILL, SoundSource.BLOCKS, 1.0F, 1.0F);
            level.setBlockAndUpdate(blockPos, Blocks.FARMLAND.defaultBlockState());
            if (!level.isClientSide() && player != null) {
                context.getItemInHand().hurtAndBreak(1, player, p -> {
                });
            }

            return InteractionResult.sidedSuccess(level.isClientSide());
        } else {
            return super.useOn(context);
        }
    }
}
