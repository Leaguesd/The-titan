package net.titans.mixin;

import java.util.List;
import net.minecraft.client.resources.language.I18n;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.common.util.Size2i;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(
    targets = {"net.minecraftforge.client.gui.ModListScreen$InfoPanel"}
)
public class MixinModListInfoPanel {
    @Inject(
        method = {"setInfo"},
        at = {@At("HEAD")},
        remap = false
    )
    private void localizeTheTitansInfo(List<String> lines, ResourceLocation logoPath, Size2i logoDims, CallbackInfo callbackInfo) {
        if (lines != null && isTheTitansInfo(lines)) {
            for (int i = 0; i < lines.size(); i++) {
                String line = lines.get(i);
                if (line != null
                    && (
                        "titan.modinfo.description".equals(line)
                            || line.contains("titan.modinfo.description")
                            || line.contains("The Titans 1.20.1 Forge")
                            || line.contains("泰坦生物 1.20.1 Forge")
                    )) {
                    lines.set(i, line.replace("titan.modinfo.description", I18n.get("titan.modinfo.description", new Object[0])));
                }
            }

            boolean foundCredits = false;

            for (int ix = 0; ix < lines.size(); ix++) {
                String line = lines.get(ix);
                if (line != null
                    && (
                        "titan.modinfo.credits".equals(line)
                            || line.contains("titan.modinfo.credits")
                            || line.contains("感谢 Aqua3 代码参考")
                            || line.contains("Thanks to Aqua3 for code reference")
                    )) {
                    lines.set(ix, line.replace("titan.modinfo.credits", I18n.get("titan.modinfo.credits", new Object[0])));
                    foundCredits = true;
                }
            }

            if (!foundCredits) {
                lines.add(null);
                lines.add(I18n.get("titan.modinfo.credits", new Object[0]));
            }
        }
    }

    private static boolean isTheTitansInfo(List<String> lines) {
        for (String line : lines) {
            if (line != null && line.contains("titan")) {
                return true;
            }
        }

        return false;
    }
}
