package net.titans.loader;

import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.ItemTags;
import net.minecraft.tags.TagKey;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.EnchantmentCategory;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.RegistryObject;
import net.titans.enchantment.EnchantmentTitan;

/**
 * 原先这里是 7 个 ResourceKey，真正的数值在 data/titan/enchantment/*.json 里。
 * 1.20.1 的附魔不是数据驱动的（data 下没有 enchantments 目录），所以改为代码注册，
 * 物品支持范围仍复用 data 里的标签（titan:enchantable/*）。
 *
 * <p>数值来源（原 JSON -> 参数）：
 * <pre>
 * damage          weight 10, max_level 5,  min 5/8,   max 55/8,   #titan:enchantable/wither_turret
 * healing         weight 10, max_level 5,  min 5/8,   max 55/8,   #titan:enchantable/wither_turret
 * titan_killer    weight 10, max_level 10, min 1/3,   max 31/3,   #titan:enchantable/wither_turret_and_sword
 * knock_up        weight  5, max_level 2,  min 5/20,  max 55/20,  #minecraft:swords
 * shooting_speed  weight  2, max_level 3,  min 12/20, max 62/20,  #titan:enchantable/wither_turret
 * explosive_power weight  2, max_level 2,  min 12/20, max 62/20,  #titan:enchantable/wither_turret
 * skull_speed     weight  1, max_level 1,  min 20/0,  max 50/0,   #titan:enchantable/wither_turret
 * </pre>
 */
public class TheTitansEnchantments {
    public static final DeferredRegister<Enchantment> ENCHANTMENTS =
            DeferredRegister.create(Registries.ENCHANTMENT, "titan");

    public static final TagKey<Item> ENCHANTABLE_WITHER_TURRET =
            ItemTags.create(ResourceLocation.tryBuild("titan", "enchantable/wither_turret"));
    public static final TagKey<Item> ENCHANTABLE_WITHER_TURRET_AND_SWORD =
            ItemTags.create(ResourceLocation.tryBuild("titan", "enchantable/wither_turret_and_sword"));

    public static final RegistryObject<Enchantment> HEALING = ENCHANTMENTS.register(
            "healing",
            () -> new EnchantmentTitan(Enchantment.Rarity.COMMON, EnchantmentCategory.WEAPON,
                    ENCHANTABLE_WITHER_TURRET, 5, 5, 8, 55, 8)
    );

    public static final RegistryObject<Enchantment> DAMAGE = ENCHANTMENTS.register(
            "damage",
            () -> new EnchantmentTitan(Enchantment.Rarity.COMMON, EnchantmentCategory.WEAPON,
                    ENCHANTABLE_WITHER_TURRET, 5, 5, 8, 55, 8)
    );

    public static final RegistryObject<Enchantment> SHOOTING_SPEED = ENCHANTMENTS.register(
            "shooting_speed",
            () -> new EnchantmentTitan(Enchantment.Rarity.RARE, EnchantmentCategory.WEAPON,
                    ENCHANTABLE_WITHER_TURRET, 3, 12, 20, 62, 20)
    );

    public static final RegistryObject<Enchantment> EXPLOSIVE_POWER = ENCHANTMENTS.register(
            "explosive_power",
            () -> new EnchantmentTitan(Enchantment.Rarity.RARE, EnchantmentCategory.WEAPON,
                    ENCHANTABLE_WITHER_TURRET, 2, 12, 20, 62, 20)
    );

    public static final RegistryObject<Enchantment> SKULL_SPEED = ENCHANTMENTS.register(
            "skull_speed",
            () -> new EnchantmentTitan(Enchantment.Rarity.VERY_RARE, EnchantmentCategory.WEAPON,
                    ENCHANTABLE_WITHER_TURRET, 1, 20, 0, 50, 0)
    );

    public static final RegistryObject<Enchantment> KNOCK_UP = ENCHANTMENTS.register(
            "knock_up",
            () -> new EnchantmentTitan(Enchantment.Rarity.UNCOMMON, EnchantmentCategory.WEAPON,
                    ItemTags.SWORDS, 2, 5, 20, 55, 20)
    );

    public static final RegistryObject<Enchantment> TITAN_KILLER = ENCHANTMENTS.register(
            "titan_killer",
            () -> new EnchantmentTitan(Enchantment.Rarity.COMMON, EnchantmentCategory.WEAPON,
                    ENCHANTABLE_WITHER_TURRET_AND_SWORD, 10, 1, 3, 31, 3)
    );

    public static void registerEnchantments(IEventBus modEventBus) {
        ENCHANTMENTS.register(modEventBus);
    }
}
