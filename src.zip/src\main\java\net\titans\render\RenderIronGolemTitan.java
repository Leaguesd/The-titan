package net.titans.render;

import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.LivingEntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider.Context;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.titans.entity.titan.EntityIronGolemTitan;
import net.titans.model.ModelIronGolemTitan;

@OnlyIn(Dist.CLIENT)
public class RenderIronGolemTitan extends LivingEntityRenderer<EntityIronGolemTitan, ModelIronGolemTitan> {
    public static final ResourceLocation IRON_GOLEM_TITAN = ResourceLocation.tryBuild("titan", "textures/entity/titans/iron_golem_titan.png");

    public RenderIronGolemTitan(Context context) {
        super(context, new ModelIronGolemTitan(), 1.0F);
    }

    public void render(
        EntityIronGolemTitan entity, float entityYaw, float partialTicks, PoseStack poseStack, MultiBufferSource multiBufferSource, int packedLight
    ) {
        super.render(entity, entityYaw, partialTicks, poseStack, multiBufferSource, packedLight);
    }

    protected void scale(EntityIronGolemTitan entity, PoseStack poseStack, float partialTick) {
        float f1 = 24.0F;
        int i = entity.getInvulTime();
        if (i > 0) {
            f1 -= ((float)i - partialTick) / 440.0F * 7.75F;
        }

        int i2 = entity.getExtraPower();
        if (i2 > 0) {
            f1 += (float)i2 * 0.5F;
        }

        poseStack.scale(f1, f1, f1);
        poseStack.translate(0.0F, 0.01F, 0.0F);
    }

    protected float getShadowRadius(EntityIronGolemTitan entity) {
        return this.shadowRadius * entity.getBbWidth();
    }

    protected boolean shouldShowName(EntityIronGolemTitan entity) {
        return false;
    }

    public ResourceLocation getTextureLocation(EntityIronGolemTitan entity) {
        return IRON_GOLEM_TITAN;
    }
}
