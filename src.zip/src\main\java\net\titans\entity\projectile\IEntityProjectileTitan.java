package net.titans.entity.projectile;

public interface IEntityProjectileTitan {
    default boolean canExplosionKnockback() {
        return false;
    }
}
