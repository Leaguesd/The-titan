package net.titans.entity.titan;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.Map.Entry;
import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.Mth;
import net.minecraft.world.Difficulty;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.SpawnGroupData;
import net.minecraft.world.entity.Entity.RemovalReason;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier.Builder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.ShovelItem;
import net.minecraft.world.level.ItemLike;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.ServerLevelAccessor;
import net.minecraft.world.level.Level.ExplosionInteraction;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;
import net.titans.entity.EntityColorLightningBolt;
import net.titans.entity.IBossBarDisplay;
import net.titans.entity.ai.EntityAINearestTargetTitan;
import net.titans.entity.ai.omegafish.AnimationOmegafishAntiTitanAttack;
import net.titans.entity.ai.omegafish.AnimationOmegafishAttack1;
import net.titans.entity.ai.omegafish.AnimationOmegafishAttack2;
import net.titans.entity.ai.omegafish.AnimationOmegafishAttack3;
import net.titans.entity.ai.omegafish.AnimationOmegafishBodySlam;
import net.titans.entity.ai.omegafish.AnimationOmegafishBurrow;
import net.titans.entity.ai.omegafish.AnimationOmegafishCreation;
import net.titans.entity.ai.omegafish.AnimationOmegafishDeath;
import net.titans.entity.ai.omegafish.AnimationOmegafishLightningAttack;
import net.titans.entity.ai.omegafish.AnimationOmegafishStunned;
import net.titans.entity.ai.omegafish.AnimationOmegafishTailSmash;
import net.titans.entity.ai.omegafish.AnimationOmegafishUnburrow;
import net.titans.entity.minion.EntityOmegafishMinion;
import net.titans.entity.minion.EnumMinionType;
import net.titans.loader.TheTitansEntities;
import net.titans.loader.TheTitansRegistries;
import net.titans.loader.TheTitansPredicateTargets;
import net.titans.loader.TheTitansSounds;
import net.titans.util.AnimationUtils;

public class EntityOmegafish extends EntityTitan implements IEntityMultiPartTitan, IBossBarDisplay {
    public EntityTitanPart head = new EntityTitanPart(this, "head", 3.0F, 2.0F);
    public EntityTitanPart body = new EntityTitanPart(this, "body", 5.0F, 4.0F);
    public EntityTitanPart tailbase = new EntityTitanPart(this, "tailbase", 3.0F, 3.0F);
    public EntityTitanPart tail1 = new EntityTitanPart(this, "tail1", 3.0F, 2.0F);
    public EntityTitanPart tail2 = new EntityTitanPart(this, "tail2", 2.0F, 1.0F);
    public EntityTitanPart tailtip = new EntityTitanPart(this, "tailtip", 2.0F, 1.0F);
    @Nullable
    private UUID ownerUUID;
    @Nullable
    private Player cachedOwner;
    public int damageToParts;
    public boolean isSubdued;
    public boolean isBurrowing;
    public boolean isStunned;

    public EntityOmegafish(EntityType<? extends EntityTitan> entityType, Level level) {
        super(entityType, level);
        this.parts = new EntityTitanPart[]{this.head, this.body, this.tailbase, this.tail1, this.tail2, this.tailtip};
    }

    public EntityOmegafish(Level level) {
        this((EntityType<? extends EntityTitan>)TheTitansEntities.OMEGAFISH.get(), level);
    }

    public static Builder createAttributes() {
        return EntityTitan.createAttributes().add(Attributes.MAX_HEALTH, 16000.0).add(Attributes.ATTACK_DAMAGE, 800.0);
    }

    @Override
    public ResourceLocation getBossBarTexture() {
        return ResourceLocation.tryBuild("titan", "textures/gui/bossbar/omegafish.png");
    }

    @Override
    public int getBossBarNameColor() {
        return 3158064;
    }

    @Override
    public int getBossBarWidth() {
        return 185;
    }

    @Override
    public int getBossBarHeight() {
        return 33;
    }

    @Override
    public int getBossBarInterval() {
        return 7;
    }

    @Override
    public int getBossBarVOffset() {
        return 0;
    }

    @Override
    public int getBossBarVHeight() {
        return 0;
    }

    @Override
    public int getBossBarTextOffset() {
        return 7;
    }

    @Override
    protected void registerGoals() {
        super.registerGoals();
        this.goalSelector.addGoal(1, new AnimationOmegafishCreation(this));
        this.goalSelector.addGoal(1, new AnimationOmegafishDeath(this));
        this.goalSelector.addGoal(1, new AnimationOmegafishAntiTitanAttack(this));
        this.goalSelector.addGoal(1, new AnimationOmegafishAttack1(this));
        this.goalSelector.addGoal(1, new AnimationOmegafishAttack2(this));
        this.goalSelector.addGoal(1, new AnimationOmegafishAttack3(this));
        this.goalSelector.addGoal(1, new AnimationOmegafishBodySlam(this));
        this.goalSelector.addGoal(1, new AnimationOmegafishBurrow(this));
        this.goalSelector.addGoal(1, new AnimationOmegafishLightningAttack(this));
        this.goalSelector.addGoal(1, new AnimationOmegafishStunned(this));
        this.goalSelector.addGoal(1, new AnimationOmegafishTailSmash(this));
        this.goalSelector.addGoal(1, new AnimationOmegafishUnburrow(this));
        this.targetSelector.addGoal(0, new EntityAINearestTargetTitan(this, EntitySnowGolemTitan.class, false));
        this.targetSelector.addGoal(0, new EntityAINearestTargetTitan(this, EntityIronGolemTitan.class, false));
        this.targetSelector
            .addGoal(0, new EntityAINearestTargetTitan<LivingEntity>(this, LivingEntity.class, 0, false, false, TheTitansPredicateTargets.Omegafish));
    }

    public Entity getOwner() {
        if (this.cachedOwner != null && !this.cachedOwner.isRemoved()) {
            return this.cachedOwner;
        } else if (this.ownerUUID != null) {
            this.cachedOwner = this.level().getPlayerByUUID(this.ownerUUID);
            return this.cachedOwner;
        } else {
            return null;
        }
    }

    public void setOwner(Player owner) {
        if (owner != null) {
            this.ownerUUID = owner.getUUID();
            this.cachedOwner = owner;
        }
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        if (tag.hasUUID("Owner")) {
            this.ownerUUID = tag.getUUID("Owner");
            this.cachedOwner = null;
        }

        this.damageToParts = tag.getInt("DamageToParts");
        this.isSubdued = tag.getBoolean("IsSubdued");
        this.isBurrowing = tag.getBoolean("IsBurrowing");
        this.isStunned = tag.getBoolean("IsStunned");
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        if (this.ownerUUID != null) {
            tag.putUUID("Owner", this.ownerUUID);
        }

        tag.putInt("DamageToParts", this.damageToParts);
        tag.putBoolean("IsSubdued", this.isSubdued);
        tag.putBoolean("IsBurrowing", this.isBurrowing);
        tag.putBoolean("IsStunned", this.isStunned);
    }

    @Override
    public SpawnGroupData finalizeSpawn(
        ServerLevelAccessor level, DifficultyInstance difficulty, MobSpawnType spawnType, @Nullable SpawnGroupData spawnGroupData, @Nullable CompoundTag tag
    ) {
        SpawnGroupData groupData = super.finalizeSpawn(level, difficulty, spawnType, spawnGroupData, null);
        this.setWaiting(true);
        return groupData;
    }

    @Override
    protected void refreshAttributes() {
        if (this.level().getDifficulty() == Difficulty.HARD) {
            this.getAttribute(Attributes.MAX_HEALTH).setBaseValue(16000.0 + (double)this.getExtraPower() * 400.0);
            this.getAttribute(Attributes.ATTACK_DAMAGE).setBaseValue(800.0 + (double)this.getExtraPower() * 80.0);
        } else {
            this.getAttribute(Attributes.MAX_HEALTH).setBaseValue(8000.0 + (double)this.getExtraPower() * 200.0);
            this.getAttribute(Attributes.ATTACK_DAMAGE).setBaseValue(400.0 + (double)this.getExtraPower() * 40.0);
        }
    }

    @Override
    public boolean canAttack() {
        return false;
    }

    @Override
    public boolean canAttackEntity(Entity entity) {
        return super.canAttackEntity(entity) && !(entity instanceof EntityOmegafishMinion) && (!(entity instanceof Player) || !this.isSubdued);
    }

    @Override
    public boolean canBeHurtByPlayer() {
        return !this.isBurrowing && !this.isInvulnerable();
    }

    @Override
    public boolean shouldMove() {
        return this.getAnimationID() == 0 && !this.isStunned && !this.getWaiting() && this.getTarget() != null ? super.shouldMove() : false;
    }

    @Override
    public double getMeleeRange() {
        return (double)(
                this.getBbWidth() * this.getBbWidth() + (this.getTarget().getBbWidth() > 48.0F ? 2304.0F : this.getTarget().getBbWidth() * this.getTarget().getBbWidth())
            )
            + 100.0;
    }

    @Override
    public boolean canRegen() {
        return !this.isStunned;
    }

    @Override
    public boolean isArmored() {
        return this.deathTicks <= 0 && this.getTitanHealth() <= this.getTitanMaxHealth() / 4.0F;
    }

    @Override
    public int getMinionCap() {
        return 240;
    }

    @Override
    public int getPriestCap() {
        return 120;
    }

    @Override
    public int getZealotCap() {
        return 60;
    }

    @Override
    public int getBishopCap() {
        return 15;
    }

    @Override
    public int getTemplarCap() {
        return 8;
    }

    @Override
    public boolean canSpawnMinion() {
        boolean flag = this.getInvulTime() > 1 && this.tickCount % 20 == 0;
        float randomRate = this.random.nextFloat() * 100.0F;
        return flag || (double)randomRate < 5.0;
    }

    @Override
    public boolean canSpawnPriest() {
        boolean flag = this.getInvulTime() > 1 && this.tickCount % 20 == 0;
        float randomRate = this.random.nextFloat() * 100.0F;
        return flag || (double)randomRate < 2.5;
    }

    @Override
    public boolean canSpawnZealot() {
        boolean flag = this.getInvulTime() > 1 && this.tickCount % 20 == 0;
        float randomRate = this.random.nextFloat() * 100.0F;
        return flag || (double)randomRate < 1.25;
    }

    @Override
    public boolean canSpawnBishop() {
        boolean flag = this.getInvulTime() > 1 && this.tickCount % 20 == 0;
        float randomRate = this.random.nextFloat() * 100.0F;
        return flag || (double)randomRate < 0.625;
    }

    @Override
    public boolean canSpawnTemplar() {
        boolean flag = this.getInvulTime() > 1 && this.tickCount % 20 == 0;
        float randomRate = this.random.nextFloat() * 100.0F;
        return flag || (double)randomRate < 0.3125;
    }

    @Override
    public EnumTitanStatus getTitanStatus() {
        return EnumTitanStatus.LESSER;
    }

    @Override
    public float getSpeed() {
        return (float)(this.isBurrowing ? 0.9 + (double)this.getExtraPower() * 0.001 : 0.7 + (double)this.getExtraPower() * 0.001);
    }

    public Vec3 getPassengerRidingPosition(Entity entity) {
        if (entity instanceof Player) {
            double d8 = 1.5 + (double)this.getExtraPower() * 0.05;
            Vec3 vec3 = this.getViewVector(1.0F);
            double dx = vec3.x * d8;
            double dz = vec3.z * d8;
            return this.position().add(dx, this.isBurrowing ? 0.5 + (double)this.getExtraPower() * 0.05 : 3.0 + (double)this.getExtraPower() * 0.05, dz);
        } else {
            return this.position();
        }
    }

    protected SoundEvent getAmbientSound() {
        return !this.isStunned && !this.getWaiting() && this.getAnimationID() != 2 ? (SoundEvent)TheTitansSounds.TITAN_SILVERFISH_LIVING.get() : null;
    }

    protected SoundEvent getHurtSound(DamageSource damageSource) {
        return (SoundEvent)TheTitansSounds.TITAN_SILVERFISH_GRUNT.get();
    }

    protected SoundEvent getDeathSound() {
        return (SoundEvent)TheTitansSounds.TITAN_SILVERFISH_DEATH.get();
    }

    protected void playStepSound(BlockPos pos, BlockState state) {
    }

    @Override
    public void setTarget(@Nullable LivingEntity target) {
        if (this.isSubdued) {
            super.setTarget(null);
        } else {
            super.setTarget(target);
        }
    }

    @Override
    public boolean attackEntityFromPart(EntityTitanPart entityTitanPart, DamageSource damageSource, float amount) {
        if (entityTitanPart == this.head) {
            amount *= 2.0F;
        }

        if (this.hurt(damageSource, amount)
            && damageSource.getEntity() != null
            && damageSource.getEntity() instanceof Player
            && this.damageToParts < 8
            && !this.isStunned) {
            this.damageToParts++;
            this.hurt(damageSource, 100.0F);
            this.setTarget((LivingEntity)damageSource.getEntity());
            if (this.damageToParts >= 1) {
                this.playSound(this.getDeathSound(), this.getSoundVolume(), this.getVoicePitch());
                this.isStunned = true;
                this.damageToParts = 0;
            }
        }

        return true;
    }

    @Override
    public boolean hurt(DamageSource damageSource, float amount) {
        if (this.isArmored()) {
            amount /= 2.0F;
        }

        if (this.isStunned) {
            amount *= 3.0F;
        }

        return super.hurt(damageSource, amount);
    }

    public InteractionResult mobInteract(Player player, InteractionHand hand) {
        ItemStack itemStack = player.getItemInHand(hand);
        Item item = itemStack.getItem();
        if (this.isStunned && !this.isSubdued) {
            if (item == Items.GOLDEN_APPLE) {
                if (!player.isCreative()) {
                    itemStack.shrink(1);
                }

                player.swing(hand, true);
                float randomRate = this.random.nextFloat() * 100.0F;
                if ((double)randomRate < 0.01) {
                    this.playSound(SoundEvents.PLAYER_LEVELUP, 10.0F, 1.0F);
                    this.isSubdued = true;
                    this.setOwner(player);
                    player.sendSystemMessage(Component.translatable("entity.titan.titan.subdued", new Object[]{this.getName(), player.getName()}));
                }
            }
        } else if (!this.isStunned && this.isSubdued && this.getOwner() == player) {
            if (!itemStack.isEmpty()) {
                if (this.getAnimationID() == 0) {
                    if (itemStack.getItem() == Items.DIAMOND) {
                        if (!player.isCreative()) {
                            itemStack.shrink(1);
                        }

                        player.swing(hand, true);
                        AnimationUtils.sendPacket(this, 9);
                    }

                    if (itemStack.getItem() == Items.COOKED_CHICKEN) {
                        if (!player.isCreative()) {
                            itemStack.shrink(1);
                        }

                        player.swing(hand, true);
                        AnimationUtils.sendPacket(this, 3);
                    }

                    if (itemStack.getItem() == Items.BONE) {
                        if (!player.isCreative()) {
                            itemStack.shrink(1);
                        }

                        player.swing(hand, true);
                        switch (this.random.nextInt(2)) {
                            case 0:
                                AnimationUtils.sendPacket(this, 5);
                                break;
                            case 1:
                                AnimationUtils.sendPacket(this, 6);
                        }
                    }

                    if (itemStack.getItem() instanceof ShovelItem) {
                        player.swing(hand, true);
                        if (this.isBurrowing) {
                            AnimationUtils.sendPacket(this, 2);
                        } else {
                            AnimationUtils.sendPacket(this, 1);
                        }
                    }
                }
            } else if (!player.isPassenger()) {
                player.swing(hand, true);
                player.startRiding(this);
            }
        }

        return InteractionResult.PASS;
    }

    @Override
    protected void dropExperienceOrb() {
        for (int x = 0; x < 6; x++) {
            EntityExperienceOrbTitan experienceOrbTitan = new EntityExperienceOrbTitan(
                this.level(),
                this.getX() + (double)(this.random.nextFloat() * 12.0F - 6.0F),
                this.getY() + 4.0,
                this.getZ() + (double)(this.random.nextFloat() * 12.0F - 6.0F),
                3000
            );
            experienceOrbTitan.push(0.0, 1.0, 0.0);
            this.level().addFreshEntity(experienceOrbTitan);
        }
    }

    @Override
    protected void dropAllItem() {
        Map<ItemStack, Integer> drops = new HashMap<>();
        Map<ItemStack, Integer> rateDrops = new HashMap<>();
        drops.put(new ItemStack(Items.PAPER), 96);
        drops.put(new ItemStack(Items.COAL), 32);
        drops.put(new ItemStack(Items.EMERALD), 4);
        drops.put(new ItemStack(Items.DIAMOND), 4);
        drops.put(new ItemStack(Blocks.STONE), 16);
        drops.put(new ItemStack(Blocks.COBBLESTONE), 16);
        drops.put(new ItemStack(Blocks.INFESTED_STONE), 4);
        rateDrops.put(new ItemStack(Items.PAPER), 96);
        rateDrops.put(new ItemStack(Items.COAL), 32);
        rateDrops.put(new ItemStack(Items.EMERALD), 8);
        rateDrops.put(new ItemStack(Items.DIAMOND), 8);
        rateDrops.put(new ItemStack(Blocks.STONE), 48);
        rateDrops.put(new ItemStack(Blocks.COBBLESTONE), 48);
        rateDrops.put(new ItemStack(Blocks.MOSSY_COBBLESTONE), 48);
        rateDrops.put(new ItemStack(Blocks.STONE_BRICKS), 32);
        rateDrops.put(new ItemStack(Blocks.INFESTED_STONE), 8);
        rateDrops.put(new ItemStack((ItemLike)TheTitansRegistries.HARCADIUM_NUGGET.get()), 4);

        for (Entry<ItemStack, Integer> entry : drops.entrySet()) {
            ItemStack itemStack = entry.getKey();
            int count = entry.getValue();
            EntityItemTitan itemTitan = new EntityItemTitan(
                this.level(),
                this.getX() + (double)(this.random.nextFloat() * 12.0F - 6.0F),
                this.getY() + 4.0,
                this.getZ() + (double)(this.random.nextFloat() * 12.0F - 6.0F),
                itemStack,
                count
            );
            itemTitan.setPickUpDelay(40);
            this.level().addFreshEntity(itemTitan);
        }

        for (Entry<ItemStack, Integer> entry : rateDrops.entrySet()) {
            ItemStack itemStack = entry.getKey();
            int count = entry.getValue();
            int randomCount = this.random.nextInt(count) + 1;
            EntityItemTitan itemTitan = new EntityItemTitan(
                this.level(),
                this.getX() + (double)(this.random.nextFloat() * 12.0F - 6.0F),
                this.getY() + 4.0,
                this.getZ() + (double)(this.random.nextFloat() * 12.0F - 6.0F),
                itemStack,
                randomCount
            );
            itemTitan.setPickUpDelay(40);
            this.level().addFreshEntity(itemTitan);
        }
    }

    @Override
    protected void tickTitanDeath() {
        super.tickTitanDeath();
        AnimationUtils.sendPacket(this, 10);
        this.isBurrowing = false;
        this.isStunned = false;
        if (this.deathTicks >= 300) {
            this.setInvulTime(this.getInvulTime() + 8);
            this.setAnimationTick(this.getAnimationTick() - 1);
            float f = (this.random.nextFloat() - 0.5F) * 8.0F;
            float f1 = (this.random.nextFloat() - 0.5F) * 4.0F;
            float f2 = (this.random.nextFloat() - 0.5F) * 8.0F;
            this.level()
                .addParticle(ParticleTypes.EXPLOSION, this.getX() + (double)f, this.getY() + 2.0 + (double)f1, this.getZ() + (double)f2, 0.0, 0.0, 0.0);
        }

        if (this.getInvulTime() >= this.getThreashHold()) {
            this.onDeath();
            if (!this.level().isClientSide() && !this.isRemoved()) {
                for (EntityTitanPart part : this.parts) {
                    part.remove(RemovalReason.KILLED);
                }

                this.removeTitan(RemovalReason.KILLED);
            }
        }
    }

    @Override
    public void finalizeMinionSummon(Entity entity, EnumMinionType minionType) {
        if (minionType != EnumMinionType.SPECIAL && entity instanceof EntityOmegafishMinion omegafishMinion) {
            omegafishMinion.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 40, 4, true, false));
        }
    }

    protected void updateRiddenMovement(Player player, Vec3 travelVector) {
        if (!this.isAlive()) {
            player.stopRiding();
        } else {
            this.setTarget(null);
            this.setYRot(player.getYRot());
            this.yRotO = player.yRotO;
            this.yHeadRot = player.yHeadRot;
            if (player.zza > 0.0F) {
                this.moveRelative(this.getSpeed(), new Vec3(0.0, 0.0, 1.0));
            } else if (player.zza < 0.0F) {
                this.moveRelative(-this.getSpeed() * 0.25F, new Vec3(0.0, 0.0, 1.0));
            }

            if (player.xxa != 0.0F) {
                this.moveRelative(this.getSpeed() * 0.5F * Math.signum(player.xxa), new Vec3(1.0, 0.0, 0.0));
            }

            if (this.onGround() && player.getXRot() < -80.0F) {
                this.jumpFromGround();
            }

            if (!this.isControlledByLocalInstance()) {
                this.calculateEntityAnimation(false);
            }
        }
    }

    public void animationTick() {
        if (this.getAnimationID() == 13) {
            this.addDayTime(14000L, 50L);
            if (this.getAnimationTick() == 1) {
                this.playSound((SoundEvent)TheTitansSounds.TITAN_BIRTH.get(), 100.0F, 1.25F);
            }

            if (this.getAnimationTick() == 10) {
                this.playSound((SoundEvent)TheTitansSounds.TITAN_SILVERFISH_LIVING.get(), this.getSoundVolume(), 0.7F);
            }

            if (this.getAnimationTick() == 150) {
                this.shakeNearbyPlayerCameras(20000.0);
                this.playSound((SoundEvent)TheTitansSounds.TITAN_PRESS.get(), this.getSoundVolume(), 1.0F);
            }
        }

        if (this.getAnimationID() == 1 && this.getAnimationTick() == 50) {
            this.playSound((SoundEvent)TheTitansSounds.GROUND_SMASH.get(), 20.0F, 1.25F);
            float amount = (float)this.getAttributeBaseValue(Attributes.ATTACK_DAMAGE);
            int knockbackAmount = this.getKnockbackAmount() * 3;

            for (Entity entity : this.level().getEntities(this, this.getBoundingBox().inflate(16.0, 16.0, 16.0))) {
                if (entity != null && entity instanceof LivingEntity && this.canAttackEntity(entity)) {
                    LivingEntity livingEntity = (LivingEntity)entity;
                    this.attackEntity(livingEntity, amount);
                    this.knockbackEntity(livingEntity, (float)knockbackAmount);
                }
            }
        }

        if (this.getAnimationID() == 2) {
            if (this.getAnimationTick() == 10) {
                this.playSound((SoundEvent)TheTitansSounds.QUICK_APPERENCE.get(), 20.0F, 1.0F);
                this.destroyBlocksInAABB(this.getBoundingBox().move(0.0, -2.0, 0.0));
                this.setTitanDeltaMovement(
                    this.getDeltaMovement()
                        .add(
                            (double)(-Mth.sin(this.yHeadRot * (float) Math.PI / 180.0F) * 0.75F),
                            1.0,
                            (double)(Mth.cos(this.yHeadRot * (float) Math.PI / 180.0F) * 0.75F)
                        )
                );
                float amount = (float)this.getAttributeBaseValue(Attributes.ATTACK_DAMAGE);
                int knockbackAmount = this.getKnockbackAmount();

                for (Entity entityx : this.level().getEntities(this, this.getBoundingBox().inflate(16.0, 16.0, 16.0))) {
                    if (entityx != null && entityx instanceof LivingEntity && this.canAttackEntity(entityx)) {
                        LivingEntity livingEntity = (LivingEntity)entityx;
                        this.attackEntity(livingEntity, amount);
                        this.knockbackEntity(livingEntity, (float)knockbackAmount);
                    }
                }
            }

            if (this.getAnimationTick() == 20) {
                this.playSound((SoundEvent)TheTitansSounds.GROUND_SMASH.get(), 20.0F, 1.0F);
                float amount = (float)this.getAttributeBaseValue(Attributes.ATTACK_DAMAGE);
                int knockbackAmount = this.getKnockbackAmount() * 3;

                for (Entity entityxx : this.level().getEntities(this, this.getBoundingBox().inflate(16.0, 16.0, 16.0))) {
                    if (entityxx != null && entityxx instanceof LivingEntity && this.canAttackEntity(entityxx)) {
                        LivingEntity livingEntity = (LivingEntity)entityxx;
                        this.attackEntity(livingEntity, amount);
                        this.knockbackEntity(livingEntity, (float)knockbackAmount);
                    }
                }
            }
        }

        if (this.getAnimationID() == 3 && this.getAnimationTick() == 36) {
            this.playSound((SoundEvent)TheTitansSounds.GROUND_SMASH.get(), 20.0F, 1.5F);
            float amount = (float)this.getAttributeBaseValue(Attributes.ATTACK_DAMAGE);
            int knockbackAmount = this.getKnockbackAmount();

            for (Entity entityxxx : this.level().getEntities(this, this.getBoundingBox().inflate(64.0, 4.0, 64.0))) {
                if (entityxxx != null && entityxxx instanceof LivingEntity && this.canAttackEntity(entityxxx)) {
                    LivingEntity livingEntity = (LivingEntity)entityxxx;
                    this.attackEntity(livingEntity, amount * 4.0F);
                    this.knockbackEntity(livingEntity, (float)knockbackAmount);
                }
            }
        }

        if (this.getAnimationID() == 4 && this.getAnimationTick() == 12 && this.getTarget() != null) {
            this.playSound((SoundEvent)TheTitansSounds.TITAN_SWING.get(), 10.0F, 1.75F);
            float amount = (float)this.getAttributeBaseValue(Attributes.ATTACK_DAMAGE);
            int knockbackAmount = this.getKnockbackAmount();
            this.attackEntity(this.getTarget(), amount);
            this.knockbackEntity(this.getTarget(), (float)knockbackAmount);

            for (Entity entityxxxx : this.level().getEntities(this.getTarget(), this.getTarget().getBoundingBox().inflate(4.0, 4.0, 4.0))) {
                if (entityxxxx != null && entityxxxx != this && entityxxxx instanceof LivingEntity && this.canAttackEntity(entityxxxx)) {
                    LivingEntity livingEntity = (LivingEntity)entityxxxx;
                    this.attackEntity(livingEntity, amount);
                    this.knockbackEntity(livingEntity, (float)knockbackAmount);
                }
            }
        }

        if (this.getAnimationID() == 5) {
            if (this.getAnimationTick() == 24) {
                this.playSound((SoundEvent)TheTitansSounds.TITAN_SWING.get(), 10.0F, 1.75F);
                double d8 = 4.0;
                Vec3 vec3 = this.getViewVector(1.0F);
                double dx = vec3.x * d8;
                double dz = vec3.z * d8;
                float amount = (float)this.getAttributeBaseValue(Attributes.ATTACK_DAMAGE);
                int knockbackAmount = this.getKnockbackAmount();

                for (Entity entityxxxxx : this.level().getEntities(this, this.getBoundingBox().inflate(1.0, 1.0, 1.0).move(dx, 0.0, dz))) {
                    if (entityxxxxx != null && entityxxxxx instanceof LivingEntity && this.canAttackEntity(entityxxxxx)) {
                        LivingEntity livingEntity = (LivingEntity)entityxxxxx;
                        livingEntity.playSound(
                            SoundEvents.GENERIC_EXPLODE,
                            4.0F,
                            (1.0F + (this.level().getRandom().nextFloat() - this.level().getRandom().nextFloat()) * 0.2F) * 0.7F
                        );
                        if (this.random.nextInt(3) == 0) {
                            livingEntity.setRemainingFireTicks(20);
                        }

                        this.attackEntity(livingEntity, amount * 2.0F);

                        for (int i = 0; i < 6; i++) {
                            this.knockbackEntity(livingEntity, (float)knockbackAmount);
                        }
                    }
                }
            }

            if (this.getAnimationTick() == 26) {
                double d8 = 8.0;
                Vec3 vec3 = this.getViewVector(1.0F);
                double dx = vec3.x * d8;
                double dz = vec3.z * d8;
                float amount = (float)this.getAttributeBaseValue(Attributes.ATTACK_DAMAGE);
                int knockbackAmount = this.getKnockbackAmount();

                for (Entity entityxxxxxx : this.level().getEntities(this, this.getBoundingBox().inflate(1.0, 1.0, 1.0).move(dx, 0.0, dz))) {
                    if (entityxxxxxx != null && entityxxxxxx instanceof LivingEntity && this.canAttackEntity(entityxxxxxx)) {
                        LivingEntity livingEntity = (LivingEntity)entityxxxxxx;
                        livingEntity.playSound(
                            SoundEvents.GENERIC_EXPLODE,
                            4.0F,
                            (1.0F + (this.level().getRandom().nextFloat() - this.level().getRandom().nextFloat()) * 0.2F) * 0.7F
                        );
                        if (this.random.nextInt(3) == 0) {
                            livingEntity.setRemainingFireTicks(20);
                        }

                        this.attackEntity(livingEntity, amount * 2.0F);

                        for (int i = 0; i < 6; i++) {
                            this.knockbackEntity(livingEntity, (float)knockbackAmount);
                        }
                    }
                }
            }

            if (this.getAnimationTick() == 30) {
                double d8 = 16.0;
                Vec3 vec3 = this.getViewVector(1.0F);
                double dx = vec3.x * d8;
                double dz = vec3.z * d8;
                float amount = (float)this.getAttributeBaseValue(Attributes.ATTACK_DAMAGE);
                int knockbackAmount = this.getKnockbackAmount();

                for (Entity entityxxxxxxx : this.level().getEntities(this, this.getBoundingBox().inflate(1.0, 1.0, 1.0).move(dx, 0.0, dz))) {
                    if (entityxxxxxxx != null && entityxxxxxxx instanceof LivingEntity && this.canAttackEntity(entityxxxxxxx)) {
                        LivingEntity livingEntity = (LivingEntity)entityxxxxxxx;
                        livingEntity.playSound(
                            SoundEvents.GENERIC_EXPLODE,
                            4.0F,
                            (1.0F + (this.level().getRandom().nextFloat() - this.level().getRandom().nextFloat()) * 0.2F) * 0.7F
                        );
                        if (this.random.nextInt(3) == 0) {
                            livingEntity.setRemainingFireTicks(20);
                        }

                        this.attackEntity(livingEntity, amount * 2.0F);

                        for (int i = 0; i < 6; i++) {
                            this.knockbackEntity(livingEntity, (float)knockbackAmount);
                        }
                    }
                }
            }
        }

        if (this.getAnimationID() == 6) {
            if (this.getAnimationTick() == 24) {
                this.playSound((SoundEvent)TheTitansSounds.TITAN_SWING.get(), 10.0F, 1.75F);
                double d8 = 4.0;
                Vec3 vec3 = this.getViewVector(1.0F);
                double dx = vec3.x * d8;
                double dz = vec3.z * d8;
                float amount = (float)this.getAttributeBaseValue(Attributes.ATTACK_DAMAGE);
                int knockbackAmount = this.getKnockbackAmount();

                for (Entity entityxxxxxxxx : this.level().getEntities(this, this.getBoundingBox().inflate(1.0, 1.0, 1.0).move(dx, 0.0, dz))) {
                    if (entityxxxxxxxx != null && entityxxxxxxxx instanceof LivingEntity && this.canAttackEntity(entityxxxxxxxx)) {
                        LivingEntity livingEntity = (LivingEntity)entityxxxxxxxx;
                        livingEntity.playSound(
                            SoundEvents.GENERIC_EXPLODE,
                            4.0F,
                            (1.0F + (this.level().getRandom().nextFloat() - this.level().getRandom().nextFloat()) * 0.2F) * 0.7F
                        );
                        if (this.random.nextInt(3) == 0) {
                            livingEntity.setRemainingFireTicks(20);
                        }

                        this.attackEntity(livingEntity, amount * 2.0F);

                        for (int i = 0; i < 6; i++) {
                            this.knockbackEntity(livingEntity, (float)knockbackAmount);
                        }
                    }
                }
            }

            if (this.getAnimationTick() == 26) {
                double d8 = 8.0;
                Vec3 vec3 = this.getViewVector(1.0F);
                double dx = vec3.x * d8;
                double dz = vec3.z * d8;
                float amount = (float)this.getAttributeBaseValue(Attributes.ATTACK_DAMAGE);
                int knockbackAmount = this.getKnockbackAmount();

                for (Entity entityxxxxxxxxx : this.level().getEntities(this, this.getBoundingBox().inflate(1.0, 1.0, 1.0).move(dx, 0.0, dz))) {
                    if (entityxxxxxxxxx != null && entityxxxxxxxxx instanceof LivingEntity && this.canAttackEntity(entityxxxxxxxxx)) {
                        LivingEntity livingEntity = (LivingEntity)entityxxxxxxxxx;
                        livingEntity.playSound(
                            SoundEvents.GENERIC_EXPLODE,
                            4.0F,
                            (1.0F + (this.level().getRandom().nextFloat() - this.level().getRandom().nextFloat()) * 0.2F) * 0.7F
                        );
                        if (this.random.nextInt(3) == 0) {
                            livingEntity.setRemainingFireTicks(20);
                        }

                        this.attackEntity(livingEntity, amount * 2.0F);

                        for (int i = 0; i < 6; i++) {
                            this.knockbackEntity(livingEntity, (float)knockbackAmount);
                        }
                    }
                }
            }

            if (this.getAnimationTick() == 30) {
                double d8 = 16.0;
                Vec3 vec3 = this.getViewVector(1.0F);
                double dx = vec3.x * d8;
                double dz = vec3.z * d8;
                float amount = (float)this.getAttributeBaseValue(Attributes.ATTACK_DAMAGE);
                int knockbackAmount = this.getKnockbackAmount();

                for (Entity entityxxxxxxxxxx : this.level().getEntities(this, this.getBoundingBox().inflate(1.0, 1.0, 1.0).move(dx, 0.0, dz))) {
                    if (entityxxxxxxxxxx != null && entityxxxxxxxxxx instanceof LivingEntity && this.canAttackEntity(entityxxxxxxxxxx)) {
                        LivingEntity livingEntity = (LivingEntity)entityxxxxxxxxxx;
                        livingEntity.playSound(
                            SoundEvents.GENERIC_EXPLODE,
                            4.0F,
                            (1.0F + (this.level().getRandom().nextFloat() - this.level().getRandom().nextFloat()) * 0.2F) * 0.7F
                        );
                        if (this.random.nextInt(3) == 0) {
                            livingEntity.setRemainingFireTicks(20);
                        }

                        this.attackEntity(livingEntity, amount * 2.0F);

                        for (int i = 0; i < 6; i++) {
                            this.knockbackEntity(livingEntity, (float)knockbackAmount);
                        }
                    }
                }
            }
        }

        if (this.getAnimationID() == 7 && this.getAnimationTick() == 20) {
            double d8 = -3.0;
            Vec3 vec3 = this.getViewVector(1.0F);
            double dx = vec3.x * d8;
            double dz = vec3.z * d8;
            float amount = (float)this.getAttributeBaseValue(Attributes.ATTACK_DAMAGE);
            int knockbackAmount = this.getKnockbackAmount();
            if (!this.level().isClientSide()) {
                this.level().explode(this, this.getX() + dx, this.getY() + 8.0, this.getZ() + dz, 1.0F, false, ExplosionInteraction.MOB);
            }

            EntityColorLightningBolt colorLightningBolt1 = new EntityColorLightningBolt(this.level(), 0.5F, 0.5F, 0.5F);
            colorLightningBolt1.setPos(this.getX() + dx, this.getY() + 8.0, this.getZ() + dz);
            if (!this.level().isClientSide()) {
                this.level().addFreshEntity(colorLightningBolt1);
            }

            if (this.getTarget() != null) {
                if (!this.level().isClientSide()) {
                    this.level()
                        .explode(this, this.getTarget().getX(), this.getTarget().getY(), this.getTarget().getZ(), 2.0F, false, ExplosionInteraction.MOB);
                }

                EntityColorLightningBolt colorLightningBolt2 = new EntityColorLightningBolt(this.level(), 0.25F, 0.25F, 0.25F);
                colorLightningBolt2.setPos(this.getTarget().getX(), this.getTarget().getY(), this.getTarget().getZ());
                if (!this.level().isClientSide()) {
                    this.level().addFreshEntity(colorLightningBolt2);
                }

                this.attackEntity(this.getTarget(), amount);
                this.knockbackEntity(this.getTarget(), (float)knockbackAmount);
                this.getTarget().push(0.0, 2.0, 0.0);

                for (Entity entityxxxxxxxxxxx : this.level().getEntities(this.getTarget(), this.getTarget().getBoundingBox().inflate(2.0, 2.0, 2.0))) {
                    if (entityxxxxxxxxxxx != null
                        && entityxxxxxxxxxxx != this
                        && entityxxxxxxxxxxx instanceof LivingEntity
                        && this.canAttackEntity(entityxxxxxxxxxxx)) {
                        LivingEntity livingEntity = (LivingEntity)entityxxxxxxxxxxx;
                        this.attackEntity(livingEntity, amount);
                        this.knockbackEntity(livingEntity, (float)knockbackAmount);
                        livingEntity.push(0.0, 1.0, 0.0);
                    }
                }
            }
        }

        if (this.getAnimationID() == 8) {
            if (this.getAnimationTick() == 37) {
                this.playSound((SoundEvent)TheTitansSounds.LARGE_FALL.get(), 4.0F, 1.0F);
                this.playSound((SoundEvent)TheTitansSounds.DISTANT_LARGE_FALL.get(), 10000.0F, 1.0F);
            }

            if (this.getAnimationTick() == 380) {
                this.isStunned = false;
            } else {
                this.setTarget(null);
            }
        }

        if (this.getAnimationID() == 9) {
            if (this.getAnimationTick() == 80) {
                this.setTitanDeltaMovement(this.getDeltaMovement().add(0.0, 9.0, 0.0));
                if (this.getTarget() != null) {
                    double d0 = this.getTarget().getX() - this.getX();
                    double d1 = this.getTarget().getZ() - this.getZ();
                    double d2 = Math.sqrt(d0 * d0 + d1 * d1);
                    double hor = d2 / 16.0;
                    this.setTitanDeltaMovement(
                        d0 / d2 * hor * hor + this.getDeltaMovement().x * hor, this.getDeltaMovement().y, d1 / d2 * hor * hor + this.getDeltaMovement().z * hor
                    );
                }
            }

            if (this.getAnimationTick() == 240) {
                this.playSound((SoundEvent)TheTitansSounds.TITAN_SLAM.get(), 20.0F, 1.0F);
                this.playSound((SoundEvent)TheTitansSounds.GROUND_SMASH.get(), 20.0F, 1.5F);
                this.playSound((SoundEvent)TheTitansSounds.TITAN_LAND.get(), 10000.0F, 1.0F);
                float amountx = (float)this.getAttributeBaseValue(Attributes.ATTACK_DAMAGE);
                int knockbackAmountx = this.getKnockbackAmount();

                for (Entity entityxxxxxxxxxxxx : this.level().getEntities(this, this.getBoundingBox().inflate(96.0, 32.0, 96.0))) {
                    if (entityxxxxxxxxxxxx != null && entityxxxxxxxxxxxx instanceof LivingEntity && this.canAttackEntity(entityxxxxxxxxxxxx)) {
                        LivingEntity livingEntity = (LivingEntity)entityxxxxxxxxxxxx;
                        if (this.random.nextInt(3) == 0) {
                            livingEntity.setRemainingFireTicks(20);
                        }

                        this.attackEntity(livingEntity, amountx * 10.0F);
                        this.knockbackEntity(livingEntity, (float)knockbackAmountx);
                        livingEntity.push(0.0, 1.5, 0.0);
                    }
                }
            }
        }

        if (this.getAnimationID() == 10) {
            if (this.getAnimationTick() == 74 || this.getAnimationTick() == 216) {
                this.playSound((SoundEvent)TheTitansSounds.TITAN_FALL.get(), 10.0F, 1.0F);
            }

            if (this.getAnimationTick() == 76) {
                this.playSound((SoundEvent)TheTitansSounds.DISTANT_LARGE_FALL.get(), 10000.0F, 1.0F);
            }
        }

        if (this.getAnimationID() == 11 && this.getAnimationTick() == 12 && this.getTarget() != null) {
            this.shakeNearbyPlayerCameras(20000.0);
            if (this.isArmored()) {
                this.playSound((SoundEvent)TheTitansSounds.TITAN_STRIKE.get(), 20.0F, 1.0F);
                this.playSound((SoundEvent)TheTitansSounds.TITAN_STRIKE.get(), 20.0F, 1.05F);
                this.playSound((SoundEvent)TheTitansSounds.TITAN_STRIKE.get(), 20.0F, 1.1F);

                for (int i = 0; i < 3; i++) {
                    this.collideWithEntities(this.body, this.level().getEntities(this, this.body.getBoundingBox().inflate(26.0, 26.0, 26.0)));
                }
            }

            float amountx = (float)this.getAttributeBaseValue(Attributes.ATTACK_DAMAGE);
            int knockbackAmountx = this.getKnockbackAmount();
            this.collideWithEntities(this.body, this.level().getEntities(this, this.body.getBoundingBox().inflate(48.0, 48.0, 48.0)));

            for (int i = 0; i < 4; i++) {
                this.attackEntity(this.getTarget(), amountx);
            }

            this.knockbackEntity(this.getTarget(), (float)knockbackAmountx);

            for (Entity entityxxxxxxxxxxxxx : this.level().getEntities(this.getTarget(), this.getTarget().getBoundingBox().inflate(8.0, 8.0, 8.0))) {
                if (entityxxxxxxxxxxxxx != null
                    && entityxxxxxxxxxxxxx != this
                    && entityxxxxxxxxxxxxx instanceof LivingEntity
                    && this.canAttackEntity(entityxxxxxxxxxxxxx)) {
                    LivingEntity livingEntity = (LivingEntity)entityxxxxxxxxxxxxx;

                    for (int i = 0; i < 2; i++) {
                        this.attackEntity(livingEntity, amountx);
                    }

                    this.knockbackEntity(livingEntity, (float)knockbackAmountx);
                }
            }
        }
    }

    @Override
    public void tick() {
        super.tick();
        this.checkWaiting(24.0);
        if (this.getAnimationID() == 0 && !this.isPassenger() && !this.getWaiting() && !this.isStunned && !this.isBurrowing) {
            if (this.getTarget() != null && this.distanceToSqr(this.getTarget()) > this.getMeleeRange() + (!this.getTarget().onGround() ? 1000.0 : 8000.0)) {
                if (this.getY() <= this.getTarget().getY() + 12.0 && this.getY() < 256.0 - (double)this.getBbHeight()) {
                    this.fallDistance = 0.0F;
                    this.setTitanDeltaMovement(this.getDeltaMovement().x, this.getDeltaMovement().y + 0.9 - this.getDeltaMovement().y, this.getDeltaMovement().z);
                    if (this.getDeltaMovement().y < 0.0) {
                        this.setTitanDeltaMovement(this.getDeltaMovement().x, 0.0, this.getDeltaMovement().z);
                    }
                }

                this.setTitanDeltaMovement(this.getDeltaMovement().x, this.getDeltaMovement().y * 0.6, this.getDeltaMovement().z);
            }

            if (!this.onGround()) {
                float f3 = (this.random.nextFloat() - 0.5F) * 10.0F;
                float f4 = (this.random.nextFloat() - 0.5F) * 1.0F;
                float f5 = (this.random.nextFloat() - 0.5F) * 10.0F;
                this.level()
                    .addParticle(
                        ParticleTypes.EXPLOSION, this.getX() + (double)f3, this.getY() + 5.0 + (double)f4, this.getZ() + (double)f5, 0.0, 0.0, 0.0
                    );
            }
        }

        if (this.getAnimationID() != 2 && this.getAnimationID() != 9 && !this.isPassenger() && !this.getWaiting() && !this.isStunned && !this.isBurrowing) {
            if (this.getTarget() != null && this.distanceToSqr(this.getTarget()) > this.getMeleeRange() + 4000.0) {
                if (this.getY() <= this.getTarget().getY() + 12.0 && this.getY() < 256.0 - (double)this.getBbHeight()) {
                    this.fallDistance = 0.0F;
                    this.setTitanDeltaMovement(this.getDeltaMovement().x, this.getDeltaMovement().y + 0.9 - this.getDeltaMovement().y, this.getDeltaMovement().z);
                    if (this.getDeltaMovement().y < 0.0) {
                        this.setTitanDeltaMovement(this.getDeltaMovement().x, 0.0, this.getDeltaMovement().z);
                    }
                }

                this.setTitanDeltaMovement(this.getDeltaMovement().x, this.getDeltaMovement().y * 0.6, this.getDeltaMovement().z);
            }

            if (!this.onGround()) {
                float f3 = (this.random.nextFloat() - 0.5F) * 10.0F;
                float f4 = (this.random.nextFloat() - 0.5F) * 1.0F;
                float f5 = (this.random.nextFloat() - 0.5F) * 10.0F;
                this.level()
                    .addParticle(
                        ParticleTypes.EXPLOSION, this.getX() + (double)f3, this.getY() + 5.0 + (double)f4, this.getZ() + (double)f5, 0.0, 0.0, 0.0
                    );
            }
        }

        if (this.getAnimationID() == 1) {
            this.isBurrowing = true;
        } else if (this.getAnimationID() == 2) {
            this.isBurrowing = false;
        }

        if (this.tickCount > 5) {
            float f = this.yBodyRot * (float) Math.PI / 180.0F;
            float f1 = Mth.sin(f);
            float f2 = Mth.cos(f);
            this.head
                .moveTo(
                    this.getX() - (double)(Mth.sin(this.yHeadRot * (float) Math.PI / 180.0F) * 3.0F),
                    this.getY() - (double)(Mth.sin(this.getXRot() * (float) Math.PI / 180.0F) * 2.0F),
                    this.getZ() + (double)(Mth.cos(this.yHeadRot * (float) Math.PI / 180.0F) * 3.0F)
                );
            this.body.moveTo(this.getX(), this.getY(), this.getZ());
            this.tailbase.moveTo(this.getX() + (double)f1 * 4.0, this.getY(), this.getZ() - (double)f2 * 4.0);
            this.tail1.moveTo(this.getX() + (double)f1 * 7.0, this.getY(), this.getZ() - (double)f2 * 7.0);
            this.tail2.moveTo(this.getX() + (double)f1 * 9.5, this.getY(), this.getZ() - (double)f2 * 9.5);
            this.tailtip.moveTo(this.getX() + (double)f1 * 11.5, this.getY(), this.getZ() - (double)f2 * 11.5);
            if (this.isAlive() && !this.isStunned) {
                this.collideWithEntities(this.head, this.level().getEntities(this, this.head.getBoundingBox().inflate(1.0, 0.0, 1.0)));
                this.collideWithEntities(this.body, this.level().getEntities(this, this.body.getBoundingBox().inflate(1.0, 0.0, 1.0)));
                this.collideWithEntities(this.tailbase, this.level().getEntities(this, this.tailbase.getBoundingBox()));
                this.collideWithEntities(this.tail1, this.level().getEntities(this, this.tail1.getBoundingBox()));
                this.collideWithEntities(this.tail2, this.level().getEntities(this, this.tail2.getBoundingBox()));
                this.collideWithEntities(this.tailtip, this.level().getEntities(this, this.tailtip.getBoundingBox()));
            }

            for (EntityTitanPart part : this.parts) {
                this.destroyBlocksInAABB(part.getBoundingBox());
            }
        }

        if (this.getAnimationID() == 0 && this.getTarget() != null && !this.isStunned) {
            double d0 = this.distanceToSqr(this.getTarget());
            if (d0 < this.getMeleeRange()) {
                if (this.isBurrowing) {
                    AnimationUtils.sendPacket(this, 2);
                } else if (!(this.getTarget() instanceof EntityTitan)
                    && !(this.getTarget().getBbHeight() >= 6.0F)
                    && !(this.getTarget().getY() > this.getY() + 6.0)) {
                    switch (this.random.nextInt(3)) {
                        case 0:
                            AnimationUtils.sendPacket(this, 6);
                            break;
                        case 1:
                            AnimationUtils.sendPacket(this, 5);
                            break;
                        case 2:
                            AnimationUtils.sendPacket(this, 4);
                    }
                } else {
                    AnimationUtils.sendPacket(this, 11);
                }
            } else if (!this.isBurrowing && this.random.nextInt(this.isArmored() ? 20 : 60) == 0) {
                if (this.getTarget().getY() > this.getY() + 12.0) {
                    AnimationUtils.sendPacket(this, 7);
                } else {
                    switch (this.random.nextInt(4)) {
                        case 0:
                            AnimationUtils.sendPacket(this, 3);
                            break;
                        case 1:
                            AnimationUtils.sendPacket(this, 7);
                            break;
                        case 2:
                            if (!this.isBurrowing) {
                                AnimationUtils.sendPacket(this, 1);
                            } else {
                                AnimationUtils.sendPacket(this, 3);
                            }
                            break;
                        case 3:
                            if (this.random.nextInt(3) == 0) {
                                AnimationUtils.sendPacket(this, 9);
                            } else {
                                AnimationUtils.sendPacket(this, 3);
                            }
                    }
                }
            }
        }

        if (this.isBurrowing) {
            if (this.tickCount % 40 == 0) {
                for (int i = 10; i > 6; i--) {
                    this.playSound((SoundEvent)TheTitansSounds.TITAN_RUMBLE.get(), 10.0F, 1.0F);
                }

                for (int i = 5; i > 1; i--) {
                    this.playSound((SoundEvent)TheTitansSounds.TITAN_QUAKE.get(), (float)i, 1.0F);
                }
            }

            this.destroyBlocksInAABB(this.getBoundingBox().inflate(2.0, 0.0, 2.0));
        }

        if (this.isStunned) {
            this.setTarget(null);
            AnimationUtils.sendPacket(this, 8);
        }

        if (this.isStunned || this.deathTicks > 0) {
            this.setDeltaMovement(0.0, this.getDeltaMovement().y, 0.0);
        }

        this.animationTick();
        if (!this.getPassengers().isEmpty() && this.getFirstPassenger() instanceof Player) {
            Player player = (Player)this.getFirstPassenger();
            this.updateRiddenMovement(player, new Vec3((double)this.xxa, (double)this.yya, (double)this.zza));
        }
    }
}
