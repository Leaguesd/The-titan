package net.titans.mixin;

import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.titans.entity.titan.EntityItemTitan;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({LivingEntity.class})
public class MixinLivingEntity {
    @Inject(
        method = {"take"},
        at = {@At("HEAD")},
        cancellable = true
    )
    public void take(Entity entity, int amount, CallbackInfo callbackInfo) {
        if (entity instanceof EntityItemTitan) {
            callbackInfo.cancel();
        }
    }
}
