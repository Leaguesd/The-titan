package net.titans.entity.projectile;

import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.ItemSupplier;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.Level.ExplosionInteraction;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;
import net.titans.entity.EntityColorLightningBolt;
import net.titans.entity.titan.EntityEnderColossus;
import net.titans.entity.titan.EntityTitan;
import net.titans.loader.TheTitansEntities;

public class EntityLightningBall extends EntityTitanProjectile implements ItemSupplier {
    public EntityLightningBall(EntityType<? extends EntityLightningBall> entityType, Level level) {
        super((EntityType)TheTitansEntities.LIGHTNING_BALL.get(), level);
    }

    public EntityLightningBall(Level level, LivingEntity shooter) {
        this((EntityType<? extends EntityLightningBall>)TheTitansEntities.LIGHTNING_BALL.get(), level);
        this.setOwner(shooter);
    }

    public ItemStack getItem() {
        return new ItemStack(Items.SNOWBALL);
    }

    protected boolean shouldBurn() {
        return false;
    }

    protected boolean canHitEntity(Entity entity) {
        return this.getOwner() != null && entity == this.getOwner() ? false : super.canHitEntity(entity);
    }

    public boolean hurt(DamageSource damageSource, float amount) {
        return false;
    }

    protected void onHitEntity(EntityHitResult result) {
        Entity entity = result.getEntity();
        if (entity instanceof LivingEntity && this.getOwner() instanceof EntityTitan) {
            LivingEntity livingEntity = (LivingEntity)entity;
            EntityTitan titan = (EntityTitan)this.getOwner();
            float amount = 2000.0F;
            titan.attackEntity(livingEntity, amount);
            if (!this.level().isClientSide()) {
                this.level()
                    .explode(
                        (Entity)(this.getOwner() != null ? this.getOwner() : this),
                        this.getX(),
                        this.getY(),
                        this.getZ(),
                        7.0F,
                        true,
                        ExplosionInteraction.MOB
                    );
                this.discard();
            }
        }

        super.onHitEntity(result);
    }

    protected void onHitBlock(BlockHitResult result) {
        if (!this.level().isClientSide()) {
            this.discard();
        }
    }

    public void tick() {
        super.tick();
        this.setRemainingFireTicks(4);
        if (this.tickCount % 600 == 0 && !this.level().isClientSide()) {
            this.level()
                .explode(
                    (Entity)(this.getOwner() != null ? this.getOwner() : this),
                    this.getX(),
                    this.getY(),
                    this.getZ(),
                    7.0F,
                    true,
                    ExplosionInteraction.MOB
                );
            this.discard();
        }

        if (this.random.nextInt(30) == 0) {
            EntityColorLightningBolt colorLightningBolt = new EntityColorLightningBolt(this.level(), 1.0F, 0.0F, 1.0F);
            colorLightningBolt.setPos(this.getX(), this.getY(), this.getZ());
            if (!this.level().isClientSide()) {
                this.level().addFreshEntity(colorLightningBolt);
            }
        }

        for (Entity entity : this.level().getEntities(this, this.getBoundingBox().inflate(8.0, 8.0, 8.0))) {
            if (entity != null
                && entity.isAlive()
                && entity instanceof LivingEntity
                && this.getOwner() instanceof EntityEnderColossus
                && !(entity instanceof EntityEnderColossus)) {
                LivingEntity livingEntity = (LivingEntity)entity;
                EntityEnderColossus titan = (EntityEnderColossus)this.getOwner();
                float amount = 5.0F;
                int knockbackAmount = 1;
                if (titan.canAttackEntity(livingEntity)) {
                    livingEntity.setRemainingFireTicks(15);
                    livingEntity.hurt(this.damageSources().lightningBolt(), 100.0F);
                    EntityColorLightningBolt colorLightningBolt1 = new EntityColorLightningBolt(this.level(), 1.0F, 0.0F, 1.0F);
                    colorLightningBolt1.setPos(this.getX(), this.getY(), this.getZ());
                    EntityColorLightningBolt colorLightningBolt2 = new EntityColorLightningBolt(this.level(), 1.0F, 0.0F, 1.0F);
                    colorLightningBolt2.setPos(livingEntity.getX(), livingEntity.getY(), livingEntity.getZ());
                    if (!this.level().isClientSide()) {
                        this.level().addFreshEntity(colorLightningBolt1);
                        this.level().addFreshEntity(colorLightningBolt2);
                    }

                    titan.attackEntity(livingEntity, amount);
                    titan.knockbackEntity(livingEntity, (float)knockbackAmount);
                }
            }
        }
    }
}
