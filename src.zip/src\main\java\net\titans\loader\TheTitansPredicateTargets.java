package net.titans.loader;

import java.util.function.Predicate;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.animal.Chicken;
import net.minecraft.world.entity.animal.IronGolem;
import net.minecraft.world.entity.animal.SnowGolem;
import net.minecraft.world.entity.monster.MagmaCube;
import net.minecraft.world.entity.monster.Slime;
import net.minecraft.world.entity.player.Player;
import net.titans.entity.EntityWitherTurret;
import net.titans.entity.PredicateTitanTarget;
import net.titans.entity.minion.EntityBlazeTitanMinion;
import net.titans.entity.minion.EntityCaveSpiderTitanMinion;
import net.titans.entity.minion.EntityCreeperTitanMinion;
import net.titans.entity.minion.EntityDragonMinion;
import net.titans.entity.minion.EntityEnderColossusMinion;
import net.titans.entity.minion.EntityGhastGuardMinion;
import net.titans.entity.minion.EntityGhastTitanMinion;
import net.titans.entity.minion.EntityOmegafishMinion;
import net.titans.entity.minion.EntitySkeletonTitanMinion;
import net.titans.entity.minion.EntitySpiderTitanMinion;
import net.titans.entity.minion.EntityWitherMinion;
import net.titans.entity.minion.EntityWitherSkeletonTitanMinion;
import net.titans.entity.minion.EntityWitherzillaMinion;
import net.titans.entity.minion.EntityZombieTitanGiantMinion;
import net.titans.entity.minion.EntityZombieTitanMinion;
import net.titans.entity.minion.EntityZombifiedPiglinTitanMinion;
import net.titans.entity.titan.EntityBlazeTitan;
import net.titans.entity.titan.EntityCaveSpiderTitan;
import net.titans.entity.titan.EntityCreeperTitan;
import net.titans.entity.titan.EntityEnderColossus;
import net.titans.entity.titan.EntityGhastTitan;
import net.titans.entity.titan.EntityIronGolemTitan;
import net.titans.entity.titan.EntityMagmaCubeTitan;
import net.titans.entity.titan.EntityOmegafish;
import net.titans.entity.titan.EntitySkeletonTitan;
import net.titans.entity.titan.EntitySlimeTitan;
import net.titans.entity.titan.EntitySnowGolemTitan;
import net.titans.entity.titan.EntitySpiderTitan;
import net.titans.entity.titan.EntityWitherzilla;
import net.titans.entity.titan.EntityZombieTitan;
import net.titans.entity.titan.EntityZombifiedPiglinTitan;

public class TheTitansPredicateTargets {
    public static final PredicateTitanTarget All = new PredicateTitanTarget(entity -> true, true);
    public static final PredicateTitanTarget SnowGolemTitan = new PredicateTitanTarget(
        new Predicate<LivingEntity>() {
            public boolean test(LivingEntity entity) {
                return !(entity instanceof EntitySnowGolemTitan)
                    && !(entity instanceof EntityIronGolemTitan)
                    && !(entity instanceof SnowGolem)
                    && !(entity instanceof Player);
            }
        }
    );
    public static final PredicateTitanTarget SlimeTitan = new PredicateTitanTarget(new Predicate<LivingEntity>() {
        public boolean test(LivingEntity entity) {
            return !(entity instanceof EntitySlimeTitan) && !(entity instanceof Slime);
        }
    });
    public static final PredicateTitanTarget MagmaCubeTitan = new PredicateTitanTarget(new Predicate<LivingEntity>() {
        public boolean test(LivingEntity entity) {
            return !(entity instanceof EntityMagmaCubeTitan) && !(entity instanceof MagmaCube);
        }
    });
    public static final PredicateTitanTarget Omegafish = new PredicateTitanTarget(new Predicate<LivingEntity>() {
        public boolean test(LivingEntity entity) {
            return !(entity instanceof EntityOmegafish) && !(entity instanceof EntityOmegafishMinion);
        }
    });
    public static final PredicateTitanTarget ZombieTitan = new PredicateTitanTarget(
        new Predicate<LivingEntity>() {
            public boolean test(LivingEntity entity) {
                return !(entity instanceof EntityZombieTitan)
                    && !(entity instanceof EntityZombieTitanMinion)
                    && !(entity instanceof EntityZombieTitanGiantMinion)
                    && (
                        !(entity instanceof Chicken)
                            || !((Chicken)entity).isChickenJockey()
                            || !entity.isVehicle()
                            || !entity.hasPassenger(passenger -> passenger instanceof EntityZombieTitanMinion)
                    );
            }
        }
    );
    public static final PredicateTitanTarget SkeletonTitan = new PredicateTitanTarget(
        new Predicate<LivingEntity>() {
            public boolean test(LivingEntity entity) {
                return !(entity instanceof EntitySkeletonTitan)
                    && (!entity.isVehicle() || !entity.hasPassenger(passenger -> passenger instanceof EntitySkeletonTitan))
                    && !(entity instanceof EntitySkeletonTitanMinion)
                    && (!entity.isVehicle() || !entity.hasPassenger(passenger -> passenger instanceof EntitySkeletonTitanMinion))
                    && !(entity instanceof EntityWitherSkeletonTitanMinion)
                    && !(entity instanceof EntityWitherMinion);
            }
        }
    );
    public static final PredicateTitanTarget CreeperTitan = new PredicateTitanTarget(new Predicate<LivingEntity>() {
        public boolean test(LivingEntity entity) {
            return !(entity instanceof EntityCreeperTitan) && !(entity instanceof EntityCreeperTitanMinion);
        }
    });
    public static final PredicateTitanTarget SpiderTitan = new PredicateTitanTarget(
        new Predicate<LivingEntity>() {
            public boolean test(LivingEntity entity) {
                return !(entity instanceof EntitySpiderTitan)
                    && (!entity.isPassenger() || !(entity.getVehicle() instanceof EntitySpiderTitan))
                    && !(entity instanceof EntitySpiderTitanMinion)
                    && (!entity.isPassenger() || !(entity.getVehicle() instanceof EntitySpiderTitanMinion));
            }
        }
    );
    public static final PredicateTitanTarget CaveSpiderTitan = new PredicateTitanTarget(
        new Predicate<LivingEntity>() {
            public boolean test(LivingEntity entity) {
                return !(entity instanceof EntityCaveSpiderTitan)
                    && (!entity.isPassenger() || !(entity.getVehicle() instanceof EntityCaveSpiderTitan))
                    && !(entity instanceof EntityCaveSpiderTitanMinion)
                    && (!entity.isPassenger() || !(entity.getVehicle() instanceof EntityCaveSpiderTitanMinion));
            }
        }
    );
    public static final PredicateTitanTarget ZombifiedPiglinTitan = new PredicateTitanTarget(
        new Predicate<LivingEntity>() {
            public boolean test(LivingEntity entity) {
                return !(entity instanceof EntityZombifiedPiglinTitan)
                    && !(entity instanceof EntityZombifiedPiglinTitanMinion)
                    && !(entity instanceof EntityGhastGuardMinion);
            }
        }
    );
    public static final PredicateTitanTarget BlazeTitan = new PredicateTitanTarget(new Predicate<LivingEntity>() {
        public boolean test(LivingEntity entity) {
            return !(entity instanceof EntityBlazeTitan) && !(entity instanceof EntityBlazeTitanMinion);
        }
    });
    public static final PredicateTitanTarget EnderColossus = new PredicateTitanTarget(new Predicate<LivingEntity>() {
        public boolean test(LivingEntity entity) {
            return !(entity instanceof EntityEnderColossus) && !(entity instanceof EntityEnderColossusMinion) && !(entity instanceof EntityDragonMinion);
        }
    });
    public static final PredicateTitanTarget GhastTitan = new PredicateTitanTarget(new Predicate<LivingEntity>() {
        public boolean test(LivingEntity entity) {
            return !(entity instanceof EntityGhastTitan) && !(entity instanceof EntityGhastTitanMinion);
        }
    });
    public static final PredicateTitanTarget IronGolemTitan = new PredicateTitanTarget(new Predicate<LivingEntity>() {
        public boolean test(LivingEntity entity) {
            return !(entity instanceof EntityIronGolemTitan) && !(entity instanceof EntitySnowGolemTitan) && !(entity instanceof IronGolem);
        }
    });
    public static final PredicateTitanTarget Witherzilla = new PredicateTitanTarget(new Predicate<LivingEntity>() {
        public boolean test(LivingEntity entity) {
            return !(entity instanceof EntityWitherzilla) && !(entity instanceof EntityWitherzillaMinion) && !(entity instanceof EntityWitherTurret);
        }
    }, true);
}
