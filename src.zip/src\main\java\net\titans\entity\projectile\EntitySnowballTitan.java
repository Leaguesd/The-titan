package net.titans.entity.projectile;

import net.minecraft.core.BlockPos;
import net.minecraft.util.Mth;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.ItemSupplier;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.Level.ExplosionInteraction;
import net.minecraft.world.level.biome.Biome;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;
import net.titans.entity.titan.EntityTitan;
import net.titans.loader.TheTitansEntities;

public class EntitySnowballTitan extends EntityTitanProjectile implements ItemSupplier {
    public EntitySnowballTitan(EntityType<? extends EntitySnowballTitan> entityType, Level level) {
        super(entityType, level);
    }

    public EntitySnowballTitan(Level level, LivingEntity shooter) {
        this((EntityType<? extends EntitySnowballTitan>)TheTitansEntities.SNOWBALL_TITAN.get(), level);
        this.setOwner(shooter);
    }

    public ItemStack getItem() {
        return new ItemStack(Items.SNOWBALL);
    }

    protected boolean shouldBurn() {
        return false;
    }

    protected boolean canHitEntity(Entity entity) {
        return this.getOwner() != null && entity == this.getOwner() ? false : super.canHitEntity(entity);
    }

    public boolean hurt(DamageSource damageSource, float amount) {
        return false;
    }

    protected void onHitEntity(EntityHitResult result) {
        Entity entity = result.getEntity();
        if (entity instanceof LivingEntity && this.getOwner() instanceof EntityTitan) {
            LivingEntity livingEntity = (LivingEntity)entity;
            EntityTitan titan = (EntityTitan)this.getOwner();
            float amount = 60.0F;
            titan.attackEntity(livingEntity, amount);
            if (!this.level().isClientSide()) {
                this.discard();
            }
        }

        super.onHitEntity(result);
    }

    protected void onHitBlock(BlockHitResult result) {
        for (int i = 0; i < 128; i++) {
            int x = Mth.floor(this.getX() + ((double)this.random.nextFloat() - 0.5) * (double)this.getBbWidth());
            int y = Mth.floor(this.getY());
            int z = Mth.floor(this.getZ() + ((double)this.random.nextFloat() - 0.5) * (double)this.getBbWidth());
            BlockPos blockPos = new BlockPos(x, y, z);
            BlockState blockState = this.level().getBlockState(blockPos);
            if (blockState.isAir()
                && ((Biome)this.level().getBiome(blockPos).value()).getBaseTemperature() < 1.3F
                && Blocks.SNOW.defaultBlockState().canSurvive(this.level(), blockPos)) {
                this.level().setBlockAndUpdate(blockPos, Blocks.SNOW.defaultBlockState());
            }
        }

        if (!this.level().isClientSide()) {
            this.level()
                .explode(
                    (Entity)(this.getOwner() != null ? this.getOwner() : this),
                    this.getX(),
                    this.getY(),
                    this.getZ(),
                    1.0F,
                    false,
                    ExplosionInteraction.MOB
                );
            this.discard();
        }
    }

    public void tick() {
        super.tick();

        for (Entity entity : this.level().getEntities(this, this.getBoundingBox())) {
            if (this.canHitEntity(entity)) {
                this.onHitEntity(new EntityHitResult(entity));
            }
        }
    }
}
