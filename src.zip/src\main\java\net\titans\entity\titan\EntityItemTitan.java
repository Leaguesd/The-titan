package net.titans.entity.titan;

import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.titans.loader.TheTitansEntities;

public class EntityItemTitan extends ItemEntity {
    public EntityItemTitan(EntityType<? extends ItemEntity> entityType, Level level) {
        super((EntityType)TheTitansEntities.ITEM_TITAN.get(), level);
    }

    public EntityItemTitan(Level level, double posX, double posY, double posZ, ItemStack itemStack, int count) {
        this(level, posX, posY, posZ, itemStack);
        itemStack.setCount(itemStack.getCount() * count);
    }

    public EntityItemTitan(Level level, double posX, double posY, double posZ, ItemStack itemStack) {
        this((EntityType<? extends ItemEntity>)TheTitansEntities.ITEM_TITAN.get(), level);
        this.setPos(posX, posY, posZ);
        this.setItem(itemStack);
    }

    public EntityItemTitan(Level level, double posX, double posY, double posZ, ItemStack itemStack, double deltaX, double deltaY, double deltaZ) {
        this(level, posX, posY, posZ, itemStack);
        this.setDeltaMovement(deltaX, deltaY, deltaZ);
    }

    public boolean fireImmune() {
        return true;
    }

    public boolean hurt(DamageSource damageSource, float amount) {
        return false;
    }

    public void updateFluidHeightAndDoFluidPushing() {
    }
}
