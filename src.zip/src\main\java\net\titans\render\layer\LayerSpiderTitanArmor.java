package net.titans.render.layer;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.titans.entity.titan.EntitySpiderTitan;
import net.titans.model.ModelSpiderTitan;

@OnlyIn(Dist.CLIENT)
public class LayerSpiderTitanArmor extends RenderLayer<EntitySpiderTitan, ModelSpiderTitan> {
    private static final ResourceLocation DISINTIGRATION = ResourceLocation.tryBuild("titan", "textures/entity/disintigration.png");
    public ModelSpiderTitan model = new ModelSpiderTitan(0.1F);

    public LayerSpiderTitanArmor(RenderLayerParent<EntitySpiderTitan, ModelSpiderTitan> renderer) {
        super(renderer);
    }

    public void render(
        PoseStack poseStack,
        MultiBufferSource multiBufferSource,
        int packedLight,
        EntitySpiderTitan entity,
        float limbSwing,
        float limbSwingAmount,
        float partialTicks,
        float ageInTicks,
        float netHeadYaw,
        float headPitch
    ) {
        if (entity.isArmored()) {
            float f = (float)entity.tickCount + partialTicks;
            this.model.prepareMobModel(entity, limbSwing, limbSwingAmount, partialTicks);
            ((ModelSpiderTitan)this.getParentModel()).copyPropertiesTo(this.model);
            VertexConsumer vertexconsumer = multiBufferSource.getBuffer(RenderType.energySwirl(DISINTIGRATION, this.xOffset(f) % 1.0F, f * 0.01F % 1.0F));
            this.model.setupAnim(entity, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch);
            this.model.renderToBuffer(poseStack, vertexconsumer, packedLight, OverlayTexture.NO_OVERLAY, 1.0F, 1.0F, 1.0F, 1.0F);
        }
    }

    protected float xOffset(float tickCount) {
        return Mth.cos(tickCount * 0.02F) * 5.0F;
    }
}
