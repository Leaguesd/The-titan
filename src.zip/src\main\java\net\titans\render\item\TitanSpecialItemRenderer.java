package net.titans.render.item;

import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.geom.EntityModelSet;
import net.minecraft.client.renderer.BlockEntityWithoutLevelRenderer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.blockentity.BlockEntityRenderDispatcher;
import net.minecraft.client.resources.model.BakedModel;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.client.extensions.common.IClientItemExtensions;
import net.titans.item.ItemTitanSpawnEgg;
import net.titans.loader.TheTitansRegistries;

@OnlyIn(Dist.CLIENT)
public class TitanSpecialItemRenderer extends BlockEntityWithoutLevelRenderer {
    private static BlockEntityWithoutLevelRenderer INSTANCE;
    private final RenderUltimaBlade ultimaBlade = new RenderUltimaBlade();
    private final RenderOptimaAxe optimaAxe = new RenderOptimaAxe();
    private final RenderTitanSpawnEgg titanSpawnEgg = new RenderTitanSpawnEgg();
    private final RenderWitherzillaSpawnEgg witherzillaSpawnEgg = new RenderWitherzillaSpawnEgg();

    public TitanSpecialItemRenderer(BlockEntityRenderDispatcher blockEntityRenderDispatcher, EntityModelSet entityModelSet) {
        super(blockEntityRenderDispatcher, entityModelSet);
    }

    public static IClientItemExtensions createExtensions() {
        return new IClientItemExtensions() {
            public BlockEntityWithoutLevelRenderer getCustomRenderer() {
                if (TitanSpecialItemRenderer.INSTANCE == null) {
                    Minecraft minecraft = Minecraft.getInstance();
                    TitanSpecialItemRenderer.INSTANCE = new TitanSpecialItemRenderer(minecraft.getBlockEntityRenderDispatcher(), minecraft.getEntityModels());
                }

                return TitanSpecialItemRenderer.INSTANCE;
            }
        };
    }

    public void renderByItem(
        ItemStack stack, ItemDisplayContext context, PoseStack poseStack, MultiBufferSource multiBufferSource, int packedLight, int packedOverlay
    ) {
        IItemRenderer renderer = this.getRenderer(stack.getItem());
        if (renderer != null) {
            Minecraft minecraft = Minecraft.getInstance();
            BakedModel bakedModel = minecraft.getItemRenderer().getModel(stack, minecraft.level, minecraft.player, 0);
            boolean leftHand = context == ItemDisplayContext.FIRST_PERSON_LEFT_HAND || context == ItemDisplayContext.THIRD_PERSON_LEFT_HAND;
            renderer.render(stack, context, leftHand, poseStack, multiBufferSource, packedLight, packedOverlay, bakedModel);
        }
    }

    private IItemRenderer getRenderer(Item item) {
        if (item == TheTitansRegistries.ULTIMA_BLADE.get()) {
            return this.ultimaBlade;
        } else if (item == TheTitansRegistries.OPTIMA_AXE.get()) {
            return this.optimaAxe;
        } else if (item instanceof ItemTitanSpawnEgg) {
            return (IItemRenderer)(item == TheTitansRegistries.SPAWN_EGG_WITHERZILLA.get() ? this.witherzillaSpawnEgg : this.titanSpawnEgg);
        } else {
            return null;
        }
    }
}
