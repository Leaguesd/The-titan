package net.titans.loader;

import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.biome.Biome;

public class TheTitansBiomes {
    public static final ResourceKey<Biome> THE_VOID = ResourceKey.create(Registries.BIOME, ResourceLocation.tryBuild("titan", "the_void"));
}
