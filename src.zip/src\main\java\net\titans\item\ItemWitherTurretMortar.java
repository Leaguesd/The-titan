package net.titans.item;

import net.minecraft.world.item.Item.Properties;
import net.minecraft.world.level.Level;
import net.titans.entity.EntityWitherTurret;
import net.titans.entity.EntityWitherTurretMortar;

public class ItemWitherTurretMortar extends ItemWitherTurret {
    public ItemWitherTurretMortar(Properties properties) {
        super(properties);
    }

    @Override
    public EntityWitherTurret getEntity(Level level) {
        return new EntityWitherTurretMortar(level);
    }
}
