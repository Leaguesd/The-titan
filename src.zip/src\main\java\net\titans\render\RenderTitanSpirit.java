package net.titans.render;

import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider.Context;
import net.minecraft.resources.ResourceLocation;
import net.titans.entity.titan.EntityTitanSpirit;

public class RenderTitanSpirit extends EntityRenderer<EntityTitanSpirit> {
    public RenderTitanSpirit(Context context) {
        super(context);
    }

    public ResourceLocation getTextureLocation(EntityTitanSpirit entity) {
        return null;
    }
}
