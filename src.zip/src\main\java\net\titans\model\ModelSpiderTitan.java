package net.titans.model;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.util.Mth;
import net.titans.animation.Animator;
import net.titans.entity.titan.EntitySpiderTitan;

public class ModelSpiderTitan extends EntityModel<EntitySpiderTitan> {
    public Animator animator;
    public ModelPart thorax;
    public ModelPart head;
    public ModelPart abdoman;
    public ModelPart frontleftupperarm;
    public ModelPart frontrightupperarm;
    public ModelPart frontleftupperleg;
    public ModelPart frontrightupperleg;
    public ModelPart backrightupperleg1;
    public ModelPart backrightupperleg2;
    public ModelPart backleftupperleg1;
    public ModelPart backleftupperleg2;
    public ModelPart frontleftlowerarm;
    public ModelPart frontrightlowerarm;
    public ModelPart frontleftlowerleg;
    public ModelPart frontrightlowerleg;
    public ModelPart backrightlowerleg1;
    public ModelPart backrightlowerleg2;
    public ModelPart backleftlowerleg1;
    public ModelPart backleftlowerleg2;

    public ModelSpiderTitan(float grow) {
        ModelPart root = createBodyLayer(grow).bakeRoot();
        this.thorax = root.getChild("thorax");
        this.head = root.getChild("thorax").getChild("head");
        this.abdoman = root.getChild("thorax").getChild("abdoman");
        this.frontleftupperarm = root.getChild("thorax").getChild("frontleftupperarm");
        this.frontleftlowerarm = root.getChild("thorax").getChild("frontleftupperarm").getChild("frontleftlowerarm");
        this.frontrightupperarm = root.getChild("thorax").getChild("frontrightupperarm");
        this.frontrightlowerarm = root.getChild("thorax").getChild("frontrightupperarm").getChild("frontrightlowerarm");
        this.frontleftupperleg = root.getChild("thorax").getChild("frontleftupperleg");
        this.frontleftlowerleg = root.getChild("thorax").getChild("frontleftupperleg").getChild("frontleftlowerleg");
        this.frontrightupperleg = root.getChild("thorax").getChild("frontrightupperleg");
        this.frontrightlowerleg = root.getChild("thorax").getChild("frontrightupperleg").getChild("frontrightlowerleg");
        this.backleftupperleg1 = root.getChild("thorax").getChild("backleftupperleg1");
        this.backleftlowerleg1 = root.getChild("thorax").getChild("backleftupperleg1").getChild("backleftlowerleg1");
        this.backleftupperleg2 = root.getChild("thorax").getChild("backleftupperleg2");
        this.backleftlowerleg2 = root.getChild("thorax").getChild("backleftupperleg2").getChild("backleftlowerleg2");
        this.backrightupperleg1 = root.getChild("thorax").getChild("backrightupperleg1");
        this.backrightlowerleg1 = root.getChild("thorax").getChild("backrightupperleg1").getChild("backrightlowerleg1");
        this.backrightupperleg2 = root.getChild("thorax").getChild("backrightupperleg2");
        this.backrightlowerleg2 = root.getChild("thorax").getChild("backrightupperleg2").getChild("backrightlowerleg2");
        this.animator = new Animator(root);
    }

    public static LayerDefinition createBodyLayer(float grow) {
        MeshDefinition meshDefinition = new MeshDefinition();
        PartDefinition partDefinition = meshDefinition.getRoot();
        CubeDeformation cubeDeformation = new CubeDeformation(grow);
        partDefinition.addOrReplaceChild(
            "thorax",
            CubeListBuilder.create().texOffs(0, 16).addBox(-3.0F, -3.0F, -3.0F, 6.0F, 6.0F, 6.0F, cubeDeformation),
            PartPose.offsetAndRotation(0.0F, 15.0F, 0.0F, 0.0F, 0.0F, 0.0F)
        );
        partDefinition.getChild("thorax")
            .addOrReplaceChild(
                "head",
                CubeListBuilder.create().texOffs(0, 0).addBox(-4.0F, -4.0F, -8.0F, 8.0F, 8.0F, 8.0F, cubeDeformation),
                PartPose.offsetAndRotation(0.0F, 0.0F, -3.0F, 0.0F, 0.0F, 0.0F)
            );
        partDefinition.getChild("thorax")
            .addOrReplaceChild(
                "abdoman",
                CubeListBuilder.create().texOffs(0, 28).addBox(-5.0F, -4.0F, 0.0F, 10.0F, 8.0F, 12.0F, cubeDeformation),
                PartPose.offsetAndRotation(0.0F, 0.0F, 3.0F, 0.0F, 0.0F, 0.0F)
            );
        partDefinition.getChild("thorax")
            .addOrReplaceChild(
                "frontleftupperarm",
                CubeListBuilder.create().texOffs(32, 0).mirror().addBox(-1.0F, 0.0F, -1.0F, 2.0F, 8.0F, 2.0F, cubeDeformation),
                PartPose.offsetAndRotation(3.0F, 0.0F, -2.0F, 0.0F, 0.0F, 0.0F)
            );
        partDefinition.getChild("thorax")
            .getChild("frontleftupperarm")
            .addOrReplaceChild(
                "frontleftlowerarm",
                CubeListBuilder.create().texOffs(32, 10).mirror().addBox(-1.0F, 0.0F, -1.0F, 2.0F, 8.0F, 2.0F, cubeDeformation),
                PartPose.offsetAndRotation(0.0F, 8.0F, 0.0F, 0.0F, 0.0F, 0.0F)
            );
        partDefinition.getChild("thorax")
            .addOrReplaceChild(
                "frontrightupperarm",
                CubeListBuilder.create().texOffs(32, 0).addBox(-1.0F, 0.0F, -1.0F, 2.0F, 8.0F, 2.0F, cubeDeformation),
                PartPose.offsetAndRotation(-3.0F, 0.0F, -2.0F, 0.0F, 0.0F, 0.0F)
            );
        partDefinition.getChild("thorax")
            .getChild("frontrightupperarm")
            .addOrReplaceChild(
                "frontrightlowerarm",
                CubeListBuilder.create().texOffs(32, 10).addBox(-1.0F, 0.0F, -1.0F, 2.0F, 8.0F, 2.0F, cubeDeformation),
                PartPose.offsetAndRotation(0.0F, 8.0F, 0.0F, 0.0F, 0.0F, 0.0F)
            );
        partDefinition.getChild("thorax")
            .addOrReplaceChild(
                "frontleftupperleg",
                CubeListBuilder.create().texOffs(32, 0).mirror().addBox(-1.0F, 0.0F, -1.0F, 2.0F, 8.0F, 2.0F, cubeDeformation),
                PartPose.offsetAndRotation(-3.0F, 0.0F, 1.0F, 0.0F, 0.0F, 0.0F)
            );
        partDefinition.getChild("thorax")
            .getChild("frontleftupperleg")
            .addOrReplaceChild(
                "frontleftlowerleg",
                CubeListBuilder.create().texOffs(32, 10).mirror().addBox(-1.0F, 0.0F, -1.0F, 2.0F, 8.0F, 2.0F, cubeDeformation),
                PartPose.offsetAndRotation(0.0F, 8.0F, 0.0F, 0.0F, 0.0F, 0.0F)
            );
        partDefinition.getChild("thorax")
            .addOrReplaceChild(
                "frontrightupperleg",
                CubeListBuilder.create().texOffs(32, 0).addBox(-1.0F, 0.0F, -1.0F, 2.0F, 8.0F, 2.0F, cubeDeformation),
                PartPose.offsetAndRotation(-3.0F, 0.0F, -1.0F, 0.0F, 0.0F, 0.0F)
            );
        partDefinition.getChild("thorax")
            .getChild("frontrightupperleg")
            .addOrReplaceChild(
                "frontrightlowerleg",
                CubeListBuilder.create().texOffs(32, 10).addBox(-1.0F, 0.0F, -1.0F, 2.0F, 8.0F, 2.0F, cubeDeformation),
                PartPose.offsetAndRotation(0.0F, 8.0F, 0.0F, 0.0F, 0.0F, 0.0F)
            );
        partDefinition.getChild("thorax")
            .addOrReplaceChild(
                "backleftupperleg1",
                CubeListBuilder.create().texOffs(32, 0).mirror().addBox(-1.0F, 0.0F, -1.0F, 2.0F, 8.0F, 2.0F, cubeDeformation),
                PartPose.offsetAndRotation(3.0F, 0.0F, 1.0F, 0.0F, 0.0F, 0.0F)
            );
        partDefinition.getChild("thorax")
            .getChild("backleftupperleg1")
            .addOrReplaceChild(
                "backleftlowerleg1",
                CubeListBuilder.create().texOffs(32, 10).mirror().addBox(-1.0F, 0.0F, -1.0F, 2.0F, 8.0F, 2.0F, cubeDeformation),
                PartPose.offsetAndRotation(0.0F, 8.0F, 0.0F, 0.0F, 0.0F, 0.0F)
            );
        partDefinition.getChild("thorax")
            .addOrReplaceChild(
                "backleftupperleg2",
                CubeListBuilder.create().texOffs(32, 0).mirror().addBox(-1.0F, 0.0F, -1.0F, 2.0F, 8.0F, 2.0F, cubeDeformation),
                PartPose.offsetAndRotation(3.0F, 0.0F, 2.0F, 0.0F, 0.0F, 0.0F)
            );
        partDefinition.getChild("thorax")
            .getChild("backleftupperleg2")
            .addOrReplaceChild(
                "backleftlowerleg2",
                CubeListBuilder.create().texOffs(32, 10).mirror().addBox(-1.0F, 0.0F, -1.0F, 2.0F, 8.0F, 2.0F, cubeDeformation),
                PartPose.offsetAndRotation(0.0F, 8.0F, 0.0F, 0.0F, 0.0F, 0.0F)
            );
        partDefinition.getChild("thorax")
            .addOrReplaceChild(
                "backrightupperleg1",
                CubeListBuilder.create().texOffs(32, 0).addBox(-1.0F, 0.0F, -1.0F, 2.0F, 8.0F, 2.0F, cubeDeformation),
                PartPose.offsetAndRotation(3.0F, 0.0F, -1.0F, 0.0F, 0.0F, 0.0F)
            );
        partDefinition.getChild("thorax")
            .getChild("backrightupperleg1")
            .addOrReplaceChild(
                "backrightlowerleg1",
                CubeListBuilder.create().texOffs(32, 10).addBox(-1.0F, 0.0F, -1.0F, 2.0F, 8.0F, 2.0F, cubeDeformation),
                PartPose.offsetAndRotation(0.0F, 8.0F, 0.0F, 0.0F, 0.0F, 0.0F)
            );
        partDefinition.getChild("thorax")
            .addOrReplaceChild(
                "backrightupperleg2",
                CubeListBuilder.create().texOffs(32, 0).addBox(-1.0F, 0.0F, -1.0F, 2.0F, 8.0F, 2.0F, cubeDeformation),
                PartPose.offsetAndRotation(-3.0F, 0.0F, 2.0F, 0.0F, 0.0F, 0.0F)
            );
        partDefinition.getChild("thorax")
            .getChild("backrightupperleg2")
            .addOrReplaceChild(
                "backrightlowerleg2",
                CubeListBuilder.create().texOffs(32, 0).addBox(-1.0F, 0.0F, -1.0F, 2.0F, 8.0F, 2.0F, cubeDeformation),
                PartPose.offsetAndRotation(0.0F, 8.0F, 0.0F, 0.0F, 0.0F, 0.0F)
            );
        return LayerDefinition.create(meshDefinition, 64, 64);
    }

    public void setupAnim(EntitySpiderTitan entity, float limbSwing, float limbSwingAmount, float ageInTicks, float headYaw, float headPitch) {
        this.animate(entity, limbSwing, limbSwingAmount, ageInTicks, headYaw, headPitch);
    }

    public void renderToBuffer(PoseStack poseStack, VertexConsumer vertexConsumer, int packedLight, int packedOverlay, float red, float green, float blue, float alpha) {
        this.thorax.render(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
    }

    public void setAngles() {
        this.thorax.y = 15.0F;
        this.thorax.x = 0.0F;
        this.thorax.z = 0.0F;
        this.head.xRot = 0.0F;
        this.thorax.xRot = 0.0F;
        this.abdoman.xRot = 0.0F;
        this.frontrightupperarm.xRot = -1.2217305F;
        this.frontrightupperarm.yRot = 0.87266463F;
        this.frontleftupperarm.xRot = -1.2217305F;
        this.frontleftupperarm.yRot = -0.87266463F;
        this.frontrightlowerarm.xRot = 0.475F;
        this.frontleftlowerarm.xRot = 0.475F;
        this.frontleftupperleg.xRot = -1.2217305F;
        this.frontleftupperleg.yRot = (float) (-Math.PI * 5.0 / 12.0);
        this.frontrightupperleg.xRot = -1.2217305F;
        this.frontrightupperleg.yRot = (float) (Math.PI * 5.0 / 12.0);
        this.frontleftlowerleg.xRot = 0.475F;
        this.frontrightlowerleg.xRot = 0.475F;
        this.backleftupperleg1.xRot = -1.2217305F;
        this.backleftupperleg1.yRot = (float) (-Math.PI * 7.0 / 12.0);
        this.backrightupperleg1.xRot = -1.2217305F;
        this.backrightupperleg1.yRot = (float) (Math.PI * 7.0 / 12.0);
        this.backleftlowerleg1.xRot = 0.475F;
        this.backrightlowerleg1.xRot = 0.475F;
        this.backleftupperleg2.xRot = -1.2217305F;
        this.backleftupperleg2.yRot = -2.1816616F;
        this.backrightupperleg2.xRot = -1.2217305F;
        this.backrightupperleg2.yRot = 2.1816616F;
        this.backleftlowerleg2.xRot = 0.475F;
        this.backrightlowerleg2.xRot = 0.475F;
    }

    public void animate(EntitySpiderTitan entity, float limbSwing, float limbSwingAmount, float ageInTicks, float headYaw, float headPitch) {
        float partialTicks = Minecraft.getInstance().getFrameTime();
        this.animator.update(entity);
        this.setAngles();
        if (entity.deathTicks <= 0) {
            if (this.riding) {
                this.frontrightupperarm.yRot = 0.87266463F;
                this.frontleftupperarm.yRot = -0.87266463F;
                this.frontrightupperleg.yRot = (float) (Math.PI * 5.0 / 12.0);
                this.frontleftupperleg.yRot = (float) (-Math.PI * 5.0 / 12.0);
                this.backrightupperleg1.yRot = (float) (Math.PI * 7.0 / 12.0);
                this.backleftupperleg1.yRot = (float) (-Math.PI * 7.0 / 12.0);
                this.backrightupperleg2.yRot = 2.1816616F;
                this.backleftupperleg2.yRot = -2.1816616F;
                this.frontrightupperarm.xRot = -0.8F;
                this.frontleftupperarm.xRot = -0.8F;
                this.frontrightupperleg.xRot = -0.8F;
                this.frontleftupperleg.xRot = -0.8F;
                this.backrightupperleg1.xRot = -0.8F;
                this.backleftupperleg1.xRot = -0.8F;
                this.backrightupperleg2.xRot = -0.8F;
                this.backleftupperleg2.xRot = -0.8F;
            } else if (entity.getAnimationID() == 0) {
                this.frontrightupperarm.yRot = 0.87266463F + Mth.cos(limbSwing * 0.5F + 2.0F) * 0.3F * limbSwingAmount;
                this.frontleftupperarm.yRot = -0.87266463F + Mth.cos(limbSwing * 0.5F + 4.0F) * 0.3F * limbSwingAmount;
                this.frontrightupperleg.yRot = (float) (Math.PI * 5.0 / 12.0) + Mth.cos(limbSwing * 0.5F + 6.0F) * 0.3F * limbSwingAmount;
                this.frontleftupperleg.yRot = (float) (-Math.PI * 5.0 / 12.0) + Mth.cos(limbSwing * 0.5F) * 0.3F * limbSwingAmount;
                this.backrightupperleg1.yRot = (float) (Math.PI * 7.0 / 12.0) + Mth.cos(limbSwing * 0.5F + 6.0F) * 0.3F * limbSwingAmount;
                this.backleftupperleg1.yRot = (float) (-Math.PI * 7.0 / 12.0) + Mth.cos(limbSwing * 0.5F + 4.0F) * 0.3F * limbSwingAmount;
                this.backrightupperleg2.yRot = 2.1816616F + Mth.cos(limbSwing * 0.5F + 2.0F) * 0.3F * limbSwingAmount;
                this.backleftupperleg2.yRot = -2.1816616F + Mth.cos(limbSwing * 0.5F) * 0.3F * limbSwingAmount;
                this.frontrightupperarm.xRot = -1.2217305F + Mth.cos(limbSwing * 0.5F + 2.0F) * 0.15F * limbSwingAmount;
                this.frontleftupperarm.xRot = -1.2217305F + Mth.cos(limbSwing * 0.5F + 4.0F) * 0.15F * limbSwingAmount;
                this.frontrightupperleg.xRot = -1.2217305F + Mth.cos(limbSwing * 0.5F + 6.0F) * 0.15F * limbSwingAmount;
                this.frontleftupperleg.xRot = -1.2217305F + Mth.cos(limbSwing * 0.5F) * 0.15F * limbSwingAmount;
                this.backrightupperleg1.xRot = -1.2217305F + Mth.cos(limbSwing * 0.5F + 6.0F) * 0.15F * limbSwingAmount;
                this.backleftupperleg1.xRot = -1.2217305F + Mth.cos(limbSwing * 0.5F + 4.0F) * 0.15F * limbSwingAmount;
                this.backrightupperleg2.xRot = -1.2217305F + Mth.cos(limbSwing * 0.5F + 2.0F) * 0.15F * limbSwingAmount;
                this.backleftupperleg2.xRot = -1.2217305F + Mth.cos(limbSwing * 0.5F) * 0.15F * limbSwingAmount;
            }

            if (!entity.onGround() && !this.riding) {
                this.abdoman.xRot = (float)(
                    (double)this.abdoman.xRot
                        - (
                            Math.cos((double)(limbSwing * 0.35F - 1.5F)) * 0.1F * (double)limbSwingAmount
                                - 0.25
                                + (double)entity.walkAnimation.speed(partialTicks)
                        )
                );
                this.frontrightupperarm.yRot = 0.5F;
                this.frontleftupperarm.yRot = -0.5F;
                this.frontrightupperleg.yRot = 1.4F + entity.walkAnimation.speed(partialTicks);
                this.frontleftupperleg.yRot = -1.4F - entity.walkAnimation.speed(partialTicks);
                this.backrightupperleg1.yRot = 1.8F + entity.walkAnimation.speed(partialTicks);
                this.backleftupperleg1.yRot = -1.8F - entity.walkAnimation.speed(partialTicks);
                this.backrightupperleg2.yRot = 2.0F + entity.walkAnimation.speed(partialTicks);
                this.backleftupperleg2.yRot = -2.0F - entity.walkAnimation.speed(partialTicks);
                this.frontrightupperleg.xRot = -1.2217305F + Mth.cos(ageInTicks * 0.2F) * 0.25F;
                this.frontleftupperleg.xRot = -1.2217305F + Mth.cos(ageInTicks * 0.2F - 0.5F) * 0.25F;
                this.backrightupperleg1.xRot = -1.2217305F + Mth.cos(ageInTicks * 0.2F - 1.0F) * 0.25F;
                this.backleftupperleg1.xRot = -1.2217305F + Mth.cos(ageInTicks * 0.2F - 1.5F) * 0.25F;
                this.backrightupperleg2.xRot = -1.2217305F + Mth.cos(ageInTicks * 0.2F - 2.0F) * 0.25F;
                this.backleftupperleg2.xRot = -1.2217305F + Mth.cos(ageInTicks * 0.2F - 2.5F) * 0.25F;
                if (entity.getAnimationID() == 0) {
                    this.frontrightupperarm.xRot = -2.0F;
                    this.frontleftupperarm.xRot = -2.0F;
                }
            }

            if (entity.getAnimationID() == 0) {
                this.head.xRot = (0.01F + 0.01F * Mth.cos(ageInTicks * 0.1F)) * (float) Math.PI;
                this.abdoman.xRot = -(0.01F + 0.01F * Mth.cos(ageInTicks * 0.1F)) * (float) Math.PI;
                this.thorax.y = 15.0F - 0.025F * Mth.cos(ageInTicks * 0.1F) * (float) Math.PI;
            }

            if (entity.getAnimationID() == 6 && entity.getAnimationTick() >= 30 && entity.getAnimationTick() < 50) {
                this.abdoman.xRot = 0.1F * Mth.cos(ageInTicks * 1.0F) * (float) Math.PI;
            }

            if (entity.getAnimationID() == 6 && entity.getAnimationTick() >= 50 && entity.getAnimationTick() < 100) {
                this.abdoman.xRot = 0.1F * Mth.cos(ageInTicks * 1.5F) * (float) Math.PI;
            }

            float faceYaw = headYaw * (float) Math.PI / 180.0F;
            float facePitch = headPitch * (float) Math.PI / 180.0F;
            this.head.xRot += facePitch * 0.9F;
            this.head.yRot += faceYaw * 0.9F;
            if (entity.getAnimationID() == 1) {
                switch (entity.getAntiTitanAttackAnimationID()) {
                    case 0:
                        this.animateAntiTitanAttack1();
                        break;
                    case 1:
                        this.animateAntiTitanAttack2();
                        break;
                    case 2:
                        this.animateAntiTitanAttack3();
                        break;
                    case 3:
                        this.animateAntiTitanAttack4();
                }
            }

            this.animateBirth();
            this.animateBite();
            this.animateSpit();
            this.animateStomp();
            this.animateSwat();
            this.animateShootLightning();
            this.animateShootWeb();
            this.animateStunned();
            this.animateCrush();
        } else {
            this.animateDeath();
        }
    }

    private void animateBite() {
        this.animator.setAnimationID(4);
        this.animator.startPhase(20);
        this.animator.rotate(this.head, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.abdoman, 0.0F, 0.0F, 0.0F);
        this.animator.move(this.thorax, 0.0F, -4.0F, 0.0F);
        this.animator.rotate(this.frontleftupperarm, -1.5F, 0.6F, 0.0F);
        this.animator.rotate(this.frontrightupperarm, -1.5F, -0.6F, 0.0F);
        this.animator.rotate(this.frontleftlowerarm, 0.75F, -0.3F, 0.0F);
        this.animator.rotate(this.frontrightlowerarm, 0.75F, 0.3F, 0.0F);
        this.animator.rotate(this.frontrightupperleg, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.frontleftupperleg, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.backleftupperleg1, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.backleftupperleg2, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.backrightupperleg1, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.backrightupperleg2, 0.5F, 0.0F, 0.0F);
        this.animator.endPhase();
        this.animator.startPhase(10);
        this.animator.move(this.thorax, 0.0F, 0.0F, -16.0F);
        this.animator.rotate(this.frontleftupperarm, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.frontrightupperarm, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.frontleftlowerarm, 0.5F, -0.5F, 0.0F);
        this.animator.rotate(this.frontrightlowerarm, 0.5F, 0.5F, 0.0F);
        this.animator.rotate(this.head, 1.0F, 0.0F, 0.0F);
        this.animator.rotate(this.abdoman, 0.0F, 0.0F, 0.0F);
        this.animator.rotate(this.thorax, 0.0F, 0.0F, 0.0F);
        this.animator.rotate(this.frontrightupperleg, 0.0F, 1.0F, 0.0F);
        this.animator.rotate(this.frontleftupperleg, 0.0F, -1.0F, 0.0F);
        this.animator.rotate(this.backleftupperleg1, 0.0F, -1.0F, 0.0F);
        this.animator.rotate(this.backleftupperleg2, 0.0F, -1.0F, 0.0F);
        this.animator.rotate(this.backrightupperleg1, 0.0F, 1.0F, 0.0F);
        this.animator.rotate(this.backrightupperleg2, 0.0F, 1.0F, 0.0F);
        this.animator.endPhase();
        this.animator.resetPhase(30);
    }

    private void animateSpit() {
        this.animator.setAnimationID(2);
        this.animator.startPhase(20);
        this.animator.rotate(this.head, 0.3F, 0.0F, 0.0F);
        this.animator.rotate(this.abdoman, 0.3F, 0.0F, 0.0F);
        this.animator.move(this.thorax, 0.0F, 1.0F, 0.0F);
        this.animator.rotate(this.frontleftupperarm, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.frontrightupperarm, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.frontrightupperleg, -0.05F, 0.0F, 0.0F);
        this.animator.rotate(this.frontleftupperleg, -0.05F, 0.0F, 0.0F);
        this.animator.rotate(this.backleftupperleg1, -0.05F, 0.0F, 0.0F);
        this.animator.rotate(this.backleftupperleg2, -0.05F, 0.0F, 0.0F);
        this.animator.rotate(this.backrightupperleg1, -0.05F, 0.0F, 0.0F);
        this.animator.rotate(this.backrightupperleg2, -0.05F, 0.0F, 0.0F);
        this.animator.endPhase();
        this.animator.startPhase(40);
        this.animator.rotate(this.head, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.frontleftupperarm, -1.5F, -0.6F, 0.0F);
        this.animator.rotate(this.frontrightupperarm, -1.5F, 0.6F, 0.0F);
        this.animator.rotate(this.frontleftlowerarm, 0.75F, -0.3F, 0.0F);
        this.animator.rotate(this.frontrightlowerarm, 0.75F, 0.3F, 0.0F);
        this.animator.endPhase();
        this.animator.startPhase(10);
        this.animator.rotate(this.head, -0.25F, 0.0F, 0.0F);
        this.animator.rotate(this.frontleftupperarm, -1.5F, -0.6F, 0.0F);
        this.animator.rotate(this.frontrightupperarm, -1.5F, 0.6F, 0.0F);
        this.animator.rotate(this.frontleftlowerarm, 0.75F, -0.3F, 0.0F);
        this.animator.rotate(this.frontrightlowerarm, 0.75F, 0.3F, 0.0F);
        this.animator.endPhase();
        this.animator.startPhase(10);
        this.animator.rotate(this.head, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.frontleftupperarm, -1.5F, -0.6F, 0.0F);
        this.animator.rotate(this.frontrightupperarm, -1.5F, 0.6F, 0.0F);
        this.animator.rotate(this.frontleftlowerarm, 0.75F, -0.3F, 0.0F);
        this.animator.rotate(this.frontrightlowerarm, 0.75F, 0.3F, 0.0F);
        this.animator.endPhase();
        this.animator.setStationaryPhase(20);
        this.animator.resetPhase(20);
    }

    private void animateStomp() {
        this.animator.setAnimationID(3);
        this.animator.startPhase(20);
        this.animator.rotate(this.head, 0.3F, 0.0F, 0.0F);
        this.animator.rotate(this.abdoman, 0.3F, 0.0F, 0.0F);
        this.animator.move(this.thorax, 0.0F, 1.0F, 0.0F);
        this.animator.rotate(this.frontleftupperarm, -0.05F, 0.0F, 0.0F);
        this.animator.rotate(this.frontrightupperarm, -0.05F, 0.0F, 0.0F);
        this.animator.rotate(this.frontrightupperleg, -0.05F, 0.0F, 0.0F);
        this.animator.rotate(this.frontleftupperleg, -0.05F, 0.0F, 0.0F);
        this.animator.rotate(this.backleftupperleg1, -0.05F, 0.0F, 0.0F);
        this.animator.rotate(this.backleftupperleg2, -0.05F, 0.0F, 0.0F);
        this.animator.rotate(this.backrightupperleg1, -0.05F, 0.0F, 0.0F);
        this.animator.rotate(this.backrightupperleg2, -0.05F, 0.0F, 0.0F);
        this.animator.endPhase();
        this.animator.startPhase(20);
        this.animator.rotate(this.head, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.abdoman, 0.3F, 0.0F, 0.0F);
        this.animator.rotate(this.thorax, -0.5F, 0.0F, 0.0F);
        this.animator.move(this.thorax, 0.0F, -1.0F, 0.0F);
        this.animator.rotate(this.frontleftupperarm, -2.0F, 0.6F, 0.0F);
        this.animator.rotate(this.frontrightupperarm, -2.0F, -0.6F, 0.0F);
        this.animator.rotate(this.frontleftlowerarm, 0.75F, -0.3F, 0.0F);
        this.animator.rotate(this.frontrightlowerarm, 0.75F, 0.3F, 0.0F);
        this.animator.rotate(this.frontrightupperleg, 0.2F, 0.2F, 0.0F);
        this.animator.rotate(this.frontleftupperleg, 0.2F, -0.2F, 0.0F);
        this.animator.rotate(this.backleftupperleg1, -0.2F, -0.2F, 0.0F);
        this.animator.rotate(this.backleftupperleg2, -0.4F, -0.3F, 0.0F);
        this.animator.rotate(this.backrightupperleg1, -0.2F, 0.2F, 0.0F);
        this.animator.rotate(this.backrightupperleg2, -0.4F, 0.3F, 0.0F);
        this.animator.endPhase();
        this.animator.startPhase(20);
        this.animator.rotate(this.head, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.frontleftupperarm, 0.2F, 0.75F, 0.0F);
        this.animator.rotate(this.frontrightupperarm, 0.2F, -0.75F, 0.0F);
        this.animator.rotate(this.frontleftlowerarm, 0.2F, -0.75F, 0.0F);
        this.animator.rotate(this.frontrightlowerarm, 0.2F, 0.75F, 0.0F);
        this.animator.endPhase();
        this.animator.resetPhase(20);
    }

    private void animateSwat() {
        this.animator.setAnimationID(5);
        this.animator.startPhase(20);
        this.animator.rotate(this.frontrightupperarm, -1.5F, 0.0F, -1.0F);
        this.animator.rotate(this.frontrightlowerarm, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.head, 0.4F, -0.5F, 0.1F);
        this.animator.rotate(this.abdoman, 0.3F, 0.0F, 0.0F);
        this.animator.rotate(this.thorax, 0.0F, 0.5F, 0.0F);
        this.animator.rotate(this.frontleftupperarm, 0.0F, 0.5F, 0.0F);
        this.animator.rotate(this.frontrightupperleg, 0.0F, 0.5F, 0.0F);
        this.animator.rotate(this.frontleftupperleg, 0.0F, 0.5F, 0.0F);
        this.animator.rotate(this.backleftupperleg1, 0.0F, 0.5F, 0.0F);
        this.animator.rotate(this.backleftupperleg2, 0.0F, 0.5F, 0.0F);
        this.animator.rotate(this.backrightupperleg1, 0.0F, 0.5F, 0.0F);
        this.animator.rotate(this.backrightupperleg2, 0.0F, 0.5F, 0.0F);
        this.animator.endPhase();
        this.animator.startPhase(10);
        this.animator.rotate(this.frontrightupperarm, 2.0F, -2.0F, -1.0F);
        this.animator.rotate(this.frontrightlowerarm, 1.0F, 0.0F, 0.0F);
        this.animator.rotate(this.head, 0.4F, 0.5F, -0.1F);
        this.animator.rotate(this.abdoman, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.thorax, 0.0F, -0.5F, 0.0F);
        this.animator.rotate(this.frontleftupperarm, 0.0F, -0.1F, 0.0F);
        this.animator.rotate(this.frontrightupperleg, 0.0F, -0.1F, 0.0F);
        this.animator.rotate(this.frontleftupperleg, 0.0F, -0.1F, 0.0F);
        this.animator.rotate(this.backleftupperleg1, 0.0F, -0.1F, 0.0F);
        this.animator.rotate(this.backleftupperleg2, 0.0F, -0.1F, 0.0F);
        this.animator.rotate(this.backrightupperleg1, 0.0F, -0.1F, 0.0F);
        this.animator.rotate(this.backrightupperleg2, 0.0F, -0.1F, 0.0F);
        this.animator.endPhase();
        this.animator.resetPhase(20);
    }

    private void animateAntiTitanAttack1() {
        this.animator.setAnimationID(1);
        this.animator.startPhase(10);
        this.animator.move(this.thorax, 0.0F, 0.0F, 12.0F);
        this.animator.rotate(this.frontleftupperarm, -2.0F, 0.9F, 0.0F);
        this.animator.rotate(this.frontrightupperarm, -2.0F, -0.6F, 0.0F);
        this.animator.rotate(this.frontleftlowerarm, 0.75F, -0.3F, 0.0F);
        this.animator.rotate(this.frontrightlowerarm, 0.75F, 0.3F, 0.0F);
        this.animator.rotate(this.head, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.abdoman, -0.75F, 0.5F, 0.0F);
        this.animator.rotate(this.thorax, 0.0F, 0.0F, 0.0F);
        this.animator.rotate(this.frontrightupperleg, 0.0F, -1.0F, 0.0F);
        this.animator.rotate(this.frontleftupperleg, 0.0F, 1.0F, 0.0F);
        this.animator.rotate(this.backleftupperleg1, 0.0F, 1.0F, 0.0F);
        this.animator.rotate(this.backleftupperleg2, 0.0F, 1.0F, 0.0F);
        this.animator.rotate(this.backrightupperleg1, 0.0F, -1.0F, 0.0F);
        this.animator.rotate(this.backrightupperleg2, 0.0F, -1.0F, 0.0F);
        this.animator.endPhase();
        this.animator.startPhase(10);
        this.animator.move(this.thorax, 0.0F, 0.0F, -12.0F);
        this.animator.rotate(this.frontleftupperarm, -0.5F, 0.75F, 1.0F);
        this.animator.rotate(this.frontrightupperarm, -0.5F, -1.75F, 1.0F);
        this.animator.rotate(this.frontleftlowerarm, 0.25F, -0.5F, -0.5F);
        this.animator.rotate(this.frontrightlowerarm, 0.25F, 0.5F, 0.5F);
        this.animator.rotate(this.head, -1.0F, 0.0F, 0.0F);
        this.animator.rotate(this.abdoman, 1.0F, 0.0F, 0.0F);
        this.animator.rotate(this.thorax, 0.0F, 0.0F, 0.0F);
        this.animator.rotate(this.frontrightupperleg, 0.0F, 1.0F, 0.0F);
        this.animator.rotate(this.frontleftupperleg, 0.0F, -1.0F, 0.0F);
        this.animator.rotate(this.backleftupperleg1, 0.0F, -1.0F, 0.0F);
        this.animator.rotate(this.backleftupperleg2, 0.0F, -1.0F, 0.0F);
        this.animator.rotate(this.backrightupperleg1, 0.0F, 1.0F, 0.0F);
        this.animator.rotate(this.backrightupperleg2, 0.0F, 1.0F, 0.0F);
        this.animator.endPhase();
        this.animator.resetPhase(10);
    }

    private void animateAntiTitanAttack2() {
        this.animator.setAnimationID(1);
        this.animator.startPhase(10);
        this.animator.move(this.thorax, 0.0F, 0.0F, 12.0F);
        this.animator.rotate(this.head, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.abdoman, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.thorax, 0.0F, 0.0F, 0.0F);
        this.animator.rotate(this.frontleftupperarm, -1.5F, 0.0F, 0.0F);
        this.animator.rotate(this.frontrightupperarm, -1.5F, 0.0F, 0.0F);
        this.animator.rotate(this.frontleftlowerarm, -0.5F, -0.5F, 0.0F);
        this.animator.rotate(this.frontrightlowerarm, -0.5F, 0.5F, 0.0F);
        this.animator.rotate(this.frontrightupperleg, 0.0F, -1.0F, 0.0F);
        this.animator.rotate(this.frontleftupperleg, 0.0F, 1.0F, 0.0F);
        this.animator.rotate(this.backleftupperleg1, 0.0F, 1.0F, 0.0F);
        this.animator.rotate(this.backleftupperleg2, 0.0F, 1.0F, 0.0F);
        this.animator.rotate(this.backrightupperleg1, 0.0F, -1.0F, 0.0F);
        this.animator.rotate(this.backrightupperleg2, 0.0F, -1.0F, 0.0F);
        this.animator.endPhase();
        this.animator.startPhase(10);
        this.animator.move(this.thorax, 0.0F, 0.0F, -12.0F);
        this.animator.rotate(this.head, -1.0F, 0.0F, 0.0F);
        this.animator.rotate(this.abdoman, 1.0F, 0.0F, 0.0F);
        this.animator.rotate(this.thorax, 0.0F, 0.0F, 0.0F);
        this.animator.rotate(this.frontrightupperleg, 0.0F, 1.0F, 0.0F);
        this.animator.rotate(this.frontleftupperleg, 0.0F, -1.0F, 0.0F);
        this.animator.rotate(this.backleftupperleg1, 0.0F, -1.0F, 0.0F);
        this.animator.rotate(this.backleftupperleg2, 0.0F, -1.0F, 0.0F);
        this.animator.rotate(this.backrightupperleg1, 0.0F, 1.0F, 0.0F);
        this.animator.rotate(this.backrightupperleg2, 0.0F, 1.0F, 0.0F);
        this.animator.rotate(this.frontleftupperarm, 1.5F, 0.5F, 0.0F);
        this.animator.rotate(this.frontrightupperarm, 1.5F, -0.5F, 0.0F);
        this.animator.rotate(this.frontleftlowerarm, 0.5F, -0.5F, 0.0F);
        this.animator.rotate(this.frontrightlowerarm, 0.5F, 0.5F, 0.0F);
        this.animator.endPhase();
        this.animator.resetPhase(10);
    }

    private void animateAntiTitanAttack3() {
        this.animator.setAnimationID(1);
        this.animator.startPhase(10);
        this.animator.rotate(this.head, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.abdoman, 0.0F, 0.0F, 0.0F);
        this.animator.move(this.thorax, 0.0F, 0.0F, 12.0F);
        this.animator.rotate(this.frontleftupperarm, -1.5F, 0.6F, 0.0F);
        this.animator.rotate(this.frontrightupperarm, -1.5F, -0.6F, 0.0F);
        this.animator.rotate(this.frontleftlowerarm, 0.75F, -0.3F, 0.0F);
        this.animator.rotate(this.frontrightlowerarm, 0.75F, 0.3F, 0.0F);
        this.animator.rotate(this.frontrightupperleg, 0.0F, -1.0F, 0.0F);
        this.animator.rotate(this.frontleftupperleg, 0.0F, 1.0F, 0.0F);
        this.animator.rotate(this.backleftupperleg1, 0.0F, 1.0F, 0.0F);
        this.animator.rotate(this.backleftupperleg2, 0.0F, 1.0F, 0.0F);
        this.animator.rotate(this.backrightupperleg1, 0.0F, -1.0F, 0.0F);
        this.animator.rotate(this.backrightupperleg2, 0.0F, -1.0F, 0.0F);
        this.animator.endPhase();
        this.animator.startPhase(10);
        this.animator.move(this.thorax, 0.0F, 0.0F, -12.0F);
        this.animator.rotate(this.frontleftupperarm, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.frontrightupperarm, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.frontleftlowerarm, 0.5F, -0.5F, 0.0F);
        this.animator.rotate(this.frontrightlowerarm, 0.5F, 0.5F, 0.0F);
        this.animator.rotate(this.head, 1.0F, 0.0F, 0.0F);
        this.animator.rotate(this.abdoman, 0.0F, 0.0F, 0.0F);
        this.animator.rotate(this.thorax, 0.0F, 0.0F, 0.0F);
        this.animator.rotate(this.frontrightupperleg, 0.0F, 1.0F, 0.0F);
        this.animator.rotate(this.frontleftupperleg, 0.0F, -1.0F, 0.0F);
        this.animator.rotate(this.backleftupperleg1, 0.0F, -1.0F, 0.0F);
        this.animator.rotate(this.backleftupperleg2, 0.0F, -1.0F, 0.0F);
        this.animator.rotate(this.backrightupperleg1, 0.0F, 1.0F, 0.0F);
        this.animator.rotate(this.backrightupperleg2, 0.0F, 1.0F, 0.0F);
        this.animator.endPhase();
        this.animator.resetPhase(10);
    }

    private void animateAntiTitanAttack4() {
        this.animator.setAnimationID(1);
        this.animator.startPhase(10);
        this.animator.move(this.thorax, 0.0F, 0.0F, 12.0F);
        this.animator.rotate(this.frontleftupperarm, -2.0F, 0.6F, 0.0F);
        this.animator.rotate(this.frontrightupperarm, -2.0F, -0.9F, 0.0F);
        this.animator.rotate(this.frontleftlowerarm, 1.75F, -0.3F, 0.0F);
        this.animator.rotate(this.frontrightlowerarm, 1.75F, 0.3F, 0.0F);
        this.animator.rotate(this.head, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.abdoman, -0.75F, -0.5F, 0.0F);
        this.animator.rotate(this.thorax, 0.0F, 0.0F, 0.0F);
        this.animator.rotate(this.frontrightupperleg, 0.0F, -1.0F, 0.0F);
        this.animator.rotate(this.frontleftupperleg, 0.0F, 1.0F, 0.0F);
        this.animator.rotate(this.backleftupperleg1, 0.0F, 1.0F, 0.0F);
        this.animator.rotate(this.backleftupperleg2, 0.0F, 1.0F, 0.0F);
        this.animator.rotate(this.backrightupperleg1, 0.0F, -1.0F, 0.0F);
        this.animator.rotate(this.backrightupperleg2, 0.0F, -1.0F, 0.0F);
        this.animator.endPhase();
        this.animator.startPhase(10);
        this.animator.move(this.thorax, 0.0F, 0.0F, -12.0F);
        this.animator.rotate(this.frontleftupperarm, -0.5F, -0.75F, -1.0F);
        this.animator.rotate(this.frontrightupperarm, -0.5F, 1.75F, -1.0F);
        this.animator.rotate(this.frontleftlowerarm, -0.5F, 0.5F, -0.5F);
        this.animator.rotate(this.frontrightlowerarm, -0.5F, -0.5F, 0.5F);
        this.animator.rotate(this.head, -1.0F, 0.0F, 0.0F);
        this.animator.rotate(this.abdoman, 1.0F, 0.0F, 0.0F);
        this.animator.rotate(this.thorax, 0.0F, 0.0F, 0.0F);
        this.animator.rotate(this.frontrightupperleg, 0.0F, 1.0F, 0.0F);
        this.animator.rotate(this.frontleftupperleg, 0.0F, -1.0F, 0.0F);
        this.animator.rotate(this.backleftupperleg1, 0.0F, -1.0F, 0.0F);
        this.animator.rotate(this.backleftupperleg2, 0.0F, -1.0F, 0.0F);
        this.animator.rotate(this.backrightupperleg1, 0.0F, 1.0F, 0.0F);
        this.animator.rotate(this.backrightupperleg2, 0.0F, 1.0F, 0.0F);
        this.animator.endPhase();
        this.animator.resetPhase(10);
    }

    private void animateShootWeb() {
        this.animator.setAnimationID(6);
        this.animator.startPhase(20);
        this.animator.rotate(this.head, 0.3F, 0.0F, 0.0F);
        this.animator.rotate(this.abdoman, 0.3F, 0.0F, 0.0F);
        this.animator.move(this.thorax, 0.0F, 1.0F, 0.0F);
        this.animator.rotate(this.frontleftupperarm, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.frontrightupperarm, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.frontrightupperleg, -0.05F, 0.0F, 0.0F);
        this.animator.rotate(this.frontleftupperleg, -0.05F, 0.0F, 0.0F);
        this.animator.rotate(this.backleftupperleg1, -0.05F, 0.0F, 0.0F);
        this.animator.rotate(this.backleftupperleg2, -0.05F, 0.0F, 0.0F);
        this.animator.rotate(this.backrightupperleg1, -0.05F, 0.0F, 0.0F);
        this.animator.rotate(this.backrightupperleg2, -0.05F, 0.0F, 0.0F);
        this.animator.endPhase();
        this.animator.startPhase(20);
        this.animator.rotate(this.head, -0.4F, 0.0F, 0.0F);
        this.animator.rotate(this.abdoman, -2.0F, 0.0F, 0.0F);
        this.animator.move(this.thorax, 0.0F, -4.0F, 0.0F);
        this.animator.rotate(this.frontleftupperarm, -1.5F, -0.6F, 0.0F);
        this.animator.rotate(this.frontrightupperarm, -1.5F, 0.6F, 0.0F);
        this.animator.rotate(this.frontleftlowerarm, 0.75F, -0.3F, 0.0F);
        this.animator.rotate(this.frontrightlowerarm, 0.75F, 0.3F, 0.0F);
        this.animator.rotate(this.frontrightupperleg, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.frontleftupperleg, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.backleftupperleg1, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.backleftupperleg2, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.backrightupperleg1, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.backrightupperleg2, 0.5F, 0.0F, 0.0F);
        this.animator.endPhase();
        this.animator.setStationaryPhase(60);
        this.animator.resetPhase(40);
    }

    private void animateShootLightning() {
        this.animator.setAnimationID(7);
        this.animator.startPhase(50);
        this.animator.rotate(this.head, 0.1F, 0.0F, 0.0F);
        this.animator.rotate(this.abdoman, -1.0F, 0.0F, 0.0F);
        this.animator.move(this.thorax, 0.0F, -4.0F, 0.0F);
        this.animator.rotate(this.frontleftupperarm, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.frontrightupperarm, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.frontrightupperleg, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.frontleftupperleg, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.backleftupperleg1, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.backleftupperleg2, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.backrightupperleg1, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.backrightupperleg2, 0.5F, 0.0F, 0.0F);
        this.animator.endPhase();
        this.animator.startPhase(15);
        this.animator.rotate(this.head, -0.4F, 0.0F, 0.0F);
        this.animator.rotate(this.abdoman, -0.0F, 0.0F, 0.0F);
        this.animator.move(this.thorax, 0.0F, -4.0F, 0.0F);
        this.animator.rotate(this.frontleftupperarm, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.frontrightupperarm, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.frontrightupperleg, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.frontleftupperleg, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.backleftupperleg1, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.backleftupperleg2, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.backrightupperleg1, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.backrightupperleg2, 0.5F, 0.0F, 0.0F);
        this.animator.endPhase();
        this.animator.startPhase(5);
        this.animator.rotate(this.head, 0.6F, 0.0F, 0.0F);
        this.animator.rotate(this.abdoman, -2.0F, 0.0F, 0.0F);
        this.animator.move(this.thorax, 0.0F, -4.0F, 0.0F);
        this.animator.rotate(this.frontleftupperarm, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.frontrightupperarm, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.frontrightupperleg, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.frontleftupperleg, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.backleftupperleg1, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.backleftupperleg2, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.backrightupperleg1, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.backrightupperleg2, 0.5F, 0.0F, 0.0F);
        this.animator.endPhase();
        this.animator.resetPhase(50);
    }

    private void animateStunned() {
        this.animator.setAnimationID(8);
        this.animator.startPhase(40);
        this.animator.rotate(this.head, 0.1F, 0.0F, 0.0F);
        this.animator.rotate(this.abdoman, -0.1F, 0.0F, 0.0F);
        this.animator.move(this.thorax, 0.0F, -0.75F, 0.0F);
        this.animator.rotate(this.frontleftupperarm, 0.05F, 0.0F, 0.0F);
        this.animator.rotate(this.frontrightupperarm, 0.05F, 0.0F, 0.0F);
        this.animator.rotate(this.frontrightupperleg, 0.05F, 0.0F, 0.0F);
        this.animator.rotate(this.frontleftupperleg, 0.05F, 0.0F, 0.0F);
        this.animator.rotate(this.backleftupperleg1, 0.05F, 0.0F, 0.0F);
        this.animator.rotate(this.backleftupperleg2, 0.05F, 0.0F, 0.0F);
        this.animator.rotate(this.backrightupperleg1, 0.05F, 0.0F, 0.0F);
        this.animator.rotate(this.backrightupperleg2, 0.05F, 0.0F, 0.0F);
        this.animator.endPhase();
        this.animator.startPhase(20);
        this.animator.rotate(this.head, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.abdoman, 0.5F, 0.0F, 0.0F);
        this.animator.move(this.thorax, 0.0F, 6.0F, 0.0F);
        this.animator.rotate(this.frontleftupperarm, -0.75F, 0.0F, 0.0F);
        this.animator.rotate(this.frontrightupperarm, -0.75F, 0.0F, 0.0F);
        this.animator.rotate(this.frontrightupperleg, -0.75F, 0.0F, 0.0F);
        this.animator.rotate(this.frontleftupperleg, -0.75F, 0.0F, 0.0F);
        this.animator.rotate(this.backleftupperleg1, -0.75F, 0.0F, 0.0F);
        this.animator.rotate(this.backleftupperleg2, -0.75F, 0.0F, 0.0F);
        this.animator.rotate(this.backrightupperleg1, -0.75F, 0.0F, 0.0F);
        this.animator.rotate(this.backrightupperleg2, -0.75F, 0.0F, 0.0F);
        this.animator.rotate(this.frontleftlowerarm, 0.75F, 0.0F, 0.0F);
        this.animator.rotate(this.frontrightlowerarm, 0.75F, 0.0F, 0.0F);
        this.animator.rotate(this.frontrightlowerleg, 0.75F, 0.0F, 0.0F);
        this.animator.rotate(this.frontleftlowerleg, 0.75F, 0.0F, 0.0F);
        this.animator.rotate(this.backleftlowerleg1, 0.75F, 0.0F, 0.0F);
        this.animator.rotate(this.backleftlowerleg2, 0.75F, 0.0F, 0.0F);
        this.animator.rotate(this.backrightlowerleg1, 0.75F, 0.0F, 0.0F);
        this.animator.rotate(this.backrightlowerleg2, 0.75F, 0.0F, 0.0F);
        this.animator.endPhase();
        this.animator.startPhase(60);
        this.animator.rotate(this.head, 0.25F, 0.5F, 0.5F);
        this.animator.rotate(this.abdoman, 0.0F, 0.0F, 0.0F);
        this.animator.move(this.thorax, 0.0F, 8.0F, 0.0F);
        this.animator.rotate(this.frontleftupperarm, -0.3F, 0.0F, 0.0F);
        this.animator.rotate(this.frontrightupperarm, -0.3F, 0.0F, 0.0F);
        this.animator.rotate(this.frontrightupperleg, -0.3F, 0.0F, 0.0F);
        this.animator.rotate(this.frontleftupperleg, -0.3F, 0.0F, 0.0F);
        this.animator.rotate(this.backleftupperleg1, -0.3F, 0.0F, 0.0F);
        this.animator.rotate(this.backleftupperleg2, -0.3F, 0.0F, 0.0F);
        this.animator.rotate(this.backrightupperleg1, -0.3F, 0.0F, 0.0F);
        this.animator.rotate(this.backrightupperleg2, -0.3F, 0.0F, 0.0F);
        this.animator.rotate(this.frontleftlowerarm, -0.3F, 0.0F, 0.0F);
        this.animator.rotate(this.frontrightlowerarm, -0.3F, 0.0F, 0.0F);
        this.animator.rotate(this.frontrightlowerleg, -0.3F, 0.0F, 0.0F);
        this.animator.rotate(this.frontleftlowerleg, -0.3F, 0.0F, 0.0F);
        this.animator.rotate(this.backleftlowerleg1, -0.3F, 0.0F, 0.0F);
        this.animator.rotate(this.backleftlowerleg2, -0.3F, 0.0F, 0.0F);
        this.animator.rotate(this.backrightlowerleg1, -0.3F, 0.0F, 0.0F);
        this.animator.rotate(this.backrightlowerleg2, -0.3F, 0.0F, 0.0F);
        this.animator.endPhase();
        this.animator.setStationaryPhase(300);
        this.animator.startPhase(40);
        this.animator.rotate(this.head, 0.0F, 0.0F, 0.0F);
        this.animator.move(this.thorax, 0.0F, 8.0F, 0.0F);
        this.animator.rotate(this.frontleftupperarm, -0.3F, 0.0F, 0.0F);
        this.animator.rotate(this.frontrightupperarm, -0.3F, 0.0F, 0.0F);
        this.animator.rotate(this.frontrightupperleg, -0.3F, 0.0F, 0.0F);
        this.animator.rotate(this.frontleftupperleg, -0.3F, 0.0F, 0.0F);
        this.animator.rotate(this.backleftupperleg1, -0.3F, 0.0F, 0.0F);
        this.animator.rotate(this.backleftupperleg2, -0.3F, 0.0F, 0.0F);
        this.animator.rotate(this.backrightupperleg1, -0.3F, 0.0F, 0.0F);
        this.animator.rotate(this.backrightupperleg2, -0.3F, 0.0F, 0.0F);
        this.animator.rotate(this.frontleftlowerarm, -0.3F, 0.0F, 0.0F);
        this.animator.rotate(this.frontrightlowerarm, -0.3F, 0.0F, 0.0F);
        this.animator.rotate(this.frontrightlowerleg, -0.3F, 0.0F, 0.0F);
        this.animator.rotate(this.frontleftlowerleg, -0.3F, 0.0F, 0.0F);
        this.animator.rotate(this.backleftlowerleg1, -0.3F, 0.0F, 0.0F);
        this.animator.rotate(this.backleftlowerleg2, -0.3F, 0.0F, 0.0F);
        this.animator.rotate(this.backrightlowerleg1, -0.3F, 0.0F, 0.0F);
        this.animator.rotate(this.backrightlowerleg2, -0.3F, 0.0F, 0.0F);
        this.animator.endPhase();
        this.animator.startPhase(40);
        this.animator.rotate(this.head, 0.0F, 0.0F, 0.0F);
        this.animator.move(this.thorax, 0.0F, 6.0F, 0.0F);
        this.animator.rotate(this.frontleftupperarm, -0.75F, 0.0F, 0.0F);
        this.animator.rotate(this.frontrightupperarm, -0.75F, 0.0F, 0.0F);
        this.animator.rotate(this.frontrightupperleg, -0.75F, 0.0F, 0.0F);
        this.animator.rotate(this.frontleftupperleg, -0.75F, 0.0F, 0.0F);
        this.animator.rotate(this.backleftupperleg1, -0.75F, 0.0F, 0.0F);
        this.animator.rotate(this.backleftupperleg2, -0.75F, 0.0F, 0.0F);
        this.animator.rotate(this.backrightupperleg1, -0.75F, 0.0F, 0.0F);
        this.animator.rotate(this.backrightupperleg2, -0.75F, 0.0F, 0.0F);
        this.animator.rotate(this.frontleftlowerarm, 0.75F, 0.0F, 0.0F);
        this.animator.rotate(this.frontrightlowerarm, 0.75F, 0.0F, 0.0F);
        this.animator.rotate(this.frontrightlowerleg, 0.75F, 0.0F, 0.0F);
        this.animator.rotate(this.frontleftlowerleg, 0.75F, 0.0F, 0.0F);
        this.animator.rotate(this.backleftlowerleg1, 0.75F, 0.0F, 0.0F);
        this.animator.rotate(this.backleftlowerleg2, 0.75F, 0.0F, 0.0F);
        this.animator.rotate(this.backrightlowerleg1, 0.75F, 0.0F, 0.0F);
        this.animator.rotate(this.backrightlowerleg2, 0.75F, 0.0F, 0.0F);
        this.animator.endPhase();
        this.animator.startPhase(80);
        this.animator.rotate(this.head, 0.0F, 0.0F, 0.0F);
        this.animator.move(this.thorax, 0.0F, 0.0F, 0.0F);
        this.animator.endPhase();
        this.animator.startPhase(5);
        this.animator.rotate(this.head, -0.5F, 0.75F, 0.0F);
        this.animator.endPhase();
        this.animator.startPhase(5);
        this.animator.rotate(this.head, 0.5F, -0.75F, 0.0F);
        this.animator.endPhase();
        this.animator.startPhase(5);
        this.animator.rotate(this.head, 0.5F, 0.75F, 0.0F);
        this.animator.endPhase();
        this.animator.startPhase(5);
        this.animator.rotate(this.head, 0.5F, -0.75F, 0.0F);
        this.animator.endPhase();
        this.animator.startPhase(5);
        this.animator.rotate(this.head, 0.5F, 0.75F, 0.0F);
        this.animator.endPhase();
        this.animator.startPhase(5);
        this.animator.rotate(this.head, 0.5F, -0.75F, 0.0F);
        this.animator.endPhase();
        this.animator.startPhase(5);
        this.animator.rotate(this.head, 0.5F, 0.75F, 0.0F);
        this.animator.endPhase();
        this.animator.startPhase(5);
        this.animator.rotate(this.head, 0.5F, -0.75F, 0.0F);
        this.animator.endPhase();
        this.animator.resetPhase(40);
    }

    private void animateCrush() {
        this.animator.setAnimationID(9);
        this.animator.startPhase(15);
        this.animator.rotate(this.head, 0.4F, 0.0F, 0.0F);
        this.animator.rotate(this.frontleftupperarm, 0.5F, -1.0F, -0.75F);
        this.animator.rotate(this.frontrightupperarm, 0.5F, 1.0F, 0.75F);
        this.animator.endPhase();
        this.animator.startPhase(15);
        this.animator.rotate(this.head, 0.6F, 0.0F, 0.0F);
        this.animator.rotate(this.frontleftupperarm, 0.0F, 0.7F, 0.0F);
        this.animator.rotate(this.frontrightupperarm, 0.0F, -0.7F, 0.0F);
        this.animator.rotate(this.frontleftlowerarm, 0.6F, -0.8F, 0.0F);
        this.animator.rotate(this.frontrightlowerarm, 0.6F, 0.8F, 0.0F);
        this.animator.endPhase();
        this.animator.resetPhase(20);
    }

    private void animateDeath() {
        this.animator.setAnimationID(10);
        this.animator.startPhase(10);
        this.animator.rotate(this.head, 0.5F, 0.5F, 0.0F);
        this.animator.endPhase();
        this.animator.startPhase(10);
        this.animator.rotate(this.head, -0.5F, 0.5F, 0.0F);
        this.animator.endPhase();
        this.animator.startPhase(10);
        this.animator.rotate(this.head, 0.5F, -0.5F, 0.0F);
        this.animator.endPhase();
        this.animator.startPhase(10);
        this.animator.rotate(this.head, -0.5F, -0.5F, 0.0F);
        this.animator.endPhase();
        this.animator.startPhase(10);
        this.animator.rotate(this.head, -0.5F, 0.0F, 0.4F);
        this.animator.rotate(this.abdoman, 0.25F, 0.0F, 0.0F);
        this.animator.move(this.thorax, 0.0F, 0.0F, 0.0F);
        this.animator.rotate(this.frontleftupperarm, 0.05F, -0.25F, 0.0F);
        this.animator.rotate(this.frontrightupperarm, 0.05F, 0.25F, 0.0F);
        this.animator.rotate(this.frontrightupperleg, 0.05F, 0.25F, 0.0F);
        this.animator.rotate(this.frontleftupperleg, 0.05F, -0.25F, 0.0F);
        this.animator.rotate(this.backleftupperleg1, 0.05F, -0.25F, 0.0F);
        this.animator.rotate(this.backleftupperleg2, 0.05F, -0.25F, 0.0F);
        this.animator.rotate(this.backrightupperleg1, 0.05F, 0.25F, 0.0F);
        this.animator.rotate(this.backrightupperleg2, 0.05F, 0.25F, 0.0F);
        this.animator.endPhase();
        this.animator.startPhase(40);
        this.animator.rotate(this.head, 0.25F, 0.0F, -0.4F);
        this.animator.rotate(this.abdoman, -0.25F, 0.0F, 0.0F);
        this.animator.move(this.thorax, 0.0F, 4.0F, 0.0F);
        this.animator.rotate(this.frontleftupperarm, -0.5F, 0.25F, 0.0F);
        this.animator.rotate(this.frontrightupperarm, -0.5F, -0.25F, 0.0F);
        this.animator.rotate(this.frontrightupperleg, -0.5F, 0.25F, 0.0F);
        this.animator.rotate(this.frontleftupperleg, -0.5F, -0.25F, 0.0F);
        this.animator.rotate(this.backleftupperleg1, -0.5F, -0.25F, 0.0F);
        this.animator.rotate(this.backleftupperleg2, -0.5F, -0.25F, 0.0F);
        this.animator.rotate(this.backrightupperleg1, -0.5F, 0.25F, 0.0F);
        this.animator.rotate(this.backrightupperleg2, -0.5F, 0.25F, 0.0F);
        this.animator.rotate(this.frontleftlowerarm, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.frontrightlowerarm, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.frontrightlowerleg, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.frontleftlowerleg, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.backleftlowerleg1, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.backleftlowerleg2, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.backrightlowerleg1, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.backrightlowerleg2, 0.5F, 0.0F, 0.0F);
        this.animator.endPhase();
        this.animator.startPhase(40);
        this.animator.rotate(this.head, 0.25F, 0.0F, 0.0F);
        this.animator.rotate(this.abdoman, -0.3F, 0.0F, 0.0F);
        this.animator.move(this.thorax, 0.0F, 3.5F, 0.0F);
        this.animator.rotate(this.frontleftupperarm, -0.5F, 0.25F, 0.0F);
        this.animator.rotate(this.frontrightupperarm, -0.5F, -0.25F, 0.0F);
        this.animator.rotate(this.frontrightupperleg, -0.5F, 0.25F, 0.0F);
        this.animator.rotate(this.frontleftupperleg, -0.5F, -0.25F, 0.0F);
        this.animator.rotate(this.backleftupperleg1, -0.5F, -0.25F, 0.0F);
        this.animator.rotate(this.backleftupperleg2, -0.5F, -0.25F, 0.0F);
        this.animator.rotate(this.backrightupperleg1, -0.5F, 0.25F, 0.0F);
        this.animator.rotate(this.backrightupperleg2, -0.5F, 0.25F, 0.0F);
        this.animator.rotate(this.frontleftlowerarm, 0.75F, 0.0F, 0.0F);
        this.animator.rotate(this.frontrightlowerarm, 0.75F, 0.0F, 0.0F);
        this.animator.rotate(this.frontrightlowerleg, 0.75F, 0.0F, 0.0F);
        this.animator.rotate(this.frontleftlowerleg, 0.75F, 0.0F, 0.0F);
        this.animator.rotate(this.backleftlowerleg1, 0.75F, 0.0F, 0.0F);
        this.animator.rotate(this.backleftlowerleg2, 0.75F, 0.0F, 0.0F);
        this.animator.rotate(this.backrightlowerleg1, 0.75F, 0.0F, 0.0F);
        this.animator.rotate(this.backrightlowerleg2, 0.75F, 0.0F, 0.0F);
        this.animator.endPhase();
        this.animator.startPhase(40);
        this.animator.rotate(this.head, -0.75F, 0.0F, -0.4F);
        this.animator.rotate(this.abdoman, -0.6F, 0.0F, 0.0F);
        this.animator.rotate(this.thorax, 0.1F, 0.0F, 0.0F);
        this.animator.move(this.thorax, 0.0F, -1.0F, -6.0F);
        this.animator.rotate(this.frontleftupperarm, 0.0F, -1.0F, 0.0F);
        this.animator.rotate(this.frontrightupperarm, 0.0F, 1.0F, 0.0F);
        this.animator.rotate(this.frontrightupperleg, 0.0F, 0.75F, 0.0F);
        this.animator.rotate(this.frontleftupperleg, 0.0F, -0.75F, 0.0F);
        this.animator.rotate(this.backleftupperleg1, 0.0F, -0.25F, 0.0F);
        this.animator.rotate(this.backleftupperleg2, 0.0F, -0.5F, 0.0F);
        this.animator.rotate(this.backrightupperleg1, 0.0F, 0.25F, 0.0F);
        this.animator.rotate(this.backrightupperleg2, 0.0F, 0.5F, 0.0F);
        this.animator.rotate(this.frontleftlowerarm, 0.4F, 0.0F, 0.0F);
        this.animator.rotate(this.frontrightlowerarm, 0.4F, 0.0F, 0.0F);
        this.animator.rotate(this.frontrightlowerleg, 0.4F, 0.0F, 0.0F);
        this.animator.rotate(this.frontleftlowerleg, 0.4F, 0.0F, 0.0F);
        this.animator.rotate(this.backleftlowerleg1, 0.4F, 0.0F, 0.0F);
        this.animator.rotate(this.backleftlowerleg2, 0.4F, 0.0F, 0.0F);
        this.animator.rotate(this.backrightlowerleg1, 0.4F, 0.0F, 0.0F);
        this.animator.rotate(this.backrightlowerleg2, 0.4F, 0.0F, 0.0F);
        this.animator.endPhase();
        this.animator.startPhase(60);
        this.animator.rotate(this.head, -0.75F, 0.0F, -0.75F);
        this.animator.rotate(this.thorax, 0.75F, 0.0F, 0.0F);
        this.animator.move(this.thorax, 0.0F, 6.0F, -12.0F);
        this.animator.rotate(this.frontleftupperarm, -0.5F, -1.25F, 0.0F);
        this.animator.rotate(this.frontrightupperarm, -0.5F, 1.25F, 0.0F);
        this.animator.rotate(this.frontrightupperleg, -0.5F, 1.0F, 0.0F);
        this.animator.rotate(this.frontleftupperleg, -0.5F, -1.0F, 0.0F);
        this.animator.rotate(this.backleftupperleg1, -0.75F, -0.75F, 0.0F);
        this.animator.rotate(this.backleftupperleg2, -0.75F, -0.75F, 0.0F);
        this.animator.rotate(this.backrightupperleg1, -0.75F, 0.5F, 0.0F);
        this.animator.rotate(this.backrightupperleg2, -0.75F, 0.5F, 0.0F);
        this.animator.rotate(this.frontleftlowerarm, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.frontrightlowerarm, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.frontrightlowerleg, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.frontleftlowerleg, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.backleftlowerleg1, -0.75F, 0.0F, 0.0F);
        this.animator.rotate(this.backleftlowerleg2, -0.75F, 0.0F, 0.0F);
        this.animator.rotate(this.backrightlowerleg1, -0.75F, 0.0F, 0.0F);
        this.animator.rotate(this.backrightlowerleg2, -0.75F, 0.0F, 0.0F);
        this.animator.endPhase();
        this.animator.startPhase(70);
        this.animator.rotate(this.head, 0.0F, 0.0F, -0.75F);
        this.animator.rotate(this.abdoman, 0.0F, 0.0F, 0.0F);
        this.animator.move(this.thorax, 0.0F, 8.0F, -14.0F);
        this.animator.rotate(this.frontleftupperarm, -0.3F, -1.25F, 0.0F);
        this.animator.rotate(this.frontrightupperarm, -0.3F, 1.25F, 0.0F);
        this.animator.rotate(this.frontrightupperleg, -0.3F, 1.0F, 0.0F);
        this.animator.rotate(this.frontleftupperleg, -0.3F, -1.0F, 0.0F);
        this.animator.rotate(this.backleftupperleg1, -0.3F, -0.75F, 0.0F);
        this.animator.rotate(this.backleftupperleg2, -0.3F, -0.75F, 0.0F);
        this.animator.rotate(this.backrightupperleg1, -0.3F, 0.5F, 0.0F);
        this.animator.rotate(this.backrightupperleg2, -0.3F, 0.5F, 0.0F);
        this.animator.rotate(this.frontleftlowerarm, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.frontrightlowerarm, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.frontrightlowerleg, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.frontleftlowerleg, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.backleftlowerleg1, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.backleftlowerleg2, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.backrightlowerleg1, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.backrightlowerleg2, -0.5F, 0.0F, 0.0F);
        this.animator.endPhase();
        this.animator.setStationaryPhase(1700);
        this.animator.resetPhase(0);
    }

    private void animateBirth() {
        this.animator.setAnimationID(13);
        this.animator.startPhase(0);
        this.animator.rotate(this.head, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.abdoman, -0.5F, 0.0F, 0.0F);
        this.animator.move(this.thorax, 0.0F, 14.0F, 0.0F);
        this.animator.rotate(this.frontleftupperarm, 1.0F, 0.0F, 0.0F);
        this.animator.rotate(this.frontrightupperarm, 1.0F, 0.0F, 0.0F);
        this.animator.rotate(this.frontrightupperleg, 1.0F, 0.0F, 0.0F);
        this.animator.rotate(this.frontleftupperleg, 1.0F, 0.0F, 0.0F);
        this.animator.rotate(this.backleftupperleg1, 1.0F, 0.0F, 0.0F);
        this.animator.rotate(this.backleftupperleg2, 1.0F, 0.0F, 0.0F);
        this.animator.rotate(this.backrightupperleg1, 1.0F, 0.0F, 0.0F);
        this.animator.rotate(this.backrightupperleg2, 1.0F, 0.0F, 0.0F);
        this.animator.rotate(this.frontleftlowerarm, 1.0F, 0.0F, 0.0F);
        this.animator.rotate(this.frontrightlowerarm, 1.0F, 0.0F, 0.0F);
        this.animator.rotate(this.frontrightlowerleg, 1.0F, 0.0F, 0.0F);
        this.animator.rotate(this.frontleftlowerleg, 1.0F, 0.0F, 0.0F);
        this.animator.rotate(this.backleftlowerleg1, 1.0F, 0.0F, 0.0F);
        this.animator.rotate(this.backleftlowerleg2, 1.0F, 0.0F, 0.0F);
        this.animator.rotate(this.backrightlowerleg1, 1.0F, 0.0F, 0.0F);
        this.animator.rotate(this.backrightlowerleg2, 1.0F, 0.0F, 0.0F);
        this.animator.endPhase();
        this.animator.setStationaryPhase(5);
        this.animator.startPhase(15);
        this.animator.rotate(this.head, 0.2F, 0.0F, 0.0F);
        this.animator.rotate(this.abdoman, -0.4F, 0.0F, 0.0F);
        this.animator.move(this.thorax, 0.0F, 15.0F, 0.0F);
        this.animator.rotate(this.frontleftupperarm, 1.0F, 0.0F, 0.0F);
        this.animator.rotate(this.frontrightupperarm, 1.0F, 0.0F, 0.0F);
        this.animator.rotate(this.frontrightupperleg, 1.0F, 0.0F, 0.0F);
        this.animator.rotate(this.frontleftupperleg, 1.0F, 0.0F, 0.0F);
        this.animator.rotate(this.backleftupperleg1, 1.0F, 0.0F, 0.0F);
        this.animator.rotate(this.backleftupperleg2, 1.0F, 0.0F, 0.0F);
        this.animator.rotate(this.backrightupperleg1, 1.0F, 0.0F, 0.0F);
        this.animator.rotate(this.backrightupperleg2, 1.0F, 0.0F, 0.0F);
        this.animator.rotate(this.frontleftlowerarm, 1.0F, 0.0F, 0.0F);
        this.animator.rotate(this.frontrightlowerarm, 1.0F, 0.0F, 0.0F);
        this.animator.rotate(this.frontrightlowerleg, 1.0F, 0.0F, 0.0F);
        this.animator.rotate(this.frontleftlowerleg, 1.0F, 0.0F, 0.0F);
        this.animator.rotate(this.backleftlowerleg1, 1.0F, 0.0F, 0.0F);
        this.animator.rotate(this.backleftlowerleg2, 1.0F, 0.0F, 0.0F);
        this.animator.rotate(this.backrightlowerleg1, 1.0F, 0.0F, 0.0F);
        this.animator.rotate(this.backrightlowerleg2, 1.0F, 0.0F, 0.0F);
        this.animator.endPhase();
        this.animator.startPhase(100);
        this.animator.rotate(this.head, 0.3F, 0.0F, 0.0F);
        this.animator.rotate(this.abdoman, -0.5F, 0.0F, 0.0F);
        this.animator.move(this.thorax, 0.0F, 8.0F, 0.0F);
        this.animator.rotate(this.frontleftupperarm, 1.0F, 0.0F, 0.0F);
        this.animator.rotate(this.frontrightupperarm, 1.0F, 0.0F, 0.0F);
        this.animator.rotate(this.frontrightupperleg, 1.0F, 0.0F, 0.0F);
        this.animator.rotate(this.frontleftupperleg, 1.0F, 0.0F, 0.0F);
        this.animator.rotate(this.backleftupperleg1, 1.0F, 0.0F, 0.0F);
        this.animator.rotate(this.backleftupperleg2, 1.0F, 0.0F, 0.0F);
        this.animator.rotate(this.backrightupperleg1, 1.0F, 0.0F, 0.0F);
        this.animator.rotate(this.backrightupperleg2, 1.0F, 0.0F, 0.0F);
        this.animator.rotate(this.frontleftlowerarm, 1.0F, 0.0F, 0.0F);
        this.animator.rotate(this.frontrightlowerarm, 1.0F, 0.0F, 0.0F);
        this.animator.rotate(this.frontrightlowerleg, 1.0F, 0.0F, 0.0F);
        this.animator.rotate(this.frontleftlowerleg, 1.0F, 0.0F, 0.0F);
        this.animator.rotate(this.backleftlowerleg1, 1.0F, 0.0F, 0.0F);
        this.animator.rotate(this.backleftlowerleg2, 1.0F, 0.0F, 0.0F);
        this.animator.rotate(this.backrightlowerleg1, 1.0F, 0.0F, 0.0F);
        this.animator.rotate(this.backrightlowerleg2, 1.0F, 0.0F, 0.0F);
        this.animator.endPhase();
        this.animator.startPhase(10);
        this.animator.rotate(this.head, -0.25F, 0.0F, 0.0F);
        this.animator.rotate(this.abdoman, 0.0F, 0.0F, 0.25F);
        this.animator.move(this.thorax, 0.0F, 8.0F, 0.0F);
        this.animator.rotate(this.frontleftupperarm, 1.0F, 0.0F, 0.0F);
        this.animator.rotate(this.frontrightupperarm, -1.5F, 0.0F, 0.0F);
        this.animator.rotate(this.frontrightupperleg, 1.0F, 0.0F, 0.0F);
        this.animator.rotate(this.frontleftupperleg, -1.5F, 0.0F, 0.0F);
        this.animator.rotate(this.backleftupperleg1, 1.0F, 0.0F, 0.0F);
        this.animator.rotate(this.backleftupperleg2, 1.0F, 0.0F, 0.0F);
        this.animator.rotate(this.backrightupperleg1, -1.5F, 0.0F, 0.0F);
        this.animator.rotate(this.backrightupperleg2, -1.5F, 0.0F, 0.0F);
        this.animator.rotate(this.frontleftlowerarm, 1.0F, 0.0F, 0.0F);
        this.animator.rotate(this.frontrightlowerleg, 1.0F, 0.0F, 0.0F);
        this.animator.rotate(this.backleftlowerleg1, 1.0F, 0.0F, 0.0F);
        this.animator.rotate(this.frontrightlowerarm, 0.75F, 0.0F, 0.0F);
        this.animator.rotate(this.frontleftlowerleg, 0.75F, 0.0F, 0.0F);
        this.animator.rotate(this.backrightlowerleg1, 0.75F, 0.0F, 0.0F);
        this.animator.rotate(this.backrightlowerleg2, 0.75F, 0.0F, 0.0F);
        this.animator.endPhase();
        this.animator.startPhase(10);
        this.animator.rotate(this.head, -0.25F, 0.0F, 0.0F);
        this.animator.rotate(this.abdoman, 0.0F, 0.0F, 0.5F);
        this.animator.move(this.thorax, 0.0F, 8.0F, 0.0F);
        this.animator.rotate(this.frontleftupperarm, 1.0F, 0.0F, 0.0F);
        this.animator.rotate(this.frontrightupperarm, -0.75F, 0.0F, 0.0F);
        this.animator.rotate(this.frontrightupperleg, 1.0F, 0.0F, 0.0F);
        this.animator.rotate(this.frontleftupperleg, -0.75F, 0.0F, 0.0F);
        this.animator.rotate(this.backleftupperleg1, 1.0F, 0.0F, 0.0F);
        this.animator.rotate(this.backleftupperleg2, -0.75F, 0.0F, 0.0F);
        this.animator.rotate(this.backrightupperleg1, -0.75F, 0.0F, 0.0F);
        this.animator.rotate(this.backrightupperleg2, 1.0F, 0.0F, 0.0F);
        this.animator.rotate(this.frontleftlowerarm, 1.0F, 0.0F, 0.0F);
        this.animator.rotate(this.frontrightlowerleg, 1.0F, 0.0F, 0.0F);
        this.animator.rotate(this.backleftlowerleg1, 1.0F, 0.0F, 0.0F);
        this.animator.rotate(this.backrightlowerleg2, 1.0F, 0.0F, 0.0F);
        this.animator.rotate(this.frontrightlowerarm, 0.75F, 0.0F, 0.0F);
        this.animator.rotate(this.frontleftlowerleg, 0.75F, 0.0F, 0.0F);
        this.animator.rotate(this.backrightlowerleg1, 0.75F, 0.0F, 0.0F);
        this.animator.rotate(this.backrightlowerleg2, 0.75F, 0.0F, 0.0F);
        this.animator.endPhase();
        this.animator.startPhase(10);
        this.animator.rotate(this.head, -0.25F, 0.0F, 0.0F);
        this.animator.rotate(this.abdoman, 0.0F, 0.0F, -0.25F);
        this.animator.move(this.thorax, 0.0F, 8.0F, 0.0F);
        this.animator.rotate(this.frontleftupperarm, -1.5F, 0.0F, 0.0F);
        this.animator.rotate(this.frontrightupperarm, -0.75F, 0.0F, 0.0F);
        this.animator.rotate(this.frontrightupperleg, -1.5F, 0.0F, 0.0F);
        this.animator.rotate(this.frontleftupperleg, -0.75F, 0.0F, 0.0F);
        this.animator.rotate(this.backleftupperleg1, -1.5F, 0.0F, 0.0F);
        this.animator.rotate(this.backleftupperleg2, -0.75F, 0.0F, 0.0F);
        this.animator.rotate(this.backrightupperleg1, -0.75F, 0.0F, 0.0F);
        this.animator.rotate(this.backrightupperleg2, -1.5F, 0.0F, 0.0F);
        this.animator.rotate(this.frontleftlowerarm, 0.6F, 0.0F, 0.0F);
        this.animator.rotate(this.frontrightlowerarm, 0.6F, 0.0F, 0.0F);
        this.animator.rotate(this.frontrightlowerleg, 0.6F, 0.0F, 0.0F);
        this.animator.rotate(this.frontleftlowerleg, 0.6F, 0.0F, 0.0F);
        this.animator.rotate(this.backleftlowerleg1, 0.6F, 0.0F, 0.0F);
        this.animator.rotate(this.backleftlowerleg2, 0.6F, 0.0F, 0.0F);
        this.animator.rotate(this.backrightlowerleg1, 0.6F, 0.0F, 0.0F);
        this.animator.rotate(this.backrightlowerleg2, 0.6F, 0.0F, 0.0F);
        this.animator.endPhase();
        this.animator.startPhase(10);
        this.animator.rotate(this.head, -0.25F, 0.0F, 0.0F);
        this.animator.rotate(this.abdoman, 0.0F, 0.0F, -0.5F);
        this.animator.move(this.thorax, 0.0F, 8.0F, 0.0F);
        this.animator.rotate(this.frontleftupperarm, -0.75F, 0.0F, 0.0F);
        this.animator.rotate(this.frontrightupperarm, -0.75F, 0.0F, 0.0F);
        this.animator.rotate(this.frontrightupperleg, -0.75F, 0.0F, 0.0F);
        this.animator.rotate(this.frontleftupperleg, -0.75F, 0.0F, 0.0F);
        this.animator.rotate(this.backleftupperleg1, -0.75F, 0.0F, 0.0F);
        this.animator.rotate(this.backleftupperleg2, -0.75F, 0.0F, 0.0F);
        this.animator.rotate(this.backrightupperleg1, -0.75F, 0.0F, 0.0F);
        this.animator.rotate(this.backrightupperleg2, -0.75F, 0.0F, 0.0F);
        this.animator.rotate(this.frontleftlowerarm, 0.6F, 0.0F, 0.0F);
        this.animator.rotate(this.frontrightlowerarm, 0.6F, 0.0F, 0.0F);
        this.animator.rotate(this.frontrightlowerleg, 0.6F, 0.0F, 0.0F);
        this.animator.rotate(this.frontleftlowerleg, 0.6F, 0.0F, 0.0F);
        this.animator.rotate(this.backleftlowerleg1, 0.6F, 0.0F, 0.0F);
        this.animator.rotate(this.backleftlowerleg2, 0.6F, 0.0F, 0.0F);
        this.animator.rotate(this.backrightlowerleg1, 0.6F, 0.0F, 0.0F);
        this.animator.rotate(this.backrightlowerleg2, 0.6F, 0.0F, 0.0F);
        this.animator.endPhase();
        this.animator.setStationaryPhase(20);
        this.animator.startPhase(20);
        this.animator.rotate(this.head, 0.0F, 0.0F, 0.0F);
        this.animator.move(this.thorax, 0.0F, 6.0F, 0.0F);
        this.animator.rotate(this.frontleftupperarm, -0.75F, 0.0F, 0.0F);
        this.animator.rotate(this.frontrightupperarm, -0.75F, 0.0F, 0.0F);
        this.animator.rotate(this.frontrightupperleg, -0.75F, 0.0F, 0.0F);
        this.animator.rotate(this.frontleftupperleg, -0.75F, 0.0F, 0.0F);
        this.animator.rotate(this.backleftupperleg1, -0.75F, 0.0F, 0.0F);
        this.animator.rotate(this.backleftupperleg2, -0.75F, 0.0F, 0.0F);
        this.animator.rotate(this.backrightupperleg1, -0.75F, 0.0F, 0.0F);
        this.animator.rotate(this.backrightupperleg2, -0.75F, 0.0F, 0.0F);
        this.animator.rotate(this.frontleftlowerarm, 0.75F, 0.0F, 0.0F);
        this.animator.rotate(this.frontrightlowerarm, 0.75F, 0.0F, 0.0F);
        this.animator.rotate(this.frontrightlowerleg, 0.75F, 0.0F, 0.0F);
        this.animator.rotate(this.frontleftlowerleg, 0.75F, 0.0F, 0.0F);
        this.animator.rotate(this.backleftlowerleg1, 0.75F, 0.0F, 0.0F);
        this.animator.rotate(this.backleftlowerleg2, 0.75F, 0.0F, 0.0F);
        this.animator.rotate(this.backrightlowerleg1, 0.75F, 0.0F, 0.0F);
        this.animator.rotate(this.backrightlowerleg2, 0.75F, 0.0F, 0.0F);
        this.animator.endPhase();
        this.animator.resetPhase(60);
    }
}
