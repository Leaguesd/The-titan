package net.titans.render.layer;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.blaze3d.vertex.PoseStack.Pose;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.titans.entity.titan.EntityEnderColossus;
import net.titans.model.ModelEnderColossus;
import net.titans.render.RenderEnderColossus;

@OnlyIn(Dist.CLIENT)
public class LayerEnderColossusEyesLaser extends RenderLayer<EntityEnderColossus, ModelEnderColossus> {
    public LayerEnderColossusEyesLaser(RenderLayerParent<EntityEnderColossus, ModelEnderColossus> renderer) {
        super(renderer);
    }

    private Vec3 getEntityInterpolatedPosition(EntityEnderColossus entity, double y, float partialTicks) {
        double d1 = entity.xOld + (entity.getX() - entity.xOld) * (double)partialTicks;
        double d2 = y + entity.yOld + (entity.getY() - entity.yOld) * (double)partialTicks;
        double d3 = entity.zOld + (entity.getZ() - entity.zOld) * (double)partialTicks;
        return new Vec3(d1, d2, d3);
    }

    private Vec3 getEntityLookAheadPosition(EntityEnderColossus entity, double y, float partialTicks) {
        Vec3 vec3 = entity.getViewVector(1.0F);
        double dx = vec3.x * 300.0;
        double dy = vec3.y * 300.0;
        double dz = vec3.z * 300.0;
        double d1 = entity.xOld + (entity.getX() + dx - entity.xOld) * (double)partialTicks;
        double d2 = y + entity.yOld + (entity.getY() + dy - entity.yOld) * (double)partialTicks;
        double d3 = entity.zOld + (entity.getZ() + dz - entity.zOld) * (double)partialTicks;
        return new Vec3(d1, d2, d3);
    }

    public void render(
        PoseStack poseStack,
        MultiBufferSource multiBufferSource,
        int packedLight,
        EntityEnderColossus entity,
        float limbSwing,
        float limbSwingAmount,
        float partialTicks,
        float ageInTicks,
        float headYaw,
        float headPitch
    ) {
        if (entity.isAlive() && entity.getEyeLaserTime() >= 0) {
            poseStack.pushPose();
            float f4 = (float)entity.level().getDayTime() + partialTicks;
            float f5 = f4 * 0.5F % 1.0F;
            float f6 = entity.getEyeHeight();
            poseStack.pushPose();
            ((ModelEnderColossus)this.getParentModel()).bodyBottom.translateAndRotate(poseStack);
            poseStack.pushPose();
            ((ModelEnderColossus)this.getParentModel()).bodyMiddle.translateAndRotate(poseStack);
            ((ModelEnderColossus)this.getParentModel()).bodyTop.translateAndRotate(poseStack);
            ((ModelEnderColossus)this.getParentModel()).mouth.translateAndRotate(poseStack);
            ((ModelEnderColossus)this.getParentModel()).head.translateAndRotate(poseStack);
            poseStack.translate(0.0F, -0.22F, -0.25F);
            Vec3 vec3 = this.getEntityLookAheadPosition(entity, (double)f6, partialTicks);
            Vec3 vec31 = this.getEntityInterpolatedPosition(entity, (double)f6, partialTicks);
            Vec3 vec32 = vec3.subtract(vec31);
            double d3 = vec32.length() + 0.1;
            VertexConsumer vertexConsumer = multiBufferSource.getBuffer(RenderType.energySwirl(RenderEnderColossus.ENDER_COLOSSUS_EYES_BEAM, 0.0F, 0.0F));
            Pose poseStack$pose = poseStack.last();
            double d4 = (double)f4 * 0.005 * -1.5;
            double d15 = Math.cos(d4 * 0.0 + Math.PI) * 0.25;
            double d16 = Math.sin(d4 * 0.0 + Math.PI) * 0.25;
            double d17 = Math.cos(d4 * 0.0 + 0.0) * 0.25;
            double d18 = Math.sin(d4 * 0.0 + 0.0) * 0.25;
            double d25 = (double)(-1.0F + f5);
            double d26 = d3 * 2.5 + d25;
            vertexConsumer.vertex(poseStack$pose.pose(), (float)d15, (float)d16, (float)(-d3))
                .color(255, 0, 255, 255)
                .uv(0.5F, (float)d26)
                .overlayCoords(OverlayTexture.NO_OVERLAY)
                .uv2(packedLight)
                .normal(poseStack$pose.normal(), 0.0F, 0.0F, 0.0F)
                .endVertex();
            vertexConsumer.vertex(poseStack$pose.pose(), (float)d15, (float)d16, 0.0F)
                .color(255, 0, 255, 255)
                .uv(0.5F, (float)d25)
                .overlayCoords(OverlayTexture.NO_OVERLAY)
                .uv2(packedLight)
                .normal(poseStack$pose.normal(), 0.0F, 0.0F, 0.0F)
                .endVertex();
            vertexConsumer.vertex(poseStack$pose.pose(), (float)d17, (float)d18, 0.0F)
                .color(255, 0, 255, 255)
                .uv(0.0F, (float)d25)
                .overlayCoords(OverlayTexture.NO_OVERLAY)
                .uv2(packedLight)
                .normal(poseStack$pose.normal(), 0.0F, 0.0F, 0.0F)
                .endVertex();
            vertexConsumer.vertex(poseStack$pose.pose(), (float)d17, (float)d18, (float)(-d3))
                .color(255, 0, 255, 255)
                .uv(0.0F, (float)d26)
                .overlayCoords(OverlayTexture.NO_OVERLAY)
                .uv2(packedLight)
                .normal(poseStack$pose.normal(), 0.0F, 0.0F, 0.0F)
                .endVertex();
            poseStack.popPose();
            poseStack.popPose();
            poseStack.popPose();
        }
    }
}
