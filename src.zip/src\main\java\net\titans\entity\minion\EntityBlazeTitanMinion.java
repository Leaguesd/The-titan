package net.titans.entity.minion;

import java.util.List;
import javax.annotation.Nullable;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.tags.EntityTypeTags;
import net.minecraft.world.Difficulty;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.MoverType;
import net.minecraft.world.entity.SpawnGroupData;
import net.minecraft.world.entity.Entity.RemovalReason;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier.Builder;
import net.minecraft.world.entity.ai.goal.BreakDoorGoal;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.RangedAttackGoal;
import net.minecraft.world.entity.monster.Blaze;
import net.minecraft.world.entity.monster.RangedAttackMob;
import net.minecraft.world.entity.projectile.Arrow;
import net.minecraft.world.entity.projectile.ThrownPotion;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.alchemy.PotionUtils;
import net.minecraft.world.item.alchemy.Potions;
import net.minecraft.world.level.ItemLike;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.ServerLevelAccessor;
import net.minecraft.world.level.Level.ExplosionInteraction;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.Vec3;
import net.titans.entity.ai.EntityAINearestTargetTitan;
import net.titans.entity.ai.minion.EntityAIFindEntityNearestInjuredAlly;
import net.titans.entity.ai.minion.EntityAIFindMaster;
import net.titans.entity.ai.minion.EntityAIRandomDoHurtTarget;
import net.titans.entity.ai.minion.blaze.EntityAIBlazeTitanMinionAttack;
import net.titans.entity.projectile.EntityBlazeTitanMinionSmallFireball;
import net.titans.entity.titan.EntityBlazeTitan;
import net.titans.entity.titan.EntityTitan;
import net.titans.loader.TheTitansRegistries;
import net.titans.loader.TheTitansDamageTypes;
import net.titans.loader.TheTitansEntities;
import net.titans.loader.TheTitansMobEffects;
import net.titans.loader.TheTitansPredicateTargets;
import net.titans.loader.TheTitansSounds;

public class EntityBlazeTitanMinion extends Blaze implements RangedAttackMob, IMinion {
    private static final EntityDataAccessor<Integer> MINION_TYPE = SynchedEntityData.defineId(EntityBlazeTitanMinion.class, EntityDataSerializers.INT);
    public final RangedAttackGoal rangedAttackGoal = new RangedAttackGoal(this, 1.0, 1, 64.0F);
    public EntityTitan master;
    private LivingEntity entityToHeal;
    private int attackPattern;
    private float heightOffset = 0.5F;
    private int heightOffsetUpdateTime;
    public int deathTicks;
    public int randomSoundDelay;

    public EntityBlazeTitanMinion(EntityType<? extends EntityBlazeTitanMinion> entityType, Level level) {
        super(entityType, level);
        this.getNavigation().getNodeEvaluator().setCanOpenDoors(true);
        this.getNavigation().getNodeEvaluator().setCanPassDoors(true);
        this.getNavigation().getNodeEvaluator().setCanFloat(true);
        this.getNavigation().getNodeEvaluator().setCanWalkOverFences(true);
        this.refreshAttributes();
        this.setHealth(this.getMaxHealth());
    }

    public EntityBlazeTitanMinion(Level level) {
        this((EntityType<? extends EntityBlazeTitanMinion>)TheTitansEntities.BLAZE_TITAN_MINION.get(), level);
    }

    public static Builder createAttributes() {
        return Blaze.createAttributes().add(Attributes.FOLLOW_RANGE, 24.0).add(Attributes.MOVEMENT_SPEED, 0.25).add(Attributes.KNOCKBACK_RESISTANCE, 1.0);
    }

    protected void registerGoals() {
        super.registerGoals();
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(0, new BreakDoorGoal(this, difficulty -> true));
        this.goalSelector.addGoal(0, new EntityAIFindMaster(this, 100.0, titan -> titan instanceof EntityBlazeTitan));
        this.goalSelector.addGoal(0, new EntityAIRandomDoHurtTarget(this));
        this.goalSelector.addGoal(0, new EntityAIFindEntityNearestInjuredAlly(this));
        this.goalSelector.addGoal(0, new EntityAIBlazeTitanMinionAttack(this));
        this.targetSelector
            .addGoal(0, new EntityAINearestTargetTitan<LivingEntity>(this, LivingEntity.class, 0, false, false, TheTitansPredicateTargets.BlazeTitan));
    }

    @Override
    public int getMinionTypeInt() {
        return (Integer)this.getEntityData().get(MINION_TYPE);
    }

    @Override
    public void setMinionType(int minionType) {
        this.getEntityData().set(MINION_TYPE, minionType);
        this.refreshAttributes();
    }

    @Override
    public EntityTitan getMaster() {
        return this.master;
    }

    @Override
    public void setMaster(EntityTitan master) {
        this.master = master;
    }

    @Override
    public LivingEntity getEntityToHeal() {
        return this.entityToHeal;
    }

    @Override
    public void setEntityToHeal(LivingEntity entityToHeal) {
        this.entityToHeal = entityToHeal;
    }

    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(MINION_TYPE, 0);
    }

    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        this.setMinionType(tag.getInt("MinionType"));
        this.deathTicks = tag.getInt("DeathTicks");
    }

    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putInt("MinionType", this.getMinionTypeInt());
        tag.putInt("DeathTicks", this.deathTicks);
    }

    protected void dropRareDrop(int count) {
    }

    protected void dropFewItems(boolean attackedRecently, int loottingLevel) {
        int j = this.random.nextInt(2 + loottingLevel);

        for (int k = 0; k < j; k++) {
            this.spawnAtLocation(Items.BLAZE_ROD, 1);
        }

        j = this.random.nextInt(3 + loottingLevel);

        for (int var11 = 0; var11 < j; var11++) {
            this.spawnAtLocation(Items.GLOWSTONE_DUST, 1);
        }

        if (this.isOnFire()) {
            j = this.random.nextInt(2 + loottingLevel);

            for (int var12 = 0; var12 < j; var12++) {
                this.spawnAtLocation(Items.BLAZE_ROD, 1);
            }
        }

        if (this.random.nextInt(60) == 0 || this.isOnFire() && this.random.nextInt(2) == 0 || this.random.nextInt(1 + loottingLevel) > 0) {
            this.spawnAtLocation(new ItemStack(Blocks.FIRE), 0.0F);
        }

        if (this.getMinionTypeInt() >= 1) {
            j = this.random.nextInt(2);
            if (loottingLevel > 0) {
                j += this.random.nextInt(loottingLevel + 1);
            }

            for (int var13 = 0; var13 < j; var13++) {
                this.spawnAtLocation(Items.EXPERIENCE_BOTTLE, 1);
            }

            if (this.getMinionTypeInt() >= 2) {
                j = this.random.nextInt(2);
                if (loottingLevel > 0) {
                    j += this.random.nextInt(loottingLevel + 1);
                }

                for (int var14 = 0; var14 < j; var14++) {
                    this.spawnAtLocation(Items.GOLDEN_APPLE, 1);
                }

                if (this.getMinionTypeInt() >= 3) {
                    j = this.random.nextInt(2);
                    if (loottingLevel > 0) {
                        j += this.random.nextInt(loottingLevel + 1);
                    }

                    for (int var15 = 0; var15 < j; var15++) {
                        switch (this.random.nextInt(5)) {
                            case 0:
                                this.spawnAtLocation(Items.EMERALD, 1);
                                break;
                            case 1:
                                this.spawnAtLocation(Items.DIAMOND, 1);
                                break;
                            case 2:
                                this.spawnAtLocation(Items.GOLD_INGOT, 1);
                                break;
                            case 3:
                                this.spawnAtLocation(Items.GOLD_INGOT, 1);
                                break;
                            case 4:
                                this.spawnAtLocation(Items.GOLD_INGOT, 1);
                        }
                    }

                    if (this.getMinionTypeInt() >= 4) {
                        if (this.random.nextInt(5) == 0) {
                            this.spawnAtLocation(new ItemStack((ItemLike)TheTitansRegistries.PLEASANT_BLADE_SEED.get()), 0.0F);
                        }

                        if (this.random.nextInt(100) == 0) {
                            this.spawnAtLocation(new ItemStack((ItemLike)TheTitansRegistries.MALGRUM_SEEDS.get()), 0.0F);
                        }

                        j = 2 + this.random.nextInt(5);
                        if (loottingLevel > 0) {
                            j += this.random.nextInt(loottingLevel + 1);
                        }

                        for (int var16 = 0; var16 < j; var16++) {
                            switch (this.random.nextInt(3)) {
                                case 0:
                                    this.spawnAtLocation(Items.EMERALD, 1);
                                    break;
                                case 1:
                                    this.spawnAtLocation(Items.DIAMOND, 1);
                                    break;
                                case 2:
                                    this.spawnAtLocation(Items.GOLD_INGOT, 1);
                            }
                        }
                    }
                }
            }
        }
    }

    public SpawnGroupData finalizeSpawn(
        ServerLevelAccessor level, DifficultyInstance difficulty, MobSpawnType spawnType, @Nullable SpawnGroupData spawnGroupData, @Nullable CompoundTag tag
    ) {
        SpawnGroupData groupData = super.finalizeSpawn(level, difficulty, spawnType, spawnGroupData, null);
        this.setRandomMinionType();
        this.setHealth(this.getMaxHealth());
        return groupData;
    }

    public Component getName() {
        switch (this.getMinionType()) {
            case PRIEST:
                return Component.translatable("entity.titan.blaze_priest");
            case ZEALOT:
                return Component.translatable("entity.titan.blaze_zealot");
            case BISHOP:
                return Component.translatable("entity.titan.blaze_bishop");
            case TEMPLAR:
                return Component.translatable("entity.titan.blaze_templar");
            default:
                return Component.translatable("entity.titan.blaze_loyalist");
        }
    }

    public boolean fireImmune() {
        return true;
    }

    @Override
    public void refreshAttributes() {
        switch (this.getMinionType()) {
            case PRIEST:
                this.getAttribute(Attributes.MAX_HEALTH).setBaseValue(40.0);
                this.getAttribute(Attributes.ATTACK_DAMAGE).setBaseValue(7.0);
                this.xpReward = 30;
                break;
            case ZEALOT:
                this.getAttribute(Attributes.MAX_HEALTH).setBaseValue(200.0);
                this.getAttribute(Attributes.ATTACK_DAMAGE).setBaseValue(15.0);
                this.getAttribute(Attributes.MOVEMENT_SPEED).setBaseValue(0.5);
                this.xpReward = 100;
                break;
            case BISHOP:
                this.getAttribute(Attributes.MAX_HEALTH).setBaseValue(500.0);
                this.getAttribute(Attributes.ATTACK_DAMAGE).setBaseValue(20.0);
                this.xpReward = 500;
                break;
            case TEMPLAR:
                this.getAttribute(Attributes.MAX_HEALTH).setBaseValue(2000.0);
                this.getAttribute(Attributes.ATTACK_DAMAGE).setBaseValue(60.0);
                this.getAttribute(Attributes.KNOCKBACK_RESISTANCE).setBaseValue(1.0);
                this.xpReward = 2000;
                break;
            default:
                this.getAttribute(Attributes.MAX_HEALTH).setBaseValue(26.0);
                this.getAttribute(Attributes.ATTACK_DAMAGE).setBaseValue(6.0);
                this.xpReward = 15;
        }
    }

    public boolean canAttack(LivingEntity target) {
        return this.getMaster() != null ? this.getMaster().canAttack(target) : target.canBeSeenByAnyone() && this.canAttackEntity(target);
    }

    public boolean canAttackType(EntityType<?> entityType) {
        return entityType != TheTitansEntities.BLAZE_TITAN.get() && entityType != TheTitansEntities.BLAZE_TITAN_MINION.get();
    }

    public int getArmorValue() {
        switch (this.getMinionType()) {
            case PRIEST:
                return 2;
            case ZEALOT:
                return 15;
            case BISHOP:
                return 18;
            case TEMPLAR:
                return 22;
            default:
                return 0;
        }
    }

    public boolean isSensitiveToWater() {
        return this.getMinionType() != EnumMinionType.TEMPLAR;
    }

    protected SoundEvent getAmbientSound() {
        return this.getMinionType() == EnumMinionType.TEMPLAR ? (SoundEvent)TheTitansSounds.TITAN_BLAZE_BREATHE.get() : SoundEvents.BLAZE_AMBIENT;
    }

    protected SoundEvent getHurtSound(DamageSource damageSource) {
        return this.getMinionType() == EnumMinionType.TEMPLAR ? (SoundEvent)TheTitansSounds.TITAN_BLAZE_GRUNT.get() : SoundEvents.BLAZE_HURT;
    }

    protected SoundEvent getDeathSound() {
        return this.getMinionType() == EnumMinionType.TEMPLAR ? (SoundEvent)TheTitansSounds.TITAN_BLAZE_DEATH.get() : SoundEvents.BLAZE_DEATH;
    }

    public float getVoicePitch() {
        return this.getMinionType() == EnumMinionType.TEMPLAR ? super.getVoicePitch() + 0.6F : super.getVoicePitch();
    }

    protected float getDamageAfterMagicAbsorb(DamageSource damageSource, float damage) {
        damage = super.getDamageAfterMagicAbsorb(damageSource, damage);
        if (this.getMinionType() == EnumMinionType.TEMPLAR) {
            if (damageSource.getEntity() == this) {
                damage = 0.0F;
            }

            if (damageSource.is(DamageTypeTags.WITCH_RESISTANT_TO)) {
                damage *= 0.15F;
            }
        }

        return damage;
    }

    public void remove(RemovalReason reason) {
        super.remove(reason);
        if (this.getMaster() != null) {
            this.getMaster().retractMinionNumFromType(this.getMinionType());
        }
    }

    public void setTarget(@Nullable LivingEntity target) {
        if (target != this) {
            if (this.getMaster() != null) {
                if (!this.getMaster().canAttackEntity(target, true)) {
                    return;
                }
            } else if (!this.canAttackEntity(target, true)) {
                return;
            }

            super.setTarget(target);
        }
    }

    public boolean doHurtTarget(Entity entity) {
        if (this.isOnFire()) {
            entity.setRemainingFireTicks(10);
        }

        if (super.doHurtTarget(entity) && entity instanceof LivingEntity && this.getMinionTypeInt() >= 3) {
            LivingEntity livingEntity = (LivingEntity)entity;
            int i = 10;
            if (this.level().getDifficulty() == Difficulty.NORMAL) {
                i = 20;
            } else if (this.level().getDifficulty() == Difficulty.HARD) {
                i = 30;
            }

            if (i > 0) {
                livingEntity.addEffect(new MobEffectInstance((MobEffect)TheTitansMobEffects.ELECTRIC_JUDGMENT.get(), i * 20, 0));
            }

            return true;
        } else {
            return false;
        }
    }

    public boolean hurt(DamageSource damageSource, float amount) {
        Entity entity = damageSource.getEntity();
        if (!this.isInvulnerable() && (this.getMinionTypeInt() < 4 || !damageSource.is(TheTitansDamageTypes.RADIATION))) {
            if (entity instanceof EntityBlazeTitanMinion || entity instanceof EntityBlazeTitan) {
                return false;
            } else if (entity != null && this.xxa == 0.0F && this.getMinionType() == EnumMinionType.ZEALOT) {
                this.playSound((SoundEvent)TheTitansSounds.TITAN_SWING.get(), 1.0F, 2.0F);
                switch (this.random.nextInt(3)) {
                    case 0:
                        this.zza = -2.0F;
                        this.moveRelative(0.99F, new Vec3(0.0, 0.0, -2.0));
                        this.xxa = 0.01F;
                        break;
                    case 1:
                        this.xxa = 1.0F;
                        this.moveRelative(0.25F, new Vec3(1.0, 0.0, 0.0));
                        break;
                    case 2:
                        this.xxa = -1.0F;
                        this.moveRelative(0.25F, new Vec3(-1.0, 0.0, 0.0));
                }

                this.jumpFromGround();
                return false;
            } else {
                if (entity instanceof LivingEntity livingEntity && this.canAttack(livingEntity)) {
                    for (Entity minionEntity : this.level().getEntities(this, this.getBoundingBox().inflate(32.0, 32.0, 32.0))) {
                        if (minionEntity instanceof EntityBlazeTitanMinion blazeTitanMinion) {
                            blazeTitanMinion.setTarget(livingEntity);
                            blazeTitanMinion.randomSoundDelay = this.random.nextInt(40);
                        }

                        this.setTarget(livingEntity);
                        this.randomSoundDelay = this.random.nextInt(40);
                    }
                }

                return super.hurt(damageSource, amount);
            }
        } else {
            return false;
        }
    }

    public boolean causeFallDamage(float fallDistance, float multiplier, DamageSource damageSource) {
        if (this.getMinionType() == EnumMinionType.TEMPLAR) {
            this.xxa = 0.0F;
            this.zza = 0.0F;
            return false;
        } else {
            return super.causeFallDamage(fallDistance, multiplier, damageSource);
        }
    }

    public void performRangedAttack(LivingEntity target, float velocity) {
        this.swing(InteractionHand.MAIN_HAND);
        if (this.distanceToSqr(target) < (double)(target.getBbWidth() * target.getBbWidth()) + 36.0) {
            this.doHurtTarget(target);
        } else {
            int randomInt = this.random.nextInt(4);
            if (randomInt == 0) {
                this.playSound(SoundEvents.SKELETON_SHOOT, 1.0F, 1.0F / (this.random.nextFloat() * 0.4F + 0.8F));

                for (int i = 0; i < 10; i++) {
                    Arrow arrow = new Arrow(EntityType.ARROW, this.level());
                    double d0 = target.getX() - this.getX();
                    double d1 = target.getY(0.3333333333333333) - this.getY() - (double)this.getEyeHeight();
                    double d2 = target.getZ() - this.getZ();
                    double d3 = Math.sqrt(d0 * d0 + d2 * d2);
                    arrow.setOwner(this);
                    arrow.setPos(this.getX(), this.getY() + (double)this.getEyeHeight(), this.getZ());
                    arrow.shoot(d0, d1 + d3 * 0.2F, d2, 1.6F, 1.0F);
                    arrow.setCritArrow(true);
                    arrow.setBaseDamage((double)(velocity * 2.0F) + this.random.nextGaussian() * 0.25 + (double)((float)this.level().getDifficulty().getId() * 0.11F));
                    if (!this.level().isClientSide()) {
                        this.level().addFreshEntity(arrow);
                    }
                }
            } else if (randomInt == 1) {
                for (int ix = 0; ix < 20; ix++) {
                    ThrownPotion thrownPotion = new ThrownPotion(this.level(), this);
                    ItemStack itemStack = PotionUtils.setPotion(new ItemStack(Items.SPLASH_POTION), Potions.HARMING);
                    thrownPotion.setItem(itemStack);
                    if (target.getType().is(EntityTypeTags.SKELETONS)) {
                        itemStack = PotionUtils.setPotion(new ItemStack(Items.SPLASH_POTION), Potions.HEALING);
                        thrownPotion.setItem(itemStack);
                    }

                    thrownPotion.setXRot(thrownPotion.getXRot() + 20.0F);
                    double d0 = target.getX() + target.getDeltaMovement().x - this.getX();
                    double d1 = target.getX() + 0.5 - this.getY();
                    double d2 = target.getZ() + target.getDeltaMovement().z - this.getZ();
                    double d3 = Math.sqrt(d0 * d0 + d2 * d2);
                    thrownPotion.setPos(this.getX(), this.getY() + (double)this.getEyeHeight(), this.getZ());
                    thrownPotion.shoot(d0, d1 + d3 * 0.2F, d2, 1.6F, (float)(d3 / 20.0));
                    if (!this.level().isClientSide()) {
                        this.level().addFreshEntity(thrownPotion);
                    }
                }
            } else if (randomInt == 2) {
                for (int ix = 0; ix < 50; ix++) {
                    double d0 = target.getX() - this.getX();
                    double d1 = target.getBoundingBox().minY + (double)(target.getBbHeight() / 2.0F) - this.getY() + (double)(target.getBbHeight() / 2.0F);
                    double d2 = target.getZ() - this.getZ();
                    double d3 = Math.sqrt(Math.sqrt(this.distanceToSqr(target))) * 0.1;
                    if (!this.isSilent()) {
                        this.level().levelEvent(null, 1016, this.blockPosition(), 0);
                    }

                    EntityBlazeTitanMinionSmallFireball smallFireball = new EntityBlazeTitanMinionSmallFireball(
                        this.level(), this, new Vec3(d0 + this.random.nextGaussian() * d3, d1, d2 + this.random.nextGaussian() * d3)
                    );
                    smallFireball.setPos(this.getX(), this.getY() + 1.6, this.getZ());
                    if (!this.level().isClientSide()) {
                        this.level().addFreshEntity(smallFireball);
                    }
                }
            }
        }
    }

    public void aiStep() {
        super.aiStep();
        if (this.randomSoundDelay > 0 && this.randomSoundDelay-- == 0) {
            this.playSound(this.getHurtSound(null), this.getSoundVolume(), this.getVoicePitch() + 0.25F);
        }
    }

    protected void dropAllDeathLoot(DamageSource damageSource) {
        super.dropAllDeathLoot(damageSource);
    }

    protected void tickDeath() {
        if (this.getMinionType() == EnumMinionType.TEMPLAR) {
            this.deathTime = 0;
            this.tickCount--;
            this.deathTicks++;
            this.setDeltaMovement(0.0, 0.0, 0.0);
            this.move(MoverType.SELF, new Vec3(0.0, 0.1, 0.0));
            if (this.getMaster() != null) {
                double mx = this.getX() - this.getMaster().getX();
                double my = this.getY() + (double)(this.getBbHeight() / 2.0F) - (this.getMaster().getY() + (double)(this.getMaster().getBbHeight() / 2.0F));
                double mz = this.getZ() - this.getMaster().getZ();
                short particleCount = (short)((int)(this.distanceTo(this.getMaster()) * 2.0F));

                for (int i = 0; i < particleCount; i++) {
                    double d9 = (double)i / ((double)particleCount - 1.0);
                    double d6 = this.getX() + mx * -d9;
                    double d7 = this.getY() + (double)this.getEyeHeight() + my * -d9;
                    double d8 = this.getZ() + mz * -d9;
                    this.level()
                        .addParticle(
                            ParticleTypes.FIREWORK,
                            d6,
                            d7,
                            d8,
                            this.getMaster().getDeltaMovement().x,
                            this.getMaster().getDeltaMovement().y + 0.2,
                            this.getMaster().getDeltaMovement().z
                        );
                }
            }

            if (this.deathTicks == 1 && !this.isSilent()) {
                this.level().globalLevelEvent(1028, this.blockPosition(), 0);
            }

            if (this.deathTicks > 150 && this.deathTicks % 5 == 0 && !this.level().isClientSide()) {
                this.dropAllDeathLoot(this.damageSources().generic());
            }

            if (this.deathTicks >= 180 && this.deathTicks <= 200) {
                float f3 = (this.random.nextFloat() - 0.5F) * this.getBbWidth();
                float f4 = (this.random.nextFloat() - 0.5F) * this.getBbHeight();
                float f5 = (this.random.nextFloat() - 0.5F) * this.getBbWidth();
                this.level()
                    .addParticle(
                        ParticleTypes.EXPLOSION_EMITTER,
                        this.getX() + (double)f3,
                        this.getY() + (double)this.getEyeHeight() + (double)f4,
                        this.getZ() + (double)f5,
                        0.0,
                        0.0,
                        0.0
                    );
            }

            float f = (this.random.nextFloat() - 0.5F) * this.getBbWidth();
            float f1 = (this.random.nextFloat() - 0.5F) * this.getBbHeight();
            float f2 = (this.random.nextFloat() - 0.5F) * this.getBbWidth();
            this.level()
                .addParticle(
                    ParticleTypes.EXPLOSION,
                    this.getX() + (double)f,
                    this.getY() + (double)this.getEyeHeight() + (double)f1,
                    this.getZ() + (double)f2,
                    0.0,
                    0.0,
                    0.0
                );
            this.level()
                .addParticle(
                    ParticleTypes.LAVA,
                    this.getX() + (double)f,
                    this.getY() + (double)this.getEyeHeight() + (double)f1,
                    this.getZ() + (double)f2,
                    this.random.nextGaussian(),
                    this.random.nextGaussian(),
                    this.random.nextGaussian()
                );
            if (this.deathTicks == 200) {
                if (this.getMaster() != null) {
                    this.getMaster().heal(this.getMaster().getMaxHealth() / 100.0F);

                    for (int j = 0; j < 100; j++) {
                        double d2 = this.random.nextGaussian() * 0.02;
                        double d0 = this.random.nextGaussian() * 0.02;
                        double d1 = this.random.nextGaussian() * 0.02;
                        this.level()
                            .addParticle(
                                ParticleTypes.EXPLOSION,
                                this.getMaster().getX()
                                    + (double)(this.random.nextFloat() * this.getMaster().getBbWidth() * 2.0F)
                                    - (double)this.getMaster().getBbWidth(),
                                this.getMaster().getY() + (double)(this.random.nextFloat() * this.getMaster().getBbHeight()),
                                this.getMaster().getZ()
                                    + (double)(this.random.nextFloat() * this.getMaster().getBbWidth() * 2.0F)
                                    - (double)this.getMaster().getBbWidth(),
                                d2,
                                d0,
                                d1
                            );
                    }
                }

                if (!this.level().isClientSide() && !this.isRemoved()) {
                    this.dropAllDeathLoot(this.damageSources().generic());
                    this.level().broadcastEntityEvent(this, (byte)60);
                    this.remove(RemovalReason.KILLED);
                }
            }
        } else {
            super.tickDeath();
        }
    }

    public void tick() {
        super.tick();
        if (this.getMinionType() == EnumMinionType.PRIEST) {
            if (this.getEntityToHeal() != null && this.tickCount % 40 == 0) {
                this.playSound(SoundEvents.WITHER_SHOOT, 1.0F, 3.0F);
                if (this.getEntityToHeal().getHealth() < this.getEntityToHeal().getMaxHealth()) {
                    this.swing(InteractionHand.MAIN_HAND);
                    this.lookAt(this.getEntityToHeal(), 180.0F, (float)this.getHeadRotSpeed());
                    this.getEntityToHeal().heal(4.0F);
                } else {
                    this.setEntityToHeal(null);
                }
            }
        } else if (this.getMinionType() == EnumMinionType.ZEALOT) {
            if (this.getTarget() != null) {
                double d0 = this.distanceToSqr(this.getTarget());
                if (d0 < 0.8) {
                    this.doHurtTarget(this.getTarget());
                }

                if (this.onGround() && d0 < 256.0 && this.getTarget().getY() > this.getY() + 3.0 && this.random.nextInt(40) == 0) {
                    this.lookAt(this.getTarget(), 180.0F, 180.0F);
                    this.addEffect(new MobEffectInstance(MobEffects.JUMP, 60, 7));
                    double d01 = this.getTarget().getX() - this.getX();
                    double d1 = this.getTarget().getZ() - this.getZ();
                    float f2 = (float)Math.sqrt(d01 * d01 + d1 * d1);
                    this.jumpFromGround();
                    this.setDeltaMovement(
                        d01 / (double)f2 * 0.75 * 0.75 + this.getDeltaMovement().x * 0.75,
                        this.getDeltaMovement().y,
                        d1 / (double)f2 * 0.75 * 0.75 + this.getDeltaMovement().z * 0.75
                    );
                }
            }
        } else if (this.getMinionType() == EnumMinionType.BISHOP) {
            if (this.getMaster() == null && this.isAlive() && !this.level().isClientSide() && this.level().getDifficulty() != Difficulty.PEACEFUL) {
                float randomRate = this.random.nextFloat() * 100.0F;
                if ((double)randomRate < 0.167) {
                    EntityBlazeTitanMinion blazeTitanMinion = new EntityBlazeTitanMinion(this.level());
                    blazeTitanMinion.setPos(this.getX(), this.getY(), this.getZ());
                    blazeTitanMinion.setYRot(this.getYRot());
                    blazeTitanMinion.finalizeSpawn(
                        (ServerLevelAccessor)this.level(), this.level().getCurrentDifficultyAt(blazeTitanMinion.blockPosition()), MobSpawnType.SPAWNER, null, null
                    );
                    blazeTitanMinion.setMinionType(0);
                    blazeTitanMinion.setHealth(blazeTitanMinion.getMaxHealth());
                    this.level().addFreshEntity(blazeTitanMinion);
                }

                randomRate = this.random.nextFloat() * 100.0F;
                if ((double)randomRate < 0.083) {
                    EntityBlazeTitanMinion blazeTitanMinion = new EntityBlazeTitanMinion(this.level());
                    blazeTitanMinion.setPos(this.getX(), this.getY(), this.getZ());
                    blazeTitanMinion.setYRot(this.getYRot());
                    blazeTitanMinion.finalizeSpawn(
                        (ServerLevelAccessor)this.level(), this.level().getCurrentDifficultyAt(blazeTitanMinion.blockPosition()), MobSpawnType.SPAWNER, null, null
                    );
                    blazeTitanMinion.setMinionType(1);
                    blazeTitanMinion.setHealth(blazeTitanMinion.getMaxHealth());
                    this.level().addFreshEntity(blazeTitanMinion);
                }
            }
        } else if (this.getMinionType() == EnumMinionType.TEMPLAR) {
            if (this.tickCount % 40 == 0) {
                this.heal(1.0F);
            }

            if (this.level().getRandom().nextInt(150) == 1) {
                this.heal(2.0F);
            }

            if (this.level().getRandom().nextInt(100) == 1 && (double)this.getHealth() < (double)this.getMaxHealth() * 0.75) {
                this.heal(2.0F);
            }

            if (this.level().getRandom().nextInt(35) == 1 && (double)this.getHealth() < (double)this.getMaxHealth() * 0.5) {
                this.heal(5.0F);
            }

            if (this.level().getRandom().nextInt(30) == 1 && (double)this.getHealth() < (double)this.getMaxHealth() * 0.25) {
                this.heal(5.0F);
            }

            if (this.level().getRandom().nextInt(30) == 1 && (double)this.getHealth() < (double)this.getMaxHealth() * 0.05) {
                this.heal(200.0F);
            }

            if (!this.onGround() && this.getDeltaMovement().y < 0.0) {
                this.setDeltaMovement(this.getDeltaMovement().x, this.getDeltaMovement().y * 0.6, this.getDeltaMovement().z);
            }

            if (this.getMaster() == null && this.getHealth() > 0.0F && !this.level().isClientSide() && this.level().getDifficulty() != Difficulty.PEACEFUL) {
                float randomRatex = this.random.nextFloat() * 100.0F;
                if ((double)randomRatex < 0.167) {
                    EntityBlazeTitanMinion blazeTitanMinion = new EntityBlazeTitanMinion(this.level());
                    blazeTitanMinion.setPos(this.getX(), this.getY(), this.getZ());
                    blazeTitanMinion.setYRot(this.getYRot());
                    blazeTitanMinion.finalizeSpawn(
                        (ServerLevelAccessor)this.level(), this.level().getCurrentDifficultyAt(blazeTitanMinion.blockPosition()), MobSpawnType.SPAWNER, null, null
                    );
                    blazeTitanMinion.setMinionType(0);
                    blazeTitanMinion.setHealth(blazeTitanMinion.getMaxHealth());
                    this.level().addFreshEntity(blazeTitanMinion);
                }

                randomRatex = this.random.nextFloat() * 100.0F;
                if ((double)randomRatex < 0.083) {
                    EntityBlazeTitanMinion blazeTitanMinion = new EntityBlazeTitanMinion(this.level());
                    blazeTitanMinion.setPos(this.getX(), this.getY(), this.getZ());
                    blazeTitanMinion.setYRot(this.getYRot());
                    blazeTitanMinion.finalizeSpawn(
                        (ServerLevelAccessor)this.level(), this.level().getCurrentDifficultyAt(blazeTitanMinion.blockPosition()), MobSpawnType.SPAWNER, null, null
                    );
                    blazeTitanMinion.setMinionType(1);
                    blazeTitanMinion.setHealth(blazeTitanMinion.getMaxHealth());
                    this.level().addFreshEntity(blazeTitanMinion);
                }

                randomRatex = this.random.nextFloat() * 100.0F;
                if ((double)randomRatex < 0.042) {
                    EntityBlazeTitanMinion blazeTitanMinion = new EntityBlazeTitanMinion(this.level());
                    blazeTitanMinion.setPos(this.getX(), this.getY(), this.getZ());
                    blazeTitanMinion.setYRot(this.getYRot());
                    blazeTitanMinion.finalizeSpawn(
                        (ServerLevelAccessor)this.level(), this.level().getCurrentDifficultyAt(blazeTitanMinion.blockPosition()), MobSpawnType.SPAWNER, null, null
                    );
                    blazeTitanMinion.setMinionType(2);
                    blazeTitanMinion.setHealth(blazeTitanMinion.getMaxHealth());
                    this.level().addFreshEntity(blazeTitanMinion);
                }
            }

            if (!this.onGround()) {
                for (int i = 0; i < 3; i++) {
                    this.level()
                        .addParticle(
                            ParticleTypes.POOF,
                            this.getX() + (this.random.nextDouble() - 0.5) * (double)this.getBbWidth(),
                            this.getY(),
                            this.getZ() + (this.random.nextDouble() - 0.5) * (double)this.getBbWidth(),
                            0.0,
                            0.0,
                            0.0
                        );
                }
            } else {
                this.hasImpulse = false;
            }

            if (this.getTarget() != null && this.random.nextInt(60) == 0) {
                this.goalSelector.removeGoal(this.rangedAttackGoal);
                if (this.attackPattern == 0) {
                    this.goalSelector.addGoal(0, this.rangedAttackGoal);
                }

                if (!this.onGround()) {
                    this.attackPattern = 0;
                } else {
                    this.attackPattern = 1;
                }
            }

            this.heightOffsetUpdateTime--;
            if (this.heightOffsetUpdateTime <= 0) {
                this.jumpFromGround();
                this.heightOffsetUpdateTime = 100;
                this.heightOffset = 0.5F + this.random.nextFloat() * 3.0F;
                this.attackPattern = 0;
            }

            if (this.attackPattern == 0 && this.getTarget() != null) {
                if (this.getTarget().getY() + (double)this.getTarget().getEyeHeight() > this.getY() + (double)this.getEyeHeight() + (double)this.heightOffset) {
                    this.push(0.0, 0.4 - this.getDeltaMovement().y, 0.0);
                    this.hasImpulse = true;
                }

                this.getLookControl().setLookAt(this.getTarget(), 180.0F, 40.0F);
                double d0x = this.getTarget().getX() - this.getX();
                double d1 = this.getTarget().getZ() - this.getZ();
                double d3 = d0x * d0x + d1 * d1;
                if (d3 > (double)(this.getTarget().getBbWidth() * this.getTarget().getBbWidth() + this.getBbWidth() * this.getBbWidth()) + 16.0) {
                    double d5 = Math.sqrt(d3);
                    this.push(d0x / d5 * 0.6 - this.getDeltaMovement().y, 0.0, d1 / d5 * 0.6 - this.getDeltaMovement().z);
                }
            }

            List<Entity> entities = this.level().getEntities(this, this.getBoundingBox().inflate(8.0, 8.0, 8.0));
            if (!entities.isEmpty()
                && !this.level().isClientSide()
                && this.isAlive()
                && this.tickCount % (this.getHealth() < this.getMaxHealth() / 2.0F ? 40 : 160) == 0) {
                this.level().explode(this, this.getX(), this.getY(), this.getZ(), 8.0F, false, ExplosionInteraction.MOB);

                for (Entity entity : entities) {
                    if (entity != null && entity instanceof LivingEntity) {
                        LivingEntity liviingEntity = (LivingEntity)entity;
                        if (this.canAttack(liviingEntity)) {
                            liviingEntity.push(0.0, this.random.nextDouble(), 0.0);
                            liviingEntity.addEffect(new MobEffectInstance((MobEffect)TheTitansMobEffects.ELECTRIC_JUDGMENT.get(), 10, 1));
                        }
                    }
                }
            }
        }
    }

    public void setCharged(boolean charged) {
    }
}
