package net.titans.gen;

public abstract class NoiseGenerator {
}
