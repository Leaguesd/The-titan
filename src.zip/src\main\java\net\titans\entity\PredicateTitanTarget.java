package net.titans.entity;

import java.util.function.Predicate;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.titans.entity.titan.EntityEnderColossusCrystal;

public class PredicateTitanTarget implements Predicate<LivingEntity> {
    private Predicate<LivingEntity> predicate;

    /**
     * @param canAttackCreateMode 仅为兼容旧调用点保留，已不再使用：
     *                            创造 / 旁观模式玩家一律不作为目标（硬编码，不走配置项）
     */
    public PredicateTitanTarget(Predicate<LivingEntity> predicate, boolean canAttackCreateMode) {
        this.predicate = predicate;
    }

    public PredicateTitanTarget(Predicate<LivingEntity> predicate) {
        this.predicate = predicate;
    }

    public boolean test(LivingEntity entity) {
        if (entity instanceof EntityEnderColossusCrystal) {
            return false;
        }

        // 创造模式 / 旁观模式玩家永远不是泰坦的目标。
        // 这里直接硬编码，不再受配置项 titanAttackCreateMode 影响。
        if (entity instanceof Player player && (player.isCreative() || player.isSpectator())) {
            return false;
        }

        return this.predicate.test(entity);
    }
}
