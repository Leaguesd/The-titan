package net.titans.entity.ai.zombietitan;

import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.state.BlockState;
import net.titans.animation.AIAnimation;
import net.titans.entity.titan.EntityZombieTitan;

public class AnimationZombieTitanAttack3 extends AIAnimation {
    private EntityZombieTitan entity;

    public AnimationZombieTitanAttack3(EntityZombieTitan entity) {
        super(entity);
        this.entity = entity;
    }

    @Override
    public int getAnimationID() {
        return 7;
    }

    @Override
    public boolean isAutomatic() {
        return true;
    }

    @Override
    public int getDuration() {
        return 230;
    }

    @Override
    public boolean canContinueToUse() {
        BlockPos blockPos = this.entity.blockPosition().below();
        BlockState blockState = this.entity.level().getBlockState(blockPos);
        float explosionResistance = blockState.getBlock().getExplosionResistance();
        return this.entity.getAnimationTick() <= this.getDuration()
                && !this.entity.isStunned
                && (this.entity.isSwordSoft() ? !(explosionResistance <= 1.5F) : !(explosionResistance > 500.0F))
                && this.entity.isArmed()
            ? super.canContinueToUse()
            : false;
    }

    public void tick() {
        this.entity.setYRot(this.entity.yHeadRot);
        this.entity.setYBodyRot(this.entity.yHeadRot);
        if (this.entity.getTarget() != null && this.entity.getAnimationTick() < 10) {
            this.entity.getLookControl().setLookAt(this.entity.getTarget(), 180.0F, 40.0F);
        }
    }
}
