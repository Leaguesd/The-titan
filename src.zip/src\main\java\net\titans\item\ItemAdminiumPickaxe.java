package net.titans.item;

import net.minecraft.sounds.SoundEvent;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.PickaxeItem;
import net.minecraft.world.item.Item.Properties;
import net.titans.entity.titan.EntityTitan;
import net.titans.loader.TheTitansSounds;
import net.titans.loader.TheTitansTiers;

public class ItemAdminiumPickaxe extends PickaxeItem {
    public ItemAdminiumPickaxe(Properties properties) {
        super(TheTitansTiers.ADMINIUM, 1000000000, Float.MAX_VALUE, properties);
    }

    public boolean isFoil(ItemStack stack) {
        return true;
    }

    public boolean hurtEnemy(ItemStack stack, LivingEntity entity, LivingEntity attacker) {
        if (entity != null && (entity.getBbHeight() >= 6.0F || entity instanceof EntityTitan || !entity.onGround())) {
            entity.playSound((SoundEvent)TheTitansSounds.TITAN_PUNCH.get(), 10.0F, 1.0F);
            entity.hurt(entity.damageSources().mobAttack(attacker), 3.0E9F);
        }

        return super.hurtEnemy(stack, entity, attacker);
    }
}
