package net.titans.util;

import net.minecraft.world.entity.Entity;
import net.titans.animation.IAnimatedEntity;
import net.titans.entity.titan.EntityTitan;

public class AnimationUtils {
    public static void sendPacket(IAnimatedEntity animatedEntity, int animationID) {
        // 动画状态以服务端为准：客户端只通过 ANIMATION_ID 的实体数据同步接收，
        // 避免客户端自己的 AI goal 在本地改动画 ID/tick，造成两端状态打架。
        if (animatedEntity instanceof Entity entity && entity.level().isClientSide()) {
            return;
        }

        if (animatedEntity.getAnimationID() != animationID) {
            animatedEntity.setAnimationTick(0);
        }

        animatedEntity.setAnimationID(animationID);
    }

    public static void sendAttackPacket(EntityTitan entity, int animationAttackID) {
        entity.setAntiTitanAttackAnimationID(animationAttackID);
    }
}
