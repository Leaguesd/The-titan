package net.titans.event;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.util.Mth;
import net.minecraftforge.client.event.RenderGuiOverlayEvent;
import net.minecraftforge.client.gui.overlay.VanillaGuiOverlay;
import net.minecraftforge.eventbus.api.SubscribeEvent;

public class PlayerHealthBarEvent {
    @SubscribeEvent
    public void onRenderHealth(RenderGuiOverlayEvent.Pre event) {
        if (event.getOverlay() != VanillaGuiOverlay.PLAYER_HEALTH.type()) {
            return;
        }

        Minecraft minecraft = Minecraft.getInstance();
        LocalPlayer player = minecraft.player;
        if (player == null || player.isSpectator() || player.isCreative()) {
            return;
        }

        event.setCanceled(true);

        GuiGraphics guiGraphics = event.getGuiGraphics();
        int screenWidth = minecraft.getWindow().getGuiScaledWidth();
        int screenHeight = minecraft.getWindow().getGuiScaledHeight();

        int health = Mth.ceil(player.getHealth());
        int maxHealth = Mth.ceil(player.getMaxHealth());
        int absorption = Mth.ceil(player.getAbsorptionAmount());
        String text = health + "/" + maxHealth;

        int x = screenWidth / 2 - 91;
        int y = screenHeight - 49;

        int color = health <= maxHealth / 4 ? 16733525 : 16777215;
        guiGraphics.drawString(minecraft.font, text, x, y, color, true);
        if (absorption > 0) {
            String absorptionText = "+" + absorption;
            guiGraphics.drawString(minecraft.font, absorptionText, x + minecraft.font.width(text) + 4, y, 16777045, true);
        }
    }
}
