package net.titans.loader;

import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.EntityType.Builder;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.RegistryObject;
import net.titans.entity.EntityColorLightningBolt;
import net.titans.entity.EntityWitherTurret;
import net.titans.entity.EntityWitherTurretGround;
import net.titans.entity.EntityWitherTurretMortar;
import net.titans.entity.minion.EntityBlazeTitanMinion;
import net.titans.entity.minion.EntityCaveSpiderTitanMinion;
import net.titans.entity.minion.EntityCreeperTitanMinion;
import net.titans.entity.minion.EntityDragonMinion;
import net.titans.entity.minion.EntityEnderColossusMinion;
import net.titans.entity.minion.EntityGhastGuardMinion;
import net.titans.entity.minion.EntityGhastTitanMinion;
import net.titans.entity.minion.EntityOmegafishMinion;
import net.titans.entity.minion.EntitySkeletonTitanMinion;
import net.titans.entity.minion.EntitySpiderTitanMinion;
import net.titans.entity.minion.EntityWitherMinion;
import net.titans.entity.minion.EntityWitherSkeletonTitanMinion;
import net.titans.entity.minion.EntityWitherzillaMinion;
import net.titans.entity.minion.EntityZombieTitanGiantMinion;
import net.titans.entity.minion.EntityZombieTitanMinion;
import net.titans.entity.minion.EntityZombifiedPiglinTitanMinion;
import net.titans.entity.projectile.EntityArrowTitan;
import net.titans.entity.projectile.EntityBlazePowderTitan;
import net.titans.entity.projectile.EntityBlazeTitanMinionSmallFireball;
import net.titans.entity.projectile.EntityEnderPearlTitan;
import net.titans.entity.projectile.EntityFireballTitan;
import net.titans.entity.projectile.EntityGhastTitanMinionFireball;
import net.titans.entity.projectile.EntityGrowthSerum;
import net.titans.entity.projectile.EntityGunpowderTitan;
import net.titans.entity.projectile.EntityHarcadiumArrow;
import net.titans.entity.projectile.EntityIronIngotTitan;
import net.titans.entity.projectile.EntityLightningBall;
import net.titans.entity.projectile.EntityMortarWitherSkull;
import net.titans.entity.projectile.EntityProtoBall;
import net.titans.entity.projectile.EntitySnowballTitan;
import net.titans.entity.projectile.EntityWebShot;
import net.titans.entity.titan.EntityBlazeTitan;
import net.titans.entity.titan.EntityCaveSpiderTitan;
import net.titans.entity.titan.EntityCreeperTitan;
import net.titans.entity.titan.EntityEnderColossus;
import net.titans.entity.titan.EntityEnderColossusCrystal;
import net.titans.entity.titan.EntityExperienceOrbTitan;
import net.titans.entity.titan.EntityGhastTitan;
import net.titans.entity.titan.EntityIronGolemTitan;
import net.titans.entity.titan.EntityItemTitan;
import net.titans.entity.titan.EntityMagmaCubeTitan;
import net.titans.entity.titan.EntityOmegafish;
import net.titans.entity.titan.EntitySkeletonTitan;
import net.titans.entity.titan.EntitySlimeTitan;
import net.titans.entity.titan.EntitySnowGolemTitan;
import net.titans.entity.titan.EntitySpiderTitan;
import net.titans.entity.titan.EntityTitanSpirit;
import net.titans.entity.titan.EntityWitherSkeletonTitan;
import net.titans.entity.titan.EntityWitherzilla;
import net.titans.entity.titan.EntityZombieTitan;
import net.titans.entity.titan.EntityZombifiedPiglinTitan;

public class TheTitansEntities {
    public static final DeferredRegister<EntityType<?>> ENTITY_TYPES = DeferredRegister.create(Registries.ENTITY_TYPE, "titan");
    public static final RegistryObject<EntityType<EntityItemTitan>> ITEM_TITAN = ENTITY_TYPES.register(
        "item_titan",
        () -> Builder.<EntityItemTitan>of(EntityItemTitan::new, MobCategory.MISC)
                .clientTrackingRange(16)
                .sized(8.0F, 8.0F)
                .build(ResourceLocation.tryBuild("titan", "item_titan").toString())
    );
    public static final RegistryObject<EntityType<EntityExperienceOrbTitan>> EXPERIENCE_ORB_TITAN = ENTITY_TYPES.register(
        "experience_orb_titan",
        () -> Builder.<EntityExperienceOrbTitan>of(EntityExperienceOrbTitan::new, MobCategory.MISC)
                .clientTrackingRange(16)
                .sized(8.0F, 8.0F)
                .build(ResourceLocation.tryBuild("titan", "experience_orb_titan").toString())
    );
    public static final RegistryObject<EntityType<EntityColorLightningBolt>> COLOR_LIGHTNING_BLOT = ENTITY_TYPES.register(
        "color_lightning_bolt",
        () -> Builder.<EntityColorLightningBolt>of(EntityColorLightningBolt::new, MobCategory.MISC)
                .clientTrackingRange(16)
                .updateInterval(Integer.MAX_VALUE)
                .sized(0.0F, 0.0F)
                .build(ResourceLocation.tryBuild("titan", "color_lightning_bolt").toString())
    );
    public static final RegistryObject<EntityType<EntitySnowballTitan>> SNOWBALL_TITAN = ENTITY_TYPES.register(
        "snowball_titan",
        () -> Builder.<EntitySnowballTitan>of(EntitySnowballTitan::new, MobCategory.MISC)
                .clientTrackingRange(16)
                .sized(3.0F, 3.0F)
                .build(ResourceLocation.tryBuild("titan", "snowball_titan").toString())
    );
    public static final RegistryObject<EntityType<EntityProtoBall>> PROTO_BALL = ENTITY_TYPES.register(
        "proto_ball",
        () -> Builder.<EntityProtoBall>of(EntityProtoBall::new, MobCategory.MISC)
                .clientTrackingRange(16)
                .sized(3.0F, 3.0F)
                .build(ResourceLocation.tryBuild("titan", "proto_ball").toString())
    );
    public static final RegistryObject<EntityType<EntityArrowTitan>> ARROW_TITAN = ENTITY_TYPES.register(
        "arrow_titan",
        () -> Builder.<EntityArrowTitan>of(EntityArrowTitan::new, MobCategory.MISC)
                .clientTrackingRange(16)
                .sized(3.0F, 3.0F)
                .build(ResourceLocation.tryBuild("titan", "arrow_titan").toString())
    );
    public static final RegistryObject<EntityType<EntityGunpowderTitan>> GUNPOWDER_TITAN = ENTITY_TYPES.register(
        "gunpowder_titan",
        () -> Builder.<EntityGunpowderTitan>of(EntityGunpowderTitan::new, MobCategory.MISC)
                .clientTrackingRange(16)
                .sized(1.5F, 1.5F)
                .build(ResourceLocation.tryBuild("titan", "gunpowder_titan").toString())
    );
    public static final RegistryObject<EntityType<EntityHarcadiumArrow>> HARCADIUM_ARROW = ENTITY_TYPES.register(
        "harcadium_arrow",
        () -> Builder.<EntityHarcadiumArrow>of(EntityHarcadiumArrow::new, MobCategory.MISC)
                .clientTrackingRange(16)
                .sized(0.5F, 0.5F)
                .build(ResourceLocation.tryBuild("titan", "harcadium_arrow").toString())
    );
    public static final RegistryObject<EntityType<EntityGrowthSerum>> GROWTH_SERUM = ENTITY_TYPES.register(
        "growth_serum",
        () -> Builder.<EntityGrowthSerum>of(EntityGrowthSerum::new, MobCategory.MISC)
                .clientTrackingRange(16)
                .sized(0.5F, 0.5F)
                .build(ResourceLocation.tryBuild("titan", "growth_serum").toString())
    );
    public static final RegistryObject<EntityType<EntityWebShot>> WEB_SHOT = ENTITY_TYPES.register(
        "web_shot",
        () -> Builder.<EntityWebShot>of(EntityWebShot::new, MobCategory.MISC)
                .clientTrackingRange(16)
                .sized(3.0F, 3.0F)
                .build(ResourceLocation.tryBuild("titan", "web_shot").toString())
    );
    public static final RegistryObject<EntityType<EntityBlazePowderTitan>> BLAZE_POWDER_TITAN = ENTITY_TYPES.register(
        "blaze_powder_titan",
        () -> Builder.<EntityBlazePowderTitan>of(EntityBlazePowderTitan::new, MobCategory.MISC)
                .clientTrackingRange(16)
                .sized(2.0F, 2.0F)
                .build(ResourceLocation.tryBuild("titan", "blaze_powder_titan").toString())
    );
    public static final RegistryObject<EntityType<EntityEnderColossusCrystal>> ENDER_COLOSSUS_CRYSTAL = ENTITY_TYPES.register(
        "ender_colossus_crystal",
        () -> Builder.<EntityEnderColossusCrystal>of(EntityEnderColossusCrystal::new, MobCategory.MISC)
                .clientTrackingRange(16)
                .sized(2.0F, 2.0F)
                .build(ResourceLocation.tryBuild("titan", "ender_colossus_crystal").toString())
    );
    public static final RegistryObject<EntityType<EntityLightningBall>> LIGHTNING_BALL = ENTITY_TYPES.register(
        "lightning_ball",
        () -> Builder.<EntityLightningBall>of(EntityLightningBall::new, MobCategory.MISC)
                .clientTrackingRange(16)
                .sized(4.0F, 4.0F)
                .build(ResourceLocation.tryBuild("titan", "lightning_ball").toString())
    );
    public static final RegistryObject<EntityType<EntityEnderPearlTitan>> ENDER_PEARL_TITAN = ENTITY_TYPES.register(
        "ender_pearl_titan",
        () -> Builder.<EntityEnderPearlTitan>of(EntityEnderPearlTitan::new, MobCategory.MISC)
                .clientTrackingRange(16)
                .sized(4.0F, 4.0F)
                .build(ResourceLocation.tryBuild("titan", "ender_pearl_titan").toString())
    );
    public static final RegistryObject<EntityType<EntityFireballTitan>> FIREBALL_TITAN = ENTITY_TYPES.register(
        "fireball_titan",
        () -> Builder.<EntityFireballTitan>of(EntityFireballTitan::new, MobCategory.MISC)
                .clientTrackingRange(16)
                .sized(6.0F, 6.0F)
                .build(ResourceLocation.tryBuild("titan", "fireball_titan").toString())
    );
    public static final RegistryObject<EntityType<EntityIronIngotTitan>> IRON_INGOT_TITAN = ENTITY_TYPES.register(
        "iron_ingot_titan",
        () -> Builder.<EntityIronIngotTitan>of(EntityIronIngotTitan::new, MobCategory.MISC)
                .clientTrackingRange(16)
                .sized(6.0F, 6.0F)
                .build(ResourceLocation.tryBuild("titan", "iron_ingot_titan").toString())
    );
    public static final RegistryObject<EntityType<EntityMortarWitherSkull>> MORTAR_WITHER_SKULL = ENTITY_TYPES.register(
        "mortar_wither_skull",
        () -> Builder.<EntityMortarWitherSkull>of(EntityMortarWitherSkull::new, MobCategory.MISC)
                .clientTrackingRange(16)
                .sized(0.5F, 0.5F)
                .build(ResourceLocation.tryBuild("titan", "mortar_wither_skull").toString())
    );
    public static final RegistryObject<EntityType<EntityBlazeTitanMinionSmallFireball>> BLAZE_TITAN_MINION_SMALL_FIREBALL = ENTITY_TYPES.register(
        "blaze_titan_minion_small_fireball",
        () -> Builder.<EntityBlazeTitanMinionSmallFireball>of(EntityBlazeTitanMinionSmallFireball::new, MobCategory.MISC)
                .clientTrackingRange(4)
                .updateInterval(10)
                .sized(0.3125F, 0.3125F)
                .build(ResourceLocation.tryBuild("titan", "blaze_titan_minion_small_fireball").toString())
    );
    public static final RegistryObject<EntityType<EntityGhastTitanMinionFireball>> GHAST_TITAN_MINION_FIREBALL = ENTITY_TYPES.register(
        "ghast_titan_minion_fireball",
        () -> Builder.<EntityGhastTitanMinionFireball>of(EntityGhastTitanMinionFireball::new, MobCategory.MISC)
                .clientTrackingRange(4)
                .updateInterval(10)
                .sized(1.0F, 1.0F)
                .build(ResourceLocation.tryBuild("titan", "ghast_titan_minion_fireball").toString())
    );
    public static final RegistryObject<EntityType<EntityOmegafishMinion>> OMEGAFISH_MINION = ENTITY_TYPES.register(
        "omegafish_minion",
        () -> Builder.<EntityOmegafishMinion>of(EntityOmegafishMinion::new, MobCategory.MONSTER)
                .clientTrackingRange(8)
                .sized(0.4F, 0.3F)
                .build(ResourceLocation.tryBuild("titan", "omegafish_minion").toString())
    );
    public static final RegistryObject<EntityType<EntityZombieTitanMinion>> ZOMBIE_TITAN_MINION = ENTITY_TYPES.register(
        "zombie_titan_minion",
        () -> Builder.<EntityZombieTitanMinion>of(EntityZombieTitanMinion::new, MobCategory.MONSTER)
                .clientTrackingRange(8)
                .sized(0.5F, 1.95F)
                .build(ResourceLocation.tryBuild("titan", "zombie_titan_minion").toString())
    );
    public static final RegistryObject<EntityType<EntitySkeletonTitanMinion>> SKELETON_TITAN_MINION = ENTITY_TYPES.register(
        "skeleton_titan_minion",
        () -> Builder.<EntitySkeletonTitanMinion>of(EntitySkeletonTitanMinion::new, MobCategory.MONSTER)
                .clientTrackingRange(8)
                .sized(0.6F, 1.99F)
                .build(ResourceLocation.tryBuild("titan", "skeleton_titan_minion").toString())
    );
    public static final RegistryObject<EntityType<EntityWitherSkeletonTitanMinion>> WITHER_SKELETON_TITAN_MINION = ENTITY_TYPES.register(
        "wither_skeleton_titan_minion",
        () -> Builder.<EntityWitherSkeletonTitanMinion>of(EntityWitherSkeletonTitanMinion::new, MobCategory.MONSTER)
                .clientTrackingRange(8)
                .sized(0.7F, 2.4F)
                .build(ResourceLocation.tryBuild("titan", "wither_skeleton_titan_minion").toString())
    );
    public static final RegistryObject<EntityType<EntityCreeperTitanMinion>> CREEPER_TITAN_MINION = ENTITY_TYPES.register(
        "creeper_titan_minion",
        () -> Builder.<EntityCreeperTitanMinion>of(EntityCreeperTitanMinion::new, MobCategory.MONSTER)
                .clientTrackingRange(8)
                .sized(0.5F, 1.625F)
                .build(ResourceLocation.tryBuild("titan", "creeper_titan_minion").toString())
    );
    public static final RegistryObject<EntityType<EntitySpiderTitanMinion>> SPIDER_TITAN_MINION = ENTITY_TYPES.register(
        "spider_titan_minion",
        () -> Builder.<EntitySpiderTitanMinion>of(EntitySpiderTitanMinion::new, MobCategory.MONSTER)
                .clientTrackingRange(8)
                .sized(1.4F, 0.9F)
                .build(ResourceLocation.tryBuild("titan", "spider_titan_minion").toString())
    );
    public static final RegistryObject<EntityType<EntityCaveSpiderTitanMinion>> CAVE_SPIDER_TITAN_MINION = ENTITY_TYPES.register(
        "cave_spider_titan_minion",
        () -> Builder.<EntityCaveSpiderTitanMinion>of(EntityCaveSpiderTitanMinion::new, MobCategory.MONSTER)
                .clientTrackingRange(8)
                .sized(0.7F, 0.5F)
                .build(ResourceLocation.tryBuild("titan", "cave_spider_titan_minion").toString())
    );
    public static final RegistryObject<EntityType<EntityZombifiedPiglinTitanMinion>> ZOMBIFIED_PIGLIN_TITAN_MINION = ENTITY_TYPES.register(
        "zombified_piglin_titan_minion",
        () -> Builder.<EntityZombifiedPiglinTitanMinion>of(EntityZombifiedPiglinTitanMinion::new, MobCategory.MONSTER)
                .clientTrackingRange(8)
                .sized(0.6F, 1.95F)
                .build(ResourceLocation.tryBuild("titan", "zombified_piglin_titan_minion").toString())
    );
    public static final RegistryObject<EntityType<EntityBlazeTitanMinion>> BLAZE_TITAN_MINION = ENTITY_TYPES.register(
        "blaze_titan_minion",
        () -> Builder.<EntityBlazeTitanMinion>of(EntityBlazeTitanMinion::new, MobCategory.MONSTER)
                .clientTrackingRange(8)
                .sized(0.6F, 1.8F)
                .build(ResourceLocation.tryBuild("titan", "blaze_titan_minion").toString())
    );
    public static final RegistryObject<EntityType<EntityEnderColossusMinion>> ENDER_COLOSSUS_MINION = ENTITY_TYPES.register(
        "ender_colossus_minion",
        () -> Builder.<EntityEnderColossusMinion>of(EntityEnderColossusMinion::new, MobCategory.MONSTER)
                .clientTrackingRange(8)
                .sized(0.5F, 2.88F)
                .build(ResourceLocation.tryBuild("titan", "ender_colossus_minion").toString())
    );
    public static final RegistryObject<EntityType<EntityGhastTitanMinion>> GHAST_TITAN_MINION = ENTITY_TYPES.register(
        "ghast_titan_minion",
        () -> Builder.<EntityGhastTitanMinion>of(EntityGhastTitanMinion::new, MobCategory.MONSTER)
                .clientTrackingRange(8)
                .sized(4.5F, 4.5F)
                .build(ResourceLocation.tryBuild("titan", "ghast_titan_minion").toString())
    );
    public static final RegistryObject<EntityType<EntityWitherzillaMinion>> WITHERZILLA_MINION = ENTITY_TYPES.register(
        "witherzilla_minion",
        () -> Builder.<EntityWitherzillaMinion>of(EntityWitherzillaMinion::new, MobCategory.MONSTER)
                .clientTrackingRange(8)
                .sized(0.9F, 3.5F)
                .build(ResourceLocation.tryBuild("titan", "witherzilla_minion").toString())
    );
    public static final RegistryObject<EntityType<EntityZombieTitanGiantMinion>> ZOMBIE_TITAN_GIANT_MINION = ENTITY_TYPES.register(
        "zombie_titan_giant_minion",
        () -> Builder.<EntityZombieTitanGiantMinion>of(EntityZombieTitanGiantMinion::new, MobCategory.MONSTER)
                .clientTrackingRange(8)
                .sized(3.0F, 12.0F)
                .build(ResourceLocation.tryBuild("titan", "zombie_titan_giant_minion").toString())
    );
    public static final RegistryObject<EntityType<EntityGhastGuardMinion>> GHAST_GUARD_MINION = ENTITY_TYPES.register(
        "ghast_guard_minion",
        () -> Builder.<EntityGhastGuardMinion>of(EntityGhastGuardMinion::new, MobCategory.MONSTER)
                .clientTrackingRange(8)
                .sized(4.5F, 4.5F)
                .build(ResourceLocation.tryBuild("titan", "ghast_guard_minion").toString())
    );
    public static final RegistryObject<EntityType<EntityWitherMinion>> WITHER_MINION = ENTITY_TYPES.register(
        "wither_minion",
        () -> Builder.<EntityWitherMinion>of(EntityWitherMinion::new, MobCategory.MONSTER)
                .clientTrackingRange(8)
                .sized(0.9F, 3.5F)
                .build(ResourceLocation.tryBuild("titan", "wither_minion").toString())
    );
    public static final RegistryObject<EntityType<EntityDragonMinion>> DRAGON_MINION = ENTITY_TYPES.register(
        "dragon_minion",
        () -> Builder.<EntityDragonMinion>of(EntityDragonMinion::new, MobCategory.MONSTER)
                .clientTrackingRange(8)
                .sized(14.0F, 3.6F)
                .build(ResourceLocation.tryBuild("titan", "dragon_minion").toString())
    );
    public static final RegistryObject<EntityType<EntityTitanSpirit>> TITAN_SPIRIT = ENTITY_TYPES.register(
        "titan_spirit",
        () -> Builder.<EntityTitanSpirit>of(EntityTitanSpirit::new, MobCategory.MISC)
                .clientTrackingRange(512)
                .sized(8.0F, 8.0F)
                .build(ResourceLocation.tryBuild("titan", "titan_spirit").toString())
    );
    public static final RegistryObject<EntityType<EntitySnowGolemTitan>> SNOW_GOLEM_TITAN = ENTITY_TYPES.register(
        "snow_golem_titan",
        () -> Builder.<EntitySnowGolemTitan>of(EntitySnowGolemTitan::new, MobCategory.MISC)
                .clientTrackingRange(512)
                .sized(10.0F, 30.0F)
                .build(ResourceLocation.tryBuild("titan", "snow_golem_titan").toString())
    );
    public static final RegistryObject<EntityType<EntitySlimeTitan>> SLIME_TITAN = ENTITY_TYPES.register(
        "slime_titan",
        () -> Builder.<EntitySlimeTitan>of(EntitySlimeTitan::new, MobCategory.MISC)
                .clientTrackingRange(512)
                .sized(8.0F, 8.0F)
                .build(ResourceLocation.tryBuild("titan", "slime_titan").toString())
    );
    public static final RegistryObject<EntityType<EntityMagmaCubeTitan>> MAGMACUBE_TITAN = ENTITY_TYPES.register(
        "magmacube_titan",
        () -> Builder.<EntityMagmaCubeTitan>of(EntityMagmaCubeTitan::new, MobCategory.MISC)
                .clientTrackingRange(512)
                .sized(8.0F, 8.0F)
                .build(ResourceLocation.tryBuild("titan", "magmacube_titan").toString())
    );
    public static final RegistryObject<EntityType<EntityOmegafish>> OMEGAFISH = ENTITY_TYPES.register(
        "omegafish",
        () -> Builder.<EntityOmegafish>of(EntityOmegafish::new, MobCategory.MISC)
                .clientTrackingRange(512)
                .sized(9.0F, 6.0F)
                .build(ResourceLocation.tryBuild("titan", "omegafish").toString())
    );
    public static final RegistryObject<EntityType<EntityZombieTitan>> ZOMBIE_TITAN = ENTITY_TYPES.register(
        "zombie_titan",
        () -> Builder.<EntityZombieTitan>of(EntityZombieTitan::new, MobCategory.MISC)
                .clientTrackingRange(512)
                .sized(8.0F, 32.0F)
                .build(ResourceLocation.tryBuild("titan", "zombie_titan").toString())
    );
    public static final RegistryObject<EntityType<EntitySkeletonTitan>> SKELETON_TITAN = ENTITY_TYPES.register(
        "skeleton_titan",
        () -> Builder.<EntitySkeletonTitan>of(EntitySkeletonTitan::new, MobCategory.MISC)
                .clientTrackingRange(512)
                .sized(8.0F, 32.0F)
                .build(ResourceLocation.tryBuild("titan", "skeleton_titan").toString())
    );
    public static final RegistryObject<EntityType<EntityWitherSkeletonTitan>> WITHER_SKELETON_TITAN = ENTITY_TYPES.register(
        "wither_skeleton_titan",
        () -> Builder.<EntityWitherSkeletonTitan>of(EntityWitherSkeletonTitan::new, MobCategory.MISC)
                .clientTrackingRange(512)
                .sized(14.0F, 56.0F)
                .build(ResourceLocation.tryBuild("titan", "wither_skeleton_titan").toString())
    );
    public static final RegistryObject<EntityType<EntityCreeperTitan>> CREEPER_TITAN = ENTITY_TYPES.register(
        "creeper_titan",
        () -> Builder.<EntityCreeperTitan>of(EntityCreeperTitan::new, MobCategory.MISC)
                .clientTrackingRange(512)
                .sized(8.0F, 26.0F)
                .build(ResourceLocation.tryBuild("titan", "creeper_titan").toString())
    );
    public static final RegistryObject<EntityType<EntitySpiderTitan>> SPIDER_TITAN = ENTITY_TYPES.register(
        "spider_titan",
        () -> Builder.<EntitySpiderTitan>of(EntitySpiderTitan::new, MobCategory.MISC)
                .clientTrackingRange(512)
                .sized(28.0F, 14.0F)
                .build(ResourceLocation.tryBuild("titan", "spider_titan").toString())
    );
    public static final RegistryObject<EntityType<EntityCaveSpiderTitan>> CAVE_SPIDER_TITAN = ENTITY_TYPES.register(
        "cave_spider_titan",
        () -> Builder.<EntityCaveSpiderTitan>of(EntityCaveSpiderTitan::new, MobCategory.MISC)
                .clientTrackingRange(512)
                .sized(16.0F, 10.0F)
                .build(ResourceLocation.tryBuild("titan", "cave_spider_titan").toString())
    );
    public static final RegistryObject<EntityType<EntityZombifiedPiglinTitan>> ZOMBIFIED_PIGLIN_TITAN = ENTITY_TYPES.register(
        "zombified_piglin_titan",
        () -> Builder.<EntityZombifiedPiglinTitan>of(EntityZombifiedPiglinTitan::new, MobCategory.MISC)
                .clientTrackingRange(512)
                .sized(8.0F, 32.0F)
                .build(ResourceLocation.tryBuild("titan", "zombified_piglin_titan").toString())
    );
    public static final RegistryObject<EntityType<EntityBlazeTitan>> BLAZE_TITAN = ENTITY_TYPES.register(
        "blaze_titan",
        () -> Builder.<EntityBlazeTitan>of(EntityBlazeTitan::new, MobCategory.MISC)
                .clientTrackingRange(512)
                .sized(8.0F, 8.0F)
                .build(ResourceLocation.tryBuild("titan", "blaze_titan").toString())
    );
    public static final RegistryObject<EntityType<EntityEnderColossus>> ENDER_COLOSSUS = ENTITY_TYPES.register(
        "ender_colossus",
        () -> Builder.<EntityEnderColossus>of(EntityEnderColossus::new, MobCategory.MISC)
                .clientTrackingRange(512)
                .sized(12.0F, 72.0F)
                .build(ResourceLocation.tryBuild("titan", "ender_colossus").toString())
    );
    public static final RegistryObject<EntityType<EntityGhastTitan>> GHAST_TITAN = ENTITY_TYPES.register(
        "ghast_titan",
        () -> Builder.<EntityGhastTitan>of(EntityGhastTitan::new, MobCategory.MISC)
                .clientTrackingRange(512)
                .sized(110.0F, 110.0F)
                .build(ResourceLocation.tryBuild("titan", "ghast_titan").toString())
    );
    public static final RegistryObject<EntityType<EntityIronGolemTitan>> IRON_GOLEM_TITAN = ENTITY_TYPES.register(
        "iron_golem_titan",
        () -> Builder.<EntityIronGolemTitan>of(EntityIronGolemTitan::new, MobCategory.MISC)
                .clientTrackingRange(512)
                .sized(24.0F, 64.0F)
                .build(ResourceLocation.tryBuild("titan", "iron_golem_titan").toString())
    );
    public static final RegistryObject<EntityType<EntityWitherzilla>> WITHERZILLA = ENTITY_TYPES.register(
        "witherzilla",
        () -> Builder.<EntityWitherzilla>of(EntityWitherzilla::new, MobCategory.MISC)
                .clientTrackingRange(1024)
                .sized(64.0F, 224.0F)
                .build(ResourceLocation.tryBuild("titan", "witherzilla").toString())
    );
    public static final RegistryObject<EntityType<EntityWitherTurret>> WITHER_TURRET = ENTITY_TYPES.register(
        "wither_turret",
        () -> Builder.<EntityWitherTurret>of(EntityWitherTurret::new, MobCategory.MISC)
                .clientTrackingRange(8)
                .sized(0.35F, 2.5F)
                .build(ResourceLocation.tryBuild("titan", "wither_turret").toString())
    );
    public static final RegistryObject<EntityType<EntityWitherTurretGround>> WITHER_TURRET_GROUND = ENTITY_TYPES.register(
        "wither_turret_ground",
        () -> Builder.<EntityWitherTurretGround>of(EntityWitherTurretGround::new, MobCategory.MISC)
                .clientTrackingRange(8)
                .sized(0.75F, 1.375F)
                .build(ResourceLocation.tryBuild("titan", "wither_turret_ground").toString())
    );
    public static final RegistryObject<EntityType<EntityWitherTurretMortar>> WITHER_TURRET_MORTAR = ENTITY_TYPES.register(
        "wither_turret_mortar",
        () -> Builder.<EntityWitherTurretMortar>of(EntityWitherTurretMortar::new, MobCategory.MISC)
                .clientTrackingRange(8)
                .sized(1.0F, 3.75F)
                .build(ResourceLocation.tryBuild("titan", "wither_turret_mortar").toString())
    );

    public static void registerEntities(IEventBus modEventBus) {
        ENTITY_TYPES.register(modEventBus);
        modEventBus.addListener(TheTitansEntities::onEntityAttributeCreation);
    }

    @SubscribeEvent
    public static void onEntityAttributeCreation(EntityAttributeCreationEvent event) {
        event.put((EntityType)OMEGAFISH_MINION.get(), EntityOmegafishMinion.createAttributes().build());
        event.put((EntityType)ZOMBIE_TITAN_MINION.get(), EntityZombieTitanMinion.createAttributes().build());
        event.put((EntityType)SKELETON_TITAN_MINION.get(), EntitySkeletonTitanMinion.createAttributes().build());
        event.put((EntityType)WITHER_SKELETON_TITAN_MINION.get(), EntityWitherSkeletonTitanMinion.createAttributes().build());
        event.put((EntityType)CREEPER_TITAN_MINION.get(), EntityCreeperTitanMinion.createAttributes().build());
        event.put((EntityType)SPIDER_TITAN_MINION.get(), EntitySpiderTitanMinion.createAttributes().build());
        event.put((EntityType)CAVE_SPIDER_TITAN_MINION.get(), EntityCaveSpiderTitanMinion.createAttributes().build());
        event.put((EntityType)ZOMBIFIED_PIGLIN_TITAN_MINION.get(), EntityZombifiedPiglinTitanMinion.createAttributes().build());
        event.put((EntityType)BLAZE_TITAN_MINION.get(), EntityBlazeTitanMinion.createAttributes().build());
        event.put((EntityType)ENDER_COLOSSUS_MINION.get(), EntityEnderColossusMinion.createAttributes().build());
        event.put((EntityType)GHAST_TITAN_MINION.get(), EntityGhastTitanMinion.createAttributes().build());
        event.put((EntityType)WITHERZILLA_MINION.get(), EntityWitherzillaMinion.createAttributes().build());
        event.put((EntityType)ZOMBIE_TITAN_GIANT_MINION.get(), EntityZombieTitanGiantMinion.createAttributes().build());
        event.put((EntityType)GHAST_GUARD_MINION.get(), EntityGhastGuardMinion.createAttributes().build());
        event.put((EntityType)WITHER_MINION.get(), EntityWitherMinion.createAttributes().build());
        event.put((EntityType)DRAGON_MINION.get(), EntityDragonMinion.createAttributes().build());
        event.put((EntityType)TITAN_SPIRIT.get(), EntityTitanSpirit.createAttributes().build());
        event.put((EntityType)SNOW_GOLEM_TITAN.get(), EntitySnowGolemTitan.createAttributes().build());
        event.put((EntityType)SLIME_TITAN.get(), EntitySlimeTitan.createAttributes().build());
        event.put((EntityType)MAGMACUBE_TITAN.get(), EntityMagmaCubeTitan.createAttributes().build());
        event.put((EntityType)OMEGAFISH.get(), EntityOmegafish.createAttributes().build());
        event.put((EntityType)ZOMBIE_TITAN.get(), EntityZombieTitan.createAttributes().build());
        event.put((EntityType)SKELETON_TITAN.get(), EntitySkeletonTitan.createAttributes().build());
        event.put((EntityType)WITHER_SKELETON_TITAN.get(), EntityWitherSkeletonTitan.createAttributes().build());
        event.put((EntityType)CREEPER_TITAN.get(), EntityCreeperTitan.createAttributes().build());
        event.put((EntityType)SPIDER_TITAN.get(), EntitySpiderTitan.createAttributes().build());
        event.put((EntityType)CAVE_SPIDER_TITAN.get(), EntityCaveSpiderTitan.createAttributes().build());
        event.put((EntityType)ZOMBIFIED_PIGLIN_TITAN.get(), EntityZombifiedPiglinTitan.createAttributes().build());
        event.put((EntityType)BLAZE_TITAN.get(), EntityBlazeTitan.createAttributes().build());
        event.put((EntityType)ENDER_COLOSSUS.get(), EntityEnderColossus.createAttributes().build());
        event.put((EntityType)ENDER_COLOSSUS_CRYSTAL.get(), EntityEnderColossusCrystal.createAttributes().build());
        event.put((EntityType)GHAST_TITAN.get(), EntityGhastTitan.createAttributes().build());
        event.put((EntityType)IRON_GOLEM_TITAN.get(), EntityIronGolemTitan.createAttributes().build());
        event.put((EntityType)WITHERZILLA.get(), EntityWitherzilla.createAttributes().build());
        event.put((EntityType)WITHER_TURRET.get(), EntityWitherTurret.createAttributes().build());
        event.put((EntityType)WITHER_TURRET_GROUND.get(), EntityWitherTurretGround.createAttributes().build());
        event.put((EntityType)WITHER_TURRET_MORTAR.get(), EntityWitherTurretMortar.createAttributes().build());
    }
}
