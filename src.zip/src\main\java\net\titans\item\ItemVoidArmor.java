package net.titans.item;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.OwnableEntity;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.animal.AbstractGolem;
import net.minecraft.world.entity.npc.Villager;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ArmorMaterial;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.ArmorItem.Type;
import net.minecraft.world.item.Item.Properties;
import net.minecraft.world.level.Level;
import net.titans.entity.titan.EntityTitan;
import net.titans.loader.TheTitansRegistries;
import net.titans.loader.TheTitansSounds;

public class ItemVoidArmor extends ArmorItem {
    public ItemVoidArmor(ArmorMaterial material, Type type, Properties properties) {
        super(material, type, properties);
    }

    public void inventoryTick(ItemStack stack, Level level, Entity entity, int slotId, boolean isSelected) {
        super.inventoryTick(stack, level, entity, slotId, isSelected);
        if (entity instanceof Player player) {
            if (this.getEquipmentSlot() == EquipmentSlot.HEAD && slotId == 39) {
                player.playSound((SoundEvent)TheTitansSounds.HARCACADIUM_HUM.get(), 5.0F, 0.5F);
                player.removeEffect(MobEffects.BLINDNESS);
                player.addEffect(new MobEffectInstance(MobEffects.WATER_BREATHING, 300, 0));
                player.addEffect(new MobEffectInstance(MobEffects.NIGHT_VISION, 300, 0));
            } else if (this.getEquipmentSlot() == EquipmentSlot.CHEST && slotId == 38) {
                player.playSound((SoundEvent)TheTitansSounds.HARCACADIUM_HUM.get(), 5.0F, 0.5F);
                player.removeEffect(MobEffects.WEAKNESS);
                player.removeEffect(MobEffects.DIG_SLOWDOWN);
                player.addEffect(new MobEffectInstance(MobEffects.DIG_SPEED, 300, 99));
                player.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 300, 3));
                player.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST, 300, 49));
                player.addEffect(new MobEffectInstance(MobEffects.FIRE_RESISTANCE, 300, 0));
            } else if (this.getEquipmentSlot() == EquipmentSlot.LEGS && slotId == 37) {
                player.playSound((SoundEvent)TheTitansSounds.HARCACADIUM_HUM.get(), 5.0F, 0.0F);
                player.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 300, 199));
                player.removeEffect(MobEffects.CONFUSION);
                player.removeEffect(MobEffects.HUNGER);
                player.removeEffect(MobEffects.POISON);
            } else if (this.getEquipmentSlot() == EquipmentSlot.FEET && slotId == 36) {
                player.playSound((SoundEvent)TheTitansSounds.HARCACADIUM_HUM.get(), 5.0F, 0.5F);
                player.removeEffect(MobEffects.MOVEMENT_SLOWDOWN);
                player.addEffect(new MobEffectInstance(MobEffects.JUMP, 300, 5));
                player.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 300, 19));
            }

            if (player.getItemBySlot(EquipmentSlot.HEAD).getItem() == TheTitansRegistries.VOID_HELMET.get()
                && player.getItemBySlot(EquipmentSlot.CHEST).getItem() == TheTitansRegistries.VOID_CHESTPLATE.get()
                && player.getItemBySlot(EquipmentSlot.LEGS).getItem() == TheTitansRegistries.VOID_LEGGINGS.get()
                && player.getItemBySlot(EquipmentSlot.FEET).getItem() == TheTitansRegistries.VOID_BOOTS.get()) {
                for (int i = 0; i < 4; i++) {
                    level.addParticle(
                        ParticleTypes.MYCELIUM,
                        player.getX() + (player.getRandom().nextDouble() - 0.5) * (double)player.getBbWidth() * 2.0,
                        player.getY() - 1.75 + player.getRandom().nextDouble() * (double)player.getBbHeight(),
                        player.getZ() + (player.getRandom().nextDouble() - 0.5) * (double)player.getBbWidth() * 2.0,
                        0.0,
                        0.05,
                        0.0
                    );
                }

                player.getAttribute(Attributes.MAX_HEALTH).setBaseValue(4000.0);
                if (!level.isClientSide() && player.getHealth() < player.getMaxHealth()) {
                    player.heal(50.0F);
                }

                player.addEffect(new MobEffectInstance(MobEffects.SATURATION, 300, 99));
                player.fallDistance = 0.0F;
                if (!level.isClientSide()) {
                    for (Entity radiatedEntity : player.level().getEntities(player, player.getBoundingBox().inflate(4.0, 4.0, 4.0))) {
                        if (radiatedEntity != null
                            && radiatedEntity instanceof LivingEntity
                            && !(radiatedEntity instanceof EntityTitan)
                            && !(radiatedEntity instanceof AbstractGolem)
                            && !(radiatedEntity instanceof OwnableEntity)
                            && !(radiatedEntity instanceof Villager)) {
                            LivingEntity livingEntity = (LivingEntity)radiatedEntity;
                            if (!level.isClientSide()
                                && !(livingEntity instanceof Player)) {
                                livingEntity.hurt(livingEntity.damageSources().fellOutOfWorld(), 4.0F);
                                livingEntity.addEffect(new MobEffectInstance(MobEffects.BLINDNESS, 5000, 1));
                                livingEntity.addEffect(new MobEffectInstance(MobEffects.CONFUSION, 5000, 1));
                                livingEntity.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 5000, 9));
                                livingEntity.addEffect(new MobEffectInstance(MobEffects.WITHER, 5000, 3));
                            }
                        }
                    }
                }
            } else if (player.getAttribute(Attributes.MAX_HEALTH).getBaseValue() == 4000.0) {
                player.getAttribute(Attributes.MAX_HEALTH).setBaseValue(20.0);
                if (player.getHealth() > player.getMaxHealth()) {
                    player.setHealth(player.getMaxHealth());
                }
            }
        }
    }
}
