package net.titans.entity.titan;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import javax.annotation.Nullable;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.util.Mth;
import net.minecraft.world.Difficulty;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.SpawnGroupData;
import net.minecraft.world.entity.Entity.RemovalReason;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier.Builder;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.ItemLike;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.ServerLevelAccessor;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;
import net.titans.entity.IBossBarDisplay;
import net.titans.entity.ai.EntityAINearestTargetTitan;
import net.titans.entity.ai.blazetitan.EntityAIBlazeTitanAttack;
import net.titans.entity.minion.EntityBlazeTitanMinion;
import net.titans.loader.TheTitansEntities;
import net.titans.loader.TheTitansRegistries;
import net.titans.loader.TheTitansPredicateTargets;
import net.titans.loader.TheTitansSounds;

public class EntityBlazeTitan extends EntityTitan implements IEntityMultiPartTitan, IBossBarDisplay {
    private static final EntityDataAccessor<Byte> DATA_FLAGS_ID = SynchedEntityData.defineId(EntityBlazeTitan.class, EntityDataSerializers.BYTE);
    /** 有目标时，脚底相对目标 Y 的悬停高度。 */
    private static final double HOVER_HEIGHT = 12.0;
    /** 有目标时允许的最高高度，超过后立即停止上升。 */
    private static final double MAX_HOVER_HEIGHT = 24.0;
    public final EntityTitanPart head;
    public EntityTitanPart[] rods = new EntityTitanPart[12];
    private float heightOffset = 32.0F;
    private int heightOffsetUpdateTime;

    public EntityBlazeTitan(EntityType<? extends EntityTitan> entityType, Level level) {
        super(entityType, level);
        this.shouldParticlesBeUpward = true;
        this.head = new EntityTitanPart(this, "head", 8.0F, 8.0F);
        this.rods[0] = new EntityTitanPart(this, "rod1", 2.0F, 8.0F);
        this.rods[1] = new EntityTitanPart(this, "rod2", 2.0F, 8.0F);
        this.rods[2] = new EntityTitanPart(this, "rod3", 2.0F, 8.0F);
        this.rods[3] = new EntityTitanPart(this, "rod4", 2.0F, 8.0F);
        this.rods[4] = new EntityTitanPart(this, "rod5", 2.0F, 8.0F);
        this.rods[5] = new EntityTitanPart(this, "rod6", 2.0F, 8.0F);
        this.rods[6] = new EntityTitanPart(this, "rod7", 2.0F, 8.0F);
        this.rods[7] = new EntityTitanPart(this, "rod8", 2.0F, 8.0F);
        this.rods[8] = new EntityTitanPart(this, "rod9", 2.0F, 8.0F);
        this.rods[9] = new EntityTitanPart(this, "rod10", 2.0F, 8.0F);
        this.rods[10] = new EntityTitanPart(this, "rod11", 2.0F, 8.0F);
        this.rods[11] = new EntityTitanPart(this, "rod12", 2.0F, 8.0F);
        this.parts = new EntityTitanPart[]{
            this.head,
            this.rods[0],
            this.rods[1],
            this.rods[2],
            this.rods[3],
            this.rods[4],
            this.rods[5],
            this.rods[6],
            this.rods[7],
            this.rods[8],
            this.rods[9],
            this.rods[10],
            this.rods[11]
        };
    }

    public EntityBlazeTitan(Level level) {
        this((EntityType<? extends EntityTitan>)TheTitansEntities.BLAZE_TITAN.get(), level);
    }

    public static Builder createAttributes() {
        return EntityTitan.createAttributes().add(Attributes.MAX_HEALTH, 80000.0).add(Attributes.ATTACK_DAMAGE, 1200.0);
    }

    @Override
    public ResourceLocation getBossBarTexture() {
        return ResourceLocation.tryBuild("titan", "textures/gui/bossbar/blaze_titan.png");
    }

    @Override
    public int getBossBarNameColor() {
        switch (this.random.nextInt(2)) {
            case 0:
                return ChatFormatting.RED.getColor();
            case 1:
                return ChatFormatting.GOLD.getColor();
            default:
                return 16167425;
        }
    }

    @Override
    public int getBossBarWidth() {
        return 185;
    }

    @Override
    public int getBossBarHeight() {
        return 34;
    }

    @Override
    public int getBossBarInterval() {
        return 5;
    }

    @Override
    public int getBossBarVOffset() {
        return 0;
    }

    @Override
    public int getBossBarVHeight() {
        return 0;
    }

    @Override
    public int getBossBarTextOffset() {
        return 10;
    }

    @Override
    protected void registerGoals() {
        super.registerGoals();
        this.goalSelector.addGoal(4, new EntityAIBlazeTitanAttack(this));
        this.targetSelector.addGoal(0, new EntityAINearestTargetTitan(this, EntitySnowGolemTitan.class, false));
        this.targetSelector.addGoal(0, new EntityAINearestTargetTitan(this, EntityIronGolemTitan.class, false));
        this.targetSelector
            .addGoal(0, new EntityAINearestTargetTitan<LivingEntity>(this, LivingEntity.class, 0, false, false, TheTitansPredicateTargets.BlazeTitan));
    }

    public boolean isCharged() {
        return ((Byte)this.entityData.get(DATA_FLAGS_ID) & 1) != 0;
    }

    public void setCharged(boolean charged) {
        byte b0 = (Byte)this.entityData.get(DATA_FLAGS_ID);
        if (charged) {
            b0 = (byte)(b0 | 1);
        } else {
            b0 = (byte)(b0 & -2);
        }

        this.entityData.set(DATA_FLAGS_ID, b0);
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(DATA_FLAGS_ID, (byte)0);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
    }

    @Override
    public SpawnGroupData finalizeSpawn(
        ServerLevelAccessor level, DifficultyInstance difficulty, MobSpawnType spawnType, @Nullable SpawnGroupData spawnGroupData, @Nullable CompoundTag tag
    ) {
        return super.finalizeSpawn(level, difficulty, spawnType, spawnGroupData, null);
    }

    @Override
    protected void refreshAttributes() {
        if (this.level().getDifficulty() == Difficulty.HARD) {
            this.getAttribute(Attributes.MAX_HEALTH).setBaseValue(80000.0 + (double)this.getExtraPower() * 4000.0);
            this.getAttribute(Attributes.ATTACK_DAMAGE).setBaseValue(1200.0 + (double)this.getExtraPower() * 40.0);
        } else {
            this.getAttribute(Attributes.MAX_HEALTH).setBaseValue(40000.0 + (double)this.getExtraPower() * 2000.0);
            this.getAttribute(Attributes.ATTACK_DAMAGE).setBaseValue(600.0 + (double)this.getExtraPower() * 20.0);
        }
    }

    @Override
    public boolean canAttackEntity(Entity entity) {
        return super.canAttackEntity(entity) && !(entity instanceof EntityBlazeTitanMinion);
    }

    @Override
    public boolean canBeHurtByPlayer() {
        return !this.isInvulnerable();
    }

    @Override
    public int getRegenTime() {
        return 10;
    }

    @Override
    public boolean isArmored() {
        return this.deathTicks <= 0 && this.getTitanHealth() <= this.getTitanMaxHealth() / 4.0F;
    }

    @Override
    public SimpleParticleType getParticles() {
        return this.random.nextInt(this.isInWaterOrRain() ? 2 : 6) == 0 ? ParticleTypes.POOF : ParticleTypes.LARGE_SMOKE;
    }

    @Override
    public int getParticleCount() {
        return 40;
    }

    @Override
    public int getMinionCap() {
        return 120;
    }

    @Override
    public int getPriestCap() {
        return 60;
    }

    @Override
    public int getZealotCap() {
        return 20;
    }

    @Override
    public int getBishopCap() {
        return 15;
    }

    @Override
    public int getTemplarCap() {
        return 8;
    }

    @Override
    public boolean canSpawnMinion() {
        boolean flag = this.getInvulTime() > 1 && this.tickCount % 20 == 0;
        float randomRate = this.random.nextFloat() * 100.0F;
        return flag || (double)randomRate < 5.0;
    }

    @Override
    public boolean canSpawnPriest() {
        boolean flag = this.getInvulTime() > 1 && this.tickCount % 20 == 0;
        float randomRate = this.random.nextFloat() * 100.0F;
        return flag || (double)randomRate < 2.5;
    }

    @Override
    public boolean canSpawnZealot() {
        boolean flag = this.getInvulTime() > 1 && this.tickCount % 20 == 0;
        float randomRate = this.random.nextFloat() * 100.0F;
        return flag || (double)randomRate < 1.25;
    }

    @Override
    public boolean canSpawnBishop() {
        boolean flag = this.getInvulTime() > 1 && this.tickCount % 20 == 0;
        float randomRate = this.random.nextFloat() * 100.0F;
        return flag || (double)randomRate < 0.625;
    }

    @Override
    public boolean canSpawnTemplar() {
        boolean flag = this.getInvulTime() > 1 && this.tickCount % 20 == 0;
        float randomRate = this.random.nextFloat() * 100.0F;
        return flag || (double)randomRate < 0.3125;
    }

    @Override
    public EnumTitanStatus getTitanStatus() {
        return EnumTitanStatus.AVERAGE;
    }

    public boolean isOnFire() {
        return this.isCharged() && this.invulnerableTime < 20;
    }

    @Override
    public float getSpeed() {
        return 0.5F + (float)this.getExtraPower() * 0.001F;
    }

    public float getLightLevelDependentMagicValue() {
        return 1.0F;
    }

    public int getMaxHeadXRot() {
        return 180;
    }

    protected SoundEvent getAmbientSound() {
        return (SoundEvent)TheTitansSounds.TITAN_BLAZE_BREATHE.get();
    }

    protected SoundEvent getHurtSound(DamageSource damageSource) {
        return (SoundEvent)TheTitansSounds.TITAN_BLAZE_GRUNT.get();
    }

    protected SoundEvent getDeathSound() {
        return (SoundEvent)TheTitansSounds.TITAN_BLAZE_DEATH.get();
    }

    protected void playStepSound(BlockPos pos, BlockState state) {
    }

    @Override
    public boolean attackEntityFromPart(EntityTitanPart entityTitanPart, DamageSource damageSource, float amount) {
        this.hurt(damageSource, amount);
        return true;
    }

    @Override
    public boolean hurt(DamageSource damageSource, float amount) {
        if (this.isArmored()) {
            amount /= 2.0F;
        }

        if (!damageSource.is(DamageTypes.IN_FIRE) && !damageSource.is(DamageTypes.ON_FIRE)) {
            return super.hurt(damageSource, amount);
        } else {
            this.heal(amount);
            return false;
        }
    }

    @Override
    public boolean causeFallDamage(float fallDistance, float multiplier, DamageSource damageSource) {
        return false;
    }

    @Override
    public void aiStep() {
        super.aiStep();
        if (this.getInvulTime() < 0) {
            this.heightOffsetUpdateTime--;
            if (this.heightOffsetUpdateTime <= 0) {
                this.heightOffsetUpdateTime = 300;
                this.heightOffset = 40.0F + (float)this.random.nextGaussian() * 16.0F;
            }

            LivingEntity entity = this.getTarget();
            if (entity != null && entity.getY() + (double)entity.getEyeHeight() > this.getY() + (double)this.getEyeHeight() + (double)this.heightOffset) {
                this.setTitanDeltaMovement(
                    this.getDeltaMovement().x, this.getDeltaMovement().y + (0.9 - this.getDeltaMovement().y) * 0.9, this.getDeltaMovement().z
                );
                this.hasImpulse = true;
            }
        }
    }

    @Override
    protected void dropExperienceOrb() {
        for (int x = 0; x < 32; x++) {
            EntityExperienceOrbTitan experienceOrbTitan = new EntityExperienceOrbTitan(
                this.level(),
                this.getX() + (double)(this.random.nextFloat() * 12.0F - 6.0F),
                this.getY() + 4.0,
                this.getZ() + (double)(this.random.nextFloat() * 12.0F - 6.0F),
                18000
            );
            experienceOrbTitan.push(0.0, 1.0, 0.0);
            this.level().addFreshEntity(experienceOrbTitan);
        }
    }

    @Override
    protected void dropAllItem() {
        Map<ItemStack, Integer> drops = new HashMap<>();
        Map<ItemStack, Integer> rateDrops = new HashMap<>();
        drops.put(new ItemStack(Items.BLAZE_ROD), 144);
        drops.put(new ItemStack(Items.BLAZE_POWDER), 96);
        drops.put(new ItemStack(Items.COAL), 64);
        drops.put(new ItemStack(Items.GOLD_INGOT), 24);
        drops.put(new ItemStack(Items.EMERALD), 16);
        drops.put(new ItemStack(Items.DIAMOND), 16);
        drops.put(new ItemStack((ItemLike)TheTitansRegistries.HARCADIUM.get()), 1);
        rateDrops.put(new ItemStack(Items.BLAZE_ROD), 144);
        rateDrops.put(new ItemStack(Items.BLAZE_POWDER), 96);
        rateDrops.put(new ItemStack(Items.COAL), 64);
        rateDrops.put(new ItemStack(Items.GOLD_INGOT), 64);
        rateDrops.put(new ItemStack(Items.EMERALD), 24);
        rateDrops.put(new ItemStack(Items.DIAMOND), 24);
        rateDrops.put(new ItemStack((ItemLike)TheTitansRegistries.HARCADIUM.get()), 8);

        for (Entry<ItemStack, Integer> entry : drops.entrySet()) {
            ItemStack itemStack = entry.getKey();
            int count = entry.getValue();
            EntityItemTitan itemTitan = new EntityItemTitan(
                this.level(),
                this.getX() + (double)(this.random.nextFloat() * 12.0F - 6.0F),
                this.getY() + 4.0,
                this.getZ() + (double)(this.random.nextFloat() * 12.0F - 6.0F),
                itemStack,
                count
            );
            itemTitan.setPickUpDelay(40);
            this.level().addFreshEntity(itemTitan);
        }

        for (Entry<ItemStack, Integer> entry : rateDrops.entrySet()) {
            ItemStack itemStack = entry.getKey();
            int count = entry.getValue();
            int randomCount = this.random.nextInt(count) + 1;
            EntityItemTitan itemTitan = new EntityItemTitan(
                this.level(),
                this.getX() + (double)(this.random.nextFloat() * 12.0F - 6.0F),
                this.getY() + 4.0,
                this.getZ() + (double)(this.random.nextFloat() * 12.0F - 6.0F),
                itemStack,
                randomCount
            );
            itemTitan.setPickUpDelay(40);
            this.level().addFreshEntity(itemTitan);
        }

        if (this.random.nextInt(5) == 0) {
            EntityItemTitan itemTitan = new EntityItemTitan(
                this.level(),
                this.getX() + (double)(this.random.nextFloat() * 12.0F - 6.0F),
                this.getY() + 4.0,
                this.getZ() + (double)(this.random.nextFloat() * 12.0F - 6.0F),
                new ItemStack(Blocks.BEDROCK),
                this.random.nextInt(2) + 1
            );
            itemTitan.setPickUpDelay(40);
            this.level().addFreshEntity(itemTitan);
        }
    }

    @Override
    protected void tickTitanDeath() {
        super.tickTitanDeath();
        if (this.deathTicks > 200) {
            this.setInvulTime(this.getInvulTime() + 10);
        }

        if (this.getInvulTime() >= this.getThreashHold()) {
            this.onDeath();
            if (!this.level().isClientSide() && !this.isRemoved()) {
                for (EntityTitanPart part : this.parts) {
                    part.remove(RemovalReason.KILLED);
                }

                this.removeTitan(RemovalReason.KILLED);
            }
        }
    }

    @Override
    public void tick() {
        super.tick();
        this.hasImpulse = true;
        this.setOnGround(false);
        if (this.tickCount > 5) {
            float f = this.yBodyRot * (float) Math.PI / 180.0F;
            float f1 = (float)this.tickCount * (float) Math.PI * 0.008F + 0.15F;

            for (int i = 0; i < 4; i++) {
                this.rods[i]
                    .moveTo(
                        this.getX() - (double)(Mth.cos(f1 + f) * 10.0F),
                        this.getY() - (double)(4.0F + Mth.cos((float)(i * 2 + this.tickCount) * 0.03F)),
                        this.getZ() - (double)(Mth.sin(f1 + f) * 10.0F)
                    );
                f1++;
            }

            f1 = (float) (Math.PI / 4) + (float)this.tickCount * (float) Math.PI * -0.005F - 1.4F;

            for (int i = 4; i < 8; i++) {
                this.rods[i]
                    .moveTo(
                        this.getX() - (double)(Mth.cos(f1 + f) * 7.0F),
                        this.getY() - (double)(10.0F + Mth.cos((float)(i * 3 + this.tickCount) * 0.05F)),
                        this.getZ() - (double)(Mth.sin(f1 + f) * 7.0F)
                    );
                f1++;
            }

            f1 = 0.47123894F + (float)this.tickCount * (float) Math.PI * 0.003F - 0.8F;

            for (int i = 8; i < 12; i++) {
                this.rods[i]
                    .moveTo(
                        this.getX() - (double)(Mth.cos(f1 + f) * 4.0F),
                        this.getY() - (double)(17.0F + Mth.cos(((float)i * 1.5F + (float)this.tickCount) * 0.02F)),
                        this.getZ() - (double)(Mth.sin(f1 + f) * 4.0F)
                    );
                f1++;
            }

            this.head.moveTo(this.getX(), this.getY(), this.getZ());

            for (int u = 0; u < this.getParticleCount(); u++) {
                for (int w = 0; w < this.rods.length; w++) {
                    this.level()
                        .addParticle(
                            this.getParticles(),
                            this.rods[w].getX() + (this.random.nextDouble() - 0.5) * (double)this.rods[w].getBbWidth(),
                            this.rods[w].getY() + this.random.nextDouble() * (double)this.rods[w].getBbHeight(),
                            this.rods[w].getZ() + (this.random.nextDouble() - 0.5) * (double)this.rods[w].getBbWidth(),
                            0.0,
                            0.0,
                            0.0
                        );
                }
            }

            for (EntityTitanPart part : this.parts) {
                if (this.isAlive()) {
                    this.collideWithEntities(part, this.level().getEntities(this, part.getBoundingBox().inflate(1.0, 0.0, 1.0)));
                }

                this.destroyBlocksInAABB(part.getBoundingBox());
            }
        }

        LivingEntity target = this.getTarget();
        if (target != null) {
            this.lookAt(target, 5.0F, 180.0F);
            this.getMoveControl().setWantedPosition(target.getX(), target.getY(), target.getZ(), 20.0);
            double hoverY = target.getY() + HOVER_HEIGHT;
            if (this.getY() < hoverY) {
                if (this.getDeltaMovement().y < 0.0) {
                    this.setTitanDeltaMovement(this.getDeltaMovement().x, 0.0, this.getDeltaMovement().z);
                }

                this.setTitanDeltaMovement(
                    this.getDeltaMovement().x, this.getDeltaMovement().y + (0.8 - this.getDeltaMovement().y) * 0.8, this.getDeltaMovement().z
                );
            } else if (this.getY() > target.getY() + MAX_HOVER_HEIGHT && this.getDeltaMovement().y > 0.0) {
                // 已经高过悬停上限：立刻取消上升，交给重力回落，避免一路往上飘
                this.setTitanDeltaMovement(this.getDeltaMovement().x, 0.0, this.getDeltaMovement().z);
            }
        } else if (!this.onGround() && this.getDeltaMovement().y < 0.0) {
            // 没有目标时保持缓慢下沉，但离地太高时恢复正常下落，避免长时间挂在空中
            int groundY = this.level()
                .getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, Mth.floor(this.getX()), Mth.floor(this.getZ()));
            if (this.getY() <= (double)groundY + 32.0) {
                this.setTitanDeltaMovement(this.getDeltaMovement().x, this.getDeltaMovement().y * 0.25, this.getDeltaMovement().z);
            }
        }
    }
}
