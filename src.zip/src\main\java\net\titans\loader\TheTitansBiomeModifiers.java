package net.titans.loader;

import com.mojang.serialization.Codec;
import java.util.function.Supplier;
import net.minecraftforge.common.world.BiomeModifier;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries.Keys;
import net.titans.biome.BiomeModifierAddSpawns;

public class TheTitansBiomeModifiers {
    public static final DeferredRegister<Codec<? extends BiomeModifier>> BIOME_MODIFIERS = DeferredRegister.create(Keys.BIOME_MODIFIER_SERIALIZERS, "titan");
    public static final Supplier<Codec<BiomeModifierAddSpawns>> ADD_SPAWNS_BIOME_MODIFIER = BIOME_MODIFIERS.register(
        "add_spawns", () -> BiomeModifierAddSpawns.CODEC
    );

    public static void registerBiomeModifiers(IEventBus modEventBus) {
        BIOME_MODIFIERS.register(modEventBus);
    }
}
