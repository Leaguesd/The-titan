package net.titans.event;

import java.util.regex.Matcher;
import java.util.regex.Pattern;
import net.minecraft.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.client.event.ViewportEvent.ComputeFogColor;
import net.minecraftforge.event.entity.player.ItemTooltipEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.titans.entity.titan.EntityWitherzilla;
import net.titans.item.ItemUltimaBlade;
import net.titans.loader.TheTitansDimensions;
import net.titans.util.ItemUtils;

public class TheTitansClientEvent {
    public static long lastTime = System.currentTimeMillis();
    private static final ChatFormatting[] rainbow = new ChatFormatting[]{
        ChatFormatting.DARK_PURPLE,
        ChatFormatting.LIGHT_PURPLE,
        ChatFormatting.WHITE,
        ChatFormatting.WHITE,
        ChatFormatting.WHITE,
        ChatFormatting.DARK_PURPLE,
        ChatFormatting.LIGHT_PURPLE
    };

    public static String ColorTransformationFormatting(String input, ChatFormatting[] colours, double delay, int step, int posstep) {
        StringBuilder stringBuilder = new StringBuilder(input.length() * 3);
        if (delay <= 0.0) {
            delay = 0.001;
        }

        int offset = Mth.floor((double)(System.currentTimeMillis() - lastTime) / delay) % colours.length;

        for (int i = 0; i < input.length(); i++) {
            char c = input.charAt(i);
            int colorIndex = (i * posstep + colours.length - offset) % colours.length;
            stringBuilder.append(colours[colorIndex].toString());
            stringBuilder.append(c);
        }

        return stringBuilder.toString();
    }

    public static Component makeRainbow(String text) {
        return Component.literal(ColorTransformationFormatting(text, rainbow, 90.0, 1, 1));
    }

    @SubscribeEvent
    public void onTooltip(ItemTooltipEvent event) {
        ItemStack itemStack = event.getItemStack();
        Item item = itemStack.getItem();
        if (ItemUtils.isAdminiumTool(item) || ItemUtils.isUltimateTool(item)) {
            for (int i = 0; i < event.getToolTip().size(); i++) {
                Component component = (Component)event.getToolTip().get(i);
                if (component.contains(Component.translatable("attribute.name.generic.attack_speed"))) {
                    event.getToolTip().remove(i);
                }
            }
        }

        if (ItemUtils.isUltimateTool(item)) {
            for (int ix = 0; ix < event.getToolTip().size(); ix++) {
                Component component = (Component)event.getToolTip().get(ix);
                if (component.contains(Component.translatable("attribute.name.generic.attack_damage"))) {
                    Pattern pattern = Pattern.compile("[^0-9]");
                    Matcher matcher = pattern.matcher(component.getString());
                    String attackDamage = item instanceof ItemUltimaBlade
                        ? Component.translatable("item.titan.ultima_blade.attack_damage").getString()
                        : Component.translatable("item.titan.optima_axe.attack_damage").getString();
                    String text = component.getString().replace(matcher.replaceAll(""), makeRainbow(attackDamage).getString() + ChatFormatting.DARK_GREEN);
                    event.getToolTip().set(ix, Component.literal(text));
                }
            }
        }
    }

    @SubscribeEvent
    public void onComputeFogColor(ComputeFogColor event) {
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer player = mc.player;
        if (player.level().dimension() == TheTitansDimensions.THE_VOID) {
            for (Entity entity : player.level().getEntities(player, player.getBoundingBox().inflate(1024.0, 1024.0, 1024.0))) {
                if (entity instanceof EntityWitherzilla) {
                    EntityWitherzilla witherzilla = (EntityWitherzilla)entity;
                    if (witherzilla.deathTicks <= 0) {
                        float red = Mth.cos((float)player.tickCount * 0.05F + (float) Math.PI);
                        float green = Mth.sin((float)player.tickCount * 0.05F + (float) (Math.PI * 2));
                        float blue = -Mth.cos((float)player.tickCount * 0.05F + (float) (Math.PI * 3));
                        event.setRed(red);
                        event.setGreen(green);
                        event.setBlue(blue);
                    } else {
                        event.setRed(1.0F);
                        event.setGreen(1.0F);
                        event.setBlue(1.0F);
                    }
                }
            }
        }
    }
}
