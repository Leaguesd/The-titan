package net.titans.entity.titan;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.Difficulty;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier.Builder;
import net.minecraft.world.entity.monster.MagmaCube;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.ItemLike;
import net.minecraft.world.level.Level;
import net.titans.entity.ai.EntityAINearestTargetTitan;
import net.titans.loader.TheTitansEntities;
import net.titans.loader.TheTitansRegistries;
import net.titans.loader.TheTitansPredicateTargets;

public class EntityMagmaCubeTitan extends EntitySlimeTitan {
    public EntityMagmaCubeTitan(EntityType<? extends EntityTitan> entityType, Level level) {
        super(entityType, level);
    }

    public EntityMagmaCubeTitan(Level level) {
        this((EntityType<? extends EntityTitan>)TheTitansEntities.MAGMACUBE_TITAN.get(), level);
    }

    public static Builder createAttributes() {
        return EntityTitan.createAttributes().add(Attributes.MAX_HEALTH, 4000.0).add(Attributes.ATTACK_DAMAGE, 500.0);
    }

    @Override
    public ResourceLocation getBossBarTexture() {
        return ResourceLocation.tryBuild("titan", "textures/gui/bossbar/magma_cube_titan.png");
    }

    @Override
    public int getBossBarNameColor() {
        return 16579584;
    }

    @Override
    public int getBossBarWidth() {
        return 193;
    }

    @Override
    public int getBossBarHeight() {
        return 19;
    }

    @Override
    public int getBossBarInterval() {
        return 2;
    }

    @Override
    public int getBossBarVOffset() {
        return 0;
    }

    @Override
    public int getBossBarVHeight() {
        return 0;
    }

    @Override
    public int getBossBarTextOffset() {
        return 7;
    }

    @Override
    protected void registerGoals() {
        super.registerGoals();
        this.targetSelector.removeAllGoals(goal -> true);
        this.targetSelector.addGoal(0, new EntityAINearestTargetTitan(this, EntitySnowGolemTitan.class, false));
        this.targetSelector.addGoal(0, new EntityAINearestTargetTitan(this, EntityIronGolemTitan.class, false));
        this.targetSelector
            .addGoal(0, new EntityAINearestTargetTitan<LivingEntity>(this, LivingEntity.class, 0, false, false, TheTitansPredicateTargets.MagmaCubeTitan));
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
    }

    @Override
    protected void dropExperienceOrb() {
        for (int x = 0; x < this.getSlimeSize(); x++) {
            EntityExperienceOrbTitan experienceOrbTitan = new EntityExperienceOrbTitan(
                this.level(),
                this.getX() + (double)(this.random.nextFloat() * 12.0F - 6.0F),
                this.getY() + 4.0,
                this.getZ() + (double)(this.random.nextFloat() * 12.0F - 6.0F),
                2000
            );
            experienceOrbTitan.push(0.0, 1.0, 0.0);
            this.level().addFreshEntity(experienceOrbTitan);
        }
    }

    @Override
    protected void dropAllItem() {
        Map<ItemStack, Integer> drops = new HashMap<>();
        Map<ItemStack, Integer> rateDrops = new HashMap<>();
        drops.put(new ItemStack(Items.MAGMA_CREAM), 64);
        drops.put(new ItemStack(Items.COAL), 16);
        rateDrops.put(new ItemStack(Items.MAGMA_CREAM), 64);
        rateDrops.put(new ItemStack(Items.COAL), 16);
        rateDrops.put(new ItemStack(Items.EMERALD), 8);
        rateDrops.put(new ItemStack(Items.DIAMOND), 8);
        rateDrops.put(new ItemStack((ItemLike)TheTitansRegistries.HARCADIUM_WAFLET.get()), 4);

        for (Entry<ItemStack, Integer> entry : drops.entrySet()) {
            ItemStack itemStack = entry.getKey();
            int count = entry.getValue();
            EntityItemTitan itemTitan = new EntityItemTitan(
                this.level(),
                this.getX() + (double)(this.random.nextFloat() * 12.0F - 6.0F),
                this.getY() + 4.0,
                this.getZ() + (double)(this.random.nextFloat() * 12.0F - 6.0F),
                itemStack,
                count
            );
            itemTitan.setPickUpDelay(40);
            this.level().addFreshEntity(itemTitan);
        }

        for (Entry<ItemStack, Integer> entry : rateDrops.entrySet()) {
            ItemStack itemStack = entry.getKey();
            int count = entry.getValue();
            int randomCount = this.random.nextInt(count) + 1;
            EntityItemTitan itemTitan = new EntityItemTitan(
                this.level(),
                this.getX() + (double)(this.random.nextFloat() * 12.0F - 6.0F),
                this.getY() + 4.0,
                this.getZ() + (double)(this.random.nextFloat() * 12.0F - 6.0F),
                itemStack,
                randomCount
            );
            itemTitan.setPickUpDelay(40);
            this.level().addFreshEntity(itemTitan);
        }
    }

    @Override
    protected void refreshAttributes() {
        if (this.level().getDifficulty() == Difficulty.HARD) {
            this.getAttribute(Attributes.MAX_HEALTH).setBaseValue((double)this.getSlimeSize() * 2000.0 + (double)this.getExtraPower() * 200.0);
            this.getAttribute(Attributes.ATTACK_DAMAGE).setBaseValue(500.0 + (double)this.getExtraPower() * 18.0);
        } else {
            this.getAttribute(Attributes.MAX_HEALTH).setBaseValue((double)this.getSlimeSize() * 1000.0 + (double)this.getExtraPower() * 100.0);
            this.getAttribute(Attributes.ATTACK_DAMAGE).setBaseValue(250.0 + (double)this.getExtraPower() * 9.0);
        }
    }

    @Override
    public boolean canAttackEntity(Entity entity) {
        return super.canAttackEntity(entity) && !(entity instanceof EntityMagmaCubeTitan) && !(entity instanceof MagmaCube);
    }

    @Override
    public int getJumpDelay() {
        return super.getJumpDelay() * 4;
    }

    public float getLightLevelDependentMagicValue() {
        return 1.0F;
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource damageSource) {
        return SoundEvents.MAGMA_CUBE_HURT;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.MAGMA_CUBE_DEATH;
    }

    @Override
    protected SoundEvent getSquishSound() {
        return SoundEvents.MAGMA_CUBE_SQUISH;
    }

    @Override
    public SoundEvent getJumpSound() {
        return SoundEvents.MAGMA_CUBE_JUMP;
    }

    @Override
    public boolean hurt(DamageSource damageSource, float amount) {
        if (!damageSource.is(DamageTypes.IN_FIRE) && !damageSource.is(DamageTypes.ON_FIRE)) {
            return super.hurt(damageSource, amount);
        } else {
            this.heal(amount);
            return false;
        }
    }

    @Override
    public void jumpFromGround() {
        this.setTitanDeltaMovement(this.getDeltaMovement().x, 4.0 + (double)((float)this.getSlimeSize() * 0.33F), this.getDeltaMovement().z);
        this.hasImpulse = true;
        if (this.getTarget() != null) {
            double d0 = this.getTarget().getX() - this.getX();
            double d1 = this.getTarget().getZ() - this.getZ();
            double d2 = Math.sqrt(d0 * d0 + d1 * d1);
            double hor = 1.0 + (double)this.getSlimeSize() * 0.25;
            this.setTitanDeltaMovement(
                d0 / d2 * hor * hor + this.getDeltaMovement().x * hor, this.getDeltaMovement().y, d1 / d2 * hor * hor + this.getDeltaMovement().z * hor
            );
        }
    }
}
