package net.titans.entity.ai.creepertitan;

import net.titans.animation.AIAnimation;
import net.titans.entity.titan.EntityCreeperTitan;

public class AnimationCreeperTitanCreation extends AIAnimation {
    private EntityCreeperTitan entity;

    public AnimationCreeperTitanCreation(EntityCreeperTitan entity) {
        super(entity);
        this.entity = entity;
    }

    @Override
    public int getAnimationID() {
        return 13;
    }

    @Override
    public boolean isAutomatic() {
        return true;
    }

    @Override
    public int getDuration() {
        return 480;
    }

    @Override
    public boolean canContinueToUse() {
        return this.entity.getAnimationTick() > this.getDuration() ? false : super.canContinueToUse();
    }
}
