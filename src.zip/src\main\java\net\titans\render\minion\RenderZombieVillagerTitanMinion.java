package net.titans.render.minion;

import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.model.ZombieVillagerModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.HumanoidMobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider.Context;
import net.minecraft.client.renderer.entity.layers.HumanoidArmorLayer;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.titans.entity.minion.EntityZombieTitanMinion;

@OnlyIn(Dist.CLIENT)
public class RenderZombieVillagerTitanMinion extends HumanoidMobRenderer<EntityZombieTitanMinion, ZombieVillagerModel<EntityZombieTitanMinion>> {
    public static final ResourceLocation ZOMBIE_VILLAGER = new ResourceLocation("minecraft", "textures/entity/zombie_villager/zombie_villager.png");
    public static final ResourceLocation ZOMBIE_VILLAGER_PRIEST = ResourceLocation.tryBuild(
        "titan", "textures/entity/minions/zombie/zombie_villager_priest.png"
    );
    public static final ResourceLocation ZOMBIE_VILLAGER_ZEALOT = ResourceLocation.tryBuild(
        "titan", "textures/entity/minions/zombie/zombie_villager_zealot.png"
    );
    public static final ResourceLocation ZOMBIE_VILLAGER_BISHOP = ResourceLocation.tryBuild(
        "titan", "textures/entity/minions/zombie/zombie_villager_bishop.png"
    );
    public static final ResourceLocation ZOMBIE_VILLAGER_TEMPLAR = ResourceLocation.tryBuild(
        "titan", "textures/entity/minions/zombie/zombie_villager_templar.png"
    );

    public RenderZombieVillagerTitanMinion(Context context) {
        super(context, new ZombieVillagerModel(context.bakeLayer(ModelLayers.ZOMBIE_VILLAGER)), 0.5F);
        this.addLayer(
            new HumanoidArmorLayer(
                this,
                new ZombieVillagerModel(context.bakeLayer(ModelLayers.ZOMBIE_VILLAGER_INNER_ARMOR)),
                new ZombieVillagerModel(context.bakeLayer(ModelLayers.ZOMBIE_VILLAGER_OUTER_ARMOR)),
                context.getModelManager()
            )
        );
    }

    public void render(
        EntityZombieTitanMinion entity, float entityYaw, float partialTicks, PoseStack poseStack, MultiBufferSource multiBufferSource, int packedLight
    ) {
        super.render(entity, entityYaw, partialTicks, poseStack, multiBufferSource, packedLight);
    }

    public ResourceLocation getTextureLocation(EntityZombieTitanMinion entity) {
        switch (entity.getMinionType()) {
            case PRIEST:
                return ZOMBIE_VILLAGER_PRIEST;
            case ZEALOT:
                return ZOMBIE_VILLAGER_ZEALOT;
            case BISHOP:
                return ZOMBIE_VILLAGER_BISHOP;
            case TEMPLAR:
                return ZOMBIE_VILLAGER_TEMPLAR;
            default:
                return ZOMBIE_VILLAGER;
        }
    }

    protected boolean isShaking(EntityZombieTitanMinion entity) {
        return super.isShaking(entity) || entity.isUnderWaterConverting();
    }
}
