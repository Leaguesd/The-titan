package net.titans.block;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.Direction.Axis;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.util.valueproviders.UniformInt;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.DropExperienceBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.BlockBehaviour.Properties;
import net.titans.loader.TheTitansSounds;

public class BlockHarcadiumOre extends DropExperienceBlock {
    public BlockHarcadiumOre(Properties properties) {
        super(properties, UniformInt.of(15, 50));
    }

    private static void spawnParticles(Level level, BlockPos pos) {
        double d0 = 0.5625;
        RandomSource randomSource = level.random;

        for (Direction direction : Direction.values()) {
            BlockPos blockPos = pos.relative(direction);
            if (!level.getBlockState(blockPos).isSolidRender(level, blockPos)) {
                Axis direction$axis = direction.getAxis();
                double d1 = direction$axis == Axis.X ? 0.5 + d0 * (double)direction.getStepX() : (double)randomSource.nextFloat();
                double d2 = direction$axis == Axis.Y ? 0.5 + d0 * (double)direction.getStepY() : (double)randomSource.nextFloat();
                double d3 = direction$axis == Axis.Z ? 0.5 + d0 * (double)direction.getStepZ() : (double)randomSource.nextFloat();
                level.addParticle(ParticleTypes.PORTAL, (double)pos.getX() + d1, (double)pos.getY() + d2, (double)pos.getZ() + d3, 0.0, 0.0, 0.0);
            }
        }
    }

    public void animateTick(BlockState state, Level level, BlockPos pos, RandomSource random) {
        if (random.nextInt(200) == 0) {
            level.playLocalSound(
                (double)((float)pos.getX() + 0.5F),
                (double)((float)pos.getY() + 0.5F),
                (double)((float)pos.getZ() + 0.5F),
                (SoundEvent)TheTitansSounds.HARCACADIUM_BLOCK_HUM.get(),
                SoundSource.BLOCKS,
                1.0F,
                1.0F,
                false
            );
        }

        spawnParticles(level, pos);
    }
}
