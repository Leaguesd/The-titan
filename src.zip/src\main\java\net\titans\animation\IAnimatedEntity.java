package net.titans.animation;

public interface IAnimatedEntity {
    int getAnimationID();

    void setAnimationID(int var1);

    int getAnimationTick();

    void setAnimationTick(int var1);
}
