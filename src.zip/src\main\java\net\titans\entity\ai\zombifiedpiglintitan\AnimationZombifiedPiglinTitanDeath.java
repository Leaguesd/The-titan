package net.titans.entity.ai.zombifiedpiglintitan;

import net.titans.animation.AIAnimation;
import net.titans.entity.titan.EntityZombifiedPiglinTitan;

public class AnimationZombifiedPiglinTitanDeath extends AIAnimation {
    private EntityZombifiedPiglinTitan entity;

    public AnimationZombifiedPiglinTitanDeath(EntityZombifiedPiglinTitan entity) {
        super(entity);
        this.entity = entity;
    }

    @Override
    public int getAnimationID() {
        return 10;
    }

    @Override
    public boolean isAutomatic() {
        return true;
    }

    @Override
    public int getDuration() {
        return 2000;
    }

    @Override
    public boolean canUse() {
        return this.entity.deathTicks > 0 && !this.entity.isAlive() ? super.canUse() : false;
    }

    @Override
    public boolean canContinueToUse() {
        return this.entity.deathTicks > 0 && !this.entity.isAlive() ? super.canContinueToUse() : false;
    }
}
