package net.titans.render;

import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.LivingEntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider.Context;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.titans.entity.titan.EntityBlazeTitan;
import net.titans.model.ModelBlazeTitan;
import net.titans.render.layer.LayerBlazeTitanArmor;

@OnlyIn(Dist.CLIENT)
public class RenderBlazeTitan extends LivingEntityRenderer<EntityBlazeTitan, ModelBlazeTitan> {
    public static final ResourceLocation BLAZE_TITAN = new ResourceLocation("minecraft", "textures/entity/blaze.png");

    public RenderBlazeTitan(Context context) {
        super(context, new ModelBlazeTitan(0.0F), 0.5F);
        this.addLayer(new LayerBlazeTitanArmor(this));
    }

    public void render(EntityBlazeTitan entity, float entityYaw, float partialTicks, PoseStack poseStack, MultiBufferSource multiBufferSource, int packedLight) {
        super.render(entity, entityYaw, partialTicks, poseStack, multiBufferSource, packedLight);
    }

    protected void scale(EntityBlazeTitan entity, PoseStack poseStack, float partialTick) {
        float f1 = 16.0F;
        int i = entity.getInvulTime();
        if (i > 0) {
            f1 -= ((float)i - partialTick) / 440.0F * 7.75F;
        }

        if (i > 900) {
            poseStack.scale(1.0F, -1.0F, 1.0F);
        }

        int i2 = entity.getExtraPower();
        if (i2 > 0) {
            f1 += (float)i2 * 0.5F;
        }

        poseStack.scale(f1, f1, f1);
        poseStack.translate(0.0F, 1.26F, 0.0F);
    }

    protected float getShadowRadius(EntityBlazeTitan entity) {
        return this.shadowRadius * entity.getBbWidth();
    }

    protected boolean shouldShowName(EntityBlazeTitan entity) {
        return false;
    }

    public ResourceLocation getTextureLocation(EntityBlazeTitan entity) {
        return BLAZE_TITAN;
    }
}
