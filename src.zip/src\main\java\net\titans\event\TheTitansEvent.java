package net.titans.event;

import com.google.common.collect.ImmutableList;
import com.google.common.collect.UnmodifiableIterator;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.TagKey;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.event.entity.EntityJoinLevelEvent;
import net.minecraftforge.event.entity.living.LivingDamageEvent;
import net.minecraftforge.event.entity.living.LivingEvent.LivingTickEvent;
import net.minecraftforge.event.entity.player.PlayerInteractEvent.LeftClickBlock;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.titans.damage.DamageSourceTitanAttack;
import net.titans.entity.EntityColorLightningBolt;
import net.titans.entity.titan.EntityEnderColossus;
import net.titans.entity.titan.EntityTitan;
import net.titans.loader.TheTitansItemTags;
import net.titans.loader.TheTitansRegistries;
import net.titans.loader.TheTitansTriggers;
import net.titans.util.ItemUtils;

public class TheTitansEvent {
    @SubscribeEvent
    public void onEntityJoinWorld(EntityJoinLevelEvent event) {
        if (event.getEntity() instanceof ItemEntity itemEntity) {
            ItemStack itemStack = itemEntity.getItem();
            List<TagKey<Item>> tags = itemStack.getTags().toList();
            if (tags.contains(TheTitansItemTags.IMMORTAL)) {
                itemEntity.setInvulnerable(true);
            }
        }
    }

    @SubscribeEvent
    public void onLivingTick(LivingTickEvent event) {
        Level level = event.getEntity().level();
        if (event.getEntity() instanceof Player) {
            Player player = (Player)event.getEntity();
            if (player instanceof ServerPlayer serverPlayer) {
                TheTitansTriggers.ROOT.trigger(serverPlayer);
            }

            if (ItemUtils.hasItem(player.getInventory(), (Item)TheTitansRegistries.ULTIMA_BLADE.get())
                && ItemUtils.hasItem(player.getInventory(), (Item)TheTitansRegistries.OPTIMA_AXE.get())) {
                boolean flag = true;
                if (!player.level().isClientSide()) {
                    ServerLevel serverLevel = (ServerLevel)player.level();
                    ImmutableList<Entity> entities = ImmutableList.copyOf(serverLevel.getAllEntities());
                    UnmodifiableIterator var7 = entities.iterator();

                    while (var7.hasNext()) {
                        Entity entity = (Entity)var7.next();
                        if (entity != null && entity.isAlive() && entity instanceof EntityEnderColossus) {
                            flag = false;
                        }
                    }

                    if (flag) {
                        serverLevel.setWeatherParameters(0, ServerLevel.THUNDER_DURATION.sample(serverLevel.getRandom()), true, true);
                    }

                    if (level.random.nextInt(60) == 0) {
                        var7 = entities.iterator();

                        while (var7.hasNext()) {
                            Entity entity = (Entity)var7.next();
                            if (entity != null && entity != player && entity.isAlive() && entity instanceof LivingEntity) {
                                EntityColorLightningBolt colorLightningBolt = new EntityColorLightningBolt(
                                    level, level.getRandom().nextFloat(), level.getRandom().nextFloat(), level.getRandom().nextFloat()
                                );
                                colorLightningBolt.setPos(entity.getX(), entity.getY() + (double)entity.getBbHeight(), entity.getZ());
                                level.addFreshEntity(colorLightningBolt);
                            }
                        }
                    }
                }
            }
        }
    }

    @SubscribeEvent
    public void onLivingHurt(LivingDamageEvent event) {
        DamageSource damageSource = event.getSource();
        if (damageSource.getEntity() instanceof Player player) {
            ItemStack itemStack = player.getMainHandItem();
            if (!itemStack.isEmpty()) {
                int a = 0;
                if (a > 0) {
                    event.getEntity().setOnGround(false);
                    event.getEntity().push(0.0, 1.0 * (double)a, 0.0);
                }

                int b = 0;
                if (b > 0 && !(damageSource instanceof DamageSourceTitanAttack) && event.getEntity() instanceof EntityTitan) {
                    EntityTitan titan = (EntityTitan)event.getEntity();
                    titan.hurt(new DamageSourceTitanAttack(player), (float)b * 100.0F);
                }
            }
        }
    }

    @SubscribeEvent
    public void onPlayerLeftClick(LeftClickBlock event) {
        Level level = event.getLevel();
        Player player = event.getEntity();
        BlockPos blockPos = event.getPos();
        BlockState blockState = level.getBlockState(blockPos);
        Block block = blockState.getBlock();
        InteractionHand hand = event.getHand();
        ItemStack itemStack = event.getItemStack();
        Item item = itemStack.getItem();
        if (ItemUtils.isAdminiumTool(item)) {
            if (!level.isClientSide() && !player.isCreative()) {
                List<ItemStack> drops = new ArrayList<>();
                List<ItemStack> blockDrops = Block.getDrops(blockState, (ServerLevel)level, blockPos, null);
                if (!blockDrops.isEmpty()) {
                    drops.addAll(blockDrops);
                } else {
                    drops.add(new ItemStack(block));
                }

                level.destroyBlock(blockPos, false);
                if (!drops.isEmpty()) {
                    for (ItemStack stack : drops) {
                        ItemEntity itemEntity = new ItemEntity(
                            level, (double)blockPos.getX(), (double)blockPos.getY(), (double)blockPos.getZ(), stack
                        );
                        itemEntity.setDefaultPickUpDelay();
                        level.addFreshEntity(itemEntity);
                    }
                }

                itemStack.hurtAndBreak(1, player, p -> {
                });
            }
        } else if (ItemUtils.isUltimateTool(item)) {
            itemStack.mineBlock(level, blockState, blockPos, player);
        }
    }
}
