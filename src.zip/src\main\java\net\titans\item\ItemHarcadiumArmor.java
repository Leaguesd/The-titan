package net.titans.item;

import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ArmorMaterial;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.ArmorItem.Type;
import net.minecraft.world.item.Item.Properties;
import net.minecraft.world.level.Level;
import net.titans.loader.TheTitansRegistries;

public class ItemHarcadiumArmor extends ArmorItem {
    public ItemHarcadiumArmor(ArmorMaterial material, Type type, Properties properties) {
        super(material, type, properties);
    }

    public void inventoryTick(ItemStack stack, Level level, Entity entity, int slotId, boolean isSelected) {
        super.inventoryTick(stack, level, entity, slotId, isSelected);
        if (entity instanceof Player player) {
            if (this.getEquipmentSlot() == EquipmentSlot.HEAD && slotId == 39) {
                player.removeEffect(MobEffects.BLINDNESS);
                player.addEffect(new MobEffectInstance(MobEffects.WATER_BREATHING, 300, 0));
                player.addEffect(new MobEffectInstance(MobEffects.NIGHT_VISION, 300, 0));
            } else if (this.getEquipmentSlot() == EquipmentSlot.CHEST && slotId == 38) {
                player.removeEffect(MobEffects.WEAKNESS);
                player.removeEffect(MobEffects.DIG_SLOWDOWN);
                player.addEffect(new MobEffectInstance(MobEffects.DIG_SPEED, 300, 3));
                player.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 300, 3));
                player.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST, 300, 9));
                player.addEffect(new MobEffectInstance(MobEffects.FIRE_RESISTANCE, 300, 0));
            } else if (this.getEquipmentSlot() == EquipmentSlot.LEGS && slotId == 37) {
                player.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 300, 10));
                player.removeEffect(MobEffects.CONFUSION);
                player.removeEffect(MobEffects.HUNGER);
                player.removeEffect(MobEffects.POISON);
            } else if (this.getEquipmentSlot() == EquipmentSlot.FEET && slotId == 36) {
                player.removeEffect(MobEffects.MOVEMENT_SLOWDOWN);
                player.addEffect(new MobEffectInstance(MobEffects.JUMP, 300, 3));
                player.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 300, 3));
            }

            if (player.getItemBySlot(EquipmentSlot.HEAD).getItem() == TheTitansRegistries.HARCADIUM_HELMET.get()
                && player.getItemBySlot(EquipmentSlot.CHEST).getItem() == TheTitansRegistries.HARCADIUM_CHESTPLATE.get()
                && player.getItemBySlot(EquipmentSlot.LEGS).getItem() == TheTitansRegistries.HARCADIUM_LEGGINGS.get()
                && player.getItemBySlot(EquipmentSlot.FEET).getItem() == TheTitansRegistries.HARCADIUM_BOOTS.get()) {
                player.getAttribute(Attributes.MAX_HEALTH).setBaseValue(2000.0);
                if (!level.isClientSide() && player.getHealth() < player.getMaxHealth()) {
                    player.heal(25.0F);
                }
            } else if (player.getAttribute(Attributes.MAX_HEALTH).getBaseValue() == 2000.0) {
                player.getAttribute(Attributes.MAX_HEALTH).setBaseValue(20.0);
                if (player.getHealth() > player.getMaxHealth()) {
                    player.setHealth(player.getMaxHealth());
                }
            }
        }
    }
}
