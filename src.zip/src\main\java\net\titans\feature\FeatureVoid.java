package net.titans.feature;

import com.mojang.serialization.Codec;
import net.minecraft.core.BlockPos;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.WorldGenLevel;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.levelgen.Heightmap.Types;
import net.minecraft.world.level.levelgen.feature.Feature;
import net.minecraft.world.level.levelgen.feature.FeaturePlaceContext;
import net.minecraft.world.level.levelgen.feature.configurations.NoneFeatureConfiguration;
import net.titans.entity.EntityWitherTurret;
import net.titans.entity.EntityWitherTurretGround;
import net.titans.entity.EntityWitherTurretMortar;

public class FeatureVoid extends Feature<NoneFeatureConfiguration> {
    public FeatureVoid(Codec<NoneFeatureConfiguration> codec) {
        super(codec);
    }

    public void generateTurret(WorldGenLevel level, RandomSource random, int x, int y, int z, int type) {
        int l = random.nextInt(2) + 4;
        int i1 = random.nextInt(1) + 1;
        if (type == 1) {
            l = 2;
            i1 = 2;
        } else if (type == 2) {
            l = 3;
            i1 = 3;
        }

        for (int j1 = x - i1; j1 <= x + i1; j1++) {
            for (int k1 = z - i1; k1 <= z + i1; k1++) {
                int l1 = j1 - x;
                int i2 = k1 - z;
                if (l1 * l1 + i2 * i2 <= i1 * i1 + 1 && level.getBlockState(new BlockPos(j1, y - 1, k1)).getBlock() != Blocks.BEDROCK) {
                    return;
                }
            }
        }

        for (int var14 = y; var14 < y + l && var14 < 256; var14++) {
            for (int k1x = x - i1; k1x <= x + i1; k1x++) {
                for (int l1 = z - i1; l1 <= z + i1; l1++) {
                    int i2 = k1x - x;
                    int j2 = l1 - z;
                    if (i2 * i2 + j2 * j2 <= i1 * i1 + 1) {
                        level.setBlock(new BlockPos(k1x, var14, l1), Blocks.BEDROCK.defaultBlockState(), 0, 2);
                    }
                }
            }
        }

        EntityWitherTurret witherTurret = new EntityWitherTurret(level.getLevel());
        if (type == 1) {
            witherTurret = new EntityWitherTurretGround(level.getLevel());
        } else if (type == 2) {
            witherTurret = new EntityWitherTurretMortar(level.getLevel());
        }

        witherTurret.setPos((double)((float)x + 0.5F), (double)(y + l), (double)((float)z + 0.5F));
        witherTurret.setYRot(random.nextFloat() * 360.0F);
        level.getLevel().addFreshEntity(witherTurret);
    }

    public boolean place(FeaturePlaceContext<NoneFeatureConfiguration> context) {
        WorldGenLevel worldGenLevel = context.level();
        RandomSource randomSource = context.random();
        BlockPos blockPos = context.origin();
        if (randomSource.nextInt(2) == 0) {
            int i = blockPos.getX() + randomSource.nextInt(16) + 8;
            int j = blockPos.getZ() + randomSource.nextInt(16) + 8;
            int k = worldGenLevel.getHeight(Types.WORLD_SURFACE, i, j);
            this.generateTurret(worldGenLevel, randomSource, i, k, j, 0);
        }

        if (randomSource.nextInt(2) == 0) {
            int i = blockPos.getX() + randomSource.nextInt(16) + 8;
            int j = blockPos.getZ() + randomSource.nextInt(16) + 8;
            int k = worldGenLevel.getHeight(Types.WORLD_SURFACE, i, j);
            this.generateTurret(worldGenLevel, randomSource, i, k, j, 1);
        }

        if (randomSource.nextInt(5) == 0) {
            int i = blockPos.getX() + randomSource.nextInt(16) + 8;
            int j = blockPos.getZ() + randomSource.nextInt(16) + 8;
            int k = worldGenLevel.getHeight(Types.WORLD_SURFACE, i, j);
            this.generateTurret(worldGenLevel, randomSource, i, k, j, 2);
        }

        return true;
    }
}
