package net.titans.loader;

import net.minecraft.world.entity.MobSpawnType;
import net.titans.entity.titan.EntityCreeperTitan;
import net.titans.entity.titan.EntitySkeletonTitan;
import net.titans.entity.titan.EntitySpiderTitan;
import net.titans.item.ItemTitanSpawnEgg;

public class TheTitansSpawns {
    public static final ItemTitanSpawnEgg.OnSpawned SPAWNED_CHARGED_CREEPER_TITAN = (level, entity) -> {
        if (entity instanceof EntityCreeperTitan creeperTitan) {
            creeperTitan.setCharged(true);
            creeperTitan.setTitanHealth(creeperTitan.getTitanMaxHealth());
        }
    };
    public static final ItemTitanSpawnEgg.OnSpawned SPAWNED_SPIDER_JOCKEY_TITAN = (level, entity) -> {
        if (entity instanceof EntitySpiderTitan spiderTitan) {
            EntitySkeletonTitan skeletonTitan = new EntitySkeletonTitan(level);
            skeletonTitan.setPos(spiderTitan.getX(), spiderTitan.getY(), spiderTitan.getZ());
            skeletonTitan.setXRot(spiderTitan.getXRot());
            skeletonTitan.setYRot(spiderTitan.getYRot());
            skeletonTitan.finalizeSpawn(level, level.getCurrentDifficultyAt(spiderTitan.blockPosition()), MobSpawnType.SPAWN_EGG, null, null);
            skeletonTitan.setTitanHealth(skeletonTitan.getTitanMaxHealth());
            level.addFreshEntity(skeletonTitan);
            skeletonTitan.startRiding(spiderTitan);
        }
    };
}
