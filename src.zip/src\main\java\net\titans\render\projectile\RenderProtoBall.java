package net.titans.render.projectile;

import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.ItemRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider.Context;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.client.renderer.texture.TextureAtlas;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.titans.entity.projectile.EntityProtoBall;

public class RenderProtoBall extends EntityRenderer<EntityProtoBall> {
    private final ItemRenderer itemRenderer;

    public RenderProtoBall(Context context) {
        super(context);
        this.itemRenderer = context.getItemRenderer();
    }

    public void render(EntityProtoBall entity, float entityYaw, float partialTicks, PoseStack poseStack, MultiBufferSource multiBufferSource, int packedLight) {
        poseStack.pushPose();
        poseStack.scale(3.0F, 3.0F, 3.0F);
        this.itemRenderer
            .renderStatic(
                new ItemStack(Items.FIRE_CHARGE),
                ItemDisplayContext.GROUND,
                packedLight,
                OverlayTexture.NO_OVERLAY,
                poseStack,
                multiBufferSource,
                entity.level(),
                entity.getId()
            );
        poseStack.popPose();
        super.render(entity, entityYaw, partialTicks, poseStack, multiBufferSource, packedLight);
    }

    public ResourceLocation getTextureLocation(EntityProtoBall entity) {
        return TextureAtlas.LOCATION_BLOCKS;
    }
}
