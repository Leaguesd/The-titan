package net.titans.render;

import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.LivingEntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider.Context;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.titans.entity.EntityWitherTurretMortar;
import net.titans.model.ModelWitherTurretMortar;

@OnlyIn(Dist.CLIENT)
public class RenderWitherTurretMortar extends LivingEntityRenderer<EntityWitherTurretMortar, ModelWitherTurretMortar> {
    public static final ResourceLocation WITHER = new ResourceLocation("minecraft", "textures/entity/wither/wither.png");

    public RenderWitherTurretMortar(Context context) {
        super(context, new ModelWitherTurretMortar(), 1.25F);
    }

    public void render(
        EntityWitherTurretMortar entity, float entityYaw, float partialTicks, PoseStack poseStack, MultiBufferSource multiBufferSource, int packedLight
    ) {
        super.render(entity, entityYaw, partialTicks, poseStack, multiBufferSource, packedLight);
    }

    protected void scale(EntityWitherTurretMortar entity, PoseStack poseStack, float partialTick) {
        poseStack.scale(2.5F, 2.5F, 2.5F);
    }

    protected boolean shouldShowName(EntityWitherTurretMortar entity) {
        return false;
    }

    public ResourceLocation getTextureLocation(EntityWitherTurretMortar entity) {
        return WITHER;
    }
}
