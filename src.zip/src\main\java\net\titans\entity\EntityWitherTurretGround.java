package net.titans.entity;

import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ExperienceOrb;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier.Builder;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.enchantment.Enchantments;
import net.minecraft.world.level.GameRules;
import net.minecraft.world.level.ItemLike;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.Level.ExplosionInteraction;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.titans.entity.projectile.EntityMortarWitherSkull;
import net.titans.entity.titan.EntityTitan;
import net.titans.loader.TheTitansEntities;
import net.titans.loader.TheTitansRegistries;
import net.titans.loader.TheTitansSounds;

public class EntityWitherTurretGround extends EntityWitherTurret {

    /** 一轮爆发可以打出的子弹数 */
    public int shots = 14;

    /** 对地炮塔允许锁定的最高目标高度（相对自身 Y） */
    private static final double MAX_TARGET_HEIGHT = 6.0;
    /** 索敌水平半径 */
    private static final double SEARCH_RADIUS = 32.0;
    /** 目标丢失距离平方（64 格） */
    private static final double MAX_TARGET_DISTANCE_SQR = 64.0 * 64.0;

    public EntityWitherTurretGround(EntityType<? extends EntityWitherTurret> entityType, Level level) {
        super(entityType, level);
    }

    public EntityWitherTurretGround(Level level) {
        this((EntityType<? extends EntityWitherTurret>)TheTitansEntities.WITHER_TURRET_GROUND.get(), level);
    }

    public static Builder createAttributes() {
        return EntityTitan.createAttributes()
            .add(Attributes.MAX_HEALTH, 4000.0)
            .add(Attributes.MOVEMENT_SPEED, 0.0)
            .add(Attributes.FOLLOW_RANGE, 32.0)
            .add(Attributes.KNOCKBACK_RESISTANCE, 1.0);
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        if (tag.contains("Shots", 3)) {
            this.shots = tag.getInt("Shots");
        }
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putInt("Shots", this.shots);
    }

    @Override
    protected ItemStack getItemStack() {
        // 注意：原实现里 7 个附魔全部写成了 UNBREAKING，属于复制粘贴错误。
        // 如需要正确还原，请改成 TheTitansRegistries 中对应的附魔（DURABILITY、FEROCITY 等）。
        ItemStack itemStack = new ItemStack((ItemLike)TheTitansRegistries.WITHER_TURRET_GROUND.get());
        if (this.durabilityLevel > 0) {
            itemStack.enchant(Enchantments.UNBREAKING, this.durabilityLevel);
        }
        if (this.ferocityLevel > 0) {
            itemStack.enchant(Enchantments.UNBREAKING, this.ferocityLevel);
        }
        if (this.maniacLevel > 0) {
            itemStack.enchant(Enchantments.UNBREAKING, this.maniacLevel);
        }
        if (this.unstabilityLevel > 0) {
            itemStack.enchant(Enchantments.UNBREAKING, this.unstabilityLevel);
        }
        if (this.shurakinLevel > 0) {
            itemStack.enchant(Enchantments.UNBREAKING, this.shurakinLevel);
        }
        if (this.unbreakingLevel > 0) {
            itemStack.enchant(Enchantments.UNBREAKING, this.unbreakingLevel);
        }
        if (this.titanKillerLevel > 0) {
            itemStack.enchant(Enchantments.UNBREAKING, this.titanKillerLevel);
        }
        return itemStack;
    }

    @Override
    protected void performRangedAttack(int head, double x, double y, double z, boolean isDangerous) {
        if (this.shootingTimer > 0) {
            return;
        }

        this.playSound((SoundEvent)TheTitansSounds.TURRET_SHOOT_2.get(), 6.0F, 1.0F);

        // 双管齐射：head 1、head 2
        for (int i = 1; i < 3; i++) {
            double d0 = this.getHeadX(i);
            double d1 = this.getHeadY(i);
            double d2 = this.getHeadZ(i);
            Vec3 dir = new Vec3(x - d0, y - d1, z - d2).normalize();

            EntityMortarWitherSkull witherSkull =
                new EntityMortarWitherSkull(this.level(), this, dir, (float)this.shurakinLevel * 0.1F);
            witherSkull.setPos(d0, d1, d2);
            if (isDangerous) {
                witherSkull.setDangerous(true);
            }
            witherSkull.setBullet(true);
            witherSkull.extraDamage = this.ferocityLevel * 2;
            witherSkull.explosivePower = (int)((float)this.unstabilityLevel * 0.75F);
            witherSkull.titanDamage = this.titanKillerLevel * 10;

            if (!this.level().isClientSide()) {
                this.level().addFreshEntity(witherSkull);
            }

            this.shots -= 2;

            // 射击时脚下短暂变为荧石
            BlockPos blockPos = this.blockPosition().below();
            if (this.level().getBlockState(blockPos).getBlock() != Blocks.GLOWSTONE) {
                this.level().setBlockAndUpdate(blockPos, Blocks.GLOWSTONE.defaultBlockState());
            }

            this.shootingTimer = this.shots > 0 ? 2 : 14 - this.maniacLevel * 4;
        }
    }

    @Override
    public void performRangedAttack(LivingEntity target, float velocity) {
        this.performRangedAttack(0, target);
    }
    @Override
    protected void tickDeath() {
        this.playSound((SoundEvent)TheTitansSounds.TURRET_DEATH_2.get(), 6.0F, 1.0F);
        if (!this.level().isClientSide()) {
            this.level().explode(this, this.getX(), this.getY() - 1.0, this.getZ(), 2.0F, true, ExplosionInteraction.MOB);
        }

        if (this.level().getGameRules().getBoolean(GameRules.RULE_DOMOBLOOT)) {
            ItemStack itemStack;
            if (this.isPlayerCreated()) {
                itemStack = this.getItemStack();
            } else {
                itemStack = new ItemStack(Items.WITHER_SKELETON_SKULL);
                itemStack.setCount(2);
            }

            if (!itemStack.isEmpty()) {
                ItemEntity itemEntity = new ItemEntity(this.level(), this.getX(), this.getY() + 3.0, this.getZ(), itemStack);
                itemEntity.setDefaultPickUpDelay();
                if (!this.level().isClientSide()) {
                    this.level().addFreshEntity(itemEntity);
                }
            }

            if (!this.level().isClientSide()) {
                ServerLevel serverLevel = (ServerLevel)this.level();
                ExperienceOrb.award(serverLevel, this.position(), 100);
            }
        }

        if (!this.level().isClientSide()) {
            this.discard();
        }
    }

    @Override
    public void aiStep() {
        this.originalAiStep();

        // 底座保护
        BlockPos blockPos = this.blockPosition().below();
        if (this.level().getBlockState(blockPos).getBlock() != Blocks.BEDROCK) {
            this.level().setBlockAndUpdate(blockPos, Blocks.BEDROCK.defaultBlockState());
        }

        LivingEntity currentTarget = this.getTarget();

        if (currentTarget == null) {
            this.scanForTarget();
        } else {
            this.getLookControl().setLookAt(currentTarget, 30.0F, 180.0F);
            this.performRangedAttack(currentTarget, 1.0F);

            boolean invalid =
                !currentTarget.isAlive()
                || currentTarget.isRemoved()
                || this.distanceToSqr(currentTarget) > MAX_TARGET_DISTANCE_SQR
                || !this.hasLineOfSight(currentTarget)
                || !this.canTargetEntity(currentTarget)
                || currentTarget.getY() > this.getY() + MAX_TARGET_HEIGHT; // 目标升到高处就丢失（与对地定位一致）

            if (invalid) {
                this.setTarget(null);
            }
        }
    }

    /**
     * 无目标时：旋转炮塔并在周围搜索一个可攻击的地面目标。
     * 搜索范围为以自身为中心、水平 ±32 格、垂直约 [自身Y-42, 自身Y+6.8] 的盒子。
     */
    private void scanForTarget() {
        this.setXRot(-5.0F); // 略微朝下，符合对地炮塔

        AABB searchBox = this.getBoundingBox()
            .inflate(SEARCH_RADIUS, 24.0, SEARCH_RADIUS)
            .move(0.0, -18.0, 0.0);

        LivingEntity best = null;
        double bestDist = Double.MAX_VALUE;

        for (Entity entity : this.level().getEntities(this, searchBox)) {
            if (!(entity instanceof LivingEntity living)) {
                continue;
            }
            if (!this.canTargetEntity(living)) {
                continue;
            }
            if (!this.hasLineOfSight(living)) {
                continue;
            }
            // 对地：目标不能高于自身 +MAX_TARGET_HEIGHT
            if (living.getY() > this.getY() + MAX_TARGET_HEIGHT) {
                continue;
            }
            if (living instanceof EntityTitan) {
                EntityTitan titan = (EntityTitan)living;
                if (titan.isInvulnerable()) {
                    continue;
                }
            }

            double dist = this.distanceToSqr(living);
            if (dist < bestDist) {
                bestDist = dist;
                best = living;
            }
        }

        if (best != null) {
            this.setTarget(best);
        }
    }

    @Override
    public void tick() {
        this.originalTick();
        this.setOnGround(true);
        this.hasImpulse = false;
        this.setYRot(this.yHeadRot);
        this.yBodyRot = this.yHeadRot;

        // 弹药耗尽后自动装填（与原逻辑一致）
        if (this.shots <= 0 && this.shootingTimer <= 10) {
            this.shots = 14;
        }

        if (this.shootingTimer > 0) {
            this.shootingTimer--;
        }

        for (int i = 0; i < 6; i++) {
            this.level().addParticle(
                ParticleTypes.SMOKE,
                this.getX() + this.random.nextGaussian() * 0.3F,
                this.getY() + (double)this.getEyeHeight() + this.random.nextGaussian() * 0.3F,
                this.getZ() + this.random.nextGaussian() * 0.3F,
                0.0, 0.0, 0.0
            );
        }

        if (this.tickCount % 20 == 0) {
            this.heal(1.0F + (float)this.durabilityLevel);
        }
    }
}