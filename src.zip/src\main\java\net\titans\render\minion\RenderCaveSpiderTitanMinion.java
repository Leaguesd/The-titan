package net.titans.render.minion;

import net.minecraft.client.renderer.entity.CaveSpiderRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider.Context;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.monster.CaveSpider;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.titans.entity.minion.IMinion;

@OnlyIn(Dist.CLIENT)
public class RenderCaveSpiderTitanMinion extends CaveSpiderRenderer {
    public static final ResourceLocation CAVE_SPIDER = new ResourceLocation("minecraft", "textures/entity/spider/cave_spider.png");
    public static final ResourceLocation CAVE_SPIDER_PRIEST = ResourceLocation.tryBuild("titan", "textures/entity/minions/spider/cave_spider_priest.png");
    public static final ResourceLocation CAVE_SPIDER_ZEALOT = ResourceLocation.tryBuild("titan", "textures/entity/minions/spider/cave_spider_zealot.png");
    public static final ResourceLocation CAVE_SPIDER_BISHOP = ResourceLocation.tryBuild("titan", "textures/entity/minions/spider/cave_spider_bishop.png");
    public static final ResourceLocation CAVE_SPIDER_TEMPLAR = ResourceLocation.tryBuild("titan", "textures/entity/minions/spider/cave_spider_templar.png");

    public RenderCaveSpiderTitanMinion(Context context) {
        super(context);
    }

    public ResourceLocation getTextureLocation(CaveSpider entity) {
        if (entity instanceof IMinion minion) {
            switch (minion.getMinionType()) {
                case PRIEST:
                    return CAVE_SPIDER_PRIEST;
                case ZEALOT:
                    return CAVE_SPIDER_ZEALOT;
                case BISHOP:
                    return CAVE_SPIDER_BISHOP;
                case TEMPLAR:
                    return CAVE_SPIDER_TEMPLAR;
                default:
                    return CAVE_SPIDER;
            }
        } else {
            return super.getTextureLocation(entity);
        }
    }
}
