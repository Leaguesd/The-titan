package net.titans.loader;

import net.minecraft.core.registries.Registries;
import net.minecraft.world.effect.MobEffect;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.RegistryObject;
import net.titans.effect.MobEffectAdvancedWither;
import net.titans.effect.MobEffectDeath;
import net.titans.effect.MobEffectElectricJudgment;
import net.titans.effect.MobEffectRadiation;

public class TheTitansMobEffects {
    public static final DeferredRegister<MobEffect> MOBEFFECTS = DeferredRegister.create(Registries.MOB_EFFECT, "titan");
    public static final RegistryObject<MobEffect> RADIATION = MOBEFFECTS.register("radiation", () -> new MobEffectRadiation());
    public static final RegistryObject<MobEffect> ADVANCED_WITHER = MOBEFFECTS.register("advanced_wither", () -> new MobEffectAdvancedWither());
    public static final RegistryObject<MobEffect> ELECTRIC_JUDGMENT = MOBEFFECTS.register("electric_judgment", () -> new MobEffectElectricJudgment());
    public static final RegistryObject<MobEffect> DEATH = MOBEFFECTS.register("death", () -> new MobEffectDeath());

    public static void registerMobEffects(IEventBus modEventBus) {
        MOBEFFECTS.register(modEventBus);
    }
}
