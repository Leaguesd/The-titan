package net.titans.block;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.Direction.Axis;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.util.valueproviders.UniformInt;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.item.enchantment.Enchantments;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.Level.ExplosionInteraction;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.DropExperienceBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.BlockBehaviour.Properties;
import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;
import net.titans.loader.TheTitansSounds;

public class BlockVoidOre extends DropExperienceBlock {
    public BlockVoidOre(Properties properties) {
        super(properties, UniformInt.of(12000, 12000));
    }

    public boolean onDestroyedByPlayer(BlockState state, Level level, BlockPos pos, Player player, boolean willHarvest, FluidState fluid) {
        if (EnchantmentHelper.getItemEnchantmentLevel(Enchantments.SILK_TOUCH, player.getMainHandItem()) <= 0 && !level.isClientSide()) {
            level.explode(null, (double)pos.getX(), (double)pos.getY(), (double)pos.getZ(), 1.0F, false, ExplosionInteraction.BLOCK);
        }

        return super.onDestroyedByPlayer(state, level, pos, player, willHarvest, fluid);
    }

    public VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        return Block.box(0.1F, 0.1F, 0.1F, 15.9F, 15.9F, 15.9F);
    }

    public void entityInside(BlockState state, Level level, BlockPos pos, Entity entity) {
        if (entity != null) {
            entity.hurt(entity.damageSources().fellOutOfWorld(), 4.0F);
            entity.setDeltaMovement(entity.getDeltaMovement().x * 0.2, entity.getDeltaMovement().y, entity.getDeltaMovement().z * 0.2);
            if (entity instanceof LivingEntity livingEntity) {
                if (livingEntity.level().random.nextInt(10) == 0) {
                    livingEntity.setRemainingFireTicks(40);
                }

                if (livingEntity.level().random.nextInt(60) == 0 && !level.isClientSide()) {
                    livingEntity.addEffect(new MobEffectInstance(MobEffects.WITHER, 160, 1));
                }
            }
        }
    }

    private static void spawnParticles(Level level, BlockPos pos) {
        double d0 = 0.5625;
        RandomSource randomSource = level.random;

        for (Direction direction : Direction.values()) {
            BlockPos blockPos = pos.relative(direction);
            if (!level.getBlockState(blockPos).isSolidRender(level, blockPos)) {
                Axis direction$axis = direction.getAxis();
                double d1 = direction$axis == Axis.X ? 0.5 + d0 * (double)direction.getStepX() : (double)randomSource.nextFloat();
                double d2 = direction$axis == Axis.Y ? 0.5 + d0 * (double)direction.getStepY() : (double)randomSource.nextFloat();
                double d3 = direction$axis == Axis.Z ? 0.5 + d0 * (double)direction.getStepZ() : (double)randomSource.nextFloat();
                level.addParticle(ParticleTypes.SMOKE, (double)pos.getX() + d1, (double)pos.getY() + d2, (double)pos.getZ() + d3, 0.0, 0.0, 0.0);
                level.addParticle(ParticleTypes.LARGE_SMOKE, (double)pos.getX() + d1, (double)pos.getY() + d2, (double)pos.getZ() + d3, 0.0, 0.0, 0.0);

                for (int i = 0; i < 4; i++) {
                    level.addParticle(
                        ParticleTypes.MYCELIUM, (double)pos.getX() + d1, (double)pos.getY() + d2, (double)pos.getZ() + d3, 0.0, 0.0, 0.0
                    );
                }
            }
        }
    }

    public void animateTick(BlockState state, Level level, BlockPos pos, RandomSource random) {
        if (random.nextInt(20) == 0) {
            level.playLocalSound(
                (double)((float)pos.getX() + 0.5F),
                (double)((float)pos.getY() + 0.5F),
                (double)((float)pos.getZ() + 0.5F),
                (SoundEvent)TheTitansSounds.HARCACADIUM_BLOCK_HUM.get(),
                SoundSource.BLOCKS,
                1.0F,
                1.0F,
                false
            );
        }

        spawnParticles(level, pos);
    }
}
