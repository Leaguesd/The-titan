package net.titans.render;

import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.LivingEntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider.Context;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.titans.entity.titan.EntityCreeperTitan;
import net.titans.model.ModelCreeperTitan;
import net.titans.render.layer.LayerCreeperTitanArmor;

@OnlyIn(Dist.CLIENT)
public class RenderCreeperTitan extends LivingEntityRenderer<EntityCreeperTitan, ModelCreeperTitan> {
    public static final ResourceLocation CREEPER_TITAN = ResourceLocation.tryBuild("titan", "textures/entity/titans/creeper_titan.png");

    public RenderCreeperTitan(Context context) {
        super(context, new ModelCreeperTitan(0.0F), 0.75F);
        this.addLayer(new LayerCreeperTitanArmor(this));
    }

    public void render(
        EntityCreeperTitan entity, float entityYaw, float partialTicks, PoseStack poseStack, MultiBufferSource multiBufferSource, int packedLight
    ) {
        super.render(entity, entityYaw, partialTicks, poseStack, multiBufferSource, packedLight);
    }

    protected void scale(EntityCreeperTitan entity, PoseStack poseStack, float partialTick) {
        float f1 = 16.0F;
        int i = entity.getInvulTime();
        if (i > 0) {
            f1 -= ((float)i - partialTick) / 440.0F * 7.75F;
        }

        int i2 = entity.getExtraPower();
        if (i2 > 0) {
            f1 += (float)i2 * 0.5F;
        }

        poseStack.scale(f1, f1, f1);
        poseStack.translate(0.0F, 0.01F, 0.0F);
    }

    protected float getShadowRadius(EntityCreeperTitan entity) {
        return this.shadowRadius * entity.getBbWidth();
    }

    protected boolean shouldShowName(EntityCreeperTitan entity) {
        return false;
    }

    public ResourceLocation getTextureLocation(EntityCreeperTitan entity) {
        return CREEPER_TITAN;
    }
}
