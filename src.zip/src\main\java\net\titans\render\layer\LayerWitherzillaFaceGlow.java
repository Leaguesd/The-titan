package net.titans.render.layer;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.titans.entity.titan.EntityWitherzilla;
import net.titans.model.ModelWitherzilla;

/**
 * 凋零斯拉的发光五官层（眼睛 + 嘴巴）。
 *
 * <p>凋零斯拉的模型没有独立的眼睛/嘴巴部件，它们只是画在 {@code witherzilla.png}
 * 头部正面的 UV 像素上。这里用一张只保留“白色眼睛高光 + 整块嘴巴”的
 * {@code witherzilla_face_glow.png}，以 {@link RenderType#eyes} + 全亮度再渲染一次
 * 三颗头，从而在不改动原贴图的情况下让五官在暗处也发亮；眼睛的灰阶瞳孔保持透明，
 * 不会被糊成白块。
 *
 * <p>普通形态和 Omega 形态共用同一套头部模型/UV，所以这个层对两种形态都生效。
 */
@OnlyIn(Dist.CLIENT)
public class LayerWitherzillaFaceGlow extends RenderLayer<EntityWitherzilla, ModelWitherzilla> {
    private static final ResourceLocation GLOW = ResourceLocation.tryBuild("titan", "textures/entity/titans/witherzilla_face_glow.png");

    public LayerWitherzillaFaceGlow(RenderLayerParent<EntityWitherzilla, ModelWitherzilla> parent) {
        super(parent);
    }

    @Override
    public void render(
        PoseStack poseStack,
        MultiBufferSource multiBufferSource,
        int packedLight,
        EntityWitherzilla entity,
        float limbSwing,
        float limbSwingAmount,
        float partialTicks,
        float ageInTicks,
        float netHeadYaw,
        float headPitch
    ) {
        // eyes 渲染类型是 additive + 不写深度；只有遮罩里不透明的像素会产生光。
        VertexConsumer vertexConsumer = multiBufferSource.getBuffer(RenderType.eyes(GLOW));
        for (ModelPart head : this.getParentModel().heads) {
            head.render(poseStack, vertexConsumer, LightTexture.FULL_BRIGHT, OverlayTexture.NO_OVERLAY, 1.0F, 1.0F, 1.0F, 1.0F);
        }
    }
}
