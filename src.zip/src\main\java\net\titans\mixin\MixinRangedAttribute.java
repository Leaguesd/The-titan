package net.titans.mixin;

import net.minecraft.world.entity.ai.attributes.RangedAttribute;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({RangedAttribute.class})
public abstract class MixinRangedAttribute {
    @Accessor("minValue")
    @Mutable
    public abstract void setMinValue(double var1);

    @Accessor("maxValue")
    @Mutable
    public abstract void setMaxValue(double var1);

    @Inject(
        method = {"<init>"},
        at = {@At("TAIL")}
    )
    public void injected(CallbackInfo callbackInfo) {
        RangedAttribute attribute = (RangedAttribute)(Object)this;
        if ("attribute.name.generic.max_health".equals(attribute.getDescriptionId())) {
            this.setMaxValue(Double.MAX_VALUE);
        } else if ("attribute.name.generic.armor".equals(attribute.getDescriptionId())) {
            this.setMaxValue(Double.MAX_VALUE);
        }
    }
}
