package net.titans.render.layer;

import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.titans.entity.titan.EntityZombieTitan;
import net.titans.model.ModelZombieTitan;

@OnlyIn(Dist.CLIENT)
public class LayerZombieTitanItemInHand extends RenderLayer<EntityZombieTitan, ModelZombieTitan> {
    public LayerZombieTitanItemInHand(RenderLayerParent<EntityZombieTitan, ModelZombieTitan> renderer) {
        super(renderer);
    }

    public void render(
        PoseStack poseStack,
        MultiBufferSource multiBufferSource,
        int packedLight,
        EntityZombieTitan entity,
        float limbSwing,
        float limbSwingAmount,
        float partialTicks,
        float ageInTicks,
        float netHeadYaw,
        float headPitch
    ) {
        ModelZombieTitan model = (ModelZombieTitan)this.getParentModel();

        // 剑是直接画在 armed 贴图里的：贴图 1024×1024（64×64 逻辑纹素放大 16 倍），
        // ModelZombieTitan 里 heldItem 是 texOffs(32,32) 的 0×16×16 平面，
        // 它的侧面 UV 落在 (32,48)-(48,64)，那 16×16 的格子里画的正是铁剑，
        // 而未持剑的贴图同一区域完全透明。所以只要按状态切换这个平面即可。
        //
        // （原实现是把它隐藏后用 RenderUtils.bakeItem 画四边形，但那个方法在原始 jar
        //   里就是空实现，结果两种状态都没有剑。）
        model.heldItem.visible = entity.isArmed();
    }
}
