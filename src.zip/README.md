# 泰坦生物 (titan) —— 1.20.1 Forge 模组源码还原工程

本工程由工作区中的 `泰坦生物.jar` 反向还原而来，目标是把已编译的模组恢复成可阅读、可继续开发、可重新构建的 Gradle 项目。

## 源码来源与还原方式

| 步骤 | 使用的工具 | 说明 |
| --- | --- | --- |
| 1. 反编译 | Vineflower 1.10.1 | 对 `泰坦生物.jar` 中 432 个 `.class` 做反编译，产出 378 个 `.java` 文件（内部类合并回外部类） |
| 2. 去混淆 | `srg-mcp-1.20.1.txt` (TSRG2) | 原 jar 是 Forge 生产环境构建，方法/字段名是 SRG 形式（`m_12345_` / `f_12345_`）。用该映射把 **31,176 处** SRG 名换回官方名（如 `m_135353_` → `defineId`），**未映射残留 0 处** |
| 3. 组装工程 | `1.20.1-mdk开发包.zip` | 以官方 Forge 1.20.1 MDK 为骨架，改写 `build.gradle` / `gradle.properties` 适配本模组 |
| 4. 资源提取 | 直接解包 jar | `assets/`（777 个文件）、`data/`（331 个文件）、`pack.mcmeta`、Mixin 配置按原样放回 `src/main/resources` |

## 目录结构

```
泰坦生物源码/
├── build.gradle                  # ForgeGradle 6 构建脚本（已配好 AT 与 MixinConfigs 清单属性）
├── gradle.properties             # mod_id=titan，Forge 47.4.23，official 1.20.1 映射
├── settings.gradle
├── gradlew / gradlew.bat / gradle/wrapper
└── src/main/
    ├── java/net/titans/          # 378 个还原的 Java 源文件
    │   ├── theTitans.java        # 模组主类 @Mod("titan")
    │   ├── loader/               # 注册中心（实体、物品、方块、音效、维度、特性…）
    │   ├── entity/titan|minion|projectile/  # 泰坦、仆从、弹射物
    │   ├── entity/ai/            # 各泰坦的 AI 与动画状态
    │   ├── model/ render/        # 实体模型与渲染器
    │   ├── animation/            # 自研关键帧动画框架
    │   ├── mixin/                # 12 个 Mixin
    │   └── block/ item/ effect/ gen/ feature/ ...
    └── resources/
        ├── META-INF/mods.toml            # 原样保留（modId=titan，displayName=泰坦生物）
        ├── META-INF/accesstransformer.cfg
        ├── META-INF/enumextensions.json
        ├── titan.mixins.json / titan.refmap.json
        ├── pack.mcmeta
        ├── assets/titan/             # 模型、贴图、语言文件、音效
        └── data/                         # 战利品表、配方、标签、维度、世界生成
```

## 如何构建

### Termux / Linux / macOS（一条命令）

```bash
pkg install openjdk-17 unzip curl     # Termux 首次准备，已有 JDK 17 可跳过
unzip titan-src.zip && cd titan-src
sh gradlew build                      # 或者 ./gradlew build
```

### Windows

```powershell
$env:JAVA_HOME='C:\Users\shihu\AppData\Roaming\.minecraft\runtime\java-runtime-gamma-snapshot'
$env:PATH="$env:JAVA_HOME\bin;$env:PATH"
.\gradlew.bat build
```

## 反编译后处理与编译修复

Vineflower 在没有 Minecraft 类路径的情况下反编译，会在少数依赖泛型推断的地方产出无法编译的写法。以下 61 处编译错误已全部修复（均为等价改写，不改变运行语义）：

| 位置 | 问题 | 修复 |
| --- | --- | --- |
| `entity/ai/ghasttitan/EntityAIGhastTitanMoveControl`、`entity/ai/minion/ghast/…`（2 处） | 反编译器生成了 `import …MoveControl.Operation;`，而 `Operation` 是 `protected` 嵌套枚举，不能 import | 删除该 import，改用子类继承来的简单名 `Operation` |
| `mixin/MixinEntityType`、`MixinItemStack`、`MixinRangedAttribute`（3 处） | `(EntityType<?>)this` 之类的单层强转，Mixin 类并不是目标类型的真实子类 | 改为先转 `Object`：`(EntityType<?>)(Object)this` |
| `biome/BiomeModifierAddSpawns`（1 处） | 反编译器插入了裸类型 `(List)` / `(SpawnerData)` 强转，破坏了 Codec 的泛型推断，`forGetter` 无法绑定 | 去掉这些裸类型强转，让 `xmap` 正常推断出 `Codec<List<SpawnerData>>` |
| `loader/TheTitansEntityRenderers`（1 处） | `modEventBus.addListener(event -> …)` 的 `event` 被推断成 `Event`，匹配不到 `RegisterRenderers` 重载 | 显式标注 lambda 参数类型 `(RegisterRenderers event)` |
| `loader/TheTitansEntities`（54 处） | `Builder.of(EntityItemTitan::new, …)`：实体构造器参数是 `EntityType<? extends ItemEntity>` 这样的**通配符**，javac 无法从构造器引用反推 `T`，判定为 `Entity` 后构造器引用不兼容 | 显式给出类型实参：`Builder.<EntityItemTitan>of(EntityItemTitan::new, …)` |

> 其中第 5 类是数量最多的一类。这与源码本身无关——原始 jar 的字节码里构造器签名确实是 `EntityType<? extends ItemEntity>`（已用 `javap` 核对），只是 javac 在“泛型方法 `.build()` 作为接收者时按独立表达式定型”的规则下推不出 `T`，因此必须显式写类型实参。

