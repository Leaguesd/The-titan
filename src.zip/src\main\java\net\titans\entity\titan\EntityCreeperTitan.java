package net.titans.entity.titan;

import com.google.common.collect.ImmutableList;
import com.google.common.collect.UnmodifiableIterator;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import javax.annotation.Nullable;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.Difficulty;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.SpawnGroupData;
import net.minecraft.world.entity.Entity.RemovalReason;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier.Builder;
import net.minecraft.world.entity.item.PrimedTnt;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.ItemLike;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.ServerLevelAccessor;
import net.minecraft.world.level.Level.ExplosionInteraction;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;
import net.titans.entity.EntityColorLightningBolt;
import net.titans.entity.EntityWitherTurret;
import net.titans.entity.IBossBarDisplay;
import net.titans.entity.ai.EntityAINearestTargetTitan;
import net.titans.entity.ai.creepertitan.AnimationCreeperTitanAntiTitanAttack;
import net.titans.entity.ai.creepertitan.AnimationCreeperTitanAttack1;
import net.titans.entity.ai.creepertitan.AnimationCreeperTitanAttack2;
import net.titans.entity.ai.creepertitan.AnimationCreeperTitanAttack3;
import net.titans.entity.ai.creepertitan.AnimationCreeperTitanAttack4;
import net.titans.entity.ai.creepertitan.AnimationCreeperTitanCreation;
import net.titans.entity.ai.creepertitan.AnimationCreeperTitanDeath;
import net.titans.entity.ai.creepertitan.AnimationCreeperTitanSpit;
import net.titans.entity.ai.creepertitan.AnimationCreeperTitanStunned;
import net.titans.entity.ai.creepertitan.AnimationCreeperTitanThunderClap;
import net.titans.entity.ai.creepertitan.EntityAICreeperTitanSwell;
import net.titans.entity.minion.EntityCreeperTitanMinion;
import net.titans.entity.minion.EnumMinionType;
import net.titans.entity.projectile.EntityGunpowderTitan;
import net.titans.loader.TheTitansEntities;
import net.titans.loader.TheTitansRegistries;
import net.titans.loader.TheTitansMobEffects;
import net.titans.loader.TheTitansPredicateTargets;
import net.titans.loader.TheTitansSounds;
import net.titans.util.AnimationUtils;

public class EntityCreeperTitan extends EntityTitan implements IEntityMultiPartTitan, IBossBarDisplay {
    private static final EntityDataAccessor<Integer> STATE = SynchedEntityData.defineId(EntityCreeperTitan.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Boolean> CHARGED = SynchedEntityData.defineId(EntityCreeperTitan.class, EntityDataSerializers.BOOLEAN);
    public final EntityTitanPart head;
    public final EntityTitanPart body;
    public final EntityTitanPart leg1;
    public final EntityTitanPart leg2;
    public final EntityTitanPart leg3;
    public final EntityTitanPart leg4;
    public int damageToLegs;
    public boolean isStunned;
    private int timeSinceIgnited;
    private int fuseTime = 200;

    public EntityCreeperTitan(EntityType<? extends EntityTitan> entityType, Level level) {
        super(entityType, level);
        this.head = new EntityTitanPart(this, "head", 8.0F, 8.0F);
        this.body = new EntityTitanPart(this, "body", 7.0F, 12.0F);
        this.leg1 = new EntityTitanPart(this, "leg1", 4.5F, 8.0F);
        this.leg2 = new EntityTitanPart(this, "leg2", 4.5F, 8.0F);
        this.leg3 = new EntityTitanPart(this, "leg3", 4.5F, 8.0F);
        this.leg4 = new EntityTitanPart(this, "leg4", 4.5F, 8.0F);
        this.parts = new EntityTitanPart[]{this.head, this.body, this.leg1, this.leg2, this.leg3, this.leg4};
    }

    public EntityCreeperTitan(Level level) {
        this((EntityType<? extends EntityTitan>)TheTitansEntities.CREEPER_TITAN.get(), level);
    }

    public static Builder createAttributes() {
        return EntityTitan.createAttributes().add(Attributes.MAX_HEALTH, 50000.0).add(Attributes.ATTACK_DAMAGE, 1080.0);
    }

    @Override
    public ResourceLocation getBossBarTexture() {
        return this.getCharged()
            ? ResourceLocation.tryBuild("titan", "textures/gui/bossbar/charged_creeper_titan.png")
            : ResourceLocation.tryBuild("titan", "textures/gui/bossbar/creeper_titan.png");
    }

    @Override
    public int getBossBarNameColor() {
        if (this.getCharged()) {
            switch (this.random.nextInt(5)) {
                case 0:
                    return ChatFormatting.DARK_GREEN.getColor();
                case 1:
                    return ChatFormatting.DARK_RED.getColor();
                case 2:
                    return ChatFormatting.GOLD.getColor();
                case 3:
                    return ChatFormatting.GREEN.getColor();
                case 4:
                    return ChatFormatting.YELLOW.getColor();
            }
        }

        return 894731;
    }

    @Override
    public int getBossBarWidth() {
        return 215;
    }

    @Override
    public int getBossBarHeight() {
        return 33;
    }

    @Override
    public int getBossBarInterval() {
        return 5;
    }

    @Override
    public int getBossBarVOffset() {
        return 0;
    }

    @Override
    public int getBossBarVHeight() {
        return 0;
    }

    @Override
    public int getBossBarTextOffset() {
        return 16;
    }

    @Override
    protected void registerGoals() {
        super.registerGoals();
        this.goalSelector.addGoal(0, new EntityAICreeperTitanSwell(this));
        this.goalSelector.addGoal(1, new AnimationCreeperTitanCreation(this));
        this.goalSelector.addGoal(1, new AnimationCreeperTitanDeath(this));
        this.goalSelector.addGoal(1, new AnimationCreeperTitanAntiTitanAttack(this));
        this.goalSelector.addGoal(1, new AnimationCreeperTitanAttack1(this));
        this.goalSelector.addGoal(1, new AnimationCreeperTitanAttack2(this));
        this.goalSelector.addGoal(1, new AnimationCreeperTitanAttack3(this));
        this.goalSelector.addGoal(1, new AnimationCreeperTitanAttack4(this));
        this.goalSelector.addGoal(1, new AnimationCreeperTitanSpit(this));
        this.goalSelector.addGoal(1, new AnimationCreeperTitanStunned(this));
        this.goalSelector.addGoal(1, new AnimationCreeperTitanThunderClap(this));
        this.targetSelector.addGoal(0, new EntityAINearestTargetTitan(this, EntitySnowGolemTitan.class, false));
        this.targetSelector.addGoal(0, new EntityAINearestTargetTitan(this, EntityIronGolemTitan.class, false));
        this.targetSelector
            .addGoal(0, new EntityAINearestTargetTitan<LivingEntity>(this, LivingEntity.class, 0, false, false, TheTitansPredicateTargets.CreeperTitan));
    }

    public int getCreeperState() {
        return (Integer)this.entityData.get(STATE);
    }

    public void setCreeperState(int creeperState) {
        this.entityData.set(STATE, creeperState);
    }

    public boolean getCharged() {
        return (Boolean)this.entityData.get(CHARGED);
    }

    public void setCharged(boolean charged) {
        this.entityData.set(CHARGED, charged);
        this.refreshTitanAttributes();
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(STATE, 0);
        this.entityData.define(CHARGED, false);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        this.setCreeperState(tag.getInt("CreeperState"));
        this.setCharged(tag.getBoolean("IsCharged"));
        this.damageToLegs = tag.getInt("DamageToLegs");
        this.isStunned = tag.getBoolean("IsStunned");
        this.fuseTime = tag.getInt("FuseTime");
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putInt("CreeperState", this.getCreeperState());
        tag.putBoolean("IsCharged", this.getCharged());
        tag.putInt("DamageToLegs", this.damageToLegs);
        tag.putBoolean("IsStunned", this.isStunned);
        tag.putInt("FuseTime", this.fuseTime);
    }

    public void doLightningAttackToEntity(LivingEntity entity) {
        float amount = (float)this.getAttributeBaseValue(Attributes.ATTACK_DAMAGE) / 3.0F;
        if (this.getCharged()) {
            this.level()
                .playLocalSound(
                    this.getX(),
                    this.getY(),
                    this.getZ(),
                    SoundEvents.LIGHTNING_BOLT_THUNDER,
                    SoundSource.WEATHER,
                    10000.0F,
                    0.8F + this.random.nextFloat() * 0.2F,
                    true
                );
            this.level()
                .playLocalSound(
                    this.getX(),
                    this.getY(),
                    this.getZ(),
                    SoundEvents.LIGHTNING_BOLT_THUNDER,
                    SoundSource.WEATHER,
                    10000.0F,
                    0.8F + this.random.nextFloat() * 0.2F,
                    true
                );
            if (!this.level().isClientSide()) {
                this.level()
                    .explode(this, entity.getX(), entity.getY() + (double)entity.getEyeHeight(), entity.getZ(), 8.0F, false, ExplosionInteraction.MOB);
                this.level().explode(this, this.getX(), this.head.getY() + 4.0, this.getZ(), 4.0F, false, ExplosionInteraction.MOB);
            }

            int knockbackAmount = this.getKnockbackAmount();
            if (entity != this) {
                entity.hurt(this.damageSources().lightningBolt(), 50.0F);
                this.attackEntity(entity, amount);
                this.knockbackEntity(entity, (float)knockbackAmount);
            }

            EntityColorLightningBolt colorLightningBolt1 = new EntityColorLightningBolt(this.level(), 0.0F, 0.5F, 1.0F);
            EntityColorLightningBolt colorLightningBolt2 = new EntityColorLightningBolt(this.level(), 0.0F, 0.5F, 1.0F);
            colorLightningBolt1.setPos(this.getX(), this.head.getY() + 4.0, this.getZ());
            colorLightningBolt2.setPos(entity.getX(), entity.getY(), entity.getZ());
            if (!this.level().isClientSide()) {
                this.level().addFreshEntity(colorLightningBolt1);
                this.level().addFreshEntity(colorLightningBolt2);
            }
        } else {
            if (!this.level().isClientSide()) {
                this.level()
                    .explode(this, entity.getX(), entity.getY() + (double)entity.getEyeHeight(), entity.getZ(), 4.0F, false, ExplosionInteraction.MOB);
                this.level().explode(this, this.getX(), this.head.getY() + 4.0, this.getZ(), 2.0F, false, ExplosionInteraction.MOB);
            }

            int knockbackAmountx = this.getKnockbackAmount();
            if (entity != this) {
                entity.hurt(this.damageSources().lightningBolt(), 50.0F);
                this.attackEntity(entity, amount);
                this.knockbackEntity(entity, (float)knockbackAmountx);
            }

            EntityColorLightningBolt colorLightningBolt1 = new EntityColorLightningBolt(this.level(), 0.0F, 0.5F, 0.25F);
            EntityColorLightningBolt colorLightningBolt2 = new EntityColorLightningBolt(this.level(), 0.0F, 0.5F, 0.25F);
            colorLightningBolt1.setPos(this.getX(), this.head.getY() + 4.0, this.getZ());
            colorLightningBolt2.setPos(entity.getX(), entity.getY(), entity.getZ());
            if (!this.level().isClientSide()) {
                this.level().addFreshEntity(colorLightningBolt1);
                this.level().addFreshEntity(colorLightningBolt2);
            }
        }
    }

    private void explode() {
        for (int i = 0; i < 1000; i++) {
            float f = (this.random.nextFloat() - 0.5F) * 16.0F;
            float f1 = (this.random.nextFloat() - 0.5F) * 48.0F;
            float f2 = (this.random.nextFloat() - 0.5F) * 16.0F;
            this.level()
                .addParticle(
                    ParticleTypes.EXPLOSION,
                    this.getX() + (double)f,
                    this.getY() + (double)f1,
                    this.getZ() + (double)f2,
                    this.random.nextDouble() - 0.5,
                    0.0,
                    this.random.nextDouble() - 0.5
                );
        }

        this.playSound((SoundEvent)TheTitansSounds.TITAN_CREEPER_EXPLOSION.get(), Float.MAX_VALUE, 1.0F);
        this.playSound((SoundEvent)TheTitansSounds.TITAN_LAND.get(), 10000.0F, 1.0F);
        this.playSound(this.getDeathSound(), this.getSoundVolume(), this.getVoicePitch());
        double d1 = (double)(this.getCharged() ? 256 : 128);
        double d2 = d1 * 8.0;
        this.destroyBlocksInAABBGriefingBypass(this.getBoundingBox().inflate(d1, d1, d1));

        for (Entity entity : this.level().getEntities(this, this.getBoundingBox().inflate(d1, d1, d1))) {
            if (entity != null && entity instanceof LivingEntity) {
                LivingEntity livingEntity = (LivingEntity)entity;
                if (livingEntity instanceof EntityCreeperTitan creeperTitan) {
                    creeperTitan.heal(this.getCharged() ? 10000.0F : 5000.0F);
                    creeperTitan.setCharged(true);
                } else {
                    this.attackEntity(livingEntity, this.getCharged() ? 10000.0F : 5000.0F);
                }
            }
        }

        for (Entity entityx : this.level().getEntities(this, this.getBoundingBox().inflate(d2, d2, d2))) {
            if (entityx != null && entityx instanceof LivingEntity livingEntity) {
                livingEntity.addEffect(new MobEffectInstance((MobEffect)TheTitansMobEffects.RADIATION.get(), 30000, 1));
            }
        }
    }

    @Override
    public SpawnGroupData finalizeSpawn(
        ServerLevelAccessor level, DifficultyInstance difficulty, MobSpawnType spawnType, @Nullable SpawnGroupData spawnGroupData, @Nullable CompoundTag tag
    ) {
        SpawnGroupData groupData = super.finalizeSpawn(level, difficulty, spawnType, spawnGroupData, null);
        this.setWaiting(true);
        return groupData;
    }

    public Component getName() {
        return this.getCharged() ? Component.translatable("entity.titan.charged_creeper_titan") : Component.translatable("entity.titan.creeper_titan");
    }

    @Override
    protected void refreshAttributes() {
        if (this.getCharged()) {
            if (this.level().getDifficulty() == Difficulty.HARD) {
                this.getAttribute(Attributes.MAX_HEALTH).setBaseValue(50000.0 + (double)this.getExtraPower() * 2500.0);
                this.getAttribute(Attributes.ATTACK_DAMAGE).setBaseValue(1620.0 + (double)this.getExtraPower() * 270.0);
            } else {
                this.getAttribute(Attributes.MAX_HEALTH).setBaseValue(25000.0 + (double)this.getExtraPower() * 1250.0);
                this.getAttribute(Attributes.ATTACK_DAMAGE).setBaseValue(540.0 + (double)this.getExtraPower() * 90.0);
            }
        } else if (this.level().getDifficulty() == Difficulty.HARD) {
            this.getAttribute(Attributes.MAX_HEALTH).setBaseValue(50000.0 + (double)this.getExtraPower() * 2500.0);
            this.getAttribute(Attributes.ATTACK_DAMAGE).setBaseValue(1080.0 + (double)this.getExtraPower() * 90.0);
        } else {
            this.getAttribute(Attributes.MAX_HEALTH).setBaseValue(25000.0 + (double)this.getExtraPower() * 1250.0);
            this.getAttribute(Attributes.ATTACK_DAMAGE).setBaseValue(541.0 + (double)this.getExtraPower() * 45.0);
        }
    }

    @Override
    public boolean canAttack() {
        return true;
    }

    @Override
    public boolean canAttackEntity(Entity entity) {
        return super.canAttackEntity(entity) && !(entity instanceof EntityCreeperTitanMinion);
    }

    @Override
    public boolean canBeHurtByPlayer() {
        return !this.isInvulnerable();
    }

    @Override
    public boolean shouldMove() {
        return this.getAnimationID() == 0 && !this.isStunned && this.getTarget() != null ? super.shouldMove() : false;
    }

    @Override
    public double getMeleeRange() {
        return (double)(
                this.getBbWidth() * this.getBbWidth() + (this.getTarget().getBbWidth() > 48.0F ? 2304.0F : this.getTarget().getBbWidth() * this.getTarget().getBbWidth())
            )
            + 600.0;
    }

    @Override
    public boolean canRegen() {
        return !this.isStunned;
    }

    @Override
    public int getMinionCap() {
        return 120;
    }

    @Override
    public int getPriestCap() {
        return 60;
    }

    @Override
    public int getZealotCap() {
        return 30;
    }

    @Override
    public int getBishopCap() {
        return 15;
    }

    @Override
    public int getTemplarCap() {
        return 8;
    }

    @Override
    public boolean canSpawnMinion() {
        boolean flag = this.getInvulTime() > 1 && this.tickCount % 20 == 0;
        float randomRate = this.random.nextFloat() * 100.0F;
        return flag || (double)randomRate < 5.0;
    }

    @Override
    public boolean canSpawnPriest() {
        boolean flag = this.getInvulTime() > 1 && this.tickCount % 20 == 0;
        float randomRate = this.random.nextFloat() * 100.0F;
        return flag || (double)randomRate < 2.5;
    }

    @Override
    public boolean canSpawnZealot() {
        boolean flag = this.getInvulTime() > 1 && this.tickCount % 20 == 0;
        float randomRate = this.random.nextFloat() * 100.0F;
        return flag || (double)randomRate < 1.25;
    }

    @Override
    public boolean canSpawnBishop() {
        boolean flag = this.getInvulTime() > 1 && this.tickCount % 20 == 0;
        float randomRate = this.random.nextFloat() * 100.0F;
        return flag || (double)randomRate < 0.625;
    }

    @Override
    public boolean canSpawnTemplar() {
        boolean flag = this.getInvulTime() > 1 && this.tickCount % 20 == 0;
        float randomRate = this.random.nextFloat() * 100.0F;
        return flag || (double)randomRate < 0.3125;
    }

    @Override
    public EnumTitanStatus getTitanStatus() {
        return EnumTitanStatus.AVERAGE;
    }

    @Override
    public int getThreashHold() {
        return this.fuseTime;
    }

    @Override
    public float getSpeed() {
        return this.getCharged() ? 0.35F + (float)this.getExtraPower() * 0.001F : 0.3F + (float)this.getExtraPower() * 0.001F;
    }

    protected SoundEvent getAmbientSound() {
        return !this.getWaiting() && this.getAnimationID() != 13 && !this.isStunned ? (SoundEvent)TheTitansSounds.TITAN_CREEPER_LIVING.get() : null;
    }

    protected SoundEvent getHurtSound(DamageSource damageSource) {
        return (SoundEvent)TheTitansSounds.TITAN_CREEPER_GRUNT.get();
    }

    protected SoundEvent getDeathSound() {
        return (SoundEvent)TheTitansSounds.TITAN_CREEPER_DEATH.get();
    }

    protected void playStepSound(BlockPos pos, BlockState state) {
        for (int i = 0; i < 2; i++) {
            this.shakeNearbyPlayerCameras(4000.0);
            this.playSound((SoundEvent)TheTitansSounds.TITAN_STEP.get(), 10.0F, 1.1F);
        }

        if (!this.getWaiting() && this.getAnimationID() != 13) {
            if (this.footID == 0) {
                this.destroyBlocksInAABB(this.leg1.getBoundingBox().move(0.0, -1.0, 0.0));
                this.destroyBlocksInAABB(this.leg3.getBoundingBox().move(0.0, -1.0, 0.0));
                this.footID++;
            } else {
                this.destroyBlocksInAABB(this.leg2.getBoundingBox().move(0.0, -1.0, 0.0));
                this.destroyBlocksInAABB(this.leg4.getBoundingBox().move(0.0, -1.0, 0.0));
                this.footID = 0;
            }
        }
    }

    public void thunderHit(ServerLevel level, LightningBolt lightningBolt) {
        float randomRate = this.random.nextFloat() * 100.0F;
        if ((double)randomRate < 0.1) {
            this.setCharged(true);
        }
    }

    @Override
    public boolean attackEntityFromPart(EntityTitanPart entityTitanPart, DamageSource damageSource, float amount) {
        if (damageSource != this.damageSources().lightningBolt()
            && !(damageSource.getEntity() instanceof EntityCreeperTitan)
            && (!damageSource.is(DamageTypes.EXPLOSION) || damageSource.getEntity() instanceof EntityWitherTurret)) {
            if (this.hurt(damageSource, amount)
                && damageSource.getEntity() != null
                && damageSource.getEntity() instanceof Player
                && this.damageToLegs < 8
                && !this.isStunned
                && (entityTitanPart == this.leg1 || entityTitanPart == this.leg2 || entityTitanPart == this.leg3 || entityTitanPart == this.leg4)) {
                this.damageToLegs++;
                this.hurt(damageSource, 100.0F);
                this.setTarget((LivingEntity)damageSource.getEntity());
                if (this.damageToLegs >= 8) {
                    this.playSound(this.getDeathSound(), this.getSoundVolume(), this.getVoicePitch());
                    this.isStunned = true;
                    this.damageToLegs = 0;
                }
            }

            return true;
        } else {
            this.heal(amount);
            return false;
        }
    }

    @Override
    public boolean causeFallDamage(float fallDistance, float multiplier, DamageSource damageSource) {
        this.setOnGround(true);
        this.hasImpulse = false;
        if (fallDistance <= 0.0F) {
            return false;
        } else {
            MobEffectInstance mobEffectInstance = this.getEffect(MobEffects.JUMP);
            float f1 = mobEffectInstance != null ? (float)(mobEffectInstance.getAmplifier() + 1) : 0.0F;
            int i = Mth.ceil(fallDistance - 24.0F - f1);
            if (i > 0) {
                this.shakeNearbyPlayerCameras(400000.0);
                this.playSound((SoundEvent)TheTitansSounds.GROUND_SMASH.get(), 20.0F, 1.0F);
                this.playSound((SoundEvent)TheTitansSounds.TITAN_LAND.get(), 10000.0F, 1.0F);
                this.playSound((SoundEvent)TheTitansSounds.TITAN_STRIKE.get(), 10.0F, 1.0F);
                this.playSound((SoundEvent)TheTitansSounds.TITAN_SLAM.get(), 10.0F, 1.0F);
                this.collideWithEntities(this.body, this.level().getEntities(this, this.getBoundingBox().inflate(24.0, 4.0, 24.0)));
                this.destroyBlocksInAABBTopless(this.getBoundingBox().inflate(24.0, 1.0, 24.0));

                for (Entity entity : this.level().getEntities(this, this.getBoundingBox().inflate(48.0, 4.0, 48.0))) {
                    if (entity != null && entity instanceof LivingEntity && !(entity instanceof EntityTitan) && this.canAttackEntity(entity)) {
                        LivingEntity livingEntity = (LivingEntity)entity;
                        float smash = 50.0F - this.distanceTo(livingEntity);
                        if (smash <= 1.0F) {
                            smash = 1.0F;
                        }

                        this.attackEntity(livingEntity, smash);
                        double d0 = this.getBoundingBox().minX + this.getBoundingBox().maxX;
                        double d1 = this.getBoundingBox().minZ + this.getBoundingBox().maxZ;
                        double d2 = entity.getX() - d0;
                        double d3 = entity.getZ() - d1;
                        double d4 = d2 * d2 + d3 * d3;
                        if (d4 >= 0.01) {
                            double d5 = d2 / d4 * 8.0;
                            double d6 = 1.0;
                            double d7 = d3 / d4 * 8.0;
                            livingEntity.push(d5, d6, d7);
                        }
                    }
                }
            }

            return true;
        }
    }

    @Override
    protected void dropExperienceOrb() {
        for (int x = 0; x < (this.getCharged() ? 60 : 16); x++) {
            EntityExperienceOrbTitan experienceOrbTitan = new EntityExperienceOrbTitan(
                this.level(),
                this.getX() + (double)(this.random.nextFloat() * 12.0F - 6.0F),
                this.getY() + 4.0,
                this.getZ() + (double)(this.random.nextFloat() * 12.0F - 6.0F),
                16000
            );
            experienceOrbTitan.push(0.0, 1.0, 0.0);
            this.level().addFreshEntity(experienceOrbTitan);
        }
    }

    @Override
    protected void dropAllItem() {
        Map<ItemStack, Integer> drops = new HashMap<>();
        Map<ItemStack, Integer> rateDrops = new HashMap<>();
        drops.put(new ItemStack(Items.GUNPOWDER), 256);
        drops.put(new ItemStack(Blocks.TNT), 64);
        drops.put(new ItemStack(Items.COAL), 32);
        drops.put(new ItemStack(Items.EMERALD), 8);
        drops.put(new ItemStack(Items.DIAMOND), 8);
        drops.put(new ItemStack(Items.GUNPOWDER), 256);
        drops.put(new ItemStack(Blocks.TNT), 64);
        rateDrops.put(new ItemStack(Items.COAL), 32);
        rateDrops.put(new ItemStack(Items.EMERALD), 8);
        rateDrops.put(new ItemStack(Items.DIAMOND), 8);
        rateDrops.put(new ItemStack((ItemLike)TheTitansRegistries.HARCADIUM.get()), 4);

        for (Entry<ItemStack, Integer> entry : drops.entrySet()) {
            ItemStack itemStack = entry.getKey();
            int count = entry.getValue();
            EntityItemTitan itemTitan = new EntityItemTitan(
                this.level(),
                this.getX() + (double)(this.random.nextFloat() * 12.0F - 6.0F),
                this.getY() + 4.0,
                this.getZ() + (double)(this.random.nextFloat() * 12.0F - 6.0F),
                itemStack,
                count
            );
            itemTitan.setPickUpDelay(40);
            this.level().addFreshEntity(itemTitan);
        }

        for (Entry<ItemStack, Integer> entry : rateDrops.entrySet()) {
            ItemStack itemStack = entry.getKey();
            int count = entry.getValue();
            int randomCount = this.random.nextInt(count) + 1;
            EntityItemTitan itemTitan = new EntityItemTitan(
                this.level(),
                this.getX() + (double)(this.random.nextFloat() * 12.0F - 6.0F),
                this.getY() + 4.0,
                this.getZ() + (double)(this.random.nextFloat() * 12.0F - 6.0F),
                itemStack,
                randomCount
            );
            itemTitan.setPickUpDelay(40);
            this.level().addFreshEntity(itemTitan);
        }

        if (this.random.nextInt(10) == 0) {
            EntityItemTitan itemTitan = new EntityItemTitan(
                this.level(),
                this.getX() + (double)(this.random.nextFloat() * 12.0F - 6.0F),
                this.getY() + 4.0,
                this.getZ() + (double)(this.random.nextFloat() * 12.0F - 6.0F),
                new ItemStack(Blocks.BEDROCK),
                1
            );
            itemTitan.setPickUpDelay(40);
            this.level().addFreshEntity(itemTitan);
        }
    }

    @Override
    protected void tickTitanDeath() {
        super.tickTitanDeath();
        AnimationUtils.sendPacket(this, 10);
        this.isStunned = false;
        if (this.deathTicks < 300) {
            this.timeSinceIgnited = 0;
        }

        if (this.deathTicks >= 300) {
            if (this.timeSinceIgnited == 1) {
                this.playSound((SoundEvent)TheTitansSounds.TITAN_CREEPER_WARNING.get(), Float.MAX_VALUE, 1.0F);
            }

            this.timeSinceIgnited++;
            this.setAnimationTick(this.getAnimationTick() - 1);
            this.setCreeperState(1);
            float f = (this.random.nextFloat() - 0.5F) * 16.0F;
            float f1 = (this.random.nextFloat() - 0.5F) * 12.0F;
            float f2 = (this.random.nextFloat() - 0.5F) * 16.0F;
            this.level()
                .addParticle(ParticleTypes.EXPLOSION, this.getX() + (double)f, this.getY() + 2.0 + (double)f1, this.getZ() + (double)f2, 0.0, 0.0, 0.0);
        }

        if (this.timeSinceIgnited >= this.getThreashHold()) {
            this.deathTicks = 200;
            this.explode();
            this.onDeath();
            if (!this.level().isClientSide() && !this.isRemoved()) {
                for (EntityTitanPart part : this.parts) {
                    part.remove(RemovalReason.KILLED);
                }

                this.removeTitan(RemovalReason.KILLED);
            }
        }
    }

    @Override
    public void finalizeMinionSummon(Entity entity, EnumMinionType minionType) {
        if (minionType != EnumMinionType.SPECIAL && entity instanceof EntityCreeperTitanMinion creeperTitanMinion) {
            creeperTitanMinion.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 40, 4, true, false));
            if (this.getCharged()) {
                LightningBolt lightningBolt = new LightningBolt(EntityType.LIGHTNING_BOLT, this.level());
                lightningBolt.setPos(creeperTitanMinion.getX(), creeperTitanMinion.getY(), creeperTitanMinion.getZ());
                this.level().addFreshEntity(lightningBolt);
            }
        }
    }

    public void animationTick() {
        if (this.getAnimationID() == 13) {
            this.addDayTime(14000L, 50L);
            if (this.getAnimationTick() == 1) {
                this.playSound((SoundEvent)TheTitansSounds.TITAN_BIRTH.get(), 1000.0F, 1.0F);
            }

            if (this.getAnimationTick() == 10) {
                this.playSound((SoundEvent)TheTitansSounds.TITAN_CREEPER_AWAKEN.get(), this.getSoundVolume(), 1.0F);
            }

            if (this.getAnimationTick() == 130) {
                this.playSound((SoundEvent)TheTitansSounds.TITAN_RUMBLE.get(), this.getSoundVolume(), 1.0F);
            }

            if (this.getAnimationTick() == 160) {
                this.playSound((SoundEvent)TheTitansSounds.TITAN_CREEPER_BEGINMOVE.get(), this.getSoundVolume(), 1.0F);
            }

            if (this.getAnimationTick() == 260 || this.getAnimationTick() == 261 || this.getAnimationTick() == 390 || this.getAnimationTick() == 410) {
                this.playStepSound(new BlockPos(0, 0, 0), Blocks.STONE.defaultBlockState());
                this.playSound((SoundEvent)TheTitansSounds.TITAN_PRESS.get(), this.getSoundVolume(), 1.0F);
            }
        }

        if (this.getAnimationID() == 1 && this.getAnimationTick() == 12 && this.getTarget() != null) {
            this.shakeNearbyPlayerCameras(20000.0);
            float amount = (float)this.getAttributeBaseValue(Attributes.ATTACK_DAMAGE);
            int knockbackAmount = this.getKnockbackAmount();
            this.collideWithEntities(this.body, this.level().getEntities(this, this.body.getBoundingBox().inflate(48.0, 48.0, 48.0)));

            for (int i = 0; i < 4; i++) {
                this.attackEntity(this.getTarget(), amount);
            }

            this.knockbackEntity(this.getTarget(), (float)knockbackAmount);

            for (Entity entity : this.level().getEntities(this.getTarget(), this.getTarget().getBoundingBox().inflate(8.0, 8.0, 8.0))) {
                if (entity != null && entity != this && entity instanceof LivingEntity && this.canAttackEntity(entity)) {
                    LivingEntity livingEntity = (LivingEntity)entity;

                    for (int i = 0; i < 2; i++) {
                        this.attackEntity(livingEntity, amount);
                    }

                    this.knockbackEntity(livingEntity, (float)knockbackAmount);
                }
            }
        }

        if (this.getAnimationID() == 2 && (this.getAnimationTick() == 60 || this.getAnimationTick() == 104)) {
            this.shakeNearbyPlayerCameras(20000.0);
            this.playSound((SoundEvent)TheTitansSounds.TITAN_SLAM.get(), 20.0F, 1.0F);
            float amount = (float)this.getAttributeBaseValue(Attributes.ATTACK_DAMAGE);
            this.collideWithEntities(this.body, this.level().getEntities(this, this.body.getBoundingBox().inflate(16.0, 8.0, 16.0)));

            for (Entity entityx : this.level().getEntities(this, this.getBoundingBox().inflate(32.0, 8.0, 32.0))) {
                if (entityx != null && entityx instanceof LivingEntity && this.canAttackEntity(entityx)) {
                    LivingEntity livingEntity = (LivingEntity)entityx;
                    this.attackEntity(livingEntity, amount);
                    livingEntity.push(0.0, 1.0 + this.random.nextDouble(), 0.0);
                }
            }
        }

        if (this.getAnimationID() == 3 && this.getAnimationTick() == 90) {
            this.shakeNearbyPlayerCameras(20000.0);
            this.playSound((SoundEvent)TheTitansSounds.TITAN_SLAM.get(), 20.0F, 1.0F);
            this.playSound((SoundEvent)TheTitansSounds.GROUND_SMASH.get(), 20.0F, 1.0F);
            double d8 = 12.0;
            Vec3 vec3 = this.getViewVector(1.0F);
            double dx = vec3.x * d8;
            double dz = vec3.z * d8;
            float amount = (float)this.getAttributeBaseValue(Attributes.ATTACK_DAMAGE);
            this.collideWithEntities(this.body, this.level().getEntities(this, this.body.getBoundingBox().inflate(16.0, 8.0, 16.0)));

            for (Entity entityxx : this.level().getEntities(this, this.getBoundingBox().inflate(32.0, 2.0, 32.0).move(dx, 0.0, dz))) {
                if (entityxx != null && entityxx instanceof LivingEntity && this.canAttackEntity(entityxx)) {
                    LivingEntity livingEntity = (LivingEntity)entityxx;

                    for (int i = 0; i < 2; i++) {
                        this.attackEntity(livingEntity, amount * 2.0F);
                    }

                    livingEntity.push(0.0, 1.0 + this.random.nextDouble() + this.random.nextDouble(), 0.0);
                }
            }
        }

        if (this.getAnimationID() == 4 && this.getAnimationTick() == 32) {
            this.shakeNearbyPlayerCameras(20000.0);
            this.playSound((SoundEvent)TheTitansSounds.TITAN_STRIKE.get(), 20.0F, 1.0F);
            if (this.getTarget() != null) {
                this.doLightningAttackToEntity(this.getTarget());
            }

            float d0 = 16.0F;
            float f3 = this.yBodyRot * (float) Math.PI / 180.0F;
            float f11 = Mth.sin(f3);
            float f4 = Mth.cos(f3);
            float amount = (float)this.getAttributeBaseValue(Attributes.ATTACK_DAMAGE);
            int knockbackAmount = this.getKnockbackAmount();
            this.collideWithEntities(
                this.head,
                this.level().getEntities(this, this.head.getBoundingBox().inflate(48.0, 12.0, 48.0).move((double)(-(f11 * d0)), -8.0, (double)(f4 * d0)))
            );

            for (Entity entityxxx : this.level()
                .getEntities(this, this.getBoundingBox().inflate(32.0, 8.0, 32.0).move((double)(-(f11 * d0)), -4.0, (double)(f4 * d0)))) {
                if (entityxxx != null && entityxxx instanceof LivingEntity && this.canAttackEntity(entityxxx)) {
                    LivingEntity livingEntity = (LivingEntity)entityxxx;

                    for (int i = 0; i < 2; i++) {
                        this.attackEntity(livingEntity, amount * 2.0F);
                    }

                    this.knockbackEntity(livingEntity, (float)knockbackAmount);
                }
            }
        }

        if (this.getAnimationID() == 5 && this.getAnimationTick() == 30 && this.getTarget() != null) {
            float amount = (float)this.getAttributeBaseValue(Attributes.ATTACK_DAMAGE);
            int knockbackAmount = this.getKnockbackAmount();
            this.collideWithEntities(this.body, this.level().getEntities(this, this.body.getBoundingBox().inflate(4.0, 2.0, 4.0)));
            this.attackEntity(this.getTarget(), amount);
            this.knockbackEntity(this.getTarget(), (float)knockbackAmount);

            for (Entity entityxxxx : this.level().getEntities(this.getTarget(), this.getTarget().getBoundingBox().inflate(8.0, 8.0, 8.0))) {
                if (entityxxxx != null && entityxxxx != this && entityxxxx instanceof LivingEntity && this.canAttackEntity(entityxxxx)) {
                    LivingEntity livingEntity = (LivingEntity)entityxxxx;
                    this.attackEntity(livingEntity, amount);
                    this.knockbackEntity(livingEntity, (float)knockbackAmount);
                }
            }
        }

        if (this.getAnimationID() == 6 && this.getAnimationTick() <= 50 && this.getAnimationTick() >= 20 && this.getTarget() != null) {
            int num = this.getCharged() ? 50 + this.random.nextInt(50) : 10 + this.random.nextInt(10);

            for (int i = 0; i < num; i++) {
                switch (this.random.nextInt(3)) {
                    case 0:
                        this.playSound((SoundEvent)TheTitansSounds.TITAN_GHAST_FIREBALL.get(), 100.0F, 1.25F);
                        Vec3 vec3 = this.getViewVector(1.0F);
                        double d0 = this.head.getX() + vec3.x * 6.0;
                        double d1 = this.head.getY() + 1.0;
                        double d2 = this.head.getZ() + vec3.z * 6.0;
                        double d3 = this.getTarget().getX() + (double)((this.random.nextFloat() * 2.0F - 1.0F) * 16.0F) - d0;
                        double d4 = this.getTarget().getY() - 16.0 + (double)((this.random.nextFloat() * 2.0F - 1.0F) * 16.0F) - d1;
                        double d5 = this.getTarget().getZ() + (double)((this.random.nextFloat() * 2.0F - 1.0F) * 16.0F) - d2;
                        EntityGunpowderTitan gunpowderTitan = new EntityGunpowderTitan(this.level(), this);
                        gunpowderTitan.setPos(d0, d1, d2);
                        gunpowderTitan.shoot(d3, d4, d5, 1.0F, 1.0F);
                        if (!this.level().isClientSide()) {
                            this.level().addFreshEntity(gunpowderTitan);
                        }
                        break;
                    case 1:
                        this.playSound(SoundEvents.TNT_PRIMED, 1.0F, 1.0F);
                        PrimedTnt tnt = new PrimedTnt(
                            this.level(),
                            this.getTarget().getX() + 0.5 + (double)((this.random.nextFloat() * 2.0F - 1.0F) * 32.0F),
                            this.getTarget().getY() + 32.0 + (double)((this.random.nextFloat() * 2.0F - 1.0F) * 32.0F),
                            this.getTarget().getZ() + 0.5 + (double)((this.random.nextFloat() * 2.0F - 1.0F) * 32.0F),
                            this
                        );
                        tnt.setFuse(100 + this.random.nextInt(60));
                        if (!this.level().isClientSide()) {
                            this.level().addFreshEntity(tnt);
                        }
                }
            }
        }

        if (this.getAnimationID() == 7) {
            if (this.getAnimationTick() == 100) {
                this.shakeNearbyPlayerCameras(20000.0);
                this.playSound((SoundEvent)TheTitansSounds.TITAN_STRIKE.get(), 20.0F, 1.1F);
                if (this.getTarget() != null) {
                    this.doLightningAttackToEntity(this.getTarget());
                }

                double d8 = 12.0;
                Vec3 vec3 = this.getViewVector(1.0F);
                double dx = vec3.x * d8;
                double dz = vec3.z * d8;
                float amount = (float)this.getAttributeBaseValue(Attributes.ATTACK_DAMAGE);
                int knockbackAmount = this.getKnockbackAmount();
                if (!this.level().isClientSide()) {
                    this.level().explode(this, this.getX() + dx, this.getY() + 10.0, this.getZ() + dz, 3.0F, false, ExplosionInteraction.MOB);
                }

                this.collideWithEntities(this.head, this.level().getEntities(this, this.head.getBoundingBox().inflate(16.0, 2.0, 16.0)));

                for (Entity entityxxxxx : this.level().getEntities(this, this.getBoundingBox().inflate(32.0, 2.0, 32.0).move(dx, 0.0, dz))) {
                    if (entityxxxxx != null && entityxxxxx instanceof LivingEntity && this.canAttackEntity(entityxxxxx)) {
                        LivingEntity livingEntity = (LivingEntity)entityxxxxx;
                        this.attackEntity(livingEntity, amount * 2.0F);
                        this.knockbackEntity(livingEntity, (float)knockbackAmount);
                    }
                }
            }

            if (this.getAnimationTick() == 150) {
                this.playSound((SoundEvent)TheTitansSounds.TITAN_SLAM.get(), 20.0F, 1.0F);
                this.playSound((SoundEvent)TheTitansSounds.GROUND_SMASH.get(), 20.0F, 1.0F);
                double d8 = 12.0;
                Vec3 vec3 = this.getViewVector(1.0F);
                double dx = vec3.x * d8;
                double dz = vec3.z * d8;
                float amount = (float)this.getAttributeBaseValue(Attributes.ATTACK_DAMAGE);
                int knockbackAmount = this.getKnockbackAmount();
                this.collideWithEntities(this.body, this.level().getEntities(this, this.body.getBoundingBox().inflate(16.0, 8.0, 16.0)));

                for (Entity entityxxxxxx : this.level().getEntities(this, this.getBoundingBox().inflate(32.0, 2.0, 32.0).move(dx, 0.0, dz))) {
                    if (entityxxxxxx != null && entityxxxxxx instanceof LivingEntity) {
                        LivingEntity livingEntity = (LivingEntity)entityxxxxxx;

                        for (int i = 0; i < 2; i++) {
                            this.attackEntity(livingEntity, amount * 2.0F);
                        }

                        this.knockbackEntity(livingEntity, (float)knockbackAmount);
                        livingEntity.push(0.0, 1.0 + this.random.nextDouble() + this.random.nextDouble(), 0.0);
                    }
                }
            }
        }

        if (this.getAnimationID() == 8) {
            if (this.getAnimationTick() == 20) {
                this.playSound((SoundEvent)TheTitansSounds.TITAN_CREEPER_STUN.get(), this.getSoundVolume(), this.getVoicePitch());
            }

            if (this.getAnimationTick() == 120) {
                this.shakeNearbyPlayerCameras(10000.0);
                this.playSound((SoundEvent)TheTitansSounds.GROUND_SMASH.get(), 8.0F, 0.9F);
                this.playSound((SoundEvent)TheTitansSounds.TITAN_FALL.get(), 10.0F, 1.0F);
            }

            if (this.getAnimationTick() > 500) {
                this.isStunned = false;
            } else {
                this.isStunned = true;
            }

            this.setTarget(null);
        }

        if (this.getAnimationID() == 10) {
            if (this.getAnimationTick() == 50 || this.getAnimationTick() == 70 || this.getAnimationTick() == 100) {
                this.playStepSound(new BlockPos(0, 0, 0), Blocks.STONE.defaultBlockState());
            }

            if (this.getAnimationTick() == 120) {
                this.shakeNearbyPlayerCameras(10000.0);
                this.playSound((SoundEvent)TheTitansSounds.TITAN_FALL.get(), 20.0F, 1.0F);
                this.playSound((SoundEvent)TheTitansSounds.GROUND_SMASH.get(), 20.0F, 1.0F);
            }

            if (this.getAnimationTick() == 160) {
                this.shakeNearbyPlayerCameras(10000.0);
                this.playSound((SoundEvent)TheTitansSounds.TITAN_FALL.get(), 20.0F, 1.0F);
            }
        }
    }

    @Override
    public void tick() {
        super.tick();
        this.checkWaiting(24.0);
        if (this.getCharged()) {
            boolean flag = true;
            if (!this.level().isClientSide()) {
                ServerLevel serverLevel = (ServerLevel)this.level();
                ImmutableList<Entity> entities = ImmutableList.copyOf(serverLevel.getAllEntities());
                UnmodifiableIterator d1 = entities.iterator();

                while (d1.hasNext()) {
                    Entity entity = (Entity)d1.next();
                    if (entity != null && entity.isAlive() && entity instanceof EntityEnderColossus) {
                        flag = false;
                    }
                }

                if (flag) {
                    serverLevel.setWeatherParameters(0, ServerLevel.THUNDER_DURATION.sample(serverLevel.getRandom()), true, true);
                }
            }

            if (this.random.nextInt(20) == 0) {
                EntityColorLightningBolt colorLightningBolt = new EntityColorLightningBolt(this.level(), 0.0F, 0.5F, 1.0F);
                colorLightningBolt.setPos(this.getX(), this.head.getY() + 4.0, this.getZ());
                if (!this.level().isClientSide()) {
                    this.level().addFreshEntity(colorLightningBolt);
                }
            }

            if (this.random.nextInt(40) == 0) {
                for (int l = 0; l < 50; l++) {
                    int i = Mth.floor(this.getX());
                    int j = Mth.floor(this.getY());
                    int k = Mth.floor(this.getZ());
                    int i1 = i + Mth.randomBetweenInclusive(this.random, 10, 100) * Mth.randomBetweenInclusive(this.random, -2, 2);
                    int j1 = j + Mth.randomBetweenInclusive(this.random, 10, 100) * Mth.randomBetweenInclusive(this.random, -2, 2);
                    int k1 = k + Mth.randomBetweenInclusive(this.random, 10, 100) * Mth.randomBetweenInclusive(this.random, -2, 2);
                    BlockPos blockPos = new BlockPos(i1, j1 - 1, k1);
                    BlockState blockState = this.level().getBlockState(blockPos);
                    if (!blockState.isAir() && blockState.isSolid()) {
                        EntityColorLightningBolt colorLightningBolt = new EntityColorLightningBolt(this.level(), 0.0F, 0.5F, 1.0F);
                        colorLightningBolt.setPos((double)i1, (double)j1, (double)k1);
                        if (!this.level().isClientSide()) {
                            this.level().addFreshEntity(colorLightningBolt);
                        }
                    }
                }
            }
        }

        if (this.getAnimationID() == 0 && !this.isPassenger() && !this.getWaiting() && !this.isStunned) {
            if (this.getTarget() != null && this.distanceToSqr(this.getTarget()) > this.getMeleeRange() + (!this.getTarget().onGround() ? 1000.0 : 8000.0)) {
                if (this.getY() <= this.getTarget().getY() + 12.0 && this.getY() < 256.0 - (double)this.getBbHeight()) {
                    this.fallDistance = 0.0F;
                    this.setTitanDeltaMovement(this.getDeltaMovement().x, this.getDeltaMovement().y + 0.9 - this.getDeltaMovement().y, this.getDeltaMovement().z);
                    if (this.getDeltaMovement().y < 0.0) {
                        this.setTitanDeltaMovement(this.getDeltaMovement().x, 0.0, this.getDeltaMovement().z);
                    }
                }

                this.setTitanDeltaMovement(this.getDeltaMovement().x, this.getDeltaMovement().y * 0.6, this.getDeltaMovement().z);
            }

            if (!this.onGround()) {
                float f3 = (this.random.nextFloat() - 0.5F) * 10.0F;
                float f4 = (this.random.nextFloat() - 0.5F) * 1.0F;
                float f5 = (this.random.nextFloat() - 0.5F) * 10.0F;
                this.level()
                    .addParticle(
                        ParticleTypes.EXPLOSION, this.getX() + (double)f3, this.getY() + 5.0 + (double)f4, this.getZ() + (double)f5, 0.0, 0.0, 0.0
                    );
            }
        }

        if (this.tickCount > 5) {
            float f = this.yBodyRot * (float) Math.PI / 180.0F;
            float f1 = Mth.sin(f);
            float f2 = Mth.cos(f);
            float offset = (this.getAnimationID() != 3 || this.getAnimationTick() <= 30 || this.getAnimationTick() >= 70)
                    && (this.getAnimationID() != 7 || this.getAnimationTick() <= 30 || this.getAnimationTick() >= 130)
                ? 0.0F
                : 6.0F;
            this.head.moveTo(this.getX(), this.getY() + (this.getAnimationID() == 8 ? 12.0 : 18.0), this.getZ());
            this.body.moveTo(this.getX(), this.getY() + (this.getAnimationID() == 8 ? 0.0 : 6.0), this.getZ());
            this.leg1
                .moveTo(
                    this.getX() - (double)(f1 * 5.5F) + (double)(f2 * 5.5F),
                    this.getY() + (double)offset,
                    this.getZ() + (double)(f2 * 5.5F) + (double)(f1 * 5.5F)
                );
            this.leg2
                .moveTo(
                    this.getX() - (double)(f1 * 5.5F) - (double)(f2 * 5.5F),
                    this.getY() + (double)offset,
                    this.getZ() + (double)(f2 * 5.5F) - (double)(f1 * 5.5F)
                );
            this.leg3
                .moveTo(
                    this.getX() + (double)(f1 * 5.5F) + (double)(f2 * 5.5F), this.getY(), this.getZ() - (double)(f2 * 5.5F) + (double)(f1 * 5.5F)
                );
            this.leg4
                .moveTo(
                    this.getX() + (double)(f1 * 5.5F) - (double)(f2 * 5.5F), this.getY(), this.getZ() - (double)(f2 * 5.5F) - (double)(f1 * 5.5F)
                );

            for (EntityTitanPart part : this.parts) {
                if (this.isAlive() && !this.isStunned) {
                    this.collideWithEntities(part, this.level().getEntities(this, part.getBoundingBox().inflate(1.0, 0.0, 1.0)));
                }

                this.destroyBlocksInAABB(part.getBoundingBox());
            }
        }

        if (this.getAnimationID() == 0 && this.getTarget() != null) {
            double d0 = this.distanceToSqr(this.getTarget());
            if (d0 < this.getMeleeRange()) {
                if (!(this.getTarget() instanceof EntityTitan) && !(this.getTarget().getBbHeight() >= 6.0F) && !(this.getTarget().getY() > this.getY() + 6.0)) {
                    switch (this.random.nextInt(4)) {
                        case 0:
                            AnimationUtils.sendPacket(this, 3);
                            break;
                        case 1:
                            AnimationUtils.sendPacket(this, 2);
                            break;
                        case 2:
                            AnimationUtils.sendPacket(this, 5);
                            break;
                        case 3:
                            AnimationUtils.sendPacket(this, 4);
                    }
                } else {
                    AnimationUtils.sendPacket(this, 1);
                }
            } else if (this.random.nextInt(100) == 0) {
                switch (this.random.nextInt(2)) {
                    case 0:
                        AnimationUtils.sendPacket(this, 7);
                        break;
                    case 1:
                        AnimationUtils.sendPacket(this, 6);
                }
            }
        }

        if (this.isStunned) {
            this.setTarget(null);
            AnimationUtils.sendPacket(this, 8);
        }

        if (this.getTarget() != null && !(this.getTarget() instanceof EntityTitan) && this.random.nextInt(this.getCharged() ? 30 : 150) == 0 && !this.isStunned
            )
         {
            this.doLightningAttackToEntity(this);
            this.doLightningAttackToEntity(this.getTarget());
        }

        if (this.getAnimationID() == 0 && this.random.nextInt(120) == 0 && this.getTarget() != null && this.onGround()) {
            if (this.distanceToSqr(this.getTarget()) > 300.0) {
                int rate = this.getCharged() ? 50 : 600;
                if (this.random.nextInt(rate) == 0) {
                    this.jumpFromGround();
                    this.playSound(this.getHurtSound(null), this.getSoundVolume(), this.getVoicePitch());
                }
            }

            int rate = this.getCharged() ? 50 : 600;
            if (this.random.nextInt(rate) == 0) {
                if (this.random.nextInt(4) == 0) {
                    this.jumpFromGround();
                    double d0 = this.getTarget().getX() - this.getX();
                    double d1 = this.getTarget().getZ() - this.getZ();
                    double d2 = Math.sqrt(d0 * d0 + d1 * d1);
                    double hor = d2 / 16.0;
                    double ver = 2.0;
                    this.setTitanDeltaMovement(d0 / d2 * hor * hor + this.getDeltaMovement().x * hor, ver, d1 / d2 * hor * hor + this.getDeltaMovement().z * hor);
                } else {
                    this.jumpAtEntity(this.getTarget());
                }
            }
        }

        this.animationTick();
    }
}
