package net.titans.util;

import java.lang.reflect.Field;
import net.minecraft.server.commands.data.EntityDataAccessor;
import net.minecraft.world.entity.Entity;

public final class DataAccessorHelper {
    private static Field entityField;
    private static boolean lookedUp;

    private DataAccessorHelper() {
    }

    public static Entity getEntity(EntityDataAccessor accessor) {
        if (!lookedUp) {
            lookedUp = true;

            for (Field field : EntityDataAccessor.class.getDeclaredFields()) {
                if (Entity.class.isAssignableFrom(field.getType())) {
                    field.setAccessible(true);
                    entityField = field;
                    break;
                }
            }
        }

        if (entityField == null) {
            return null;
        }

        try {
            return (Entity)entityField.get(accessor);
        } catch (Exception var2) {
            return null;
        }
    }
}
