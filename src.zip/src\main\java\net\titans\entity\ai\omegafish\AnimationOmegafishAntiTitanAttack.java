package net.titans.entity.ai.omegafish;

import net.titans.animation.AIAnimation;
import net.titans.entity.titan.EntityOmegafish;
import net.titans.util.AnimationUtils;

public class AnimationOmegafishAntiTitanAttack extends AIAnimation {
    private EntityOmegafish entity;

    public AnimationOmegafishAntiTitanAttack(EntityOmegafish entity) {
        super(entity);
        this.entity = entity;
    }

    @Override
    public int getAnimationID() {
        return 11;
    }

    @Override
    public boolean isAutomatic() {
        return true;
    }

    @Override
    public int getDuration() {
        return 30;
    }

    @Override
    public boolean canContinueToUse() {
        return this.entity.getAnimationTick() <= this.getDuration() && !this.entity.isStunned ? super.canContinueToUse() : false;
    }

    @Override
    public void start() {
        super.start();
        AnimationUtils.sendAttackPacket(this.entity, this.entity.level().random.nextInt(4));
    }

    public void tick() {
        if (this.entity.getTarget() != null) {
            this.entity.getLookControl().setLookAt(this.entity.getTarget(), 5.0F, 40.0F);
        }
    }
}
