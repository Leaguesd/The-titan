package net.titans.trigger;

import com.google.gson.JsonObject;
import net.minecraft.advancements.critereon.AbstractCriterionTriggerInstance;
import net.minecraft.advancements.critereon.ContextAwarePredicate;
import net.minecraft.advancements.critereon.DeserializationContext;
import net.minecraft.advancements.critereon.EntityPredicate;
import net.minecraft.advancements.critereon.SimpleCriterionTrigger;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.storage.loot.LootContext;

public class TriggerTitanWake extends SimpleCriterionTrigger<TriggerTitanWake.Instance> {
    private static final ResourceLocation ID = new ResourceLocation("titan", "titan_wake");

    public ResourceLocation getId() {
        return ID;
    }

    protected TriggerTitanWake.Instance createInstance(JsonObject jsonObject, ContextAwarePredicate player, DeserializationContext context) {
        ContextAwarePredicate entity = EntityPredicate.fromJson(jsonObject, "entity", context);
        return new TriggerTitanWake.Instance(player, entity);
    }

    public void trigger(ServerPlayer player, Entity entity) {
        LootContext lootContext = EntityPredicate.createContext(player, entity);
        this.trigger(player, instance -> instance.matches(player, lootContext));
    }

    public static class Instance extends AbstractCriterionTriggerInstance {
        private final ContextAwarePredicate entity;

        public Instance(ContextAwarePredicate player, ContextAwarePredicate entity) {
            super(TriggerTitanWake.ID, player);
            this.entity = entity;
        }

        public boolean matches(ServerPlayer player, LootContext context) {
            return this.entity.matches(context);
        }
    }
}
