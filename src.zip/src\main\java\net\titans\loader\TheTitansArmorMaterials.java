package net.titans.loader;

import java.util.function.Supplier;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.item.ArmorMaterial;
import net.minecraft.world.item.ArmorItem.Type;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.level.ItemLike;
import net.minecraftforge.eventbus.api.IEventBus;

public enum TheTitansArmorMaterials implements ArmorMaterial {
    HARCADIUM(
        "harcadium", 5000, new int[]{8, 12, 15, 9}, 30, 0.0F, 0.0F, () -> Ingredient.of(new ItemLike[]{(ItemLike)TheTitansRegistries.HARCADIUM.get()})
    ),
    VOID("absence", 100000, new int[]{9, 13, 17, 11}, 50, 0.0F, 0.0F, () -> Ingredient.of(new ItemLike[]{(ItemLike)TheTitansRegistries.VOID.get()})),
    ADMINIUM(
        "adminium",
        100000000,
        new int[]{100000, 100000, 100000, 100000},
        60,
        0.0F,
        0.0F,
        () -> Ingredient.of(new ItemLike[]{(ItemLike)TheTitansRegistries.VOID.get()})
    );

    private static final int[] HEALTH_PER_SLOT = new int[]{13, 15, 16, 11};
    private final String name;
    private final int durabilityMultiplier;
    private final int[] defense;
    private final int enchantmentValue;
    private final float toughness;
    private final float knockbackResistance;
    private final Supplier<Ingredient> repairIngredient;

    private TheTitansArmorMaterials(
        String name,
        int durabilityMultiplier,
        int[] defense,
        int enchantmentValue,
        float toughness,
        float knockbackResistance,
        Supplier<Ingredient> repairIngredient
    ) {
        this.name = name;
        this.durabilityMultiplier = durabilityMultiplier;
        this.defense = defense;
        this.enchantmentValue = enchantmentValue;
        this.toughness = toughness;
        this.knockbackResistance = knockbackResistance;
        this.repairIngredient = repairIngredient;
    }

    public int getDurabilityForType(Type type) {
        return HEALTH_PER_SLOT[type.ordinal()] * this.durabilityMultiplier;
    }

    public int getDefenseForType(Type type) {
        return this.defense[type.ordinal()];
    }

    public int getEnchantmentValue() {
        return this.enchantmentValue;
    }

    public SoundEvent getEquipSound() {
        return SoundEvents.ARMOR_EQUIP_GENERIC;
    }

    public Ingredient getRepairIngredient() {
        return this.repairIngredient.get();
    }

    public String getName() {
        return "titan:" + this.name;
    }

    public float getToughness() {
        return this.toughness;
    }

    public float getKnockbackResistance() {
        return this.knockbackResistance;
    }

    public static void registerArmorMaterials(IEventBus modEventBus) {
    }
}
