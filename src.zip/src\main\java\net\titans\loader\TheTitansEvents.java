package net.titans.loader;

import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.loading.FMLEnvironment;
import net.titans.event.PlayerHealthBarEvent;
import net.titans.event.TheTitansBossBarEvent;
import net.titans.event.TheTitansClientEvent;
import net.titans.event.TheTitansEvent;

public class TheTitansEvents {
    public static void registerEvents() {
        MinecraftForge.EVENT_BUS.register(new TheTitansEvent());
        if (FMLEnvironment.dist.isClient()) {
            MinecraftForge.EVENT_BUS.register(new TheTitansClientEvent());
            MinecraftForge.EVENT_BUS.register(new PlayerHealthBarEvent());
            MinecraftForge.EVENT_BUS.register(new TheTitansBossBarEvent());
        }
    }
}
