package net.titans.entity.ai.ghasttitan;

import java.util.EnumSet;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.control.MoveControl;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.goal.Goal.Flag;
import net.minecraft.world.entity.player.Player;
import net.titans.entity.titan.EntityGhastTitan;

/**
 * 恶魂泰坦的漂浮 AI。
 *
 * <p>之前这里把悬停高度写死成 {@code Y = 160 ± 32}：无论玩家在地面还是下界，
 * 它都会一路爬到 Y≈160，显得“飞得太高”。现在改成相对目标/玩家/自身当前位置计算，
 * 再用世界高度做一次夹取。
 */
public class EntityAIGhastTitanRandomFloatAround extends Goal {
    /** 有目标/玩家时，脚底相对其 Y 的最低悬停高度。 */
    private static final double MIN_HOVER_HEIGHT = 24.0;
    /** 有目标/玩家时，脚底相对其 Y 的最高悬停高度。 */
    private static final double MAX_HOVER_HEIGHT = 40.0;
    /** 没有目标时，围绕当前高度的上下浮动范围。 */
    private static final double IDLE_VERTICAL_RANGE = 16.0;
    /** 水平漂浮范围。 */
    private static final double HORIZONTAL_RANGE = 96.0;

    private final EntityGhastTitan entity;

    public EntityAIGhastTitanRandomFloatAround(EntityGhastTitan entity) {
        this.entity = entity;
        this.setFlags(EnumSet.of(Flag.MOVE));
    }

    public boolean canUse() {
        MoveControl moveControl = this.entity.getMoveControl();
        if (!moveControl.hasWanted()) {
            return true;
        } else {
            double d0 = moveControl.getWantedX() - this.entity.getX();
            double d1 = moveControl.getWantedY() - this.entity.getY();
            double d2 = moveControl.getWantedZ() - this.entity.getZ();
            double d3 = d0 * d0 + d1 * d1 + d2 * d2;
            return d3 < 36.0 || d3 > 40000.0;
        }
    }

    public boolean canContinueToUse() {
        return false;
    }

    public void start() {
        MoveControl moveControl = this.entity.getMoveControl();
        LivingEntity target = this.entity.getTarget();
        if (target != null) {
            this.setWantedAbove(moveControl, target.getX(), target.getY(), target.getZ());
            return;
        }

        Player player = this.entity.level().getNearestPlayer(this.entity, 512.0);
        if (player != null) {
            this.setWantedAbove(moveControl, player.getX(), player.getY(), player.getZ());
            return;
        }

        // 没有可跟随的目标时，围绕当前高度小幅浮动，不再往固定高度爬
        RandomSource random = this.entity.level().random;
        double x = this.entity.getX() + (random.nextDouble() * 2.0 - 1.0) * HORIZONTAL_RANGE;
        double y = this.entity.getY() + (random.nextDouble() * 2.0 - 1.0) * IDLE_VERTICAL_RANGE;
        double z = this.entity.getZ() + (random.nextDouble() * 2.0 - 1.0) * HORIZONTAL_RANGE;
        moveControl.setWantedPosition(x, this.clampY(y), z, 1.0);
    }

    private void setWantedAbove(MoveControl moveControl, double anchorX, double anchorY, double anchorZ) {
        RandomSource random = this.entity.level().random;
        double x = anchorX + (random.nextDouble() * 2.0 - 1.0) * HORIZONTAL_RANGE;
        double z = anchorZ + (random.nextDouble() * 2.0 - 1.0) * HORIZONTAL_RANGE;
        double y = anchorY + MIN_HOVER_HEIGHT + random.nextDouble() * (MAX_HOVER_HEIGHT - MIN_HOVER_HEIGHT);
        moveControl.setWantedPosition(x, this.clampY(y), z, 1.0);
    }

    private double clampY(double y) {
        double minY = this.entity.level().getMinBuildHeight() + 8.0;
        double maxY = this.entity.level().getMaxBuildHeight() - (double)this.entity.getBbHeight() - 8.0;
        return Mth.clamp(y, minY, Math.max(minY, maxY));
    }
}
