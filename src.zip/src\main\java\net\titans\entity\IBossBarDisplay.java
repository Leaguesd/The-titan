package net.titans.entity;

import net.minecraft.resources.ResourceLocation;

public interface IBossBarDisplay {
    ResourceLocation getBossBarTexture();

    default int getBossBarNameColor() {
        return 16777215;
    }

    default int getBossBarHealthColor() {
        return 16777215;
    }

    int getBossBarWidth();

    int getBossBarHeight();

    int getBossBarInterval();

    int getBossBarVOffset();

    int getBossBarVHeight();

    int getBossBarTextOffset();
}
