package net.titans.loader;

import com.mojang.blaze3d.vertex.PoseStack;
import java.util.HashSet;
import java.util.Set;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.EnderDragonRenderer;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.GiantMobRenderer;
import net.minecraft.client.renderer.entity.ThrownItemRenderer;
import net.minecraft.client.renderer.entity.WitherBossRenderer;
import net.minecraft.client.renderer.entity.WitherSkullRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider.Context;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.item.Items;
import net.minecraftforge.client.event.EntityRenderersEvent.RegisterRenderers;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.RegistryObject;
import net.titans.render.RenderBlazeTitan;
import net.titans.render.RenderCaveSpiderTitan;
import net.titans.render.RenderColorLightningBolt;
import net.titans.render.RenderCreeperTitan;
import net.titans.render.RenderEnderColossus;
import net.titans.render.RenderEnderColossusCrystal;
import net.titans.render.RenderExperienceOrbTitan;
import net.titans.render.RenderGhastTitan;
import net.titans.render.RenderIronGolemTitan;
import net.titans.render.RenderItemTitan;
import net.titans.render.RenderMagmaCubeTitan;
import net.titans.render.RenderOmegafish;
import net.titans.render.RenderSkeletonTitan;
import net.titans.render.RenderSlimeTitan;
import net.titans.render.RenderSnowGolemTitan;
import net.titans.render.RenderSpiderTitan;
import net.titans.render.RenderTitanSpirit;
import net.titans.render.RenderWitherTurret;
import net.titans.render.RenderWitherTurretGround;
import net.titans.render.RenderWitherTurretMortar;
import net.titans.render.RenderWitherzilla;
import net.titans.render.RenderZombieTitan;
import net.titans.render.RenderZombifiedPiglinTitan;
import net.titans.render.minion.RenderBlazeTitanMinion;
import net.titans.render.minion.RenderCaveSpiderTitanMinion;
import net.titans.render.minion.RenderCreeperTitanMinion;
import net.titans.render.minion.RenderEnderColossusMinion;
import net.titans.render.minion.RenderGhastTitanMinion;
import net.titans.render.minion.RenderOmegafishMinion;
import net.titans.render.minion.RenderSkeletonTitanMinion;
import net.titans.render.minion.RenderSpiderTitanMinion;
import net.titans.render.minion.RenderWitherSkeletonTitanMinion;
import net.titans.render.minion.RenderZombieTitanMinion;
import net.titans.render.minion.RenderZombifiedPiglinTitanMinion;
import net.titans.render.projectile.RenderArrowTitan;
import net.titans.render.projectile.RenderHarcadiumArrow;
import net.titans.render.projectile.RenderItemProjectile;
import net.titans.render.projectile.RenderProtoBall;
import net.titans.render.projectile.RenderWebShot;

public class TheTitansEntityRenderers {
    public static void registerEntityRenderers(RegisterRenderers event) {
        Set<EntityType<?>> registered = new HashSet<>();
        registerRenderer(event, registered, TheTitansEntities.TITAN_SPIRIT, RenderTitanSpirit::new);
        registerRenderer(event, registered, TheTitansEntities.SNOW_GOLEM_TITAN, RenderSnowGolemTitan::new);
        registerRenderer(event, registered, TheTitansEntities.SLIME_TITAN, RenderSlimeTitan::new);
        registerRenderer(event, registered, TheTitansEntities.MAGMACUBE_TITAN, RenderMagmaCubeTitan::new);
        registerRenderer(event, registered, TheTitansEntities.OMEGAFISH, RenderOmegafish::new);
        registerRenderer(event, registered, TheTitansEntities.ZOMBIE_TITAN, RenderZombieTitan::new);
        registerRenderer(event, registered, TheTitansEntities.SKELETON_TITAN, RenderSkeletonTitan::new);
        registerRenderer(event, registered, TheTitansEntities.WITHER_SKELETON_TITAN, RenderSkeletonTitan::new);
        registerRenderer(event, registered, TheTitansEntities.CREEPER_TITAN, RenderCreeperTitan::new);
        registerRenderer(event, registered, TheTitansEntities.SPIDER_TITAN, RenderSpiderTitan::new);
        registerRenderer(event, registered, TheTitansEntities.CAVE_SPIDER_TITAN, RenderCaveSpiderTitan::new);
        registerRenderer(event, registered, TheTitansEntities.ZOMBIFIED_PIGLIN_TITAN, RenderZombifiedPiglinTitan::new);
        registerRenderer(event, registered, TheTitansEntities.BLAZE_TITAN, RenderBlazeTitan::new);
        registerRenderer(event, registered, TheTitansEntities.ENDER_COLOSSUS, RenderEnderColossus::new);
        registerRenderer(event, registered, TheTitansEntities.GHAST_TITAN, RenderGhastTitan::new);
        registerRenderer(event, registered, TheTitansEntities.IRON_GOLEM_TITAN, RenderIronGolemTitan::new);
        registerRenderer(event, registered, TheTitansEntities.WITHERZILLA, RenderWitherzilla::new);
        registerRenderer(event, registered, TheTitansEntities.WITHER_TURRET, RenderWitherTurret::new);
        registerRenderer(event, registered, TheTitansEntities.WITHER_TURRET_GROUND, RenderWitherTurretGround::new);
        registerRenderer(event, registered, TheTitansEntities.WITHER_TURRET_MORTAR, RenderWitherTurretMortar::new);
        registerRenderer(event, registered, TheTitansEntities.OMEGAFISH_MINION, RenderOmegafishMinion::new);
        registerRenderer(event, registered, TheTitansEntities.ZOMBIE_TITAN_MINION, RenderZombieTitanMinion::new);
        registerRenderer(event, registered, TheTitansEntities.SKELETON_TITAN_MINION, RenderSkeletonTitanMinion::new);
        registerRenderer(event, registered, TheTitansEntities.WITHER_SKELETON_TITAN_MINION, RenderWitherSkeletonTitanMinion::new);
        registerRenderer(event, registered, TheTitansEntities.CREEPER_TITAN_MINION, RenderCreeperTitanMinion::new);
        registerRenderer(event, registered, TheTitansEntities.SPIDER_TITAN_MINION, RenderSpiderTitanMinion::new);
        registerRenderer(event, registered, TheTitansEntities.CAVE_SPIDER_TITAN_MINION, RenderCaveSpiderTitanMinion::new);
        registerRenderer(event, registered, TheTitansEntities.ZOMBIFIED_PIGLIN_TITAN_MINION, RenderZombifiedPiglinTitanMinion::new);
        registerRenderer(event, registered, TheTitansEntities.BLAZE_TITAN_MINION, RenderBlazeTitanMinion::new);
        registerRenderer(event, registered, TheTitansEntities.ENDER_COLOSSUS_MINION, RenderEnderColossusMinion::new);
        registerRenderer(event, registered, TheTitansEntities.GHAST_TITAN_MINION, RenderGhastTitanMinion::new);
        registerRenderer(event, registered, TheTitansEntities.GHAST_GUARD_MINION, RenderGhastTitanMinion::new);
        registerRenderer(event, registered, TheTitansEntities.WITHER_MINION, WitherBossRenderer::new);
        registerRenderer(event, registered, TheTitansEntities.WITHERZILLA_MINION, WitherBossRenderer::new);
        registerRenderer(event, registered, TheTitansEntities.ZOMBIE_TITAN_GIANT_MINION, context -> new GiantMobRenderer(context, 6.0F));
        registerRenderer(event, registered, TheTitansEntities.DRAGON_MINION, EnderDragonRenderer::new);
        registerRenderer(event, registered, TheTitansEntities.ITEM_TITAN, RenderItemTitan::new);
        registerRenderer(event, registered, TheTitansEntities.EXPERIENCE_ORB_TITAN, RenderExperienceOrbTitan::new);
        registerRenderer(event, registered, TheTitansEntities.COLOR_LIGHTNING_BLOT, RenderColorLightningBolt::new);
        registerRenderer(event, registered, TheTitansEntities.ENDER_COLOSSUS_CRYSTAL, RenderEnderColossusCrystal::new);
        registerRenderer(event, registered, TheTitansEntities.HARCADIUM_ARROW, RenderHarcadiumArrow::new);
        registerRenderer(event, registered, TheTitansEntities.GROWTH_SERUM, ThrownItemRenderer::new);
        registerRenderer(event, registered, TheTitansEntities.ARROW_TITAN, RenderArrowTitan::new);
        registerRenderer(event, registered, TheTitansEntities.WEB_SHOT, RenderWebShot::new);
        registerRenderer(event, registered, TheTitansEntities.PROTO_BALL, RenderProtoBall::new);
        registerRenderer(event, registered, TheTitansEntities.MORTAR_WITHER_SKULL, WitherSkullRenderer::new);
        registerRenderer(
            event, registered, TheTitansEntities.BLAZE_TITAN_MINION_SMALL_FIREBALL, context -> new RenderItemProjectile(context, Items.FIRE_CHARGE, 0.75F)
        );
        registerRenderer(
            event, registered, TheTitansEntities.GHAST_TITAN_MINION_FIREBALL, context -> new RenderItemProjectile(context, Items.FIRE_CHARGE, 3.0F)
        );
        registerRenderer(event, registered, TheTitansEntities.SNOWBALL_TITAN, context -> new ThrownItemRenderer(context, 4.0F, true));
        registerRenderer(event, registered, TheTitansEntities.LIGHTNING_BALL, context -> new ThrownItemRenderer(context, 4.0F, true));
        registerRenderer(event, registered, TheTitansEntities.FIREBALL_TITAN, context -> new ThrownItemRenderer(context, 6.0F, true));
        registerRenderer(event, registered, TheTitansEntities.IRON_INGOT_TITAN, context -> new ThrownItemRenderer(context, 6.0F, true));
        registerRenderer(event, registered, TheTitansEntities.GUNPOWDER_TITAN, context -> new ThrownItemRenderer(context, 2.0F, true));
        registerRenderer(event, registered, TheTitansEntities.BLAZE_POWDER_TITAN, context -> new ThrownItemRenderer(context, 2.5F, true));
        registerRenderer(event, registered, TheTitansEntities.ENDER_PEARL_TITAN, context -> new ThrownItemRenderer(context, 4.0F, true));

        for (RegistryObject<EntityType<?>> entityType : TheTitansEntities.ENTITY_TYPES.getEntries()) {
            if (!registered.contains(entityType.get())) {
                registerBlankRenderer(event, (EntityType<?>)entityType.get());
            }
        }
    }

    public static void registerEntityRenderers(IEventBus modEventBus) {
        modEventBus.addListener((RegisterRenderers event) -> registerEntityRenderers(event));
    }

    private static <T extends Entity> void registerBlankRenderer(RegisterRenderers event, EntityType<?> entityType) {
        event.registerEntityRenderer(entityType, TheTitansEntityRenderers.BlankEntityRenderer::new);
    }

    private static void registerRenderer(
        RegisterRenderers event, Set<EntityType<?>> registered, RegistryObject<? extends EntityType<?>> registryObject, EntityRendererProvider provider
    ) {
        EntityType entityType = (EntityType)registryObject.get();
        event.registerEntityRenderer(entityType, provider);
        registered.add(entityType);
    }

    private static class BlankEntityRenderer<T extends Entity> extends EntityRenderer<T> {
        private static final ResourceLocation TEXTURE = new ResourceLocation("titan", "textures/entity/blank.png");

        protected BlankEntityRenderer(Context context) {
            super(context);
        }

        public void render(T entity, float entityYaw, float partialTicks, PoseStack poseStack, MultiBufferSource buffer, int packedLight) {
        }

        public ResourceLocation getTextureLocation(T entity) {
            return TEXTURE;
        }
    }
}
