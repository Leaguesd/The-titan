package net.titans.entity.ai.creepertitan;

import net.titans.animation.AIAnimation;
import net.titans.entity.titan.EntityCreeperTitan;

public class AnimationCreeperTitanAttack3 extends AIAnimation {
    private EntityCreeperTitan entity;

    public AnimationCreeperTitanAttack3(EntityCreeperTitan entity) {
        super(entity);
        this.entity = entity;
    }

    @Override
    public int getAnimationID() {
        return 4;
    }

    @Override
    public boolean isAutomatic() {
        return true;
    }

    @Override
    public int getDuration() {
        return 70;
    }

    @Override
    public boolean canContinueToUse() {
        return this.entity.getAnimationTick() <= this.getDuration() && !this.entity.isStunned ? super.canContinueToUse() : false;
    }

    public void tick() {
        if (this.entity.getTarget() != null && this.entity.getAnimationTick() < 32) {
            this.entity.getLookControl().setLookAt(this.entity.getTarget(), 5.0F, 40.0F);
        }
    }
}
