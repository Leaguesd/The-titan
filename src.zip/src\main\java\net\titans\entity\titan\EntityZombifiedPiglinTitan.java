package net.titans.entity.titan;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.Mth;
import net.minecraft.world.Difficulty;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityDimensions;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.Pose;
import net.minecraft.world.entity.SpawnGroupData;
import net.minecraft.world.entity.Entity.RemovalReason;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier.Builder;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.ItemLike;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.ServerLevelAccessor;
import net.minecraft.world.level.Level.ExplosionInteraction;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;
import net.titans.entity.EntityColorLightningBolt;
import net.titans.entity.IBossBarDisplay;
import net.titans.entity.ai.EntityAINearestTargetTitan;
import net.titans.entity.ai.zombifiedpiglintitan.AnimationZombifiedPiglinTitanAntiTitanAttack;
import net.titans.entity.ai.zombifiedpiglintitan.AnimationZombifiedPiglinTitanAttack1;
import net.titans.entity.ai.zombifiedpiglintitan.AnimationZombifiedPiglinTitanAttack2;
import net.titans.entity.ai.zombifiedpiglintitan.AnimationZombifiedPiglinTitanAttack3;
import net.titans.entity.ai.zombifiedpiglintitan.AnimationZombifiedPiglinTitanAttack4;
import net.titans.entity.ai.zombifiedpiglintitan.AnimationZombifiedPiglinTitanAttack5;
import net.titans.entity.ai.zombifiedpiglintitan.AnimationZombifiedPiglinTitanAttack6;
import net.titans.entity.ai.zombifiedpiglintitan.AnimationZombifiedPiglinTitanCreation;
import net.titans.entity.ai.zombifiedpiglintitan.AnimationZombifiedPiglinTitanDeath;
import net.titans.entity.ai.zombifiedpiglintitan.AnimationZombifiedPiglinTitanLightningAttack;
import net.titans.entity.ai.zombifiedpiglintitan.AnimationZombifiedPiglinTitanRangedAttack;
import net.titans.entity.ai.zombifiedpiglintitan.AnimationZombifiedPiglinTitanRoar;
import net.titans.entity.ai.zombifiedpiglintitan.AnimationZombifiedPiglinTitanStun;
import net.titans.entity.minion.EntityGhastGuardMinion;
import net.titans.entity.minion.EntityZombifiedPiglinTitanMinion;
import net.titans.entity.minion.EnumMinionType;
import net.titans.entity.projectile.EntityProtoBall;
import net.titans.loader.TheTitansEntities;
import net.titans.loader.TheTitansRegistries;
import net.titans.loader.TheTitansPredicateTargets;
import net.titans.loader.TheTitansSounds;
import net.titans.util.AnimationUtils;

public class EntityZombifiedPiglinTitan extends EntityTitan implements IEntityMultiPartTitan, IBossBarDisplay {
    private static final EntityDataAccessor<Boolean> BABY = SynchedEntityData.defineId(EntityZombifiedPiglinTitan.class, EntityDataSerializers.BOOLEAN);
    public final EntityTitanPart head = new EntityTitanPart(this, "head", 8.0F, 8.0F);
    public final EntityTitanPart body = new EntityTitanPart(this, "body", 8.0F, 12.0F);
    public final EntityTitanPart leftArm = new EntityTitanPart(this, "leftarm", 4.0F, 4.0F);
    public final EntityTitanPart rightArm = new EntityTitanPart(this, "rightarm", 4.0F, 4.0F);
    public final EntityTitanPart leftLeg = new EntityTitanPart(this, "leftleg", 4.0F, 12.0F);
    public final EntityTitanPart rightLeg = new EntityTitanPart(this, "rightleg", 4.0F, 12.0F);
    public boolean isStunned;

    public EntityZombifiedPiglinTitan(EntityType<? extends EntityTitan> entityType, Level level) {
        super(entityType, level);
        this.parts = new EntityTitanPart[]{this.head, this.body, this.leftArm, this.rightArm, this.leftLeg, this.rightLeg};
    }

    public EntityZombifiedPiglinTitan(Level level) {
        this((EntityType<? extends EntityTitan>)TheTitansEntities.ZOMBIFIED_PIGLIN_TITAN.get(), level);
    }

    public static Builder createAttributes() {
        return EntityTitan.createAttributes().add(Attributes.MAX_HEALTH, 40000.0).add(Attributes.ATTACK_DAMAGE, 1800.0);
    }

    @Override
    public ResourceLocation getBossBarTexture() {
        return ResourceLocation.tryBuild("titan", "textures/gui/bossbar/zombified_piglin_titan.png");
    }

    @Override
    public int getBossBarNameColor() {
        return 15373203;
    }

    @Override
    public int getBossBarWidth() {
        return 185;
    }

    @Override
    public int getBossBarHeight() {
        return 27;
    }

    @Override
    public int getBossBarInterval() {
        return 7;
    }

    @Override
    public int getBossBarVOffset() {
        return 0;
    }

    @Override
    public int getBossBarVHeight() {
        return 0;
    }

    @Override
    public int getBossBarTextOffset() {
        return 7;
    }

    @Override
    protected void registerGoals() {
        super.registerGoals();
        this.footID = 1;
        this.goalSelector.addGoal(1, new AnimationZombifiedPiglinTitanCreation(this));
        this.goalSelector.addGoal(1, new AnimationZombifiedPiglinTitanDeath(this));
        this.goalSelector.addGoal(1, new AnimationZombifiedPiglinTitanAntiTitanAttack(this));
        this.goalSelector.addGoal(1, new AnimationZombifiedPiglinTitanAttack1(this));
        this.goalSelector.addGoal(1, new AnimationZombifiedPiglinTitanAttack2(this));
        this.goalSelector.addGoal(1, new AnimationZombifiedPiglinTitanAttack3(this));
        this.goalSelector.addGoal(1, new AnimationZombifiedPiglinTitanAttack4(this));
        this.goalSelector.addGoal(1, new AnimationZombifiedPiglinTitanAttack5(this));
        this.goalSelector.addGoal(1, new AnimationZombifiedPiglinTitanAttack6(this));
        this.goalSelector.addGoal(1, new AnimationZombifiedPiglinTitanLightningAttack(this));
        this.goalSelector.addGoal(1, new AnimationZombifiedPiglinTitanRangedAttack(this));
        this.goalSelector.addGoal(1, new AnimationZombifiedPiglinTitanRoar(this));
        this.goalSelector.addGoal(1, new AnimationZombifiedPiglinTitanStun(this));
        this.targetSelector.addGoal(0, new EntityAINearestTargetTitan(this, EntitySnowGolemTitan.class, false));
        this.targetSelector.addGoal(0, new EntityAINearestTargetTitan(this, EntityIronGolemTitan.class, false));
        this.targetSelector
            .addGoal(
                0, new EntityAINearestTargetTitan<LivingEntity>(this, LivingEntity.class, 0, false, false, TheTitansPredicateTargets.ZombifiedPiglinTitan)
            );
    }

    public boolean isBaby() {
        return (Boolean)this.entityData.get(BABY);
    }

    public void setBaby(boolean baby) {
        this.entityData.set(BABY, baby);
        this.refreshTitanAttributes();
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(BABY, false);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        this.setBaby(tag.getBoolean("IsBaby"));
        this.isStunned = tag.getBoolean("IsStunned");
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putBoolean("IsBaby", this.isBaby());
        tag.putBoolean("IsStunned", this.isStunned);
    }

    @Override
    public SpawnGroupData finalizeSpawn(
        ServerLevelAccessor level, DifficultyInstance difficulty, MobSpawnType spawnType, @Nullable SpawnGroupData spawnGroupData, @Nullable CompoundTag tag
    ) {
        SpawnGroupData groupData = super.finalizeSpawn(level, difficulty, spawnType, spawnGroupData, null);
        this.setWaiting(true);
        if (level.getRandom().nextFloat() < 0.05F) {
            this.setBaby(true);
        }

        return groupData;
    }

    public Component getName() {
        return !this.isBaby()
            ? Component.translatable("entity.titan.zombified_piglin_titan")
            : Component.translatable("entity.titan.zombified_piglin_baby_titan");
    }

    protected EntityDimensions getDefaultDimensions(Pose pose) {
        float width = this.isBaby() ? 6.0F : 8.0F;
        float height = this.isBaby() ? 18.0F : 32.0F;
        float eyeHeight = this.isBaby() ? 14.8F : 27.6F;
        return EntityDimensions.scalable(width, height);
    }

    @Override
    protected void refreshAttributes() {
        if (this.level().getDifficulty() == Difficulty.HARD) {
            if (this.isBaby()) {
                this.getAttribute(Attributes.MAX_HEALTH).setBaseValue(20000.0 + (double)this.getExtraPower() * 1000.0);
            } else {
                this.getAttribute(Attributes.MAX_HEALTH).setBaseValue(40000.0 + (double)this.getExtraPower() * 2000.0);
            }

            this.getAttribute(Attributes.ATTACK_DAMAGE).setBaseValue(1800.0 + (double)this.getExtraPower() * 180.0);
        } else {
            if (this.isBaby()) {
                this.getAttribute(Attributes.MAX_HEALTH).setBaseValue(10000.0 + (double)this.getExtraPower() * 500.0);
            } else {
                this.getAttribute(Attributes.MAX_HEALTH).setBaseValue(20000.0 + (double)this.getExtraPower() * 1000.0);
            }

            this.getAttribute(Attributes.ATTACK_DAMAGE).setBaseValue(900.0 + (double)this.getExtraPower() * 90.0);
        }
    }

    @Override
    public boolean canAttack() {
        return true;
    }

    @Override
    public boolean canAttackEntity(Entity entity) {
        return super.canAttackEntity(entity) && !(entity instanceof EntityZombifiedPiglinTitanMinion) && !(entity instanceof EntityGhastGuardMinion);
    }

    @Override
    public boolean canBeHurtByPlayer() {
        return !this.isInvulnerable();
    }

    @Override
    public boolean shouldMove() {
        return this.getAnimationID() == 0 && !this.isStunned && !this.getWaiting() && this.getTarget() != null ? super.shouldMove() : false;
    }

    @Override
    public boolean canRegen() {
        return !this.isStunned;
    }

    @Override
    public int getRegenTime() {
        return 5;
    }

    @Override
    public boolean isArmored() {
        return this.deathTicks <= 0 && this.getTitanHealth() <= this.getTitanMaxHealth() / 4.0F;
    }

    @Override
    public SimpleParticleType getParticles() {
        return this.level().getRandom().nextFloat() < 0.25F ? ParticleTypes.POOF : ParticleTypes.SMOKE;
    }

    @Override
    public int getParticleCount() {
        return 6;
    }

    @Override
    public int getMinionCap() {
        int spawnCap = 200;
        if (this.getAnimationID() == 11 && this.getAnimationTick() > 80) {
            spawnCap *= 3;
        }

        return spawnCap;
    }

    @Override
    public int getPriestCap() {
        int spawnCap = 100;
        if (this.getAnimationID() == 11 && this.getAnimationTick() > 80) {
            spawnCap *= 3;
        }

        return spawnCap;
    }

    @Override
    public int getZealotCap() {
        int spawnCap = 50;
        if (this.getAnimationID() == 11 && this.getAnimationTick() > 80) {
            spawnCap *= 2;
        }

        return spawnCap;
    }

    @Override
    public int getBishopCap() {
        int spawnCap = 20;
        if (this.getAnimationID() == 11 && this.getAnimationTick() > 80) {
            spawnCap *= 2;
        }

        return spawnCap;
    }

    @Override
    public int getTemplarCap() {
        int spawnCap = 10;
        if (this.getAnimationID() == 11 && this.getAnimationTick() > 80) {
            spawnCap *= 2;
        }

        return spawnCap;
    }

    @Override
    public int getSpecialMinionCap() {
        return 5;
    }

    @Override
    public boolean canSpawnMinion() {
        boolean flag = (this.getInvulTime() > 1 || this.getAnimationID() == 11 && this.getAnimationTick() > 80) && this.tickCount % 20 == 0;
        float randomRate = this.random.nextFloat() * 100.0F;
        return flag || (double)randomRate < 5.0;
    }

    @Override
    public boolean canSpawnPriest() {
        boolean flag = (this.getInvulTime() > 1 || this.getAnimationID() == 11 && this.getAnimationTick() > 80) && this.tickCount % 20 == 0;
        float randomRate = this.random.nextFloat() * 100.0F;
        return flag || (double)randomRate < 2.5;
    }

    @Override
    public boolean canSpawnZealot() {
        boolean flag = (this.getInvulTime() > 1 || this.getAnimationID() == 11 && this.getAnimationTick() > 80) && this.tickCount % 20 == 0;
        float randomRate = this.random.nextFloat() * 100.0F;
        return flag || (double)randomRate < 1.25;
    }

    @Override
    public boolean canSpawnBishop() {
        boolean flag = (this.getInvulTime() > 1 || this.getAnimationID() == 11 && this.getAnimationTick() > 80) && this.tickCount % 20 == 0;
        float randomRate = this.random.nextFloat() * 100.0F;
        return flag || (double)randomRate < 0.625;
    }

    @Override
    public boolean canSpawnTemplar() {
        boolean flag = (this.getInvulTime() > 1 || this.getAnimationID() == 11 && this.getAnimationTick() > 80) && this.tickCount % 20 == 0;
        float randomRate = this.random.nextFloat() * 100.0F;
        return flag || (double)randomRate < 0.3125;
    }

    @Override
    public boolean canSpawnSpecialMinion() {
        boolean flag = (this.getInvulTime() > 1 || this.getAnimationID() == 11 && this.getAnimationTick() > 80) && this.tickCount % 20 == 0;
        float randomRate = this.random.nextFloat() * 100.0F;
        return flag || (double)randomRate < 0.3125;
    }

    @Override
    public EnumTitanStatus getTitanStatus() {
        return EnumTitanStatus.AVERAGE;
    }

    @Override
    public int getFootStepModifer() {
        return 5;
    }

    @Override
    public float getSpeed() {
        return this.isBaby()
            ? 0.6F + (float)this.getExtraPower() * 0.001F
            : (this.isArmored() ? 0.45F + (float)this.getExtraPower() * 0.001F : 0.3F + (float)this.getExtraPower() * 0.001F);
    }

    protected SoundEvent getAmbientSound() {
        return !this.getWaiting() && this.getAnimationID() != 13 && !this.isStunned ? (SoundEvent)TheTitansSounds.TITAN_ZOMBIFIED_PIGLIN_LIVING.get() : null;
    }

    protected SoundEvent getHurtSound(DamageSource damageSource) {
        return (SoundEvent)TheTitansSounds.TITAN_ZOMBIFIED_PIGLIN_GRUNT.get();
    }

    protected SoundEvent getDeathSound() {
        return (SoundEvent)TheTitansSounds.TITAN_ZOMBIFIED_PIGLIN_DEATH.get();
    }

    protected void playStepSound(BlockPos pos, BlockState state) {
        this.shakeNearbyPlayerCameras(4000.0);
        this.playSound((SoundEvent)TheTitansSounds.TITAN_STEP.get(), 10.0F, 1.0F);
        if (!this.getWaiting() && this.getAnimationID() != 13) {
            float f1 = this.getYRot() * (float) Math.PI / 180.0F;
            float f2 = Mth.sin(f1);
            float f3 = Mth.cos(f1);
            if (this.footID == 0) {
                this.collideWithEntities(
                    this.leftLeg,
                    this.level().getEntities(this, this.leftLeg.getBoundingBox().inflate(1.0, 1.0, 1.0).move((double)(f2 * 4.0F), 0.0, (double)(f3 * 4.0F)))
                );
                this.destroyBlocksInAABB(this.leftLeg.getBoundingBox().move(0.0, -1.0, 0.0));
                this.footID++;
            } else {
                this.collideWithEntities(
                    this.rightLeg,
                    this.level().getEntities(this, this.rightLeg.getBoundingBox().inflate(1.0, 1.0, 1.0).move((double)(f2 * 4.0F), 0.0, (double)(f3 * 4.0F)))
                );
                this.destroyBlocksInAABB(this.rightLeg.getBoundingBox().move(0.0, -1.0, 0.0));
                this.footID = 0;
            }
        }
    }

    @Override
    public void attackEntity(LivingEntity entity, float amount) {
        if (this.isArmored()) {
            amount *= 2.0F;
        }

        super.attackEntity(entity, amount);
    }

    @Override
    public boolean attackEntityFromPart(EntityTitanPart entityTitanPart, DamageSource damageSource, float amount) {
        if (entityTitanPart != this.head) {
            amount /= 3.0F;
        }

        this.hurt(damageSource, amount);
        return true;
    }

    @Override
    public boolean hurt(DamageSource damageSource, float amount) {
        if (this.isArmored()) {
            amount /= 3.0F;
        }

        if (this.isStunned) {
            amount *= 3.0F;
        }

        if (amount > 25.0F && damageSource.getEntity() instanceof LivingEntity && !this.isInvulnerable()) {
            for (Entity entity : this.level().getEntities(this, this.getBoundingBox().inflate(256.0, 256.0, 256.0))) {
                if (entity != null && entity instanceof LivingEntity) {
                    LivingEntity livingEntity = (LivingEntity)entity;
                    if (livingEntity instanceof EntityTitan) {
                        if (livingEntity instanceof EntityZombifiedPiglinTitan titan) {
                            titan.setTarget((LivingEntity)damageSource.getEntity());
                        }
                    } else if (livingEntity instanceof Mob mob) {
                        mob.setTarget((LivingEntity)damageSource.getEntity());
                    }
                }
            }
        }

        return super.hurt(damageSource, amount);
    }

    @Override
    protected void dropExperienceOrb() {
        for (int x = 0; x < 24; x++) {
            EntityExperienceOrbTitan experienceOrbTitan = new EntityExperienceOrbTitan(
                this.level(),
                this.getX() + (double)(this.random.nextFloat() * 12.0F - 6.0F),
                this.getY() + 4.0,
                this.getZ() + (double)(this.random.nextFloat() * 12.0F - 6.0F),
                20000
            );
            experienceOrbTitan.push(0.0, 1.0, 0.0);
            this.level().addFreshEntity(experienceOrbTitan);
        }
    }

    @Override
    protected void dropRateItem() {
        Map<ItemStack, Integer> drops = new HashMap<>();
        drops.put(new ItemStack(Blocks.GOLD_BLOCK), 64);
        Entry<ItemStack, Integer> entry = drops.entrySet().stream().toList().get(this.random.nextInt(drops.entrySet().size()));
        ItemStack itemStack = entry.getKey();
        int count = entry.getValue();
        EntityItemTitan itemTitan = new EntityItemTitan(
            this.level(),
            this.getX() + (double)(this.random.nextFloat() * 12.0F - 6.0F),
            this.getY() + 4.0,
            this.getZ() + (double)(this.random.nextFloat() * 12.0F - 6.0F),
            itemStack,
            count
        );
        itemTitan.setPickUpDelay(40);
        this.level().addFreshEntity(itemTitan);
    }

    @Override
    protected void dropAllItem() {
        Map<ItemStack, Integer> drops = new HashMap<>();
        Map<ItemStack, Integer> rateDrops = new HashMap<>();
        drops.put(new ItemStack(Items.ROTTEN_FLESH), 128);
        drops.put(new ItemStack(Items.GOLD_NUGGET), 128);
        drops.put(new ItemStack(Items.BONE), 32);
        drops.put(new ItemStack(Items.COAL), 32);
        drops.put(new ItemStack(Items.GOLD_INGOT), 64);
        drops.put(new ItemStack(Items.STICK), 16);
        drops.put(new ItemStack(Items.EMERALD), 12);
        drops.put(new ItemStack(Items.DIAMOND), 12);
        rateDrops.put(new ItemStack(Items.ROTTEN_FLESH), 128);
        rateDrops.put(new ItemStack(Items.GOLD_NUGGET), 128);
        rateDrops.put(new ItemStack(Items.BONE), 32);
        rateDrops.put(new ItemStack(Items.COAL), 32);
        rateDrops.put(new ItemStack(Items.GOLD_INGOT), 32);
        rateDrops.put(new ItemStack(Items.EMERALD), 12);
        rateDrops.put(new ItemStack(Items.DIAMOND), 12);
        rateDrops.put(new ItemStack((ItemLike)TheTitansRegistries.HARCADIUM.get()), 8);

        for (Entry<ItemStack, Integer> entry : drops.entrySet()) {
            ItemStack itemStack = entry.getKey();
            int count = entry.getValue();
            EntityItemTitan itemTitan = new EntityItemTitan(
                this.level(),
                this.getX() + (double)(this.random.nextFloat() * 12.0F - 6.0F),
                this.getY() + 4.0,
                this.getZ() + (double)(this.random.nextFloat() * 12.0F - 6.0F),
                itemStack,
                count
            );
            itemTitan.setPickUpDelay(40);
            this.level().addFreshEntity(itemTitan);
        }

        for (Entry<ItemStack, Integer> entry : rateDrops.entrySet()) {
            ItemStack itemStack = entry.getKey();
            int count = entry.getValue();
            int randomCount = this.random.nextInt(count) + 1;
            EntityItemTitan itemTitan = new EntityItemTitan(
                this.level(),
                this.getX() + (double)(this.random.nextFloat() * 12.0F - 6.0F),
                this.getY() + 4.0,
                this.getZ() + (double)(this.random.nextFloat() * 12.0F - 6.0F),
                itemStack,
                randomCount
            );
            itemTitan.setPickUpDelay(40);
            this.level().addFreshEntity(itemTitan);
        }

        if (this.random.nextInt(5) == 0) {
            EntityItemTitan itemTitan = new EntityItemTitan(
                this.level(),
                this.getX() + (double)(this.random.nextFloat() * 12.0F - 6.0F),
                this.getY() + 4.0,
                this.getZ() + (double)(this.random.nextFloat() * 12.0F - 6.0F),
                new ItemStack(Blocks.BEDROCK),
                this.random.nextInt(2) + 1
            );
            itemTitan.setPickUpDelay(40);
            this.level().addFreshEntity(itemTitan);
        }
    }

    @Override
    protected void tickTitanDeath() {
        super.tickTitanDeath();
        AnimationUtils.sendPacket(this, 10);
        this.isStunned = false;
        if (this.deathTicks >= 500) {
            this.setInvulTime(this.getInvulTime() + 8);
            this.setAnimationTick(this.getAnimationTick() - 1);
            float f = (this.random.nextFloat() - 0.5F) * 12.0F;
            float f1 = (this.random.nextFloat() - 0.5F) * 3.0F;
            float f2 = (this.random.nextFloat() - 0.5F) * 12.0F;
            this.level()
                .addParticle(ParticleTypes.EXPLOSION, this.getX() + (double)f, this.getY() + 2.0 + (double)f1, this.getZ() + (double)f2, 0.0, 0.0, 0.0);
        }

        if (this.getInvulTime() >= this.getThreashHold()) {
            this.onDeath();
            if (!this.level().isClientSide() && !this.isRemoved()) {
                for (EntityTitanPart part : this.parts) {
                    part.remove(RemovalReason.KILLED);
                }

                this.removeTitan(RemovalReason.KILLED);
            }
        }
    }

    @Override
    public void finalizeMinionSummon(Entity entity, EnumMinionType minionType) {
        if (minionType != EnumMinionType.SPECIAL && entity instanceof EntityZombifiedPiglinTitanMinion zombifiedPiglinTitanMinion) {
            zombifiedPiglinTitanMinion.setBaby(this.isBaby());
            zombifiedPiglinTitanMinion.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 40, 4, true, false));
            zombifiedPiglinTitanMinion.addEffect(new MobEffectInstance(MobEffects.FIRE_RESISTANCE, Integer.MAX_VALUE, 0, true, false));
        }
    }

    public void animationTick() {
        if (this.getAnimationID() == 13) {
            this.addDayTime(14000L, 50L);
            if (this.getAnimationTick() == 1) {
                this.playSound((SoundEvent)TheTitansSounds.TITAN_BIRTH.get(), 1000.0F, 1.0F);
            }

            if (this.getAnimationTick() == 40) {
                this.playSound((SoundEvent)TheTitansSounds.TITAN_RUMBLE.get(), this.getSoundVolume(), 1.0F);
            }

            if (this.getAnimationTick() == 130) {
                this.playSound((SoundEvent)TheTitansSounds.TITAN_SKELETON_GETUP.get(), this.getSoundVolume(), 1.0F);
            }

            if (this.getAnimationTick() == 240) {
                this.playSound((SoundEvent)TheTitansSounds.TITAN_ZOMBIE_ROAR.get(), this.getSoundVolume(), 1.0F);
            }

            if (this.getAnimationTick() == 110 || this.getAnimationTick() == 150 || this.getAnimationTick() == 170) {
                this.playStepSound(new BlockPos(0, 0, 0), Blocks.STONE.defaultBlockState());
                this.playSound((SoundEvent)TheTitansSounds.TITAN_PRESS.get(), this.getSoundVolume(), 1.0F);
            }
        }

        if (this.getAnimationID() == 1 && this.getAnimationTick() == 12 && this.getTarget() != null) {
            this.shakeNearbyPlayerCameras(20000.0);
            if (this.isArmored()) {
                this.playSound((SoundEvent)TheTitansSounds.TITAN_STRIKE.get(), 20.0F, 1.0F);
                this.playSound((SoundEvent)TheTitansSounds.TITAN_STRIKE.get(), 20.0F, 1.05F);
                this.playSound((SoundEvent)TheTitansSounds.TITAN_STRIKE.get(), 20.0F, 1.1F);

                for (int i = 0; i < 3; i++) {
                    this.collideWithEntities(this.body, this.level().getEntities(this, this.body.getBoundingBox().inflate(26.0, 26.0, 26.0)));
                }
            }

            float amount = (float)this.getAttributeBaseValue(Attributes.ATTACK_DAMAGE);
            int knockbackAmount = this.getKnockbackAmount();
            this.collideWithEntities(this.body, this.level().getEntities(this, this.body.getBoundingBox().inflate(48.0, 48.0, 48.0)));

            for (int i = 0; i < 6; i++) {
                this.attackEntity(this.getTarget(), amount);
            }

            this.knockbackEntity(this.getTarget(), (float)knockbackAmount);

            for (Entity entity : this.level().getEntities(this.getTarget(), this.getTarget().getBoundingBox().inflate(8.0, 8.0, 8.0))) {
                if (entity != null && entity != this && entity instanceof LivingEntity && this.canAttackEntity(entity)) {
                    LivingEntity livingEntity = (LivingEntity)entity;

                    for (int i = 0; i < 2; i++) {
                        this.attackEntity(livingEntity, amount * 2.0F);
                    }

                    this.knockbackEntity(livingEntity, (float)knockbackAmount);
                }
            }
        }

        if (this.getAnimationID() == 2) {
            if (this.getAnimationTick() == 24) {
                this.playSound((SoundEvent)TheTitansSounds.TITAN_SWING.get(), 5.0F, 1.25F);
            }

            if (this.getAnimationTick() == 26 && this.getTarget() != null) {
                float amount = (float)this.getAttributeBaseValue(Attributes.ATTACK_DAMAGE);
                int knockbackAmount = this.getKnockbackAmount();
                this.collideWithEntities(this.head, this.level().getEntities(this, this.head.getBoundingBox().inflate(4.0, 2.0, 4.0)));

                for (int i = 0; i < 2; i++) {
                    this.attackEntity(this.getTarget(), amount);
                }

                this.knockbackEntity(this.getTarget(), (float)knockbackAmount);
                this.getTarget().push(0.0, 2.0, 0.0);

                for (Entity entityx : this.level().getEntities(this.getTarget(), this.getTarget().getBoundingBox().inflate(6.0, 2.0, 6.0))) {
                    if (entityx != null && entityx != this && entityx instanceof LivingEntity && this.canAttackEntity(entityx)) {
                        LivingEntity livingEntity = (LivingEntity)entityx;
                        this.attackEntity(livingEntity, amount);
                        this.knockbackEntity(livingEntity, (float)knockbackAmount);
                        livingEntity.push(0.0, 2.0, 0.0);
                    }
                }
            }
        }

        if (this.getAnimationID() == 3) {
            if (this.getAnimationTick() == 24) {
                this.playSound((SoundEvent)TheTitansSounds.TITAN_SWING.get(), 5.0F, 1.25F);
            }

            if (this.getAnimationTick() == 32) {
                this.shakeNearbyPlayerCameras(20000.0);
                this.playSound((SoundEvent)TheTitansSounds.TITAN_STRIKE.get(), 20.0F, 1.0F);
                double d8 = 8.0;
                Vec3 vec3 = this.getViewVector(1.0F);
                double dx = vec3.x * d8;
                double dz = vec3.z * d8;
                float amount = (float)this.getAttributeBaseValue(Attributes.ATTACK_DAMAGE);
                int knockbackAmount = this.getKnockbackAmount();
                this.collideWithEntities(this.body, this.level().getEntities(this, this.body.getBoundingBox().inflate(16.0, 8.0, 16.0)));

                for (Entity entityxx : this.level().getEntities(this, this.getBoundingBox().inflate(32.0, 2.0, 32.0).move(dx, -4.0, dz))) {
                    if (entityxx != null && entityxx instanceof LivingEntity && this.canAttackEntity(entityxx)) {
                        LivingEntity livingEntity = (LivingEntity)entityxx;
                        this.attackEntity(livingEntity, amount);
                        this.knockbackEntity(livingEntity, (float)knockbackAmount);
                    }
                }
            }
        }

        if (this.getAnimationID() == 4 && this.getAnimationTick() == 54) {
            this.shakeNearbyPlayerCameras(20000.0);
            this.playSound((SoundEvent)TheTitansSounds.TITAN_STRIKE.get(), 20.0F, 1.0F);
            double d8 = 8.0;
            Vec3 vec3 = this.getViewVector(1.0F);
            double dx = vec3.x * d8;
            double dz = vec3.z * d8;
            float amount = (float)this.getAttributeBaseValue(Attributes.ATTACK_DAMAGE);
            int knockbackAmount = this.getKnockbackAmount();
            this.collideWithEntities(this.body, this.level().getEntities(this, this.body.getBoundingBox().inflate(16.0, 8.0, 16.0)));

            for (Entity entityxxx : this.level().getEntities(this, this.getBoundingBox().inflate(32.0, 2.0, 32.0).move(dx, -4.0, dz))) {
                if (entityxxx != null && entityxxx instanceof LivingEntity && this.canAttackEntity(entityxxx)) {
                    LivingEntity livingEntity = (LivingEntity)entityxxx;
                    this.attackEntity(livingEntity, amount * 3.0F);
                    this.knockbackEntity(livingEntity, (float)knockbackAmount);
                }
            }
        }

        if (this.getAnimationID() == 5) {
            if (this.getAnimationTick() == 34) {
                this.playSound((SoundEvent)TheTitansSounds.LIGHTNING_CHARGE.get(), 100.0F, 1.0F);
            }

            if (this.getAnimationTick() <= 50 && this.getAnimationTick() >= 20) {
                float ex = this.isBaby() ? 4.5F : 9.5F;
                float fl = this.yBodyRot * (float) Math.PI / 180.0F;
                float fl1 = Mth.sin(fl);
                float fl2 = Mth.cos(fl);
                EntityColorLightningBolt colorLightningBolt1 = new EntityColorLightningBolt(this.level(), 1.0F, 0.0F, 0.0F);
                EntityColorLightningBolt colorLightningBolt2 = new EntityColorLightningBolt(this.level(), 1.0F, 0.0F, 0.0F);
                colorLightningBolt1.setPos(
                    this.getX() - (double)(fl2 * ex), this.getY() + (this.isBaby() ? 13.0 : 26.0), this.getZ() - (double)(fl1 * ex)
                );
                colorLightningBolt2.setPos(
                    this.getX() + (double)(fl2 * ex), this.getY() + (this.isBaby() ? 13.0 : 26.0), this.getZ() + (double)(fl1 * ex)
                );
                if (!this.level().isClientSide()) {
                    this.level().addFreshEntity(colorLightningBolt1);
                    this.level().addFreshEntity(colorLightningBolt2);
                }

                if (this.getTarget() == null) {
                    this.heal(50.0F);
                }
            }

            if (this.getAnimationTick() == 64) {
                this.playSound((SoundEvent)TheTitansSounds.LIGHTNING_THROW.get(), 100.0F, 1.0F);
                double d8 = this.isBaby() ? 6.0 : 12.0;
                Vec3 vec3 = this.getViewVector(1.0F);
                double dx = vec3.x * d8;
                double dz = vec3.z * d8;
                if (!this.level().isClientSide()) {
                    this.level().explode(this, this.getX() + dx, this.getY() + 26.0, this.getZ() + dz, 1.0F, false, ExplosionInteraction.MOB);
                }

                EntityColorLightningBolt colorLightningBolt = new EntityColorLightningBolt(this.level(), 1.0F, 0.0F, 0.0F);
                colorLightningBolt.setPos(this.getX() + dx, this.getY() + (this.isBaby() ? 9.0 : 18.0), this.getZ() + dz);
                if (!this.level().isClientSide()) {
                    this.level().addFreshEntity(colorLightningBolt);
                }

                if (this.getTarget() != null) {
                    if (!this.level().isClientSide()) {
                        this.level()
                            .explode(
                                this, this.getTarget().getX(), this.getTarget().getY(), this.getTarget().getZ(), 2.0F, false, ExplosionInteraction.MOB
                            );
                    }

                    EntityColorLightningBolt colorLightningBolt1x = new EntityColorLightningBolt(this.level(), 1.0F, 0.0F, 0.0F);
                    colorLightningBolt1x.setPos(this.getTarget().getX(), this.getTarget().getY(), this.getTarget().getZ());
                    if (!this.level().isClientSide()) {
                        this.level().addFreshEntity(colorLightningBolt1x);
                    }

                    float amount = (float)this.getAttributeBaseValue(Attributes.ATTACK_DAMAGE);
                    int knockbackAmount = this.getKnockbackAmount();
                    this.attackEntity(this.getTarget(), amount * 3.0F);
                    this.knockbackEntity(this.getTarget(), (float)knockbackAmount);
                    this.getTarget().push(0.0, 1.0 + this.random.nextDouble(), 0.0);

                    for (Entity entityxxxx : this.level().getEntities(this.getTarget(), this.getTarget().getBoundingBox().inflate(12.0, 12.0, 12.0))) {
                        if (entityxxxx != null && entityxxxx != this && entityxxxx instanceof LivingEntity && this.canAttackEntity(entityxxxx)) {
                            LivingEntity livingEntity = (LivingEntity)entityxxxx;
                            if (!this.level().isClientSide()) {
                                this.level()
                                    .explode(
                                        this, livingEntity.getX(), livingEntity.getY(), livingEntity.getZ(), 2.0F, false, ExplosionInteraction.MOB
                                    );
                            }

                            EntityColorLightningBolt colorLightningBolt2x = new EntityColorLightningBolt(this.level(), 1.0F, 0.0F, 0.0F);
                            colorLightningBolt2x.setPos(livingEntity.getX(), livingEntity.getY(), livingEntity.getZ());
                            if (!this.level().isClientSide()) {
                                this.level().addFreshEntity(colorLightningBolt2x);
                            }

                            this.attackEntity(livingEntity, amount);
                            this.knockbackEntity(livingEntity, (float)knockbackAmount);
                            livingEntity.push(0.0, 1.0 + this.random.nextDouble(), 0.0);
                        }
                    }
                }
            }
        }

        if (this.getAnimationID() == 6 && (this.getAnimationTick() == 60 || this.getAnimationTick() == 104)) {
            this.shakeNearbyPlayerCameras(20000.0);
            this.playSound((SoundEvent)TheTitansSounds.TITAN_SLAM.get(), 100.0F, 1.0F);
            this.playSound((SoundEvent)TheTitansSounds.TITAN_PRESS.get(), 100.0F, 1.0F);
            float amount = (float)this.getAttributeBaseValue(Attributes.ATTACK_DAMAGE);
            this.collideWithEntities(this.body, this.level().getEntities(this, this.body.getBoundingBox().inflate(16.0, 8.0, 16.0)));

            for (Entity entityxxxxx : this.level().getEntities(this, this.getBoundingBox().inflate(32.0, 2.0, 32.0))) {
                if (entityxxxxx != null && entityxxxxx instanceof LivingEntity && this.canAttackEntity(entityxxxxx)) {
                    LivingEntity livingEntityx = (LivingEntity)entityxxxxx;
                    this.attackEntity(livingEntityx, amount);
                    livingEntityx.push(0.0, 1.0 + this.random.nextDouble() + this.random.nextDouble(), 0.0);
                }
            }
        }

        if (this.getAnimationID() == 7) {
            if (this.getAnimationTick() == 120) {
                this.shakeNearbyPlayerCameras(20000.0);
                this.playSound((SoundEvent)TheTitansSounds.TITAN_SLAM.get(), 100.0F, 1.0F);
                this.playSound((SoundEvent)TheTitansSounds.TITAN_PRESS.get(), 100.0F, 1.0F);
                double d8x = 36.0;
                Vec3 vec3x = this.getViewVector(1.0F);
                double dxx = vec3x.x * d8x;
                double dzx = vec3x.z * d8x;
                float amount = (float)this.getAttributeBaseValue(Attributes.ATTACK_DAMAGE);
                int knockbackAmount = this.getKnockbackAmount();
                this.collideWithEntities(this.body, this.level().getEntities(this, this.body.getBoundingBox().inflate(16.0, 8.0, 16.0)));

                for (Entity entityxxxxxx : this.level().getEntities(this, this.getBoundingBox().inflate(24.0, 2.0, 24.0).move(dxx, -2.0, dzx))) {
                    if (entityxxxxxx != null && entityxxxxxx instanceof LivingEntity && this.canAttackEntity(entityxxxxxx)) {
                        LivingEntity livingEntityx = (LivingEntity)entityxxxxxx;
                        this.attackEntity(livingEntityx, amount * 15.0F);
                        this.knockbackEntity(livingEntityx, (float)knockbackAmount);
                    }
                }
            }

            if (this.getAnimationTick() == 122) {
                double d8x = this.isBaby() ? 16.0 : 32.0;
                Vec3 vec3x = this.getViewVector(1.0F);
                double dxx = vec3x.x * d8x;
                double dzx = vec3x.z * d8x;
                int x = Mth.floor(this.getX() + dxx);
                int y = Mth.floor(this.getY());
                int z = Mth.floor(this.getZ() + dzx);
                BlockPos blockPos = new BlockPos(x, y, z);
                BlockState blockState = this.level().getBlockState(blockPos);
                if (!blockState.isAir()) {
                    this.playSound((SoundEvent)TheTitansSounds.TITAN_STRIKE.get(), 20.0F, 1.0F);
                    this.playSound((SoundEvent)TheTitansSounds.TITAN_SLAM.get(), 20.0F, 1.0F);
                }

                for (int rangeX = -4; rangeX <= 4; rangeX++) {
                    for (int rangeY = -1; rangeY <= 1; rangeY++) {
                        for (int rangeZ = -4; rangeZ <= 4; rangeZ++) {
                            int posX = x + rangeX;
                            int posY = y + rangeY;
                            int posZ = z + rangeZ;
                            BlockPos pos = new BlockPos(posX, posY, posZ);
                            BlockState state = this.level().getBlockState(pos);
                            Block block = state.getBlock();
                            if (!state.isAir() && block == Blocks.GRASS_BLOCK) {
                                this.level().setBlockAndUpdate(pos, Blocks.DIRT.defaultBlockState());
                            }

                            if (block.getExplosionResistance() <= 1.5F
                                && !state.isAir()
                                && block != Blocks.NETHERRACK
                                && block != Blocks.DIRT
                                && block != Blocks.GRASS_BLOCK
                                && block != Blocks.GLASS
                                && block != Blocks.GLASS_PANE) {
                                this.playSound(SoundEvents.ANVIL_LAND, 20.0F, 0.5F);
                                AnimationUtils.sendPacket(this, 8);
                                this.isStunned = true;
                            }
                        }
                    }
                }
            }
        }

        if (this.getAnimationID() == 8) {
            if (this.getAnimationTick() == 140 || this.getAnimationTick() == 300 || this.getAnimationTick() == 330) {
                this.playSound((SoundEvent)TheTitansSounds.SLASH_FLESH.get(), 20.0F, 1.0F);
                this.attackEntityFromPart(this.head, this.damageSources().generic(), 1000.0F);
            }

            if (this.getAnimationTick() == 400) {
                this.playSound((SoundEvent)TheTitansSounds.TITAN_ZOMBIE_ROAR.get(), 1000.0F, 0.95F);
            }

            if (this.getAnimationTick() == 530) {
                this.isStunned = false;
            }
        }

        if (this.getAnimationID() == 9 && this.getAnimationTick() >= 104 && this.getAnimationTick() <= 106) {
            this.playSound((SoundEvent)TheTitansSounds.SLASH_FLESH.get(), 10.0F, 1.0F);
            double d8x = 24.0;
            Vec3 vec3x = this.getViewVector(1.0F);
            double dxx = vec3x.x * d8x;
            double dzx = vec3x.z * d8x;
            float amount = (float)this.getAttributeBaseValue(Attributes.ATTACK_DAMAGE);
            int knockbackAmount = this.getKnockbackAmount();
            this.collideWithEntities(this.body, this.level().getEntities(this, this.body.getBoundingBox().inflate(16.0, 8.0, 16.0)));

            for (Entity entityxxxxxxx : this.level().getEntities(this, this.getBoundingBox().inflate(16.0, 1.0, 16.0).move(dxx, 0.0, dzx))) {
                if (entityxxxxxxx != null && entityxxxxxxx instanceof LivingEntity && this.canAttackEntity(entityxxxxxxx)) {
                    LivingEntity livingEntityx = (LivingEntity)entityxxxxxxx;
                    this.attackEntity(livingEntityx, amount * 4.0F);
                    this.knockbackEntity(livingEntityx, (float)knockbackAmount);
                }
            }
        }

        if (this.getAnimationID() == 10) {
            if (this.getAnimationTick() == 30 || this.getAnimationTick() == 70) {
                this.playStepSound(new BlockPos(0, 0, 0), Blocks.STONE.defaultBlockState());
            }

            if (this.getAnimationTick() == 190) {
                this.shakeNearbyPlayerCameras(10000.0);
                this.playSound((SoundEvent)TheTitansSounds.TITAN_FALL.get(), 20.0F, 1.0F);
                this.playSound((SoundEvent)TheTitansSounds.GROUND_SMASH.get(), 20.0F, 1.0F);

                for (int i = 0; i < 2; i++) {
                    this.collideWithEntities(this.leftLeg, this.level().getEntities(this, this.leftLeg.getBoundingBox().inflate(48.0, 48.0, 48.0)));
                    this.collideWithEntities(this.rightLeg, this.level().getEntities(this, this.rightLeg.getBoundingBox().inflate(48.0, 48.0, 48.0)));
                }
            }

            if (this.getAnimationTick() == 200) {
                this.playSound((SoundEvent)TheTitansSounds.DISTANT_LARGE_FALL.get(), 10000.0F, 1.0F);
            }
        }

        if (this.getAnimationID() == 11) {
            if (this.getAnimationTick() == 20) {
                this.playSound((SoundEvent)TheTitansSounds.TITAN_ZOMBIE_ROAR.get(), 1000.0F, 1.0F);
                this.collideWithEntities(this.head, this.level().getEntities(this, this.head.getBoundingBox().inflate(64.0, 64.0, 64.0)));

                for (Entity entityxxxxxxxx : this.level().getEntities(this, this.getBoundingBox().inflate(64.0, 64.0, 64.0))) {
                    if (entityxxxxxxxx != null && entityxxxxxxxx instanceof LivingEntity && this.canAttackEntity(entityxxxxxxxx)) {
                        LivingEntity livingEntityx = (LivingEntity)entityxxxxxxxx;
                        this.attackEntity(livingEntityx, 40.0F);
                    }
                }
            }

            if (this.getAnimationTick() >= 20) {
                for (Entity entityxxxxxxxxx : this.level().getEntities(this, this.getBoundingBox().inflate(64.0, 64.0, 64.0))) {
                    if (entityxxxxxxxxx != null && entityxxxxxxxxx instanceof LivingEntity && this.canAttackEntity(entityxxxxxxxxx)) {
                        LivingEntity livingEntityx = (LivingEntity)entityxxxxxxxxx;
                        if (!this.level().isClientSide()) {
                            livingEntityx.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 20, 4));
                        }
                    }
                }
            }
        }

        if (this.getAnimationID() == 12 && this.getAnimationTick() == 55 && this.getTarget() != null) {
            for (int i = 0; i < 4 + 2 * this.level().getDifficulty().getId(); i++) {
                double d8x = 12.0;
                Vec3 vec3x = this.getViewVector(1.0F);
                double dxx = vec3x.x * d8x;
                double dzx = vec3x.z * d8x;
                double d0 = this.head.getX() + dxx;
                double d1 = this.head.getY();
                double d2 = this.head.getZ() + dzx;
                double d3 = this.getTarget().getX() + this.getTarget().getDeltaMovement().x - d0;
                double d4 = this.getTarget().getY() + (double)this.getTarget().getEyeHeight() - 8.0 - d1;
                double d5 = this.getTarget().getZ() + this.getTarget().getDeltaMovement().z - d2;
                double d6 = Math.sqrt(d3 * d3 + d5 * d5);
                int knockbackAmount = 5;
                EntityProtoBall entityProtoBall = new EntityProtoBall(this.level());
                entityProtoBall.setPos(d0, d1, d2);
                entityProtoBall.shoot(d3, d4 + d6, d5, 0.95F, 45.0F - (float)this.level().getDifficulty().getId() * 5.0F);
                entityProtoBall.setDeltaMovement(
                    entityProtoBall.getDeltaMovement().x * 1.5, entityProtoBall.getDeltaMovement().y, entityProtoBall.getDeltaMovement().z * 1.5
                );
                entityProtoBall.setOwner(this);
                if (!this.level().isClientSide()) {
                    this.level().addFreshEntity(entityProtoBall);
                }

                if (this.distanceToSqr(this.getTarget()) < 400.0) {
                    this.attackEntity(this.getTarget(), 10.0F);
                    this.knockbackEntity(this.getTarget(), (float)knockbackAmount);
                }
            }
        }
    }

    @Override
    public void tick() {
        super.tick();
        this.refreshDimensions();
        this.checkWaiting(16.0);
        if (this.getAnimationID() == 0 && !this.isPassenger() && !this.getWaiting() && !this.isStunned) {
            if (this.getTarget() != null && this.distanceToSqr(this.getTarget()) > this.getMeleeRange() + (!this.getTarget().onGround() ? 1000.0 : 8000.0)) {
                if (this.getY() <= this.getTarget().getY() + 12.0 && this.getY() < 256.0 - (double)this.getBbHeight()) {
                    this.fallDistance = 0.0F;
                    this.setTitanDeltaMovement(this.getDeltaMovement().x, this.getDeltaMovement().y + 0.9 - this.getDeltaMovement().y, this.getDeltaMovement().z);
                    if (this.getDeltaMovement().y < 0.0) {
                        this.setTitanDeltaMovement(this.getDeltaMovement().x, 0.0, this.getDeltaMovement().z);
                    }
                }

                this.setTitanDeltaMovement(this.getDeltaMovement().x, this.getDeltaMovement().y * 0.6, this.getDeltaMovement().z);
            }

            if (!this.onGround()) {
                float f3 = (this.random.nextFloat() - 0.5F) * 10.0F;
                float f4 = (this.random.nextFloat() - 0.5F) * 1.0F;
                float f5 = (this.random.nextFloat() - 0.5F) * 10.0F;
                this.level()
                    .addParticle(
                        ParticleTypes.EXPLOSION, this.getX() + (double)f3, this.getY() + 5.0 + (double)f4, this.getZ() + (double)f5, 0.0, 0.0, 0.0
                    );
            }
        }

        if (this.tickCount > 5) {
            float f = this.yBodyRot * (float) Math.PI / 180.0F;
            float f1 = Mth.sin(f);
            float f2 = Mth.cos(f);
            if (this.isBaby()) {
                this.head.setSize(6.0F, 6.0F);
                this.body.setSize(3.5F, 6.0F);
                this.leftArm.setSize(2.0F, 2.0F);
                this.rightArm.setSize(2.0F, 2.0F);
                this.leftLeg.setSize(2.0F, 6.0F);
                this.rightLeg.setSize(2.0F, 6.0F);
            } else {
                this.head.setSize(8.0F, 8.0F);
                this.body.setSize(7.0F, 12.0F);
                this.leftArm.setSize(4.0F, 4.0F);
                this.rightArm.setSize(4.0F, 4.0F);
                this.leftLeg.setSize(4.0F, 12.0F);
                this.rightLeg.setSize(4.0F, 12.0F);
            }

            this.head.moveTo(this.getX(), this.getY() + (this.isBaby() ? 12.0 : 24.0), this.getZ());
            this.body.moveTo(this.getX(), this.getY() + (this.isBaby() ? 6.0 : 12.0), this.getZ());
            this.leftArm
                .moveTo(
                    this.getX() - (double)f2 * (this.isBaby() ? 3.0 : 6.0),
                    this.getY() + (this.isBaby() ? 10.0 : 20.0),
                    this.getZ() - (double)f1 * (this.isBaby() ? 3.0 : 6.0)
                );
            this.rightArm
                .moveTo(
                    this.getX() + (double)f2 * (this.isBaby() ? 3.0 : 6.0),
                    this.getY() + (this.isBaby() ? 10.0 : 20.0),
                    this.getZ() + (double)f1 * (this.isBaby() ? 3.0 : 6.0)
                );
            this.leftLeg
                .moveTo(
                    this.getX() - (double)f2 * (this.isBaby() ? 1.0 : 2.0), this.getY(), this.getZ() - (double)f1 * (this.isBaby() ? 1.0 : 2.0)
                );
            this.rightLeg
                .moveTo(
                    this.getX() + (double)f2 * (this.isBaby() ? 1.0 : 2.0), this.getY(), this.getZ() + (double)f1 * (this.isBaby() ? 1.0 : 2.0)
                );
            if (this.isAlive() && !this.isStunned) {
                for (EntityTitanPart part : this.parts) {
                    this.collideWithEntities(part, this.level().getEntities(this, part.getBoundingBox().inflate(1.0, 0.0, 1.0)));
                }
            }

            this.destroyBlocksInAABB(this.head.getBoundingBox());
            this.destroyBlocksInAABB(this.body.getBoundingBox());
            this.destroyBlocksInAABB(this.leftArm.getBoundingBox());
            this.destroyBlocksInAABB(this.rightArm.getBoundingBox());
            this.destroyBlocksInAABB(this.leftLeg.getBoundingBox().inflate(1.0, 0.0, 1.0));
            this.destroyBlocksInAABB(this.rightLeg.getBoundingBox().inflate(1.0, 0.0, 1.0));
        }

        if (this.getAnimationID() == 0 && this.getTarget() != null && !this.isStunned) {
            double d0 = this.distanceToSqr(this.getTarget());
            if (d0 < this.getMeleeRange()) {
                if (!(this.getTarget() instanceof EntityTitan) && !(this.getTarget().getBbHeight() >= 6.0F) && !(this.getTarget().getY() > this.getY() + 6.0)) {
                    switch (this.random.nextInt(7)) {
                        case 0:
                            AnimationUtils.sendPacket(this, 11);
                            break;
                        case 1:
                            AnimationUtils.sendPacket(this, 3);
                            break;
                        case 2:
                            AnimationUtils.sendPacket(this, 4);
                            break;
                        case 3:
                            AnimationUtils.sendPacket(this, 6);
                            break;
                        case 4:
                            AnimationUtils.sendPacket(this, 7);
                            break;
                        case 5:
                            AnimationUtils.sendPacket(this, 9);
                            break;
                        case 6:
                            AnimationUtils.sendPacket(this, 2);
                    }
                } else {
                    AnimationUtils.sendPacket(this, 1);
                }
            } else if (this.random.nextInt(100) == 0) {
                switch (this.random.nextInt(3)) {
                    case 0:
                        AnimationUtils.sendPacket(this, 5);
                        break;
                    case 1:
                        AnimationUtils.sendPacket(this, 12);
                        break;
                    case 2:
                        if (this.random.nextInt(4) == 0) {
                            AnimationUtils.sendPacket(this, 11);
                        } else {
                            AnimationUtils.sendPacket(this, 5);
                        }
                }
            }
        }

        if (this.isStunned) {
            this.setTarget(null);
            AnimationUtils.sendPacket(this, 8);
        }

        if (this.getAnimationID() == 0
            && this.random.nextInt(120) == 0
            && this.getTarget() != null
            && this.distanceToSqr(this.getTarget()) > 512.0
            && this.onGround()) {
            this.playSound(this.getHurtSound(null), this.getSoundVolume(), this.getVoicePitch());
            if (this.random.nextInt(4) == 0) {
                this.jumpFromGround();
                double d0 = this.getTarget().getX() - this.getX();
                double d1 = this.getTarget().getZ() - this.getZ();
                double d2 = Math.sqrt(d0 * d0 + d1 * d1);
                double hor = 2.0;
                this.setTitanDeltaMovement(
                    d0 / d2 * hor * hor + this.getDeltaMovement().x * hor, this.getDeltaMovement().y, d1 / d2 * hor * hor + this.getDeltaMovement().z * hor
                );
            } else {
                this.jumpAtEntity(this.getTarget());
            }
        }

        this.animationTick();
    }
}
