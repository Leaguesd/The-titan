package net.titans.loader;

import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.blaze3d.vertex.VertexFormat;
import net.minecraft.client.renderer.RenderType;

public class TheTitansRenderTypes {

    /**
     * Witherzilla 光锥专用 RenderType（1.20.1）。
     *
     * 对应 1.7.10 原版：
     *   glDisable(3553)        → POSITION_COLOR_SHADER
     *   glBlendFunc(770, 1)    → LIGHTNING_TRANSPARENCY (additive)
     *   glDisable(3008)        → 无 alpha test（shader 决定）
     *   glDepthMask(false)     → COLOR_WRITE（只写颜色不写深度）
     *   GL_TRIANGLES           → VertexFormat.Mode.TRIANGLES
     *
     * 注意：
     * - 必须 TRIANGLES，不能用 RenderType.lightning()（它是 QUADS 模式，
     *   每 4 个顶点拼一个四边形，3 顶点三角形光锥会错位/丢顶点）。
     * - COLOR_WRITE 不写深度，否则会挡住本体模型。
     * - LIGHTNING_TRANSPARENCY 是 additive，白天会和亮背景融合，
     *   这是原版末影龙死亡光效的设计。想白天也明显就换成
     *   RenderStateShard.TRANSLUCENT_TRANSPARENCY（如果可访问的话）。
     * - 不挂 FOG shader，避免远景被雾染成天空色。
     */
    public static final RenderType WITHERZILLA_RAYS = RenderType.create(
        "witherzilla_rays",
        DefaultVertexFormat.POSITION_COLOR,
        VertexFormat.Mode.TRIANGLES,
        256,
        false,
        false,
        RenderType.CompositeState.builder()
            .setShaderState(RenderStateAccess.positionColorShader())
            .setTransparencyState(RenderStateAccess.lightningTransparency())
            .setCullState(RenderStateAccess.noCull())
            .setWriteMaskState(RenderStateAccess.colorWrite())
            .createCompositeState(false)
    );

    /**
     * 已废弃。1.7.10 原版只画一遍光锥，不存在第二套带深度的版本。
     * 保留字段仅为兼容旧引用；确认项目里没人用后可以整行删掉。
     */
    @Deprecated
    public static final RenderType WITHERZILLA_RAYS_DEPTH = WITHERZILLA_RAYS;
}