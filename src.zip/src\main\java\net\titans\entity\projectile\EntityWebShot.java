package net.titans.entity.projectile;

import it.unimi.dsi.fastutil.ints.IntOpenHashSet;
import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.registries.Registries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.NbtUtils;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.MoverType;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.entity.projectile.ProjectileUtil;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.ClipContext.Block;
import net.minecraft.world.level.ClipContext.Fluid;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.HitResult.Type;
import net.minecraft.world.phys.shapes.VoxelShape;
import net.titans.entity.titan.EntitySpiderTitan;
import net.titans.loader.TheTitansEntities;

public class EntityWebShot extends Projectile implements IEntityProjectileTitan {
    @Nullable
    private IntOpenHashSet piercingIgnoreEntityIds;
    @Nullable
    private BlockState lastState;
    protected boolean inGround;
    protected int inGroundTime;
    public int shakeTime;
    private int life;

    public EntityWebShot(EntityType<? extends EntityWebShot> entityType, Level level) {
        super(entityType, level);
    }

    public EntityWebShot(Level level) {
        super((EntityType)TheTitansEntities.WEB_SHOT.get(), level);
    }

    protected void defineSynchedData() {
    }

    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        this.life = tag.getShort("life");
        if (tag.contains("inBlockState", 10)) {
            this.lastState = NbtUtils.readBlockState(this.level().holderLookup(Registries.BLOCK), tag.getCompound("inBlockState"));
        }

        this.shakeTime = tag.getByte("shake") & 255;
        this.inGround = tag.getBoolean("inGround");
    }

    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putShort("life", (short)this.life);
        if (this.lastState != null) {
            tag.put("inBlockState", NbtUtils.writeBlockState(this.lastState));
        }

        tag.putByte("shake", (byte)this.shakeTime);
        tag.putBoolean("inGround", this.inGround);
    }

    protected double getDefaultGravity() {
        return 0.05;
    }

    public boolean fireImmune() {
        return true;
    }

    private boolean shouldFall() {
        return this.inGround && this.level().noCollision(new AABB(this.position(), this.position()).inflate(0.06));
    }

    private void startFalling() {
        this.inGround = false;
        Vec3 vec3 = this.getDeltaMovement();
        this.setDeltaMovement(
            vec3.multiply((double)(this.random.nextFloat() * 0.2F), (double)(this.random.nextFloat() * 0.2F), (double)(this.random.nextFloat() * 0.2F))
        );
        this.life = 0;
    }

    public void move(MoverType type, Vec3 pos) {
        super.move(type, pos);
        if (type != MoverType.SELF && this.shouldFall()) {
            this.startFalling();
        }
    }

    protected void tickDespawn() {
        this.life++;
        if (this.life >= 600) {
            this.discard();
        }
    }

    protected boolean canHitEntity(Entity entity) {
        return this.getOwner() != null && entity == this.getOwner() ? false : super.canHitEntity(entity);
    }

    @Nullable
    protected EntityHitResult findHitEntity(Vec3 startVec, Vec3 endVec) {
        return ProjectileUtil.getEntityHitResult(this.level(), this, startVec, endVec, this.getBoundingBox().expandTowards(this.getDeltaMovement()).inflate(1.0), this::canHitEntity);
    }

    protected void onHitBlock(BlockHitResult result) {
        this.lastState = this.level().getBlockState(result.getBlockPos());
        super.onHitBlock(result);
        Vec3 vec3 = result.getLocation().subtract(this.getX(), this.getY(), this.getZ());
        this.setDeltaMovement(vec3);
        Vec3 vec31 = vec3.normalize().scale(0.05F);
        this.setPosRaw(this.getX() - vec31.x, this.getY() - vec31.y, this.getZ() - vec31.z);
        this.inGround = true;
        this.shakeTime = 7;
    }

    protected void onHitEntity(EntityHitResult result) {
        if (result.getEntity() instanceof LivingEntity && this.getOwner() instanceof EntitySpiderTitan) {
            LivingEntity livingEntity = (LivingEntity)result.getEntity();
            EntitySpiderTitan spiderTitan = (EntitySpiderTitan)this.getOwner();
            float amount = (float)spiderTitan.getAttributeBaseValue(Attributes.ATTACK_DAMAGE);
            int knockbackAmount = spiderTitan.getKnockbackAmount();
            spiderTitan.attackEntity(livingEntity, amount);
            spiderTitan.knockbackEntity(livingEntity, (float)knockbackAmount);
            int i11 = Mth.floor(this.getX());
            int i1 = Mth.floor(this.getY() + 1.0);
            int j1 = Mth.floor(this.getZ());

            for (int l1 = -2 - this.random.nextInt(4); l1 <= 2 + this.random.nextInt(4); l1++) {
                for (int i2 = -2 - this.random.nextInt(4); i2 <= 2 + this.random.nextInt(4); i2++) {
                    for (int j = -2 - this.random.nextInt(4); j <= 2 + this.random.nextInt(4); j++) {
                        int j2 = i11 + l1;
                        int k = i1 + j;
                        int l = j1 + i2;
                        BlockPos blockPos = new BlockPos(j2, k, l);
                        this.level().setBlockAndUpdate(blockPos, Blocks.COBWEB.defaultBlockState());
                    }
                }
            }

            if (!this.level().isClientSide()) {
                this.discard();
            }
        }

        super.onHitEntity(result);
    }

    public void tick() {
        super.tick();
        this.noPhysics = true;
        if (this.getOwner() != null && !this.getOwner().isAlive() && !this.level().isClientSide()) {
            this.discard();
        }

        Vec3 vec3 = this.getDeltaMovement();
        if (this.xRotO == 0.0F && this.yRotO == 0.0F) {
            double d0 = vec3.horizontalDistance();
            this.setYRot((float)(Mth.atan2(vec3.x, vec3.z) * 180.0 / (float) Math.PI));
            this.setXRot((float)(Mth.atan2(vec3.y, d0) * 180.0 / (float) Math.PI));
            this.yRotO = this.getYRot();
            this.xRotO = this.getXRot();
        }

        BlockPos blockpos = this.blockPosition();
        BlockState blockstate = this.level().getBlockState(blockpos);
        if (!blockstate.isAir() && !this.noPhysics) {
            VoxelShape voxelshape = blockstate.getCollisionShape(this.level(), blockpos);
            if (!voxelshape.isEmpty()) {
                Vec3 vec31 = this.position();

                for (AABB aabb : voxelshape.toAabbs()) {
                    if (aabb.move(blockpos).contains(vec31)) {
                        this.inGround = true;
                        break;
                    }
                }
            }
        }

        if (this.shakeTime > 0) {
            this.shakeTime--;
        }

        if (this.isInWaterOrRain() || blockstate.is(Blocks.POWDER_SNOW) || this.isInFluidType((fluidType, height) -> this.canFluidExtinguish(fluidType))) {
            this.clearFire();
        }

        if (this.inGround) {
            this.startFalling();
            this.tickDespawn();
            if (this.lastState != blockstate && this.shouldFall()) {
                this.startFalling();
            } else if (!this.level().isClientSide()) {
                this.tickDespawn();
            }

            this.inGroundTime++;
        } else {
            this.inGroundTime = 0;
            // 空中飞行时也要计时：原本只有插在方块上才会 tickDespawn，
            // 没命中的蛛网弹会带着 0.99 的阻力永久滑行。
            this.tickDespawn();
            Vec3 vec32 = this.position();
            Vec3 vec33 = vec32.add(vec3);
            HitResult hitResult = this.level().clip(new ClipContext(vec32, vec33, Block.COLLIDER, Fluid.NONE, this));
            if (hitResult.getType() != Type.MISS) {
                vec33 = hitResult.getLocation();
            }

            if (hitResult.getType() == Type.BLOCK) {
                this.onHitBlock((BlockHitResult)hitResult);
            }

            EntityHitResult entityHitResult = this.findHitEntity(vec32, vec33);
            if (entityHitResult != null) {
                this.onHitEntity(entityHitResult);
            }

            vec3 = this.getDeltaMovement();
            double d5 = vec3.x;
            double d6 = vec3.y;
            double d1 = vec3.z;
            double d7 = this.getX() + d5;
            double d2 = this.getY() + d6;
            double d3 = this.getZ() + d1;
            double d4 = vec3.horizontalDistance();
            if (this.noPhysics) {
                this.setYRot((float)(Mth.atan2(-d5, -d1) * 180.0 / (float) Math.PI));
            } else {
                this.setYRot((float)(Mth.atan2(d5, d1) * 180.0 / (float) Math.PI));
            }

            this.setXRot((float)(Mth.atan2(d6, d4) * 180.0 / (float) Math.PI));
            this.setXRot(lerpRotation(this.xRotO, this.getXRot()));
            this.setYRot(lerpRotation(this.yRotO, this.getYRot()));
            float f = 0.99F;
            if (this.isInWater()) {
                for (int j = 0; j < 4; j++) {
                    this.level().addParticle(ParticleTypes.BUBBLE, d7 - d5 * 0.25, d2 - d6 * 0.25, d3 - d1 * 0.25, d5, d6, d1);
                }
            }

            this.setDeltaMovement(vec3.scale((double)f));
            if (!this.noPhysics) {
                this.setDeltaMovement(this.getDeltaMovement().add(0.0, -this.getDefaultGravity(), 0.0));
            }

            this.level().addParticle(ParticleTypes.POOF, this.getX(), this.getY() + 1.5, this.getZ(), 0.0, 0.0, 0.0);
            this.setPos(d7, d2, d3);
            this.checkInsideBlocks();

            for (int l1 = -1; l1 <= 1; l1++) {
                for (int i2 = -1; i2 <= 1; i2++) {
                    for (int j = -1; j <= 1; j++) {
                        int j2 = (int)this.getX() + l1;
                        int k = (int)this.getY() + 1 + j;
                        int l = (int)this.getZ() + i2;
                        BlockPos blockPos = new BlockPos(j2, k, l);
                        if (this.tickCount > 10) {
                            this.level().setBlockAndUpdate(blockPos, Blocks.COBWEB.defaultBlockState());
                        }
                    }
                }
            }
        }
    }
}
