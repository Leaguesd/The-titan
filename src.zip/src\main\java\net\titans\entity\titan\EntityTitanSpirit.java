package net.titans.entity.titan;

import net.minecraft.core.Holder;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.registries.Registries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageType;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier.Builder;
import net.minecraft.world.entity.boss.enderdragon.EndCrystal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.Level.ExplosionInteraction;
import net.titans.entity.EntityFlying;
import net.titans.entity.minion.EnumMinionType;
import net.titans.entity.minion.IMinion;
import net.titans.loader.TheTitansDamageTypes;
import net.titans.loader.TheTitansEntities;
import net.titans.loader.TheTitansMinions;
import net.titans.loader.TheTitansSounds;

public class EntityTitanSpirit extends EntityFlying {
    private static final EntityDataAccessor<String> SPIRIT_NAME = SynchedEntityData.defineId(EntityTitanSpirit.class, EntityDataSerializers.STRING);
    private static final EntityDataAccessor<Float> SOUL = SynchedEntityData.defineId(EntityTitanSpirit.class, EntityDataSerializers.FLOAT);
    public boolean isSearchingForVessel = true;
    public double waypointX;
    public double waypointY;
    public double waypointZ;
    public int ambientSoundTime;

    public EntityTitanSpirit(EntityType<? extends EntityFlying> entityType, Level level) {
        super(entityType, level);
        this.playSound((SoundEvent)TheTitansSounds.TITAN_BIRTH.get(), 10000.0F, 2.0F);
    }

    public EntityTitanSpirit(Level level, String spiritName) {
        this((EntityType<? extends EntityFlying>)TheTitansEntities.TITAN_SPIRIT.get(), level);
        this.setSpiritName(spiritName);
    }

    public static Builder createAttributes() {
        return EntityTitan.createAttributes().add(Attributes.MAX_HEALTH, Float.MAX_VALUE);
    }

    public String getSpiritName() {
        return (String)this.entityData.get(SPIRIT_NAME);
    }

    public void setSpiritName(String name) {
        this.entityData.set(SPIRIT_NAME, name);
    }

    public float getSoul() {
        return (Float)this.entityData.get(SOUL);
    }

    public void setSoul(float soul) {
        this.entityData.set(SOUL, soul);
    }

    public float getMaxSoul() {
        String var1 = this.getSpiritName();
        switch (var1) {
            case "entity.titan.omegafish":
                return 8000.0F;
            case "entity.titan.zombie_titan":
                return 20000.0F;
            case "entity.titan.zombie_baby_titan":
                return 10000.0F;
            case "entity.titan.zombie_villager_titan":
                return 20000.0F;
            case "entity.titan.zombie_villager_baby_titan":
                return 10000.0F;
            case "entity.titan.skeleton_titan":
                return 20000.0F;
            case "entity.titan.wither_skeleton_titan":
                return 100000.0F;
            case "entity.titan.creeper_titan":
                return 25000.0F;
            case "entity.titan.charged_creeper_titan":
                return 50000.0F;
            case "entity.titan.spider_titan":
                return 16000.0F;
            case "entity.titan.cave_spider_titan":
                return 12000.0F;
            case "entity.titan.zombified_piglin_titan":
                return 20000.0F;
            case "entity.titan.zombified_piglin_baby_titan":
                return 10000.0F;
            case "entity.titan.blaze_titan":
                return 40000.0F;
            case "entity.titan.ender_colossus":
                return 150000.0F;
            case "entity.titan.ghast_titan":
                return 200000.0F;
            case "entity.titan.witherzilla":
                return 1.0E7F;
            default:
                return 1.0F;
        }
    }

    public boolean isVesselHunting() {
        return this.isSearchingForVessel;
    }

    public void setVesselHunting(boolean isSearchingForVessel) {
        this.isSearchingForVessel = isSearchingForVessel;
    }

    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(SPIRIT_NAME, "");
        this.entityData.define(SOUL, 1.0F);
    }

    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        if (tag.contains("SpiritName", 8)) {
            this.setSpiritName(tag.getString("SpiritName"));
        }

        if (tag.contains("Soul", 5)) {
            this.setSoul(tag.getFloat("Soul"));
        }

        if (tag.contains("IsVesselHunting", 1)) {
            this.setVesselHunting(tag.getBoolean("IsVesselHunting"));
        }
    }

    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putString("SpiritName", this.getSpiritName());
        tag.putFloat("Soul", this.getSoul());
        tag.putBoolean("IsVesselHunting", this.isVesselHunting());
    }

    public boolean transformTitan() {
        if (!this.level().isClientSide()) {
            if (this.getSpiritName().equalsIgnoreCase("entity.titan.omegafish")) {
                this.level().explode(this, this.getX(), this.getY(), this.getZ(), 18.0F, true, ExplosionInteraction.MOB);
                EntityOmegafish omegafish = new EntityOmegafish(this.level());
                omegafish.setPos(this.getX(), this.getY(), this.getZ());
                omegafish.setYRot(this.getYRot());
                omegafish.grow();
                this.discard();
                this.level().addFreshEntity(omegafish);
                return true;
            }

            if (this.getSpiritName().equalsIgnoreCase("entity.titan.zombie_titan")
                || this.getSpiritName().equalsIgnoreCase("entity.titan.zombie_baby_titan")
                || this.getSpiritName().equalsIgnoreCase("entity.titan.zombie_villager_titan")
                || this.getSpiritName().equalsIgnoreCase("entity.titan.zombie_villager_baby_titan")) {
                this.level().explode(this, this.getX(), this.getY(), this.getZ(), 18.0F, true, ExplosionInteraction.MOB);
                EntityZombieTitan zombieTitan = new EntityZombieTitan(this.level());
                zombieTitan.setPos(this.getX(), this.getY(), this.getZ());
                zombieTitan.setYRot(this.getYRot());
                zombieTitan.setBaby(this.getSpiritName().contains("baby"));
                zombieTitan.setVillager(this.getSpiritName().contains("villager"));
                zombieTitan.grow();
                this.discard();
                this.level().addFreshEntity(zombieTitan);
                return true;
            }

            if (this.getSpiritName().equalsIgnoreCase("entity.titan.skeleton_titan")
                || this.getSpiritName().equalsIgnoreCase("entity.titan.wither_skeleton_titan")) {
                this.level().explode(this, this.getX(), this.getY(), this.getZ(), 18.0F, true, ExplosionInteraction.MOB);
                EntitySkeletonTitan skeletonTitan = this.getSpiritName().contains("wither")
                    ? new EntityWitherSkeletonTitan(this.level())
                    : new EntitySkeletonTitan(this.level());
                skeletonTitan.setPos(this.getX(), this.getY(), this.getZ());
                skeletonTitan.setYRot(this.getYRot());
                skeletonTitan.grow();
                this.discard();
                this.level().addFreshEntity(skeletonTitan);
                return true;
            }

            if (this.getSpiritName().equalsIgnoreCase("entity.titan.creeper_titan")
                || this.getSpiritName().equalsIgnoreCase("entity.titan.charged_creeper_titan")) {
                this.level().explode(this, this.getX(), this.getY(), this.getZ(), 18.0F, true, ExplosionInteraction.MOB);
                EntityCreeperTitan creeperTitan = new EntityCreeperTitan(this.level());
                creeperTitan.setPos(this.getX(), this.getY(), this.getZ());
                creeperTitan.setYRot(this.getYRot());
                creeperTitan.setCharged(this.getSpiritName().contains("charged"));
                creeperTitan.grow();
                this.discard();
                this.level().addFreshEntity(creeperTitan);
                return true;
            }

            if (this.getSpiritName().equalsIgnoreCase("entity.titan.spider_titan")) {
                this.level().explode(this, this.getX(), this.getY(), this.getZ(), 12.0F, true, ExplosionInteraction.MOB);
                EntitySpiderTitan spiderTitan = new EntitySpiderTitan(this.level());
                spiderTitan.setPos(this.getX(), this.getY(), this.getZ());
                spiderTitan.setYRot(this.getYRot());
                spiderTitan.grow();
                this.discard();
                this.level().addFreshEntity(spiderTitan);
                return true;
            }

            if (this.getSpiritName().equalsIgnoreCase("entity.titan.cave_spider_titan")) {
                this.level().explode(this, this.getX(), this.getY(), this.getZ(), 12.0F, true, ExplosionInteraction.MOB);
                EntityCaveSpiderTitan caveSpiderTitan = new EntityCaveSpiderTitan(this.level());
                caveSpiderTitan.setPos(this.getX(), this.getY(), this.getZ());
                caveSpiderTitan.setYRot(this.getYRot());
                caveSpiderTitan.grow();
                this.discard();
                this.level().addFreshEntity(caveSpiderTitan);
                return true;
            }

            if (this.getSpiritName().equalsIgnoreCase("entity.titan.zombified_piglin_titan")
                || this.getSpiritName().equalsIgnoreCase("entity.titan.zombified_piglin_baby_titan")) {
                this.level().explode(this, this.getX(), this.getY(), this.getZ(), 18.0F, true, ExplosionInteraction.MOB);
                EntityZombifiedPiglinTitan zombifiedPiglinTitan = new EntityZombifiedPiglinTitan(this.level());
                zombifiedPiglinTitan.setPos(this.getX(), this.getY(), this.getZ());
                zombifiedPiglinTitan.setYRot(this.getYRot());
                zombifiedPiglinTitan.setBaby(this.getSpiritName().contains("baby"));
                zombifiedPiglinTitan.grow();
                this.discard();
                this.level().addFreshEntity(zombifiedPiglinTitan);
                return true;
            }

            if (this.getSpiritName().equalsIgnoreCase("entity.titan.blaze_titan")) {
                this.level().explode(this, this.getX(), this.getY(), this.getZ(), 16.0F, true, ExplosionInteraction.MOB);
                EntityBlazeTitan blazeTitan = new EntityBlazeTitan(this.level());
                blazeTitan.setPos(this.getX(), this.getY(), this.getZ());
                blazeTitan.setYRot(this.getYRot());
                blazeTitan.grow();
                this.discard();
                this.level().addFreshEntity(blazeTitan);
                return true;
            }

            if (this.getSpiritName().equalsIgnoreCase("entity.titan.ender_colossus")) {
                this.level().explode(this, this.getX(), this.getY(), this.getZ(), 45.0F, true, ExplosionInteraction.MOB);
                EntityEnderColossus enderColossus = new EntityEnderColossus(this.level());
                enderColossus.setPos(this.getX(), this.getY(), this.getZ());
                enderColossus.setYRot(this.getYRot());
                enderColossus.grow();
                this.discard();
                this.level().addFreshEntity(enderColossus);
                return true;
            }

            if (this.getSpiritName().equalsIgnoreCase("entity.titan.ghast_titan")) {
                this.level().explode(this, this.getX(), this.getY(), this.getZ(), 8.0F, true, ExplosionInteraction.MOB);
                EntityGhastTitan ghastTitan = new EntityGhastTitan(this.level());
                ghastTitan.setPos(this.getX(), this.getY(), this.getZ());
                ghastTitan.setYRot(this.getYRot());
                ghastTitan.grow();
                this.discard();
                this.level().addFreshEntity(ghastTitan);
                return true;
            }
        }

        return false;
    }

    public boolean transformTitan(Entity entity) {
        if (!this.level().isClientSide()
            && entity.getClass() == TheTitansMinions.MINIONS.get(this.getSpiritName())
            && entity instanceof IMinion minion
            && minion.getMinionType() == EnumMinionType.TEMPLAR) {
            entity.discard();
            return this.transformTitan();
        }

        return false;
    }

    public Component getName() {
        return Component.translatable(this.getSpiritName());
    }

    protected SoundEvent getAmbientSound() {
        String var1 = this.getSpiritName();
        switch (var1) {
            case "entity.titan.omegafish":
                return (SoundEvent)TheTitansSounds.TITAN_SILVERFISH_LIVING.get();
            case "entity.titan.zombie_titan":
                return (SoundEvent)TheTitansSounds.TITAN_ZOMBIE_LIVING.get();
            case "entity.titan.zombie_baby_titan":
                return (SoundEvent)TheTitansSounds.TITAN_ZOMBIE_LIVING.get();
            case "entity.titan.zombie_villager_titan":
                return (SoundEvent)TheTitansSounds.TITAN_ZOMBIE_LIVING.get();
            case "entity.titan.zombie_villager_baby_titan":
                return (SoundEvent)TheTitansSounds.TITAN_ZOMBIE_LIVING.get();
            case "entity.titan.skeleton_titan":
                return (SoundEvent)TheTitansSounds.TITAN_SKELETON_LIVING.get();
            case "entity.titan.wither_skeleton_titan":
                return (SoundEvent)TheTitansSounds.TITAN_WITHER_SKELETON_LIVING.get();
            case "entity.titan.creeper_titan":
                return (SoundEvent)TheTitansSounds.TITAN_CREEPER_LIVING.get();
            case "entity.titan.charged_creeper_titan":
                return (SoundEvent)TheTitansSounds.TITAN_CREEPER_LIVING.get();
            case "entity.titan.spider_titan":
                return (SoundEvent)TheTitansSounds.TITAN_SPIDER_LIVING.get();
            case "entity.titan.cave_spider_titan":
                return (SoundEvent)TheTitansSounds.TITAN_SPIDER_LIVING.get();
            case "entity.titan.zombified_piglin_titan":
                return (SoundEvent)TheTitansSounds.TITAN_ZOMBIFIED_PIGLIN_LIVING.get();
            case "entity.titan.zombified_piglin_baby_titan":
                return (SoundEvent)TheTitansSounds.TITAN_ZOMBIFIED_PIGLIN_LIVING.get();
            case "entity.titan.blaze_titan":
                return (SoundEvent)TheTitansSounds.TITAN_BLAZE_BREATHE.get();
            case "entity.titan.ender_colossus":
                return (SoundEvent)TheTitansSounds.TITAN_ENDER_COLOSUS_LIVING.get();
            case "entity.titan.ghast_titan":
                return (SoundEvent)TheTitansSounds.TITAN_GHAST_LIVING.get();
            case "entity.titan.witherzilla":
                return (SoundEvent)TheTitansSounds.WITHERZILLA_LIVING.get();
            default:
                return SoundEvents.WITHER_AMBIENT;
        }
    }

    protected SoundEvent getHurtSound(DamageSource damageSource) {
        return null;
    }

    protected SoundEvent getDeathSound() {
        return null;
    }

    protected void playHurtSound(DamageSource damageSource) {
        this.resetAmbientSoundTime();
        super.playHurtSound(damageSource);
    }

    public int getAmbientSoundInterval() {
        return 80;
    }

    private void resetAmbientSoundTime() {
        this.ambientSoundTime = -this.getAmbientSoundInterval();
    }

    public void playAmbientSound() {
        this.playSound(this.getAmbientSound());
    }

    public boolean fireImmune() {
        return true;
    }

    public boolean isAttackable() {
        return false;
    }

    protected void serverAiStep() {
        super.serverAiStep();
        if (this.waypointY <= 0.0) {
            this.waypointY = 0.0;
        }

        if (this.waypointY > 255.0) {
            this.waypointY = 255.0;
        }

        if (this.isVesselHunting() && this.tickCount % 20 == 0 && this.random.nextInt(5) == 0) {
            Player player = this.level().getNearestPlayer(this, 256.0);
            if (player != null) {
                this.waypointX = player.getX() + (double)((this.random.nextFloat() * 2.0F - 1.0F) * 32.0F);
                this.waypointY = player.getY() + 32.0 + (double)((this.random.nextFloat() * 2.0F - 1.0F) * 16.0F);
                this.waypointZ = player.getZ() + (double)((this.random.nextFloat() * 2.0F - 1.0F) * 32.0F);
            } else {
                this.waypointX = this.getX() + (double)((this.random.nextFloat() * 2.0F - 1.0F) * 32.0F);
                this.waypointY = this.getY() + (double)((this.random.nextFloat() * 2.0F - 1.0F) * 32.0F);
                this.waypointZ = this.getZ() + (double)((this.random.nextFloat() * 2.0F - 1.0F) * 32.0F);
            }
        }

        double d0 = this.waypointX - this.getX();
        double d1 = this.waypointY - this.getY();
        double d2 = this.waypointZ - this.getZ();
        double d3 = Math.sqrt(d0 * d0 + d1 * d1 + d2 * d2);
        if (this.isVesselHunting() && this.distanceToSqr(this.waypointX, this.waypointY, this.waypointZ) > 40000.0) {
            this.waypointX = this.getX();
            this.waypointY = this.getY();
            this.waypointZ = this.getZ();
        }

        if (this.distanceToSqr(this.waypointX, this.waypointY, this.waypointZ) > 4.0) {
            this.push(d0 / d3 * 0.15, d1 / d3 * 0.15, d2 / d3 * 0.15);
        }

        if (!this.isVesselHunting()) {
            this.waypointX = this.getX() + (double)((this.random.nextFloat() * 2.0F - 1.0F) * 128.0F);
            this.waypointY = 255.0;
            this.waypointZ = this.getZ() + (double)((this.random.nextFloat() * 2.0F - 1.0F) * 128.0F);
            if (this.getY() >= 254.0) {
                this.setVesselHunting(true);
                if (this.random.nextInt(2) != 0 && !this.getSpiritName().equalsIgnoreCase("entity.titan.witherzilla")) {
                    this.setPos(
                        this.getX() + (double)((this.random.nextFloat() * 2.0F - 1.0F) * 1024.0F),
                        250.0,
                        this.getZ() + (double)((this.random.nextFloat() * 2.0F - 1.0F) * 1024.0F)
                    );
                } else {
                    if (!this.isSilent()) {
                        this.level().globalLevelEvent(1023, this.blockPosition(), 0);
                    }

                    for (Player player : this.level().players()) {
                        this.playAmbientSound();
                        if (!this.level().isClientSide()) {
                            player.sendSystemMessage(Component.translatable("entity.titan.titan_spirit.back", new Object[]{this.getName(), player.getName()}));
                        }
                    }
                }
            }
        } else {
            for (Entity entity : this.level().getEntities(this, this.getBoundingBox().inflate(256.0, 256.0, 256.0))) {
                if (entity != null) {
                    if (this.getSpiritName() == "entity.titan.witherzilla") {
                        if (entity instanceof Player) {
                            this.waypointX = entity.getX();
                            this.waypointY = entity.getY();
                            this.waypointZ = entity.getZ();
                        }
                    } else if (entity.getClass() == TheTitansMinions.MINIONS.get(this.getSpiritName()) && entity instanceof IMinion && entity instanceof Mob
                        )
                     {
                        IMinion minion = (IMinion)entity;
                        Mob mob = (Mob)entity;
                        if (minion.getMinionType() == EnumMinionType.TEMPLAR) {
                            mob.setTarget(this);
                            this.waypointX = entity.getX();
                            this.waypointY = entity.getY();
                            this.waypointZ = entity.getZ();
                        }
                    }
                }
            }
        }
    }

    public void baseTick() {
        super.baseTick();
        this.level().getProfiler().push("mobBaseTick");
        if (this.isAlive() && this.random.nextInt(1000) < this.ambientSoundTime++) {
            this.resetAmbientSoundTime();
            this.playAmbientSound();
        }

        this.level().getProfiler().pop();
    }

    public void tick() {
        super.tick();
        this.noPhysics = true;
        this.noCulling = true;
        this.deathTime = 0;
        if (this.getSoul() < 0.0F) {
            this.setSoul(0.0F);
        } else if (this.getSoul() >= this.getMaxSoul()) {
            this.transformTitan();
        }

        if (this.getY() <= -100.0) {
            this.setPos(this.getX(), -100.0, this.getZ());
        }

        for (int i = 0; i < 30; i++) {
            float f = (this.random.nextFloat() - 0.5F) * this.getBbWidth();
            float f1 = (this.random.nextFloat() - 0.5F) * this.getBbHeight();
            float f2 = (this.random.nextFloat() - 0.5F) * this.getBbWidth();
            this.level()
                .addParticle(ParticleTypes.EXPLOSION, this.getX() + (double)f, this.getY() + 4.0 + (double)f1, this.getZ() + (double)f2, 0.0, 0.0, 0.0);
            this.level()
                .addParticle(
                    ParticleTypes.POOF,
                    this.getX() + (double)f,
                    this.getY() + 2.0 + (double)f1,
                    this.getZ() + (double)f2,
                    this.getDeltaMovement().x,
                    this.getDeltaMovement().y,
                    this.getDeltaMovement().z
                );
            this.level()
                .addParticle(
                    ParticleTypes.FIREWORK,
                    this.getX() + (double)f,
                    this.getY() + 4.0 + (double)f1,
                    this.getZ() + (double)f2,
                    this.getDeltaMovement().x,
                    this.getDeltaMovement().y,
                    this.getDeltaMovement().z
                );
        }

        Holder<DamageType> damageType = this.level().registryAccess().registryOrThrow(Registries.DAMAGE_TYPE).getHolderOrThrow(TheTitansDamageTypes.TITAN_SPIRIT_ATTACK);

        for (Entity entity : this.level().getEntities(this, this.getBoundingBox().inflate(32.0, 32.0, 32.0))) {
            if (entity != null
                && entity instanceof LivingEntity
                && !(entity instanceof EntityTitan)
                && !(entity instanceof EntityTitanSpirit)
                && !(entity instanceof EntityEnderColossusCrystal)) {
                LivingEntity livingEntity = (LivingEntity)entity;
                if (this.tickCount % 40 == 0) {
                    livingEntity.hurt(new DamageSource(damageType, this), 2.0F);
                    this.setSoul(this.getSoul() + 2.0F);
                }

                double speed = livingEntity.isCrouching() ? 0.2 : 0.4;
                double mx = this.getX() - livingEntity.getX();
                double my = this.getY() + (double)(this.getBbHeight() / 2.0F) - (livingEntity.getY() + (double)(livingEntity.getBbHeight() / 2.0F));
                double mz = this.getZ() - livingEntity.getZ();
                float f2 = (float)Math.sqrt(mx * mx + my * my + mz * mz);
                entity.push(mx / (double)f2 * speed * speed, my / (double)f2 * speed * speed, mz / (double)f2 * speed * speed);
                short particleCount = (short)((int)this.distanceTo(livingEntity));

                for (int i = 0; i < particleCount; i++) {
                    double d9 = (double)i / ((double)particleCount - 1.0);
                    double d6 = this.getX() + mx * -d9;
                    double d7 = this.getY() + 4.0 + my * -d9;
                    double d8 = this.getZ() + mz * -d9;
                    this.level()
                        .addParticle(
                            ParticleTypes.FIREWORK,
                            d6,
                            d7,
                            d8,
                            livingEntity.getDeltaMovement().x,
                            livingEntity.getDeltaMovement().y,
                            livingEntity.getDeltaMovement().z
                        );
                }
            }
        }

        for (Entity entityx : this.level().getEntities(this, this.getBoundingBox())) {
            if (entityx != null) {
                if (entityx instanceof LivingEntity
                    && !(entityx instanceof EntityTitan)
                    && !(entityx instanceof EntityTitanSpirit)
                    && !this.transformTitan(entityx)) {
                    LivingEntity livingEntity = (LivingEntity)entityx;
                    livingEntity.hurt(new DamageSource(damageType, this), 100.0F);
                    if (!this.level().isClientSide()) {
                        livingEntity.addEffect(new MobEffectInstance(MobEffects.WITHER, 300, 3));
                    }
                } else if (entityx instanceof EndCrystal endCrystal) {
                    endCrystal.hurt(new DamageSource(damageType, this), 100.0F);
                }
            }
        }
    }
}
