package net.titans.entity.minion;

import net.minecraft.core.BlockPos;
import net.minecraft.util.RandomSource;
import net.minecraft.world.Difficulty;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.LightLayer;
import net.minecraft.world.level.ServerLevelAccessor;
import net.titans.entity.titan.EntityTitan;

public interface IMinion {
    int getMinionTypeInt();

    void setMinionType(int var1);

    default EnumMinionType getMinionType() {
        switch (this.getMinionTypeInt()) {
            case 1:
                return EnumMinionType.PRIEST;
            case 2:
                return EnumMinionType.ZEALOT;
            case 3:
                return EnumMinionType.BISHOP;
            case 4:
                return EnumMinionType.TEMPLAR;
            default:
                return EnumMinionType.LOYALIST;
        }
    }

    default void setRandomMinionType() {
        Entity entity = (Entity)this;
        float randomRate = entity.level().random.nextFloat() * 100.0F;
        if ((double)randomRate < 1.25) {
            this.setMinionType(4);
        } else if ((double)randomRate < 5.0) {
            this.setMinionType(3);
        } else if ((double)randomRate < 12.5) {
            this.setMinionType(2);
        } else if ((double)randomRate < 25.0) {
            this.setMinionType(1);
        } else if ((double)randomRate < 100.0) {
            this.setMinionType(0);
        }
    }

    default void refreshAttributes() {
    }

    EntityTitan getMaster();

    void setMaster(EntityTitan var1);

    default LivingEntity getEntityToHeal() {
        return null;
    }

    default void setEntityToHeal(LivingEntity entityToHeal) {
    }

    default boolean canAttackEntity(Entity entity, boolean nullable) {
        if ((nullable || entity != null) && entity != this) {
            if (entity != null && this instanceof LivingEntity livingEntity) {
                if (livingEntity.getPassengers().contains(entity) || livingEntity.getVehicle() == entity) {
                    return false;
                }

                if (this.getMaster() != null
                    && this.getMaster().getClass() == entity.getClass()) {
                    return false;
                }

                // 创造模式 / 旁观模式玩家永远不是小兵的目标，硬编码，不走配置项
                if (entity instanceof Player player && (player.isCreative() || player.isSpectator())) {
                    return false;
                }
            }

            return true;
        } else {
            return false;
        }
    }

    default boolean canAttackEntity(Entity entity) {
        return this.canAttackEntity(entity, false);
    }

    static boolean isDarkEnoughToSpawn(ServerLevelAccessor level, BlockPos pos, RandomSource random) {
        return level.getBrightness(LightLayer.BLOCK, pos) <= 7;
    }

    static boolean checkMinionSpawnRules(
        EntityType<? extends Mob> entityType, ServerLevelAccessor level, MobSpawnType spawnType, BlockPos pos, RandomSource random
    ) {
        return level.getDifficulty() != Difficulty.PEACEFUL && isDarkEnoughToSpawn(level, pos, random) && Mob.checkMobSpawnRules(entityType, level, spawnType, pos, random);
    }

    static boolean checkGhastSpawnRules(EntityType<? extends Mob> entityType, LevelAccessor level, MobSpawnType spawnType, BlockPos pos, RandomSource random) {
        return level.getDifficulty() != Difficulty.PEACEFUL && random.nextInt(20) == 0 && Mob.checkMobSpawnRules(entityType, level, spawnType, pos, random);
    }
}
