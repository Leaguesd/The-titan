package net.titans.entity.ai.skeletontitan;

import net.titans.animation.AIAnimation;
import net.titans.entity.titan.EntitySkeletonTitan;

public class AnimationSkeletonTitanCreation extends AIAnimation {
    private EntitySkeletonTitan entity;

    public AnimationSkeletonTitanCreation(EntitySkeletonTitan entity) {
        super(entity);
        this.entity = entity;
    }

    @Override
    public int getAnimationID() {
        return 13;
    }

    @Override
    public boolean isAutomatic() {
        return true;
    }

    @Override
    public int getDuration() {
        return 700;
    }

    @Override
    public boolean canContinueToUse() {
        return this.entity.getAnimationTick() > this.getDuration() ? false : super.canContinueToUse();
    }
}
