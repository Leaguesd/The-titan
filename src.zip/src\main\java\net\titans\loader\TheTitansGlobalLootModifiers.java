package net.titans.loader;

import com.mojang.serialization.Codec;
import net.minecraftforge.common.loot.IGlobalLootModifier;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;
import net.titans.loot.LootModifierAddTable;

/**
 * 1.20.1 Forge 的 GlobalLootModifier 是一个注册表（forge:global_loot_modifier_serializers），
 * 但 Forge 本身并不提供 "add_table" 这类现成的实现（1.20.6+ 才有）。
 *
 * <p>原 data 里 7 个战利品修改器用的是 {@code forge:add_table}，这里改用自带的
 * {@code titan:add_table}，行为一致：把 titan:chests/* 整张表的内容追加到原版箱子。
 *
 * <p>如果编译时报找不到 {@code GLOBAL_LOOT_MODIFIER_SERIALIZERS}，说明该版本常量名不同，
 * 把它换成 {@code ForgeRegistries.Keys.LOOT_MODIFIER_SERIALIZERS} 即可（1.19.x 的命名）。
 */
public class TheTitansGlobalLootModifiers {
    public static final DeferredRegister<Codec<? extends IGlobalLootModifier>> LOOT_MODIFIERS =
            DeferredRegister.create(ForgeRegistries.Keys.GLOBAL_LOOT_MODIFIER_SERIALIZERS, "titan");

    public static final RegistryObject<Codec<LootModifierAddTable>> ADD_TABLE =
            LOOT_MODIFIERS.register("add_table", () -> LootModifierAddTable.CODEC);

    public static void registerGlobalLootModifiers(IEventBus modEventBus) {
        LOOT_MODIFIERS.register(modEventBus);
    }
}
