package net.titans.block;

import net.minecraft.core.BlockPos;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.ItemLike;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.CropBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.BlockBehaviour.Properties;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;
import net.titans.loader.TheTitansRegistries;

public class BlockMalgrumCrop extends CropBlock {
    public BlockMalgrumCrop(Properties properties) {
        super(properties);
    }

    public ItemLike getBaseSeedId() {
        return (ItemLike)TheTitansRegistries.MALGRUM_SEEDS.get();
    }

    public VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        return Block.box(6.0, 0.0, 6.0, 10.0, 16.0, 10.0);
    }
}
