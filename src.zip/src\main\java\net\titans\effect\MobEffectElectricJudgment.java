package net.titans.effect;

import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.entity.LivingEntity;

public class MobEffectElectricJudgment extends MobEffect {
    public MobEffectElectricJudgment() {
        super(MobEffectCategory.HARMFUL, 14270531);
    }

    public boolean isDurationEffectTick(int duration, int amplifier) {
        int k = 60 >> amplifier;
        return k > 0 ? duration % k == 0 : true;
    }

    public void applyEffectTick(LivingEntity entity, int amplifier) {
        entity.setRemainingFireTicks(20);
        entity.hurt(entity.damageSources().lightningBolt(), 5.0F * (float)(amplifier + 1));
        LightningBolt lightningBolt = new LightningBolt(EntityType.LIGHTNING_BOLT, entity.level());
        lightningBolt.setPos(entity.getX() - 0.5, entity.getY(), entity.getZ() - 0.5);
        if (!entity.level().isClientSide()) {
            entity.level().addFreshEntity(lightningBolt);
        }
    }
}
