package net.titans.util;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Transformation;
import java.util.LinkedList;
import java.util.List;
import net.minecraft.client.renderer.block.model.BakedQuad;
import net.minecraft.client.renderer.texture.TextureAtlasSprite;

    public class RenderUtils {

    public static List<BakedQuad> bakeItem(Transformation state, TextureAtlasSprite... sprites) {
        return new LinkedList<>();
    }

    public static List<BakedQuad> bakeItem(TextureAtlasSprite... sprites) {
        return bakeItem(Transformation.identity(), sprites);
    }

    public static List<BakedQuad> bakeItem(TextureAtlasSprite sprite) {        
        return bakeItem(new TextureAtlasSprite[]{sprite});
    }

    public static void renderSprite(
        PoseStack.Pose pose,
        VertexConsumer consumer,
        TextureAtlasSprite sprite,
        float red,
        float green,
        float blue,
        float alpha,
        int packedLight,
        int packedOverlay
    ) {
        float u0 = sprite.getU0();
        float u1 = sprite.getU1();
        float v0 = sprite.getV0();
        float v1 = sprite.getV1();
        float h = 0.5F;

        // 正面（法线 +Z），逆时针
        vertex(pose, consumer, -h, -h, u0, v1, 0.0F, 0.0F, 1.0F, red, green, blue, alpha, packedLight, packedOverlay);
        vertex(pose, consumer, h, -h, u1, v1, 0.0F, 0.0F, 1.0F, red, green, blue, alpha, packedLight, packedOverlay);
        vertex(pose, consumer, h, h, u1, v0, 0.0F, 0.0F, 1.0F, red, green, blue, alpha, packedLight, packedOverlay);
        vertex(pose, consumer, -h, h, u0, v0, 0.0F, 0.0F, 1.0F, red, green, blue, alpha, packedLight, packedOverlay);

        // 背面（法线 -Z），顶点顺序反过来
        vertex(pose, consumer, -h, h, u0, v0, 0.0F, 0.0F, -1.0F, red, green, blue, alpha, packedLight, packedOverlay);
        vertex(pose, consumer, h, h, u1, v0, 0.0F, 0.0F, -1.0F, red, green, blue, alpha, packedLight, packedOverlay);
        vertex(pose, consumer, h, -h, u1, v1, 0.0F, 0.0F, -1.0F, red, green, blue, alpha, packedLight, packedOverlay);
        vertex(pose, consumer, -h, -h, u0, v1, 0.0F, 0.0F, -1.0F, red, green, blue, alpha, packedLight, packedOverlay);
    }

    private static void vertex(
        PoseStack.Pose pose,
        VertexConsumer consumer,
        float x,
        float y,
        float u,
        float v,
        float normalX,
        float normalY,
        float normalZ,
        float red,
        float green,
        float blue,
        float alpha,
        int packedLight,
        int packedOverlay
    ) {
        consumer.vertex(pose.pose(), x, y, 0.0F)
            .color(red, green, blue, alpha)
            .uv(u, v)
            .overlayCoords(packedOverlay)
            .uv2(packedLight)
            .normal(pose.normal(), normalX, normalY, normalZ)
            .endVertex();
    }
}
