package net.titans.item;

import net.minecraft.sounds.SoundEvent;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.PickaxeItem;
import net.minecraft.world.item.UseAnim;
import net.minecraft.world.item.Item.Properties;
import net.titans.entity.titan.EntityTitan;
import net.titans.loader.TheTitansSounds;
import net.titans.loader.TheTitansTiers;

public class ItemVoidPickaxe extends PickaxeItem {
    public ItemVoidPickaxe(Properties properties) {
        super(TheTitansTiers.VOID, 1498, -2.8F, properties);
    }

    public UseAnim getUseAnimation(ItemStack pStack) {
        return UseAnim.BOW;
    }

    public boolean hurtEnemy(ItemStack stack, LivingEntity entity, LivingEntity attacker) {
        if (entity != null && (entity.getBbHeight() >= 6.0F || entity instanceof EntityTitan || !entity.onGround())) {
            entity.playSound((SoundEvent)TheTitansSounds.TITAN_PUNCH.get(), 10.0F, 1.0F);
            entity.hurt(entity.damageSources().mobAttack(attacker), 1000.0F);
        }

        return super.hurtEnemy(stack, entity, attacker);
    }
}
