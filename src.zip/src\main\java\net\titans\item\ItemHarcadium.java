package net.titans.item;

import net.minecraft.world.item.Item;
import net.minecraft.world.item.Item.Properties;

public class ItemHarcadium extends Item {
    public ItemHarcadium(Properties properties) {
        super(properties);
    }
}