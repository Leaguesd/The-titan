package net.titans.entity.titan;

import java.util.UUID;
import javax.annotation.Nullable;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.Difficulty;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier.Builder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import net.titans.entity.ai.EntityAINearestTargetTitan;
import net.titans.entity.minion.EntityCaveSpiderTitanMinion;
import net.titans.entity.minion.EnumMinionType;
import net.titans.loader.TheTitansEntities;
import net.titans.loader.TheTitansPredicateTargets;
import net.titans.util.AnimationUtils;

public class EntityCaveSpiderTitan extends EntitySpiderTitan {
    @Nullable
    private UUID ownerUUID;
    @Nullable
    private Player cachedOwner;
    public boolean isSubdued;

    public EntityCaveSpiderTitan(EntityType<? extends EntityTitan> entityType, Level level) {
        super(entityType, level);
        this.head = new EntityTitanPart(this, "head", 5.6F, 5.6F);
        this.thorax = new EntityTitanPart(this, "thorax", 4.2F, 4.2F);
        this.abdomen = new EntityTitanPart(this, "abdomen", 8.4F, 5.6F);
        this.leftlegs = new EntityTitanPart(this, "leftleg", 8.4F, 5.6F);
        this.rightlegs = new EntityTitanPart(this, "rightleg", 8.4F, 5.6F);
        this.parts = new EntityTitanPart[]{this.head, this.thorax, this.abdomen, this.leftlegs, this.rightlegs};
    }

    public EntityCaveSpiderTitan(Level level) {
        this((EntityType<? extends EntityTitan>)TheTitansEntities.CAVE_SPIDER_TITAN.get(), level);
    }

    public static Builder createAttributes() {
        return EntityTitan.createAttributes().add(Attributes.MAX_HEALTH, 35000.0).add(Attributes.ATTACK_DAMAGE, 900.0);
    }

    @Override
    public ResourceLocation getBossBarTexture() {
        return this.isInvisible() ? null : ResourceLocation.tryBuild("titan", "textures/gui/bossbar/cave_spider_titan.png");
    }

    @Override
    public int getBossBarNameColor() {
        return 11013646;
    }

    @Override
    public int getBossBarWidth() {
        return 187;
    }

    @Override
    public int getBossBarHeight() {
        return 23;
    }

    @Override
    public int getBossBarInterval() {
        return 5;
    }

    @Override
    public int getBossBarVOffset() {
        return 0;
    }

    @Override
    public int getBossBarVHeight() {
        return 0;
    }

    @Override
    public int getBossBarTextOffset() {
        return 7;
    }

    @Override
    protected void registerGoals() {
        super.registerGoals();
        this.targetSelector.removeAllGoals(goal -> true);
        this.targetSelector.addGoal(0, new EntityAINearestTargetTitan(this, EntitySnowGolemTitan.class, false));
        this.targetSelector.addGoal(0, new EntityAINearestTargetTitan(this, EntityIronGolemTitan.class, false));
        this.targetSelector
            .addGoal(0, new EntityAINearestTargetTitan<LivingEntity>(this, LivingEntity.class, 0, false, false, TheTitansPredicateTargets.CaveSpiderTitan));
    }

    public Entity getOwner() {
        if (this.cachedOwner != null && !this.cachedOwner.isRemoved()) {
            return this.cachedOwner;
        } else if (this.ownerUUID != null) {
            this.cachedOwner = this.level().getPlayerByUUID(this.ownerUUID);
            return this.cachedOwner;
        } else {
            return null;
        }
    }

    public void setOwner(Player owner) {
        if (owner != null) {
            this.ownerUUID = owner.getUUID();
            this.cachedOwner = owner;
        }
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        if (tag.hasUUID("Owner")) {
            this.ownerUUID = tag.getUUID("Owner");
            this.cachedOwner = null;
        }

        this.isSubdued = tag.getBoolean("IsSubdued");
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        if (this.ownerUUID != null) {
            tag.putUUID("Owner", this.ownerUUID);
        }

        tag.putBoolean("IsSubdued", this.isSubdued);
    }

    @Override
    protected void refreshAttributes() {
        if (this.level().getDifficulty() == Difficulty.HARD) {
            this.getAttribute(Attributes.MAX_HEALTH).setBaseValue(35000.0 + (double)this.getExtraPower() * 1600.0);
            this.getAttribute(Attributes.ATTACK_DAMAGE).setBaseValue(900.0 + (double)this.getExtraPower() * 30.0);
        } else {
            this.getAttribute(Attributes.MAX_HEALTH).setBaseValue(18000.0 + (double)this.getExtraPower() * 800.0);
            this.getAttribute(Attributes.ATTACK_DAMAGE).setBaseValue(450.0 + (double)this.getExtraPower() * 15.0);
        }
    }

    @Override
    public boolean canAttackEntity(Entity entity) {
        return super.canAttackEntity(entity) && !(entity instanceof EntityCaveSpiderTitanMinion) && (!(entity instanceof Player) || !this.isSubdued);
    }

    @Override
    public int getMinionCap() {
        return 180;
    }

    @Override
    public int getPriestCap() {
        return 80;
    }

    @Override
    public int getZealotCap() {
        return 20;
    }

    @Override
    public int getBishopCap() {
        return 15;
    }

    @Override
    public int getTemplarCap() {
        return 4;
    }

    @Override
    public boolean canSpawnMinion() {
        boolean flag = this.getInvulTime() > 1 && this.tickCount % 20 == 0;
        float randomRate = this.random.nextFloat() * 100.0F;
        return flag || (double)randomRate < 5.0;
    }

    @Override
    public boolean canSpawnPriest() {
        boolean flag = this.getInvulTime() > 1 && this.tickCount % 20 == 0;
        float randomRate = this.random.nextFloat() * 100.0F;
        return flag || (double)randomRate < 2.5;
    }

    @Override
    public boolean canSpawnZealot() {
        boolean flag = this.getInvulTime() > 1 && this.tickCount % 20 == 0;
        float randomRate = this.random.nextFloat() * 100.0F;
        return flag || (double)randomRate < 1.25;
    }

    @Override
    public boolean canSpawnBishop() {
        boolean flag = this.getInvulTime() > 1 && this.tickCount % 20 == 0;
        float randomRate = this.random.nextFloat() * 100.0F;
        return flag || (double)randomRate < 0.625;
    }

    @Override
    public boolean canSpawnTemplar() {
        boolean flag = this.getInvulTime() > 1 && this.tickCount % 20 == 0;
        float randomRate = this.random.nextFloat() * 100.0F;
        return flag || (double)randomRate < 0.3125;
    }

    @Override
    public Vec3 getPassengerRidingPosition(Entity entity) {
        return entity instanceof Player ? this.position().add(0.0, 8.8 + (double)this.getExtraPower() * 0.1, 0.0) : this.position();
    }

    @Override
    public float getSpeed() {
        return (float)((this.getBonusID() == 1 ? 0.65 : 0.6) + (double)this.getExtraPower() * 0.001);
    }

    @Override
    public void setTarget(@Nullable LivingEntity target) {
        if (this.isSubdued) {
            super.setTarget(null);
        } else {
            super.setTarget(target);
        }
    }

    @Override
    public void attackEntity(LivingEntity entity, float amount) {
        super.attackEntity(entity, amount);
        if (!entity.level().isClientSide()) {
            entity.addEffect(new MobEffectInstance(MobEffects.POISON, 800, 3));
        }
    }

    public InteractionResult mobInteract(Player player, InteractionHand hand) {
        ItemStack itemStack = player.getItemInHand(hand);
        Item item = itemStack.getItem();
        if (this.isStunned && !this.isSubdued) {
            if (item == Items.GOLDEN_APPLE) {
                if (!player.isCreative()) {
                    itemStack.shrink(1);
                }

                player.swing(hand, true);
                float randomRate = this.random.nextFloat() * 100.0F;
                if ((double)randomRate < 0.01) {
                    this.playSound(SoundEvents.PLAYER_LEVELUP, 10.0F, 1.0F);
                    this.isSubdued = true;
                    this.setOwner(player);
                    player.sendSystemMessage(Component.translatable("entity.titan.titan.subdued", new Object[]{this.getName(), player.getName()}));
                }
            }
        } else if (!this.isStunned && this.isSubdued && this.getOwner() == player) {
            if (!itemStack.isEmpty()) {
                if (this.getAnimationID() == 0) {
                    if (itemStack.getItem() == Items.COOKED_CHICKEN) {
                        if (!player.isCreative()) {
                            itemStack.shrink(1);
                        }

                        player.swing(hand, true);
                        AnimationUtils.sendPacket(this, 3);
                    }

                    if (itemStack.getItem() == Items.BONE) {
                        if (!player.isCreative()) {
                            itemStack.shrink(1);
                        }

                        player.swing(hand, true);
                        AnimationUtils.sendPacket(this, 9);
                    }
                }
            } else if (!player.isPassenger()) {
                player.swing(hand, true);
                player.startRiding(this);
            }
        }

        return InteractionResult.PASS;
    }

    @Override
    public void finalizeMinionSummon(Entity entity, EnumMinionType minionType) {
        if (minionType != EnumMinionType.SPECIAL && entity instanceof EntityCaveSpiderTitanMinion caveSpiderTitanMinion) {
            caveSpiderTitanMinion.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 40, 4, true, false));
        }
    }

    protected void updateRiddenMovement(Player player, Vec3 travelVector) {
        if (this.getAnimationID() == 10) {
            player.stopRiding();
        } else {
            this.setTarget(null);
            this.setYRot(player.getYRot());
            this.yRotO = player.yRotO;
            this.yHeadRot = player.yHeadRot;
            if (player.zza > 0.0F) {
                this.moveRelative(this.getSpeed(), new Vec3(0.0, 0.0, 1.0));
            } else if (player.zza < 0.0F) {
                this.moveRelative(-this.getSpeed() * 0.25F, new Vec3(0.0, 0.0, 1.0));
            }

            if (player.xxa != 0.0F) {
                this.moveRelative(this.getSpeed() * 0.5F * Math.signum(player.xxa), new Vec3(1.0, 0.0, 0.0));
            }

            if (this.onGround() && player.getXRot() < -80.0F) {
                this.jumpFromGround();
            }

            if (!this.isControlledByLocalInstance()) {
                this.calculateEntityAnimation(false);
            }
        }
    }

    @Override
    public void tick() {
        super.tick();
        if (!this.getPassengers().isEmpty() && this.getFirstPassenger() instanceof Player) {
            Player player = (Player)this.getFirstPassenger();
            this.updateRiddenMovement(player, new Vec3((double)this.xxa, (double)this.yya, (double)this.zza));
        }
    }
}
