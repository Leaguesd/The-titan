package net.titans.model;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.util.Mth;
import net.titans.animation.Animator;
import net.titans.entity.titan.EntityCreeperTitan;

public class ModelCreeperTitan extends EntityModel<EntityCreeperTitan> {
    private Animator animator;
    public ModelPart bottomBody;
    public ModelPart leftfrontupperleg;
    public ModelPart leftbackupperleg;
    public ModelPart rightfrontupperleg;
    public ModelPart rightbackupperleg;
    public ModelPart bottomMiddle;
    public ModelPart bottomTop;
    public ModelPart head;
    public ModelPart leftfrontcalf;
    public ModelPart leftfrontfoot;
    public ModelPart leftbackcalf;
    public ModelPart leftbackfoot;
    public ModelPart rightfrontcalf;
    public ModelPart rightfrontfoot;
    public ModelPart rightbackcalf;
    public ModelPart rightbackfoot;

    public ModelCreeperTitan(float grow) {
        ModelPart root = createBodyLayer(grow).bakeRoot();
        this.bottomBody = root.getChild("bottomBody");
        this.leftfrontupperleg = root.getChild("leftfrontupperleg");
        this.leftbackupperleg = root.getChild("leftbackupperleg");
        this.rightfrontupperleg = root.getChild("rightfrontupperleg");
        this.rightbackupperleg = root.getChild("rightbackupperleg");
        this.bottomMiddle = root.getChild("bottomBody").getChild("bottomMiddle");
        this.bottomTop = root.getChild("bottomBody").getChild("bottomMiddle").getChild("bottomTop");
        this.head = root.getChild("bottomBody").getChild("bottomMiddle").getChild("bottomTop").getChild("head");
        this.leftfrontcalf = root.getChild("leftfrontupperleg").getChild("leftfrontcalf");
        this.leftfrontfoot = root.getChild("leftfrontupperleg").getChild("leftfrontcalf").getChild("leftfrontfoot");
        this.leftbackcalf = root.getChild("leftbackupperleg").getChild("leftbackcalf");
        this.leftbackfoot = root.getChild("leftbackupperleg").getChild("leftbackcalf").getChild("leftbackfoot");
        this.rightfrontcalf = root.getChild("rightfrontupperleg").getChild("rightfrontcalf");
        this.rightfrontfoot = root.getChild("rightfrontupperleg").getChild("rightfrontcalf").getChild("rightfrontfoot");
        this.rightbackcalf = root.getChild("rightbackupperleg").getChild("rightbackcalf");
        this.rightbackfoot = root.getChild("rightbackupperleg").getChild("rightbackcalf").getChild("rightbackfoot");
        this.animator = new Animator(root);
    }

    public static LayerDefinition createBodyLayer(float grow) {
        MeshDefinition meshDefinition = new MeshDefinition();
        PartDefinition partDefinition = meshDefinition.getRoot();
        CubeDeformation cubeDeformation = new CubeDeformation(grow);
        partDefinition.addOrReplaceChild(
            "bottomBody",
            CubeListBuilder.create().texOffs(16, 32).addBox(-4.0F, -4.0F, -2.0F, 8.0F, 4.0F, 4.0F, cubeDeformation),
            PartPose.offsetAndRotation(0.0F, 16.0F, 0.0F, 0.0F, 0.0F, 0.0F)
        );
        partDefinition.getChild("bottomBody")
            .addOrReplaceChild(
                "bottomMiddle",
                CubeListBuilder.create().texOffs(16, 24).addBox(-4.0F, -4.0F, -2.0F, 8.0F, 4.0F, 4.0F, cubeDeformation),
                PartPose.offsetAndRotation(0.0F, -2.0F, 0.0F, 0.0F, 0.0F, 0.0F)
            );
        partDefinition.getChild("bottomBody")
            .getChild("bottomMiddle")
            .addOrReplaceChild(
                "bottomTop",
                CubeListBuilder.create().texOffs(16, 16).addBox(-4.0F, -4.0F, -2.0F, 8.0F, 4.0F, 4.0F, cubeDeformation),
                PartPose.offsetAndRotation(0.0F, -4.0F, 0.0F, 0.0F, 0.0F, 0.0F)
            );
        partDefinition.getChild("bottomBody")
            .getChild("bottomMiddle")
            .getChild("bottomTop")
            .addOrReplaceChild(
                "head",
                CubeListBuilder.create().texOffs(0, 0).addBox(-4.0F, -8.0F, -4.0F, 8.0F, 8.0F, 8.0F, cubeDeformation),
                PartPose.offsetAndRotation(0.0F, -4.0F, 0.0F, 0.0F, 0.0F, 0.0F)
            );
        partDefinition.addOrReplaceChild(
            "leftfrontupperleg",
            CubeListBuilder.create().texOffs(0, 16).addBox(-2.0F, 0.0F, -2.0F, 4.0F, 4.0F, 4.0F, cubeDeformation),
            PartPose.offsetAndRotation(3.0F, 16.0F, -1.0F, 0.0F, 0.0F, 0.0F)
        );
        partDefinition.getChild("leftfrontupperleg")
            .addOrReplaceChild(
                "leftfrontcalf",
                CubeListBuilder.create().texOffs(0, 16).addBox(-2.0F, 0.0F, -2.0F, 4.0F, 4.0F, 4.0F, cubeDeformation),
                PartPose.offsetAndRotation(0.0F, 3.5F, 0.0F, 0.0F, 0.0F, 0.0F)
            );
        partDefinition.getChild("leftfrontupperleg")
            .getChild("leftfrontcalf")
            .addOrReplaceChild(
                "leftfrontfoot",
                CubeListBuilder.create().texOffs(0, 24).addBox(-2.0F, 0.0F, -2.0F, 4.0F, 4.0F, 4.0F, cubeDeformation),
                PartPose.offsetAndRotation(0.0F, 3.5F, 0.0F, 0.0F, 0.0F, 0.0F)
            );
        partDefinition.addOrReplaceChild(
            "leftbackupperleg",
            CubeListBuilder.create().texOffs(0, 16).addBox(-2.0F, 0.0F, -2.0F, 4.0F, 4.0F, 4.0F, cubeDeformation),
            PartPose.offsetAndRotation(3.0F, 16.0F, 1.0F, 0.0F, 0.0F, 0.0F)
        );
        partDefinition.getChild("leftbackupperleg")
            .addOrReplaceChild(
                "leftbackcalf",
                CubeListBuilder.create().texOffs(0, 16).addBox(-2.0F, 0.0F, -2.0F, 4.0F, 4.0F, 4.0F, cubeDeformation),
                PartPose.offsetAndRotation(0.0F, 3.5F, 0.0F, 0.0F, 0.0F, 0.0F)
            );
        partDefinition.getChild("leftbackupperleg")
            .getChild("leftbackcalf")
            .addOrReplaceChild(
                "leftbackfoot",
                CubeListBuilder.create().texOffs(0, 24).addBox(-2.0F, 0.0F, -2.0F, 4.0F, 4.0F, 4.0F, cubeDeformation),
                PartPose.offsetAndRotation(0.0F, 3.5F, 0.0F, 0.0F, 0.0F, 0.0F)
            );
        partDefinition.addOrReplaceChild(
            "rightfrontupperleg",
            CubeListBuilder.create().texOffs(0, 16).addBox(-2.0F, 0.0F, -2.0F, 4.0F, 4.0F, 4.0F, cubeDeformation),
            PartPose.offsetAndRotation(-3.0F, 16.0F, -1.0F, 0.0F, 0.0F, 0.0F)
        );
        partDefinition.getChild("rightfrontupperleg")
            .addOrReplaceChild(
                "rightfrontcalf",
                CubeListBuilder.create().texOffs(0, 16).addBox(-2.0F, 0.0F, -2.0F, 4.0F, 4.0F, 4.0F, cubeDeformation),
                PartPose.offsetAndRotation(0.0F, 3.5F, 0.0F, 0.0F, 0.0F, 0.0F)
            );
        partDefinition.getChild("rightfrontupperleg")
            .getChild("rightfrontcalf")
            .addOrReplaceChild(
                "rightfrontfoot",
                CubeListBuilder.create().texOffs(0, 24).addBox(-2.0F, 0.0F, -2.0F, 4.0F, 4.0F, 4.0F, cubeDeformation),
                PartPose.offsetAndRotation(0.0F, 3.5F, 0.0F, 0.0F, 0.0F, 0.0F)
            );
        partDefinition.addOrReplaceChild(
            "rightbackupperleg",
            CubeListBuilder.create().texOffs(0, 16).addBox(-2.0F, 0.0F, -2.0F, 4.0F, 4.0F, 4.0F, cubeDeformation),
            PartPose.offsetAndRotation(-3.0F, 16.0F, 1.0F, 0.0F, 0.0F, 0.0F)
        );
        partDefinition.getChild("rightbackupperleg")
            .addOrReplaceChild(
                "rightbackcalf",
                CubeListBuilder.create().texOffs(0, 16).addBox(-2.0F, 0.0F, -2.0F, 4.0F, 4.0F, 4.0F, cubeDeformation),
                PartPose.offsetAndRotation(0.0F, 3.5F, 0.0F, 0.0F, 0.0F, 0.0F)
            );
        partDefinition.getChild("rightbackupperleg")
            .getChild("rightbackcalf")
            .addOrReplaceChild(
                "rightbackfoot",
                CubeListBuilder.create().texOffs(0, 24).addBox(-2.0F, 0.0F, -2.0F, 4.0F, 4.0F, 4.0F, cubeDeformation),
                PartPose.offsetAndRotation(0.0F, 3.5F, 0.0F, 0.0F, 0.0F, 0.0F)
            );
        return LayerDefinition.create(meshDefinition, 64, 64);
    }

    public void setupAnim(EntityCreeperTitan entity, float limbSwing, float limbSwingAmount, float ageInTicks, float headYaw, float headPitch) {
        this.animate(entity, limbSwing, limbSwingAmount, ageInTicks, headYaw, headPitch);
    }

    public void renderToBuffer(PoseStack poseStack, VertexConsumer vertexConsumer, int packedLight, int packedOverlay, float red, float green, float blue, float alpha) {
        this.leftfrontupperleg.render(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
        this.rightbackupperleg.render(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
        this.bottomBody.render(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
        this.leftbackupperleg.render(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
        this.rightfrontupperleg.render(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
    }

    public void setAngles() {
        float f = 16.1F;
        this.rightbackupperleg.setPos(-3.0F, f, 1.0F);
        this.leftfrontupperleg.setPos(3.0F, f, -1.0F);
        this.bottomBody.setPos(0.0F, f, 0.0F);
        this.leftbackupperleg.setPos(3.0F, f, 1.0F);
        this.rightfrontupperleg.setPos(-3.0F, f, -1.0F);
        this.rightbackcalf.xRot = (float) (Math.PI / 4);
        this.leftfrontcalf.xRot = (float) (Math.PI / 4);
        this.leftbackcalf.xRot = (float) (Math.PI / 4);
        this.rightfrontcalf.xRot = (float) (Math.PI / 4);
        this.rightbackfoot.xRot = (float) (Math.PI / 6);
        this.leftfrontfoot.xRot = (float) (Math.PI / 6);
        this.rightfrontfoot.xRot = (float) (Math.PI / 6);
        this.leftbackfoot.xRot = (float) (Math.PI / 6);
        this.leftfrontupperleg.xRot = (float) (-Math.PI * 5.0 / 12.0);
        this.leftfrontupperleg.yRot = -0.525F;
        this.rightbackupperleg.yRot = 2.625F;
        this.rightbackupperleg.xRot = (float) (-Math.PI * 5.0 / 12.0);
        this.leftbackupperleg.yRot = -2.625F;
        this.leftbackupperleg.xRot = (float) (-Math.PI * 5.0 / 12.0);
        this.rightfrontupperleg.xRot = (float) (-Math.PI * 5.0 / 12.0);
        this.rightfrontupperleg.yRot = 0.525F;
    }

    public void animate(EntityCreeperTitan entity, float limbSwing, float limbSwingAmount, float ageInTicks, float headYaw, float headPitch) {
        float partialTicks = Minecraft.getInstance().getFrameTime();
        this.animator.update(entity);
        this.setAngles();
        float f6 = Mth.cos(ageInTicks * 0.1F);
        if (entity.deathTicks <= 0) {
            float faceYaw = headYaw * (float) Math.PI / 180.0F;
            float facePitch = headPitch * (float) Math.PI / 180.0F;
            this.bottomBody.zRot = Mth.cos(limbSwing * 0.25F) * 0.3F * limbSwingAmount;
            this.bottomMiddle.zRot = Mth.cos(limbSwing * 0.25F - 1.0F) * 0.3F * limbSwingAmount;
            this.bottomTop.zRot = Mth.cos(limbSwing * 0.25F - 2.0F) * 0.3F * limbSwingAmount;
            this.head.zRot = Mth.cos(limbSwing * 0.25F - 3.0F) * 0.3F * limbSwingAmount;
            if (entity.getAnimationID() == 8 && entity.getAnimationTick() > 130 && entity.getAnimationTick() < 430) {
                this.bottomMiddle.yRot = Mth.cos(ageInTicks * 0.05F + 2.0F) * 0.2F;
                this.bottomTop.yRot = Mth.cos(ageInTicks * 0.05F + 1.0F) * 0.2F;
                this.head.yRot = Mth.cos(ageInTicks * 0.05F) * 0.2F;
                this.bottomMiddle.xRot = (-0.025F + -0.0125F * Mth.cos(ageInTicks * 0.1F - 2.0F)) * (float) Math.PI;
                this.bottomTop.xRot = (0.0125F + 0.0125F * Mth.cos(ageInTicks * 0.1F - 1.0F)) * (float) Math.PI;
                this.head.xRot = (0.0125F + 0.0125F * f6) * (float) Math.PI;
            }

            if (entity.getAnimationID() == 13 && entity.getAnimationTick() < 5) {
                this.bottomMiddle.xRot = (-0.005F + -0.005F * Mth.cos(ageInTicks * 0.1F - 2.0F)) * (float) Math.PI;
                this.bottomTop.xRot = (0.005F + 0.005F * Mth.cos(ageInTicks * 0.1F - 1.0F)) * (float) Math.PI;
                this.head.xRot = (0.005F + 0.005F * f6) * (float) Math.PI;
            }

            if (this.riding) {
                this.rightbackupperleg.setPos(-3.0F, 21.0F, 1.0F);
                this.leftfrontupperleg.setPos(3.0F, 21.0F, -1.0F);
                this.bottomBody.setPos(0.0F, 21.0F, 0.0F);
                this.leftbackupperleg.setPos(3.0F, 21.0F, 1.0F);
                this.rightfrontupperleg.setPos(-3.0F, 21.0F, -1.0F);
                this.leftfrontupperleg.xRot = -1.6F;
                this.leftbackupperleg.xRot = -1.6F;
                this.rightfrontupperleg.xRot = -1.6F;
                this.rightbackupperleg.xRot = -1.6F;
                this.leftfrontupperleg.yRot = -0.725F;
                this.leftbackupperleg.yRot = -2.25F;
                this.rightfrontupperleg.yRot = 0.725F;
                this.rightbackupperleg.yRot = 2.25F;
                this.leftbackcalf.xRot = 1.0F;
                this.leftfrontcalf.xRot = 1.0F;
                this.rightbackcalf.xRot = 1.0F;
                this.rightfrontcalf.xRot = 1.0F;
            } else if (entity.getAnimationID() == 0) {
                this.bottomMiddle.xRot = (-0.025F + -0.0125F * Mth.cos(ageInTicks * 0.1F - 2.0F)) * (float) Math.PI;
                this.bottomTop.xRot = (0.0125F + 0.0125F * Mth.cos(ageInTicks * 0.1F - 1.0F)) * (float) Math.PI;
                this.head.xRot = (0.0125F + 0.0125F * f6) * (float) Math.PI;
                this.leftfrontupperleg.xRot = (float) (-Math.PI * 5.0 / 12.0) + Mth.cos(limbSwing * 0.25F + 0.25F) * 0.75F * limbSwingAmount;
                this.leftbackupperleg.xRot = (float) (-Math.PI * 5.0 / 12.0) + Mth.cos(limbSwing * 0.25F + 3.3915927F) * 0.75F * limbSwingAmount;
                this.rightfrontupperleg.xRot = (float) (-Math.PI * 5.0 / 12.0) + Mth.cos(limbSwing * 0.25F + 3.3915927F) * 0.75F * limbSwingAmount;
                this.rightbackupperleg.xRot = (float) (-Math.PI * 5.0 / 12.0) + Mth.cos(limbSwing * 0.25F + 0.25F) * 0.75F * limbSwingAmount;
                this.leftfrontupperleg.yRot = -0.525F + Mth.cos(limbSwing * 0.25F + 2.6415927F) * 0.5F * limbSwingAmount;
                this.leftbackupperleg.yRot = -2.625F + Mth.cos(limbSwing * 0.25F - 0.5F) * 0.5F * limbSwingAmount;
                this.rightfrontupperleg.yRot = 0.525F - Mth.cos(limbSwing * 0.25F - 0.75F) * 0.5F * limbSwingAmount;
                this.rightbackupperleg.yRot = 2.625F - Mth.cos(limbSwing * 0.25F + 2.6415927F) * 0.5F * limbSwingAmount;
                this.leftbackcalf.xRot = (float) (Math.PI / 4) + Mth.cos(limbSwing * 0.25F) * 0.5F * limbSwingAmount;
                this.leftfrontcalf.xRot = (float) (Math.PI / 4) + Mth.cos(limbSwing * 0.25F + (float) Math.PI) * 0.5F * limbSwingAmount;
                this.rightbackcalf.xRot = (float) (Math.PI / 4) + Mth.cos(limbSwing * 0.25F + (float) Math.PI) * 0.5F * limbSwingAmount;
                this.rightfrontcalf.xRot = (float) (Math.PI / 4) + Mth.cos(limbSwing * 0.25F) * 0.5F * limbSwingAmount;
                if (this.leftfrontupperleg.xRot > (float) (-Math.PI * 5.0 / 12.0)) {
                    this.leftfrontupperleg.xRot = (float) (-Math.PI * 5.0 / 12.0);
                }

                if (this.rightfrontupperleg.xRot > (float) (-Math.PI * 5.0 / 12.0)) {
                    this.rightfrontupperleg.xRot = (float) (-Math.PI * 5.0 / 12.0);
                }

                if (this.rightbackupperleg.xRot > (float) (-Math.PI * 5.0 / 12.0)) {
                    this.rightbackupperleg.xRot = (float) (-Math.PI * 5.0 / 12.0);
                }

                if (this.leftbackupperleg.xRot > (float) (-Math.PI * 5.0 / 12.0)) {
                    this.leftbackupperleg.xRot = (float) (-Math.PI * 5.0 / 12.0);
                }

                if (this.rightbackcalf.xRot < (float) (Math.PI / 4)) {
                    this.rightbackcalf.xRot = (float) (Math.PI / 4);
                }

                if (this.rightfrontcalf.xRot < (float) (Math.PI / 4)) {
                    this.rightfrontcalf.xRot = (float) (Math.PI / 4);
                }

                if (this.leftbackcalf.xRot < (float) (Math.PI / 4)) {
                    this.leftbackcalf.xRot = (float) (Math.PI / 4);
                }

                if (this.leftfrontcalf.xRot < (float) (Math.PI / 4)) {
                    this.leftfrontcalf.xRot = (float) (Math.PI / 4);
                }

                if (this.rightbackcalf.xRot < (float) (Math.PI / 4)) {
                    this.rightbackcalf.xRot = (float) (Math.PI / 4);
                }

                if (this.rightfrontcalf.xRot < (float) (Math.PI / 4)) {
                    this.rightfrontcalf.xRot = (float) (Math.PI / 4);
                }
            }

            this.head.xRot += facePitch * 0.3F;
            this.head.yRot += faceYaw * 0.3F;
            this.bottomTop.xRot += facePitch * 0.3F;
            this.bottomTop.yRot += faceYaw * 0.3F;
            this.bottomMiddle.xRot += facePitch * 0.3F;
            this.bottomMiddle.yRot += faceYaw * 0.3F;
            if (!entity.onGround() && !this.riding) {
                this.bottomBody.zRot = 0.0F;
                this.bottomMiddle.zRot = 0.0F;
                this.bottomTop.zRot = 0.0F;
                this.head.zRot = 0.0F;
                this.head.xRot = this.head.xRot - entity.walkAnimation.speed(partialTicks);
                this.bottomBody.xRot = this.bottomBody.xRot + entity.walkAnimation.speed(partialTicks);
                this.leftfrontupperleg.yRot = -0.25F;
                this.rightbackupperleg.yRot = 2.75F;
                this.leftbackupperleg.yRot = -2.75F;
                this.rightfrontupperleg.yRot = 0.25F;
                this.rightbackupperleg.xRot = -2.0F
                    - Mth.cos(ageInTicks * 0.2F) * 0.25F
                    - (float)(entity.getDeltaMovement().y / 5.0)
                    - entity.walkAnimation.speed(partialTicks);
                this.leftbackupperleg.xRot = -2.0F
                    - Mth.cos(ageInTicks * 0.2F - (float) Math.PI) * 0.25F
                    - (float)(entity.getDeltaMovement().y / 5.0)
                    - entity.walkAnimation.speed(partialTicks);
                this.rightfrontupperleg.xRot = -2.0F
                    - Mth.cos(ageInTicks * 0.2F) * 0.25F
                    - (float)(entity.getDeltaMovement().y / 5.0)
                    + entity.walkAnimation.speed(partialTicks);
                this.leftfrontupperleg.xRot = -2.0F
                    - Mth.cos(ageInTicks * 0.2F - (float) Math.PI) * 0.25F
                    - (float)(entity.getDeltaMovement().y / 5.0)
                    + entity.walkAnimation.speed(partialTicks);
            }

            if (entity.getAnimationID() == 1) {
                switch (entity.getAntiTitanAttackAnimationID()) {
                    case 0:
                        this.animateAntiTitanAttack1();
                        break;
                    case 1:
                        this.animateAntiTitanAttack2();
                        break;
                    case 2:
                        this.animateAntiTitanAttack3();
                        break;
                    case 3:
                        this.animateAntiTitanAttack4();
                }
            }

            this.animateStunned();
            this.animateThunderClap();
            this.animateSpit();
            this.animateKick();
            this.animateStomp();
            this.animateAttackStomp();
            this.animateHeadSlam();
            this.animateBirth();
        } else {
            this.animateDeath();
        }
    }

    private void animateAntiTitanAttack1() {
        this.animator.setAnimationID(1);
        this.animator.startPhase(10);
        this.animator.move(this.bottomBody, 0.0F, -3.0F, 4.0F);
        this.animator.move(this.leftfrontupperleg, 0.0F, -4.0F, 4.0F);
        this.animator.move(this.rightfrontupperleg, 0.0F, -4.0F, 4.0F);
        this.animator.move(this.rightbackupperleg, 0.0F, -2.0F, 4.0F);
        this.animator.move(this.leftbackupperleg, 0.0F, -2.0F, 4.0F);
        this.animator.rotate(this.head, -1.0F, -1.2F, 0.0F);
        this.animator.rotate(this.bottomTop, -0.75F, 0.6F, 0.0F);
        this.animator.rotate(this.bottomMiddle, -0.75F, 0.6F, 0.0F);
        this.animator.rotate(this.bottomBody, -0.75F, -0.75F, 0.0F);
        this.animator.rotate(this.rightfrontupperleg, -2.25F, -0.75F, 0.0F);
        this.animator.rotate(this.leftfrontupperleg, -2.25F, 0.75F, 0.0F);
        this.animator.rotate(this.rightbackupperleg, 1.0F, 0.0F, 0.0F);
        this.animator.rotate(this.leftbackupperleg, 1.0F, 0.0F, 0.0F);
        this.animator.rotate(this.leftfrontcalf, 0.2F, 0.0F, 0.0F);
        this.animator.rotate(this.leftfrontfoot, 0.2F, 0.0F, 0.0F);
        this.animator.rotate(this.rightfrontcalf, 0.2F, 0.0F, 0.0F);
        this.animator.rotate(this.rightfrontfoot, 0.2F, 0.0F, 0.0F);
        this.animator.endPhase();
        this.animator.startPhase(10);
        this.animator.move(this.bottomBody, 0.0F, 1.0F, -8.0F);
        this.animator.move(this.leftfrontupperleg, 0.0F, 1.0F, -8.0F);
        this.animator.move(this.rightfrontupperleg, 0.0F, 1.0F, -8.0F);
        this.animator.move(this.rightbackupperleg, 0.0F, 0.0F, -8.0F);
        this.animator.move(this.leftbackupperleg, 0.0F, 0.0F, -8.0F);
        this.animator.rotate(this.head, 0.5F, 0.75F, 0.0F);
        this.animator.rotate(this.bottomTop, 0.75F, 0.75F, 0.0F);
        this.animator.rotate(this.bottomMiddle, 0.75F, 0.5F, 0.0F);
        this.animator.rotate(this.bottomBody, 1.0F, 0.0F, 0.0F);
        this.animator.rotate(this.rightfrontupperleg, 0.0F, -0.5F, 0.0F);
        this.animator.rotate(this.leftfrontupperleg, 0.0F, 0.5F, 0.0F);
        this.animator.rotate(this.rightbackupperleg, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.leftbackupperleg, -0.5F, 0.0F, 0.0F);
        this.animator.endPhase();
        this.animator.resetPhase(10);
    }

    private void animateAntiTitanAttack2() {
        this.animator.setAnimationID(1);
        this.animator.startPhase(10);
        this.animator.move(this.bottomBody, 0.0F, -3.0F, 4.0F);
        this.animator.move(this.leftfrontupperleg, 0.0F, -4.0F, 4.0F);
        this.animator.move(this.rightfrontupperleg, 0.0F, -4.0F, 4.0F);
        this.animator.move(this.rightbackupperleg, 0.0F, -2.0F, 4.0F);
        this.animator.move(this.leftbackupperleg, 0.0F, -2.0F, 4.0F);
        this.animator.rotate(this.head, 0.5F, 0.5F, 0.0F);
        this.animator.rotate(this.bottomTop, 0.5F, 0.5F, 0.0F);
        this.animator.rotate(this.bottomMiddle, 0.5F, 0.5F, 0.0F);
        this.animator.rotate(this.bottomBody, 0.5F, 1.0F, 0.0F);
        this.animator.rotate(this.rightfrontupperleg, -1.5F, -0.75F, 0.0F);
        this.animator.rotate(this.leftfrontupperleg, -1.5F, 0.75F, 0.0F);
        this.animator.rotate(this.rightbackupperleg, 1.0F, 0.0F, 0.0F);
        this.animator.rotate(this.leftbackupperleg, 1.0F, 0.0F, 0.0F);
        this.animator.rotate(this.leftfrontcalf, 0.2F, 0.0F, 0.0F);
        this.animator.rotate(this.leftfrontfoot, 0.2F, 0.0F, 0.0F);
        this.animator.rotate(this.rightfrontcalf, 0.2F, 0.0F, 0.0F);
        this.animator.rotate(this.rightfrontfoot, 0.2F, 0.0F, 0.0F);
        this.animator.endPhase();
        this.animator.startPhase(10);
        this.animator.move(this.bottomBody, 0.0F, 0.0F, -8.0F);
        this.animator.move(this.leftfrontupperleg, 0.0F, 0.0F, -8.0F);
        this.animator.move(this.rightfrontupperleg, 0.0F, 0.0F, -8.0F);
        this.animator.move(this.rightbackupperleg, 0.0F, 0.0F, -8.0F);
        this.animator.move(this.leftbackupperleg, 0.0F, 0.0F, -8.0F);
        this.animator.rotate(this.head, 0.5F, -0.5F, 0.0F);
        this.animator.rotate(this.bottomTop, 0.5F, -0.5F, 0.0F);
        this.animator.rotate(this.bottomMiddle, 0.5F, -0.5F, 0.0F);
        this.animator.rotate(this.bottomBody, 0.5F, -1.0F, 0.0F);
        this.animator.rotate(this.rightfrontupperleg, 0.0F, -0.5F, 0.0F);
        this.animator.rotate(this.leftfrontupperleg, 0.0F, 0.5F, 0.0F);
        this.animator.rotate(this.rightbackupperleg, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.leftbackupperleg, -0.5F, 0.0F, 0.0F);
        this.animator.endPhase();
        this.animator.resetPhase(10);
    }

    private void animateAntiTitanAttack3() {
        this.animator.setAnimationID(1);
        this.animator.startPhase(10);
        this.animator.move(this.bottomBody, 0.0F, -2.0F, 4.0F);
        this.animator.move(this.leftfrontupperleg, 0.0F, -2.0F, 4.0F);
        this.animator.move(this.rightfrontupperleg, 0.0F, -2.0F, 4.0F);
        this.animator.move(this.rightbackupperleg, 0.0F, -1.0F, 4.0F);
        this.animator.move(this.leftbackupperleg, 0.0F, -1.0F, 4.0F);
        this.animator.rotate(this.head, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.bottomTop, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.bottomMiddle, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.bottomBody, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.rightfrontupperleg, -4.0F, -0.5F, -1.3F);
        this.animator.rotate(this.leftfrontupperleg, -4.0F, 0.5F, 1.3F);
        this.animator.rotate(this.rightbackupperleg, 1.0F, 0.0F, 0.0F);
        this.animator.rotate(this.leftbackupperleg, 1.0F, 0.0F, 0.0F);
        this.animator.rotate(this.leftfrontcalf, 0.2F, 0.0F, 0.0F);
        this.animator.rotate(this.leftfrontfoot, 0.2F, 0.0F, 0.0F);
        this.animator.rotate(this.rightfrontcalf, 0.2F, 0.0F, 0.0F);
        this.animator.rotate(this.rightfrontfoot, 0.2F, 0.0F, 0.0F);
        this.animator.endPhase();
        this.animator.startPhase(10);
        this.animator.move(this.bottomBody, 0.0F, -2.0F, -8.0F);
        this.animator.move(this.leftfrontupperleg, 0.0F, -2.0F, -8.0F);
        this.animator.move(this.rightfrontupperleg, 0.0F, -2.0F, -8.0F);
        this.animator.move(this.rightbackupperleg, 0.0F, -1.0F, -8.0F);
        this.animator.move(this.leftbackupperleg, 0.0F, -1.0F, -8.0F);
        this.animator.rotate(this.head, 2.0F, 0.0F, 0.0F);
        this.animator.rotate(this.bottomTop, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.bottomMiddle, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.bottomBody, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.rightfrontupperleg, 0.0F, -0.5F, -1.3F);
        this.animator.rotate(this.leftfrontupperleg, 0.0F, 0.5F, 1.3F);
        this.animator.rotate(this.rightbackupperleg, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.leftbackupperleg, -0.5F, 0.0F, 0.0F);
        this.animator.endPhase();
        this.animator.resetPhase(10);
    }

    private void animateAntiTitanAttack4() {
        this.animator.setAnimationID(1);
        this.animator.startPhase(10);
        this.animator.move(this.bottomBody, 0.0F, -3.0F, 4.0F);
        this.animator.move(this.leftfrontupperleg, 0.0F, -4.0F, 4.0F);
        this.animator.move(this.rightfrontupperleg, 0.0F, -4.0F, 4.0F);
        this.animator.move(this.rightbackupperleg, 0.0F, -2.0F, 4.0F);
        this.animator.move(this.leftbackupperleg, 0.0F, -2.0F, 4.0F);
        this.animator.rotate(this.head, -1.0F, 1.2F, 0.0F);
        this.animator.rotate(this.bottomTop, -0.75F, -0.6F, 0.0F);
        this.animator.rotate(this.bottomMiddle, -0.75F, -0.6F, 0.0F);
        this.animator.rotate(this.bottomBody, -0.75F, 0.75F, 0.0F);
        this.animator.rotate(this.rightfrontupperleg, -2.25F, -0.75F, 0.0F);
        this.animator.rotate(this.leftfrontupperleg, -2.25F, 0.75F, 0.0F);
        this.animator.rotate(this.rightbackupperleg, 1.0F, 0.0F, 0.0F);
        this.animator.rotate(this.leftbackupperleg, 1.0F, 0.0F, 0.0F);
        this.animator.rotate(this.leftfrontcalf, 0.2F, 0.0F, 0.0F);
        this.animator.rotate(this.leftfrontfoot, 0.2F, 0.0F, 0.0F);
        this.animator.rotate(this.rightfrontcalf, 0.2F, 0.0F, 0.0F);
        this.animator.rotate(this.rightfrontfoot, 0.2F, 0.0F, 0.0F);
        this.animator.endPhase();
        this.animator.startPhase(10);
        this.animator.move(this.bottomBody, 0.0F, 1.0F, -8.0F);
        this.animator.move(this.leftfrontupperleg, 0.0F, 1.0F, -8.0F);
        this.animator.move(this.rightfrontupperleg, 0.0F, 1.0F, -8.0F);
        this.animator.move(this.rightbackupperleg, 0.0F, 0.0F, -8.0F);
        this.animator.move(this.leftbackupperleg, 0.0F, 0.0F, -8.0F);
        this.animator.rotate(this.head, 0.5F, -0.75F, 0.0F);
        this.animator.rotate(this.bottomTop, 0.75F, -0.75F, 0.0F);
        this.animator.rotate(this.bottomMiddle, 0.75F, -0.5F, 0.0F);
        this.animator.rotate(this.bottomBody, 1.0F, 0.0F, 0.0F);
        this.animator.rotate(this.rightfrontupperleg, 0.0F, -0.5F, 0.0F);
        this.animator.rotate(this.leftfrontupperleg, 0.0F, 0.5F, 0.0F);
        this.animator.rotate(this.rightbackupperleg, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.leftbackupperleg, -0.5F, 0.0F, 0.0F);
        this.animator.endPhase();
        this.animator.resetPhase(10);
    }

    private void animateAttackStomp() {
        this.animator.setAnimationID(2);
        this.animator.startPhase(25);
        this.animator.rotate(this.head, -0.75F, 0.0F, 0.0F);
        this.animator.rotate(this.bottomTop, 0.25F, 0.0F, 0.0F);
        this.animator.rotate(this.bottomMiddle, 0.25F, 0.0F, 0.0F);
        this.animator.rotate(this.bottomBody, 0.25F, 0.0F, 0.0F);
        this.animator.endPhase();
        this.animator.startPhase(25);
        this.animator.move(this.bottomBody, 0.0F, -2.0F, 0.0F);
        this.animator.move(this.leftfrontupperleg, 0.0F, -1.0F, 0.0F);
        this.animator.move(this.rightfrontupperleg, 0.0F, -2.0F, 0.0F);
        this.animator.move(this.rightbackupperleg, 0.0F, -2.0F, 0.0F);
        this.animator.move(this.leftbackupperleg, 0.0F, -1.0F, 0.0F);
        this.animator.rotate(this.head, 1.0F, 0.0F, 0.0F);
        this.animator.rotate(this.bottomTop, -0.5F, 0.0F, 0.5F);
        this.animator.rotate(this.bottomMiddle, -0.5F, 0.25F, 0.5F);
        this.animator.rotate(this.bottomBody, -0.5F, 0.25F, 0.5F);
        this.animator.rotate(this.rightfrontupperleg, -1.5F, 0.75F, 0.0F);
        this.animator.rotate(this.rightbackupperleg, -1.5F, -0.75F, 0.0F);
        this.animator.rotate(this.rightbackcalf, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.rightfrontcalf, 0.5F, 0.0F, 0.0F);
        this.animator.endPhase();
        this.animator.startPhase(20);
        this.animator.rotate(this.head, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.bottomTop, 0.5F, 0.0F, -0.5F);
        this.animator.rotate(this.bottomMiddle, 0.5F, 0.25F, -0.5F);
        this.animator.rotate(this.bottomBody, 0.5F, 0.25F, -0.5F);
        this.animator.rotate(this.rightfrontupperleg, 0.0F, 0.75F, 0.0F);
        this.animator.rotate(this.rightbackupperleg, 0.0F, -0.75F, 0.0F);
        this.animator.rotate(this.rightbackcalf, 0.0F, 0.0F, 0.0F);
        this.animator.rotate(this.rightfrontcalf, 0.0F, 0.0F, 0.0F);
        this.animator.endPhase();
        this.animator.setStationaryPhase(5);
        this.animator.startPhase(20);
        this.animator.move(this.bottomBody, 0.0F, -2.0F, 0.0F);
        this.animator.move(this.leftfrontupperleg, 0.0F, -2.0F, 0.0F);
        this.animator.move(this.rightfrontupperleg, 0.0F, -1.0F, 0.0F);
        this.animator.move(this.rightbackupperleg, 0.0F, -1.0F, 0.0F);
        this.animator.move(this.leftbackupperleg, 0.0F, -2.0F, 0.0F);
        this.animator.rotate(this.head, 1.0F, 0.0F, 0.0F);
        this.animator.rotate(this.bottomTop, -0.5F, 0.0F, -0.5F);
        this.animator.rotate(this.bottomMiddle, -0.5F, -0.25F, -0.5F);
        this.animator.rotate(this.bottomBody, -0.5F, -0.25F, -0.5F);
        this.animator.rotate(this.leftfrontupperleg, -1.5F, -0.75F, 0.0F);
        this.animator.rotate(this.leftbackupperleg, -1.5F, 0.75F, 0.0F);
        this.animator.rotate(this.leftbackcalf, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.leftfrontcalf, 0.5F, 0.0F, 0.0F);
        this.animator.endPhase();
        this.animator.startPhase(20);
        this.animator.rotate(this.head, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.bottomTop, 0.5F, 0.0F, 0.5F);
        this.animator.rotate(this.bottomMiddle, 0.5F, -0.25F, 0.5F);
        this.animator.rotate(this.bottomBody, 0.5F, -0.25F, 0.5F);
        this.animator.rotate(this.leftfrontupperleg, 0.0F, -0.75F, 0.0F);
        this.animator.rotate(this.leftbackupperleg, 0.0F, 0.75F, 0.0F);
        this.animator.rotate(this.leftbackcalf, 0.0F, 0.0F, 0.0F);
        this.animator.rotate(this.leftfrontcalf, 0.0F, 0.0F, 0.0F);
        this.animator.endPhase();
        this.animator.setStationaryPhase(20);
        this.animator.resetPhase(20);
    }

    private void animateStomp() {
        this.animator.setAnimationID(3);
        this.animator.startPhase(20);
        this.animator.move(this.bottomBody, 0.0F, 0.5F, 0.0F);
        this.animator.move(this.leftfrontupperleg, 0.0F, 0.5F, 0.0F);
        this.animator.move(this.rightfrontupperleg, 0.0F, 0.5F, 0.0F);
        this.animator.rotate(this.head, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.bottomTop, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.bottomMiddle, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.bottomBody, 0.5F, 0.0F, 0.0F);
        this.animator.endPhase();
        this.animator.startPhase(40);
        this.animator.move(this.bottomBody, 0.0F, -2.0F, 1.0F);
        this.animator.move(this.leftfrontupperleg, 0.0F, -2.0F, 1.0F);
        this.animator.move(this.rightfrontupperleg, 0.0F, -2.0F, 1.0F);
        this.animator.move(this.rightbackupperleg, 0.0F, -1.0F, 1.0F);
        this.animator.move(this.leftbackupperleg, 0.0F, -1.0F, 1.0F);
        this.animator.rotate(this.head, 1.0F, 0.0F, 0.0F);
        this.animator.rotate(this.bottomTop, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.bottomMiddle, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.bottomBody, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.rightfrontupperleg, -1.5F, -0.5F, 0.0F);
        this.animator.rotate(this.leftfrontupperleg, -1.5F, 0.5F, 0.0F);
        this.animator.rotate(this.rightbackupperleg, 0.3F, 0.0F, 0.0F);
        this.animator.rotate(this.leftbackupperleg, 0.3F, 0.0F, 0.0F);
        this.animator.rotate(this.leftfrontcalf, 0.2F, 0.0F, 0.0F);
        this.animator.rotate(this.leftfrontfoot, 0.2F, 0.0F, 0.0F);
        this.animator.rotate(this.rightfrontcalf, 0.2F, 0.0F, 0.0F);
        this.animator.rotate(this.rightfrontfoot, 0.2F, 0.0F, 0.0F);
        this.animator.endPhase();
        this.animator.startPhase(30);
        this.animator.move(this.bottomBody, 0.0F, 1.0F, -3.0F);
        this.animator.move(this.leftfrontupperleg, 0.0F, 1.0F, -2.0F);
        this.animator.move(this.rightfrontupperleg, 0.0F, 1.0F, -2.0F);
        this.animator.move(this.rightbackupperleg, 0.0F, 0.0F, -2.0F);
        this.animator.move(this.leftbackupperleg, 0.0F, 0.0F, -2.0F);
        this.animator.rotate(this.head, -1.0F, 0.0F, 0.0F);
        this.animator.rotate(this.bottomTop, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.bottomMiddle, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.bottomBody, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.rightfrontupperleg, 0.0F, -0.5F, 0.0F);
        this.animator.rotate(this.leftfrontupperleg, 0.0F, 0.5F, 0.0F);
        this.animator.rotate(this.rightbackupperleg, 0.1F, 0.0F, 0.0F);
        this.animator.rotate(this.leftbackupperleg, 0.1F, 0.0F, 0.0F);
        this.animator.endPhase();
        this.animator.startPhase(20);
        this.animator.move(this.bottomBody, 0.0F, 0.0F, 0.0F);
        this.animator.move(this.leftfrontupperleg, 0.0F, 0.0F, 0.0F);
        this.animator.move(this.rightfrontupperleg, 0.0F, 0.0F, 0.0F);
        this.animator.endPhase();
        this.animator.resetPhase(40);
    }

    private void animateHeadSlam() {
        this.animator.setAnimationID(4);
        this.animator.startPhase(10);
        this.animator.rotate(this.head, 0.25F, 0.0F, 0.0F);
        this.animator.rotate(this.bottomTop, 0.25F, 0.0F, 0.0F);
        this.animator.rotate(this.bottomMiddle, 0.25F, 0.0F, 0.0F);
        this.animator.rotate(this.bottomBody, 0.25F, 0.0F, 0.0F);
        this.animator.endPhase();
        this.animator.startPhase(15);
        this.animator.rotate(this.head, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.bottomTop, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.bottomMiddle, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.bottomBody, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.rightfrontupperleg, -1.0F, -0.5F, 0.0F);
        this.animator.rotate(this.leftfrontupperleg, -1.0F, 0.5F, 0.0F);
        this.animator.rotate(this.rightbackupperleg, 0.3F, 0.0F, 0.0F);
        this.animator.rotate(this.leftbackupperleg, 0.3F, 0.0F, 0.0F);
        this.animator.rotate(this.leftfrontcalf, 0.2F, 0.0F, 0.0F);
        this.animator.rotate(this.leftfrontfoot, 0.2F, 0.0F, 0.0F);
        this.animator.rotate(this.rightfrontcalf, 0.2F, 0.0F, 0.0F);
        this.animator.rotate(this.rightfrontfoot, 0.2F, 0.0F, 0.0F);
        this.animator.endPhase();
        this.animator.startPhase(15);
        this.animator.rotate(this.head, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.bottomTop, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.bottomMiddle, 1.0F, 0.0F, 0.0F);
        this.animator.rotate(this.bottomBody, 1.5F, 0.0F, 0.0F);
        this.animator.rotate(this.rightfrontupperleg, 0.0F, -0.5F, 0.0F);
        this.animator.rotate(this.leftfrontupperleg, 0.0F, 0.5F, 0.0F);
        this.animator.rotate(this.rightbackupperleg, 0.1F, 0.0F, 0.0F);
        this.animator.rotate(this.leftbackupperleg, 0.1F, 0.0F, 0.0F);
        this.animator.endPhase();
        this.animator.resetPhase(30);
    }

    private void animateKick() {
        this.animator.setAnimationID(5);
        this.animator.startPhase(20);
        this.animator.rotate(this.head, 0.5F, -1.0F, 0.0F);
        this.animator.rotate(this.bottomTop, -0.25F, 0.5F, 0.0F);
        this.animator.rotate(this.bottomMiddle, -0.25F, 0.5F, 0.0F);
        this.animator.rotate(this.rightfrontupperleg, -1.5F, 1.0F, 0.0F);
        this.animator.rotate(this.rightfrontcalf, 0.75F, -1.0F, 0.0F);
        this.animator.rotate(this.rightfrontfoot, 0.75F, -1.0F, 0.0F);
        this.animator.endPhase();
        this.animator.startPhase(20);
        this.animator.rotate(this.head, -1.0F, 1.0F, 0.0F);
        this.animator.rotate(this.bottomTop, 0.5F, -0.5F, 0.0F);
        this.animator.rotate(this.bottomMiddle, 0.5F, -0.5F, 0.0F);
        this.animator.rotate(this.rightfrontupperleg, -0.25F, -1.5F, 0.0F);
        this.animator.rotate(this.rightfrontcalf, -0.25F, -0.75F, 0.0F);
        this.animator.rotate(this.rightfrontfoot, -0.25F, -0.75F, 0.0F);
        this.animator.endPhase();
        this.animator.resetPhase(20);
    }

    private void animateSpit() {
        this.animator.setAnimationID(6);
        this.animator.startPhase(20);
        this.animator.rotate(this.head, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.bottomTop, -0.25F, 0.0F, 0.0F);
        this.animator.rotate(this.bottomMiddle, -0.25F, 0.0F, 0.0F);
        this.animator.move(this.bottomBody, 0.0F, -0.5F, 0.0F);
        this.animator.move(this.leftfrontupperleg, 0.0F, -0.5F, 0.0F);
        this.animator.move(this.rightbackupperleg, 0.0F, -0.5F, 0.0F);
        this.animator.move(this.leftbackupperleg, 0.0F, -0.5F, 0.0F);
        this.animator.move(this.rightfrontupperleg, 0.0F, -0.5F, 0.0F);
        this.animator.rotate(this.leftfrontupperleg, 0.1F, 0.0F, 0.0F);
        this.animator.rotate(this.rightbackupperleg, 0.1F, 0.0F, 0.0F);
        this.animator.rotate(this.leftbackupperleg, 0.1F, 0.0F, 0.0F);
        this.animator.rotate(this.rightfrontupperleg, 0.1F, 0.0F, 0.0F);
        this.animator.rotate(this.rightbackcalf, -0.1F, 0.0F, 0.0F);
        this.animator.rotate(this.leftfrontcalf, -0.1F, 0.0F, 0.0F);
        this.animator.rotate(this.leftbackcalf, -0.1F, 0.0F, 0.0F);
        this.animator.rotate(this.rightfrontcalf, -0.1F, 0.0F, 0.0F);
        this.animator.endPhase();
        this.animator.startPhase(20);
        this.animator.rotate(this.head, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.bottomTop, 0.25F, 0.0F, 0.0F);
        this.animator.rotate(this.bottomMiddle, 0.25F, 0.0F, 0.0F);
        this.animator.move(this.bottomBody, 0.0F, 0.0F, 0.0F);
        this.animator.rotate(this.rightbackcalf, -0.1F, 0.0F, 0.0F);
        this.animator.rotate(this.leftfrontcalf, -0.1F, 0.0F, 0.0F);
        this.animator.rotate(this.leftbackcalf, -0.1F, 0.0F, 0.0F);
        this.animator.rotate(this.rightfrontcalf, -0.1F, 0.0F, 0.0F);
        this.animator.endPhase();
        this.animator.resetPhase(20);
    }

    private void animateThunderClap() {
        this.animator.setAnimationID(7);
        this.animator.startPhase(20);
        this.animator.move(this.bottomBody, 0.0F, 0.5F, 0.0F);
        this.animator.move(this.leftfrontupperleg, 0.0F, 0.5F, 0.0F);
        this.animator.move(this.rightfrontupperleg, 0.0F, 0.5F, 0.0F);
        this.animator.rotate(this.head, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.bottomTop, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.bottomMiddle, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.bottomBody, 0.5F, 0.0F, 0.0F);
        this.animator.endPhase();
        this.animator.startPhase(30);
        this.animator.move(this.bottomBody, 0.0F, -2.0F, 1.0F);
        this.animator.move(this.leftfrontupperleg, 0.0F, -2.0F, 1.0F);
        this.animator.move(this.rightfrontupperleg, 0.0F, -2.0F, 1.0F);
        this.animator.move(this.rightbackupperleg, 0.0F, -1.0F, 1.0F);
        this.animator.move(this.leftbackupperleg, 0.0F, -1.0F, 1.0F);
        this.animator.rotate(this.head, 1.0F, 0.0F, 0.0F);
        this.animator.rotate(this.bottomTop, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.bottomMiddle, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.bottomBody, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.rightfrontupperleg, -1.5F, -0.5F, 0.0F);
        this.animator.rotate(this.leftfrontupperleg, -1.5F, 0.5F, 0.0F);
        this.animator.rotate(this.rightbackupperleg, 0.35F, 0.0F, 0.0F);
        this.animator.rotate(this.leftbackupperleg, 0.35F, 0.0F, 0.0F);
        this.animator.rotate(this.leftfrontcalf, 0.2F, 0.0F, 0.0F);
        this.animator.rotate(this.leftfrontfoot, 0.2F, 0.0F, 0.0F);
        this.animator.rotate(this.rightfrontcalf, 0.2F, 0.0F, 0.0F);
        this.animator.rotate(this.rightfrontfoot, 0.2F, 0.0F, 0.0F);
        this.animator.endPhase();
        this.animator.startPhase(20);
        this.animator.move(this.bottomBody, 0.0F, -2.0F, 1.0F);
        this.animator.move(this.leftfrontupperleg, 0.0F, -2.0F, 1.0F);
        this.animator.move(this.rightfrontupperleg, 0.0F, -2.0F, 1.0F);
        this.animator.move(this.rightbackupperleg, 0.0F, -1.0F, 1.0F);
        this.animator.move(this.leftbackupperleg, 0.0F, -1.0F, 1.0F);
        this.animator.rotate(this.head, 1.0F, 0.0F, 0.0F);
        this.animator.rotate(this.bottomTop, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.bottomMiddle, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.bottomBody, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.rightfrontupperleg, -1.25F, -0.5F, -1.3F);
        this.animator.rotate(this.leftfrontupperleg, -1.25F, 0.5F, 1.3F);
        this.animator.rotate(this.rightbackupperleg, 0.35F, 0.0F, 0.0F);
        this.animator.rotate(this.leftbackupperleg, 0.35F, 0.0F, 0.0F);
        this.animator.rotate(this.leftfrontcalf, 0.2F, 0.0F, 0.0F);
        this.animator.rotate(this.leftfrontfoot, 0.2F, 0.0F, 0.0F);
        this.animator.rotate(this.rightfrontcalf, 0.2F, 0.0F, 0.0F);
        this.animator.rotate(this.rightfrontfoot, 0.2F, 0.0F, 0.0F);
        this.animator.endPhase();
        this.animator.startPhase(25);
        this.animator.move(this.bottomBody, 0.0F, -2.0F, 1.0F);
        this.animator.move(this.leftfrontupperleg, 0.0F, -2.0F, 1.0F);
        this.animator.move(this.rightfrontupperleg, 0.0F, -2.0F, 1.0F);
        this.animator.move(this.rightbackupperleg, 0.0F, -1.0F, 1.0F);
        this.animator.move(this.leftbackupperleg, 0.0F, -1.0F, 1.0F);
        this.animator.rotate(this.head, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.bottomTop, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.bottomMiddle, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.bottomBody, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.rightfrontupperleg, -2.5F, -0.5F, -1.3F);
        this.animator.rotate(this.leftfrontupperleg, -2.5F, 0.5F, 1.3F);
        this.animator.rotate(this.rightbackupperleg, 0.35F, 0.0F, 0.0F);
        this.animator.rotate(this.leftbackupperleg, 0.35F, 0.0F, 0.0F);
        this.animator.rotate(this.leftfrontcalf, 0.2F, 0.0F, 0.0F);
        this.animator.rotate(this.leftfrontfoot, 0.2F, 0.0F, 0.0F);
        this.animator.rotate(this.rightfrontcalf, 0.2F, 0.0F, 0.0F);
        this.animator.rotate(this.rightfrontfoot, 0.2F, 0.0F, 0.0F);
        this.animator.endPhase();
        this.animator.startPhase(5);
        this.animator.move(this.bottomBody, 0.0F, -2.0F, 1.0F);
        this.animator.move(this.leftfrontupperleg, 0.0F, -2.0F, 1.0F);
        this.animator.move(this.rightfrontupperleg, 0.0F, -2.0F, 1.0F);
        this.animator.move(this.rightbackupperleg, 0.0F, -1.0F, 1.0F);
        this.animator.move(this.leftbackupperleg, 0.0F, -1.0F, 1.0F);
        this.animator.rotate(this.head, 2.0F, 0.0F, 0.0F);
        this.animator.rotate(this.bottomTop, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.bottomMiddle, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.bottomBody, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.rightfrontupperleg, -0.75F, -0.5F, -1.3F);
        this.animator.rotate(this.leftfrontupperleg, -0.75F, 0.5F, 1.3F);
        this.animator.rotate(this.rightbackupperleg, 0.2F, 0.0F, 0.0F);
        this.animator.rotate(this.leftbackupperleg, 0.2F, 0.0F, 0.0F);
        this.animator.rotate(this.leftfrontcalf, 0.4F, 0.0F, 0.0F);
        this.animator.rotate(this.leftfrontfoot, 0.4F, 0.0F, 0.0F);
        this.animator.rotate(this.rightfrontcalf, 0.2F, 0.0F, 0.0F);
        this.animator.rotate(this.rightfrontfoot, 0.2F, 0.0F, 0.0F);
        this.animator.endPhase();
        this.animator.startPhase(30);
        this.animator.move(this.bottomBody, 0.0F, -2.0F, 1.0F);
        this.animator.move(this.leftfrontupperleg, 0.0F, -2.0F, 1.0F);
        this.animator.move(this.rightfrontupperleg, 0.0F, -2.0F, 1.0F);
        this.animator.move(this.rightbackupperleg, 0.0F, -1.0F, 1.0F);
        this.animator.move(this.leftbackupperleg, 0.0F, -1.0F, 1.0F);
        this.animator.rotate(this.head, 1.0F, 0.0F, 0.0F);
        this.animator.rotate(this.bottomTop, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.bottomMiddle, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.bottomBody, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.rightfrontupperleg, -1.0F, -0.5F, 0.0F);
        this.animator.rotate(this.leftfrontupperleg, -1.0F, 0.5F, 0.0F);
        this.animator.rotate(this.rightbackupperleg, 0.2F, 0.0F, 0.0F);
        this.animator.rotate(this.leftbackupperleg, 0.2F, 0.0F, 0.0F);
        this.animator.rotate(this.leftfrontcalf, 0.2F, 0.0F, 0.0F);
        this.animator.rotate(this.leftfrontfoot, 0.2F, 0.0F, 0.0F);
        this.animator.rotate(this.rightfrontcalf, 0.2F, 0.0F, 0.0F);
        this.animator.rotate(this.rightfrontfoot, 0.2F, 0.0F, 0.0F);
        this.animator.endPhase();
        this.animator.startPhase(30);
        this.animator.move(this.bottomBody, 0.0F, 1.0F, -3.0F);
        this.animator.move(this.leftfrontupperleg, 0.0F, 1.0F, -2.0F);
        this.animator.move(this.rightfrontupperleg, 0.0F, 1.0F, -2.0F);
        this.animator.move(this.rightbackupperleg, 0.0F, 0.0F, -2.0F);
        this.animator.move(this.leftbackupperleg, 0.0F, 0.0F, -2.0F);
        this.animator.rotate(this.head, -1.0F, 0.0F, 0.0F);
        this.animator.rotate(this.bottomTop, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.bottomMiddle, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.bottomBody, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.rightfrontupperleg, 0.0F, -0.5F, 0.0F);
        this.animator.rotate(this.leftfrontupperleg, 0.0F, 0.5F, 0.0F);
        this.animator.rotate(this.rightbackupperleg, 0.1F, 0.0F, 0.0F);
        this.animator.rotate(this.leftbackupperleg, 0.1F, 0.0F, 0.0F);
        this.animator.endPhase();
        this.animator.startPhase(20);
        this.animator.move(this.bottomBody, 0.0F, 0.0F, 0.0F);
        this.animator.move(this.leftfrontupperleg, 0.0F, 0.0F, 0.0F);
        this.animator.move(this.rightfrontupperleg, 0.0F, 0.0F, 0.0F);
        this.animator.endPhase();
        this.animator.resetPhase(50);
    }

    private void animateStunned() {
        this.animator.setAnimationID(8);
        this.animator.startPhase(0);
        this.animator.move(this.bottomBody, 0.0F, 0.0F, 1.0F);
        this.animator.move(this.leftfrontupperleg, 0.0F, 0.0F, 1.0F);
        this.animator.move(this.rightfrontupperleg, 0.0F, 0.0F, 1.0F);
        this.animator.move(this.rightbackupperleg, 0.0F, 0.0F, 1.0F);
        this.animator.move(this.leftbackupperleg, 0.0F, 0.0F, 1.0F);
        this.animator.rotate(this.head, 1.0F, 0.0F, 0.0F);
        this.animator.rotate(this.bottomTop, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.bottomMiddle, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.bottomBody, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.rightfrontupperleg, 0.2F, 0.25F, 0.0F);
        this.animator.rotate(this.leftfrontupperleg, 0.2F, -0.25F, 0.0F);
        this.animator.rotate(this.rightbackupperleg, 0.2F, 0.0F, 0.0F);
        this.animator.rotate(this.leftbackupperleg, 0.2F, 0.0F, 0.0F);
        this.animator.rotate(this.leftfrontcalf, 0.2F, 0.0F, 0.0F);
        this.animator.rotate(this.leftfrontfoot, 0.2F, 0.0F, 0.0F);
        this.animator.rotate(this.rightfrontcalf, 0.2F, 0.0F, 0.0F);
        this.animator.rotate(this.rightfrontfoot, 0.2F, 0.0F, 0.0F);
        this.animator.endPhase();
        this.animator.startPhase(40);
        this.animator.move(this.bottomBody, 0.0F, -2.0F, 1.0F);
        this.animator.move(this.leftfrontupperleg, 0.0F, -3.0F, 1.0F);
        this.animator.move(this.rightfrontupperleg, 0.0F, -3.0F, 1.0F);
        this.animator.move(this.rightbackupperleg, 0.0F, -1.0F, 1.0F);
        this.animator.move(this.leftbackupperleg, 0.0F, -1.0F, 1.0F);
        this.animator.rotate(this.head, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.bottomTop, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.bottomMiddle, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.bottomBody, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.rightfrontupperleg, 0.25F, 0.35F, 0.0F);
        this.animator.rotate(this.leftfrontupperleg, 0.25F, -0.35F, 0.0F);
        this.animator.rotate(this.rightbackupperleg, 0.25F, 0.0F, 0.0F);
        this.animator.rotate(this.leftbackupperleg, 0.25F, 0.0F, 0.0F);
        this.animator.rotate(this.leftfrontcalf, 0.2F, 0.0F, 0.0F);
        this.animator.rotate(this.leftfrontfoot, 0.2F, 0.0F, 0.0F);
        this.animator.rotate(this.rightfrontcalf, 0.2F, 0.0F, 0.0F);
        this.animator.rotate(this.rightfrontfoot, 0.2F, 0.0F, 0.0F);
        this.animator.endPhase();
        this.animator.startPhase(60);
        this.animator.move(this.bottomBody, 0.0F, -1.0F, 1.0F);
        this.animator.move(this.leftfrontupperleg, 0.0F, -2.0F, 1.0F);
        this.animator.move(this.rightfrontupperleg, 0.0F, -2.0F, 1.0F);
        this.animator.move(this.rightbackupperleg, 0.0F, 0.0F, 1.0F);
        this.animator.move(this.leftbackupperleg, 0.0F, 0.0F, 1.0F);
        this.animator.rotate(this.head, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.bottomTop, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.bottomMiddle, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.bottomBody, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.rightfrontupperleg, 0.0F, 0.25F, 0.0F);
        this.animator.rotate(this.leftfrontupperleg, 0.0F, -0.25F, 0.0F);
        this.animator.rotate(this.rightbackupperleg, -0.25F, 0.0F, 0.0F);
        this.animator.rotate(this.leftbackupperleg, -0.25F, 0.0F, 0.0F);
        this.animator.rotate(this.leftfrontcalf, 0.2F, 0.0F, 0.0F);
        this.animator.rotate(this.leftfrontfoot, 0.2F, 0.0F, 0.0F);
        this.animator.rotate(this.rightfrontcalf, 0.2F, 0.0F, 0.0F);
        this.animator.rotate(this.rightfrontfoot, 0.2F, 0.0F, 0.0F);
        this.animator.endPhase();
        this.animator.startPhase(30);
        this.animator.move(this.bottomBody, 0.0F, 7.0F, 0.0F);
        this.animator.move(this.leftfrontupperleg, 0.0F, 7.0F, 0.0F);
        this.animator.move(this.rightfrontupperleg, 0.0F, 7.0F, 0.0F);
        this.animator.move(this.rightbackupperleg, 0.0F, 7.0F, 0.0F);
        this.animator.move(this.leftbackupperleg, 0.0F, 7.0F, 0.0F);
        this.animator.rotate(this.head, 0.25F, 0.0F, 0.0F);
        this.animator.rotate(this.bottomTop, 0.25F, 0.0F, 0.0F);
        this.animator.rotate(this.bottomMiddle, 0.25F, 0.0F, 0.0F);
        this.animator.rotate(this.bottomBody, 0.25F, 0.0F, 0.0F);
        this.animator.rotate(this.rightfrontupperleg, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.leftfrontupperleg, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.rightbackupperleg, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.leftbackupperleg, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.leftfrontcalf, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.leftfrontfoot, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.rightfrontcalf, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.rightfrontfoot, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.leftbackcalf, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.leftbackfoot, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.rightbackcalf, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.rightbackfoot, -0.5F, 0.0F, 0.0F);
        this.animator.endPhase();
        this.animator.setStationaryPhase(300);
        this.animator.startPhase(20);
        this.animator.move(this.bottomBody, 0.0F, 7.0F, 0.0F);
        this.animator.move(this.leftfrontupperleg, 0.0F, 7.0F, 0.0F);
        this.animator.move(this.rightfrontupperleg, 0.0F, 7.0F, 0.0F);
        this.animator.move(this.rightbackupperleg, 0.0F, 7.0F, 0.0F);
        this.animator.move(this.leftbackupperleg, 0.0F, 7.0F, 0.0F);
        this.animator.rotate(this.head, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.bottomTop, 0.25F, 0.0F, 0.0F);
        this.animator.rotate(this.bottomMiddle, 0.25F, 0.0F, 0.0F);
        this.animator.rotate(this.bottomBody, 0.25F, 0.0F, 0.0F);
        this.animator.rotate(this.rightfrontupperleg, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.leftfrontupperleg, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.rightbackupperleg, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.leftbackupperleg, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.leftfrontcalf, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.leftfrontfoot, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.rightfrontcalf, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.rightfrontfoot, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.leftbackcalf, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.leftbackfoot, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.rightbackcalf, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.rightbackfoot, -0.5F, 0.0F, 0.0F);
        this.animator.endPhase();
        this.animator.startPhase(20);
        this.animator.move(this.bottomBody, 0.0F, 7.0F, 0.0F);
        this.animator.move(this.leftfrontupperleg, 0.0F, 7.0F, 0.0F);
        this.animator.move(this.rightfrontupperleg, 0.0F, 7.0F, 0.0F);
        this.animator.move(this.rightbackupperleg, 0.0F, 7.0F, 0.0F);
        this.animator.move(this.leftbackupperleg, 0.0F, 7.0F, 0.0F);
        this.animator.rotate(this.head, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.bottomTop, 0.25F, 0.0F, 0.0F);
        this.animator.rotate(this.bottomMiddle, 0.25F, 0.0F, 0.0F);
        this.animator.rotate(this.bottomBody, 0.25F, 0.0F, 0.0F);
        this.animator.rotate(this.rightfrontupperleg, -1.5F, 0.0F, 0.0F);
        this.animator.rotate(this.leftfrontupperleg, -1.5F, 0.0F, 0.0F);
        this.animator.rotate(this.rightbackupperleg, -1.5F, 0.0F, 0.0F);
        this.animator.rotate(this.leftbackupperleg, -1.5F, 0.0F, 0.0F);
        this.animator.rotate(this.leftfrontcalf, 1.5F, 0.0F, 0.0F);
        this.animator.rotate(this.rightfrontcalf, 1.5F, 0.0F, 0.0F);
        this.animator.rotate(this.leftbackcalf, 1.5F, 0.0F, 0.0F);
        this.animator.rotate(this.rightbackcalf, 1.5F, 0.0F, 0.0F);
        this.animator.endPhase();
        this.animator.startPhase(20);
        this.animator.rotate(this.head, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.bottomTop, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.bottomMiddle, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.bottomBody, 0.5F, 0.0F, 0.0F);
        this.animator.endPhase();
        this.animator.resetPhase(20);
    }

    private void animateDeath() {
        this.animator.setAnimationID(10);
        this.animator.startPhase(60);
        this.animator.move(this.bottomBody, 0.0F, 0.0F, -4.0F);
        this.animator.move(this.leftfrontupperleg, 0.0F, 0.0F, -4.0F);
        this.animator.move(this.rightfrontupperleg, 0.0F, 0.0F, -4.0F);
        this.animator.move(this.rightbackupperleg, 0.0F, 0.0F, -4.0F);
        this.animator.move(this.leftbackupperleg, 0.0F, 0.0F, -4.0F);
        this.animator.rotate(this.head, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.bottomTop, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.bottomMiddle, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.bottomBody, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.rightfrontupperleg, 0.0F, 0.25F, 0.0F);
        this.animator.rotate(this.leftfrontupperleg, 0.0F, -0.25F, 0.0F);
        this.animator.rotate(this.rightbackupperleg, -0.25F, 0.0F, 0.0F);
        this.animator.rotate(this.leftbackupperleg, -0.25F, 0.0F, 0.0F);
        this.animator.rotate(this.leftfrontcalf, 0.2F, 0.0F, 0.0F);
        this.animator.rotate(this.leftfrontfoot, 0.2F, 0.0F, 0.0F);
        this.animator.rotate(this.rightfrontcalf, 0.2F, 0.0F, 0.0F);
        this.animator.rotate(this.rightfrontfoot, 0.2F, 0.0F, 0.0F);
        this.animator.endPhase();
        this.animator.startPhase(60);
        this.animator.move(this.bottomBody, 0.0F, 7.0F, 4.0F);
        this.animator.move(this.leftfrontupperleg, 0.0F, 7.0F, 4.0F);
        this.animator.move(this.rightfrontupperleg, 0.0F, 7.0F, 4.0F);
        this.animator.move(this.rightbackupperleg, 0.0F, 7.0F, 4.0F);
        this.animator.move(this.leftbackupperleg, 0.0F, 7.0F, 4.0F);
        this.animator.rotate(this.head, 0.25F, 0.0F, 0.0F);
        this.animator.rotate(this.bottomTop, 0.25F, 0.0F, 0.0F);
        this.animator.rotate(this.bottomMiddle, 0.25F, 0.0F, 0.0F);
        this.animator.rotate(this.bottomBody, -1.0F, 0.0F, 0.0F);
        this.animator.rotate(this.rightfrontupperleg, -1.5F, 0.0F, 0.0F);
        this.animator.rotate(this.leftfrontupperleg, -1.5F, 0.0F, 0.0F);
        this.animator.rotate(this.rightbackupperleg, 1.0F, 0.0F, 2.0F);
        this.animator.rotate(this.leftbackupperleg, 1.0F, 0.0F, -2.0F);
        this.animator.rotate(this.leftfrontcalf, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.leftfrontfoot, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.rightfrontcalf, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.rightfrontfoot, -0.5F, 0.0F, 0.0F);
        this.animator.endPhase();
        this.animator.startPhase(60);
        this.animator.move(this.bottomBody, 0.0F, 7.0F, 4.0F);
        this.animator.move(this.leftfrontupperleg, 0.0F, 7.0F, 4.0F);
        this.animator.move(this.rightfrontupperleg, 0.0F, 7.0F, 4.0F);
        this.animator.move(this.rightbackupperleg, 0.0F, 7.0F, 4.0F);
        this.animator.move(this.leftbackupperleg, 0.0F, 7.0F, 4.0F);
        this.animator.rotate(this.head, 0.25F, 0.25F, 0.0F);
        this.animator.rotate(this.bottomTop, -0.5F, 0.25F, 0.0F);
        this.animator.rotate(this.bottomMiddle, -0.25F, 0.25F, 0.0F);
        this.animator.rotate(this.bottomBody, -1.0F, 0.0F, 0.0F);
        this.animator.rotate(this.rightfrontupperleg, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.leftfrontupperleg, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.rightbackupperleg, -0.5F, -0.5F, 0.0F);
        this.animator.rotate(this.leftbackupperleg, -0.5F, 0.5F, 0.0F);
        this.animator.rotate(this.leftfrontcalf, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.leftfrontfoot, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.rightfrontcalf, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.rightfrontfoot, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.leftbackcalf, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.leftbackfoot, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.rightbackcalf, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.rightbackfoot, -0.5F, 0.0F, 0.0F);
        this.animator.endPhase();
        this.animator.setStationaryPhase(60);
        this.animator.startPhase(40);
        this.animator.move(this.bottomBody, 0.0F, 7.0F, 4.0F);
        this.animator.move(this.leftfrontupperleg, 0.0F, 7.0F, 4.0F);
        this.animator.move(this.rightfrontupperleg, 0.0F, 7.0F, 4.0F);
        this.animator.move(this.rightbackupperleg, 0.0F, 7.0F, 4.0F);
        this.animator.move(this.leftbackupperleg, 0.0F, 7.0F, 4.0F);
        this.animator.rotate(this.head, 0.25F, 0.0F, 0.0F);
        this.animator.rotate(this.bottomTop, 0.25F, 0.0F, 0.0F);
        this.animator.rotate(this.bottomMiddle, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.bottomBody, -1.0F, 0.0F, 0.0F);
        this.animator.rotate(this.rightfrontupperleg, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.leftfrontupperleg, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.rightbackupperleg, -0.5F, -0.5F, 0.0F);
        this.animator.rotate(this.leftbackupperleg, -0.5F, 0.5F, 0.0F);
        this.animator.rotate(this.leftfrontcalf, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.leftfrontfoot, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.rightfrontcalf, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.rightfrontfoot, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.leftbackcalf, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.leftbackfoot, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.rightbackcalf, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.rightbackfoot, -0.5F, 0.0F, 0.0F);
        this.animator.endPhase();
        this.animator.startPhase(10);
        this.animator.move(this.bottomBody, 0.0F, 7.0F, 4.0F);
        this.animator.move(this.leftfrontupperleg, 0.0F, 7.0F, 4.0F);
        this.animator.move(this.rightfrontupperleg, 0.0F, 7.0F, 4.0F);
        this.animator.move(this.rightbackupperleg, 0.0F, 7.0F, 4.0F);
        this.animator.move(this.leftbackupperleg, 0.0F, 7.0F, 4.0F);
        this.animator.rotate(this.head, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.bottomTop, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.bottomMiddle, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.bottomBody, 0.0F, 0.0F, 0.0F);
        this.animator.rotate(this.rightfrontupperleg, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.leftfrontupperleg, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.rightbackupperleg, -0.5F, -0.5F, 0.0F);
        this.animator.rotate(this.leftbackupperleg, -0.5F, 0.5F, 0.0F);
        this.animator.rotate(this.leftfrontcalf, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.leftfrontfoot, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.rightfrontcalf, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.rightfrontfoot, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.leftbackcalf, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.leftbackfoot, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.rightbackcalf, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.rightbackfoot, -0.5F, 0.0F, 0.0F);
        this.animator.endPhase();
        this.animator.startPhase(10);
        this.animator.move(this.bottomBody, 0.0F, 7.0F, 4.0F);
        this.animator.move(this.leftfrontupperleg, 0.0F, 7.0F, 4.0F);
        this.animator.move(this.rightfrontupperleg, 0.0F, 7.0F, 4.0F);
        this.animator.move(this.rightbackupperleg, 0.0F, 7.0F, 4.0F);
        this.animator.move(this.leftbackupperleg, 0.0F, 7.0F, 4.0F);
        this.animator.rotate(this.head, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.bottomTop, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.bottomMiddle, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.bottomBody, 0.0F, 0.0F, 0.0F);
        this.animator.rotate(this.rightfrontupperleg, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.leftfrontupperleg, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.rightbackupperleg, -0.5F, -0.5F, 0.0F);
        this.animator.rotate(this.leftbackupperleg, -0.5F, 0.5F, 0.0F);
        this.animator.rotate(this.leftfrontcalf, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.leftfrontfoot, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.rightfrontcalf, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.rightfrontfoot, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.leftbackcalf, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.leftbackfoot, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.rightbackcalf, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.rightbackfoot, -0.5F, 0.0F, 0.0F);
        this.animator.endPhase();
        this.animator.setStationaryPhase(1720);
        this.animator.resetPhase(0);
    }

    private void animateBirth() {
        this.animator.setAnimationID(13);
        this.animator.startPhase(0);
        this.animator.move(this.bottomBody, 0.0F, 7.0F, 0.0F);
        this.animator.move(this.leftfrontupperleg, 0.0F, 7.0F, 0.0F);
        this.animator.move(this.rightfrontupperleg, 0.0F, 7.0F, 0.0F);
        this.animator.move(this.rightbackupperleg, 0.0F, 7.0F, 0.0F);
        this.animator.move(this.leftbackupperleg, 0.0F, 7.0F, 0.0F);
        this.animator.rotate(this.head, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.bottomTop, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.bottomMiddle, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.bottomBody, 0.25F, 0.0F, 0.0F);
        this.animator.rotate(this.rightfrontupperleg, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.leftfrontupperleg, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.rightbackupperleg, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.leftbackupperleg, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.leftfrontcalf, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.leftfrontfoot, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.rightfrontcalf, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.rightfrontfoot, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.leftbackcalf, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.leftbackfoot, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.rightbackcalf, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.rightbackfoot, -0.5F, 0.0F, 0.0F);
        this.animator.endPhase();
        this.animator.setStationaryPhase(60);
        this.animator.startPhase(60);
        this.animator.move(this.bottomBody, 0.0F, 7.0F, 0.0F);
        this.animator.move(this.leftfrontupperleg, 0.0F, 7.0F, 0.0F);
        this.animator.move(this.rightfrontupperleg, 0.0F, 7.0F, 0.0F);
        this.animator.move(this.rightbackupperleg, 0.0F, 7.0F, 0.0F);
        this.animator.move(this.leftbackupperleg, 0.0F, 7.0F, 0.0F);
        this.animator.rotate(this.head, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.bottomTop, 0.25F, 0.0F, 0.0F);
        this.animator.rotate(this.bottomMiddle, 0.25F, 0.0F, 0.0F);
        this.animator.rotate(this.bottomBody, 0.25F, 0.0F, 0.0F);
        this.animator.rotate(this.rightfrontupperleg, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.leftfrontupperleg, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.rightbackupperleg, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.leftbackupperleg, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.leftfrontcalf, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.leftfrontfoot, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.rightfrontcalf, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.rightfrontfoot, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.leftbackcalf, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.leftbackfoot, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.rightbackcalf, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.rightbackfoot, -0.5F, 0.0F, 0.0F);
        this.animator.endPhase();
        this.animator.startPhase(80);
        this.animator.move(this.bottomBody, 0.0F, 7.0F, 0.0F);
        this.animator.move(this.leftfrontupperleg, 0.0F, 7.0F, 0.0F);
        this.animator.move(this.rightfrontupperleg, 0.0F, 7.0F, 0.0F);
        this.animator.move(this.rightbackupperleg, 0.0F, 7.0F, 0.0F);
        this.animator.move(this.leftbackupperleg, 0.0F, 7.0F, 0.0F);
        this.animator.rotate(this.head, 0.25F, 0.0F, 0.0F);
        this.animator.rotate(this.bottomTop, 0.25F, 0.0F, 0.0F);
        this.animator.rotate(this.bottomMiddle, 0.25F, 0.0F, 0.0F);
        this.animator.rotate(this.bottomBody, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.rightfrontupperleg, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.leftfrontupperleg, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.rightbackupperleg, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.leftbackupperleg, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.leftfrontcalf, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.leftfrontfoot, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.rightfrontcalf, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.rightfrontfoot, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.leftbackcalf, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.leftbackfoot, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.rightbackcalf, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.rightbackfoot, -0.5F, 0.0F, 0.0F);
        this.animator.endPhase();
        this.animator.startPhase(20);
        this.animator.move(this.bottomBody, 0.0F, 7.0F, 0.0F);
        this.animator.move(this.leftfrontupperleg, 0.0F, 7.0F, 0.0F);
        this.animator.move(this.rightfrontupperleg, 0.0F, 7.0F, 0.0F);
        this.animator.move(this.rightbackupperleg, 0.0F, 7.0F, 0.0F);
        this.animator.move(this.leftbackupperleg, 0.0F, 7.0F, 0.0F);
        this.animator.rotate(this.head, 0.25F, 0.0F, 0.0F);
        this.animator.rotate(this.bottomTop, 0.25F, 0.0F, 0.0F);
        this.animator.rotate(this.bottomMiddle, 0.25F, 0.0F, 0.0F);
        this.animator.rotate(this.bottomBody, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.rightfrontupperleg, -0.75F, 0.0F, 0.0F);
        this.animator.rotate(this.leftfrontupperleg, -0.75F, 0.0F, 0.0F);
        this.animator.rotate(this.rightbackupperleg, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.leftbackupperleg, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.leftfrontcalf, -0.25F, 0.0F, 0.0F);
        this.animator.rotate(this.leftfrontfoot, -0.25F, 0.0F, 0.0F);
        this.animator.rotate(this.rightfrontcalf, -0.25F, 0.0F, 0.0F);
        this.animator.rotate(this.rightfrontfoot, -0.25F, 0.0F, 0.0F);
        this.animator.rotate(this.leftbackcalf, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.leftbackfoot, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.rightbackcalf, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.rightbackfoot, -0.5F, 0.0F, 0.0F);
        this.animator.endPhase();
        this.animator.startPhase(20);
        this.animator.move(this.bottomBody, 0.0F, 6.0F, 0.0F);
        this.animator.move(this.leftfrontupperleg, 0.0F, 6.0F, 0.0F);
        this.animator.move(this.rightfrontupperleg, 0.0F, 6.0F, 0.0F);
        this.animator.move(this.rightbackupperleg, 0.0F, 7.0F, 0.0F);
        this.animator.move(this.leftbackupperleg, 0.0F, 7.0F, 0.0F);
        this.animator.rotate(this.head, 0.25F, 0.0F, 0.0F);
        this.animator.rotate(this.bottomTop, 0.25F, 0.0F, 0.0F);
        this.animator.rotate(this.bottomMiddle, 0.25F, 0.0F, 0.0F);
        this.animator.rotate(this.bottomBody, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.rightfrontupperleg, -1.25F, 0.0F, 0.0F);
        this.animator.rotate(this.leftfrontupperleg, -1.25F, 0.0F, 0.0F);
        this.animator.rotate(this.rightbackupperleg, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.leftbackupperleg, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.leftfrontcalf, -0.75F, 0.0F, 0.0F);
        this.animator.rotate(this.leftfrontfoot, -0.75F, 0.0F, 0.0F);
        this.animator.rotate(this.rightfrontcalf, -0.75F, 0.0F, 0.0F);
        this.animator.rotate(this.rightfrontfoot, -0.75F, 0.0F, 0.0F);
        this.animator.rotate(this.leftbackcalf, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.leftbackfoot, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.rightbackcalf, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.rightbackfoot, -0.5F, 0.0F, 0.0F);
        this.animator.endPhase();
        this.animator.startPhase(40);
        this.animator.move(this.bottomBody, 0.0F, 6.0F, 0.0F);
        this.animator.move(this.leftfrontupperleg, 0.0F, 6.0F, 0.0F);
        this.animator.move(this.rightfrontupperleg, 0.0F, 6.0F, 0.0F);
        this.animator.move(this.rightbackupperleg, 0.0F, 7.0F, 0.0F);
        this.animator.move(this.leftbackupperleg, 0.0F, 7.0F, 0.0F);
        this.animator.rotate(this.head, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.bottomTop, 0.25F, 0.0F, 0.0F);
        this.animator.rotate(this.bottomMiddle, 0.25F, 0.0F, 0.0F);
        this.animator.rotate(this.bottomBody, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.rightfrontupperleg, -0.75F, 0.0F, 0.0F);
        this.animator.rotate(this.leftfrontupperleg, -0.75F, 0.0F, 0.0F);
        this.animator.rotate(this.rightbackupperleg, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.leftbackupperleg, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.leftfrontcalf, 0.0F, 0.0F, 0.0F);
        this.animator.rotate(this.leftfrontfoot, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.rightfrontcalf, 0.0F, 0.0F, 0.0F);
        this.animator.rotate(this.rightfrontfoot, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.leftbackcalf, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.leftbackfoot, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.rightbackcalf, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.rightbackfoot, -0.5F, 0.0F, 0.0F);
        this.animator.endPhase();
        this.animator.startPhase(80);
        this.animator.move(this.bottomBody, 0.0F, 0.0F, 0.0F);
        this.animator.move(this.leftfrontupperleg, 0.0F, 0.0F, 0.0F);
        this.animator.move(this.rightfrontupperleg, 0.0F, 0.0F, 0.0F);
        this.animator.move(this.rightbackupperleg, 0.0F, 0.0F, 0.0F);
        this.animator.move(this.leftbackupperleg, 0.0F, 0.0F, 0.0F);
        this.animator.rotate(this.head, 0.25F, 0.0F, 0.0F);
        this.animator.rotate(this.bottomTop, 0.25F, 0.0F, 0.0F);
        this.animator.rotate(this.bottomMiddle, 0.25F, 0.0F, 0.0F);
        this.animator.rotate(this.bottomBody, 0.25F, 0.0F, 0.0F);
        this.animator.rotate(this.rightfrontupperleg, 0.0F, 0.0F, 0.0F);
        this.animator.rotate(this.leftfrontupperleg, 0.0F, 0.0F, 0.0F);
        this.animator.rotate(this.rightbackupperleg, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.leftbackupperleg, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.leftfrontcalf, 0.0F, 0.0F, 0.0F);
        this.animator.rotate(this.leftfrontfoot, 0.0F, 0.0F, 0.0F);
        this.animator.rotate(this.rightfrontcalf, 0.0F, 0.0F, 0.0F);
        this.animator.rotate(this.rightfrontfoot, 0.0F, 0.0F, 0.0F);
        this.animator.rotate(this.leftbackcalf, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.leftbackfoot, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.rightbackcalf, -0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.rightbackfoot, -0.5F, 0.0F, 0.0F);
        this.animator.endPhase();
        this.animator.startPhase(20);
        this.animator.move(this.bottomBody, 0.0F, 0.0F, 0.0F);
        this.animator.move(this.leftfrontupperleg, 0.0F, 0.0F, 0.0F);
        this.animator.move(this.rightfrontupperleg, 0.0F, 0.0F, 0.0F);
        this.animator.move(this.rightbackupperleg, 0.0F, 0.0F, 0.0F);
        this.animator.move(this.leftbackupperleg, 0.0F, 0.0F, 0.0F);
        this.animator.rotate(this.head, -0.25F, 0.0F, 0.0F);
        this.animator.rotate(this.bottomTop, 0.25F, 0.0F, 0.0F);
        this.animator.rotate(this.bottomMiddle, 0.25F, 0.0F, 0.0F);
        this.animator.rotate(this.bottomBody, -0.25F, 0.0F, 0.0F);
        this.animator.rotate(this.rightfrontupperleg, 0.0F, 0.0F, 0.0F);
        this.animator.rotate(this.leftfrontupperleg, 0.0F, 0.0F, 0.0F);
        this.animator.rotate(this.rightbackupperleg, -0.75F, 0.0F, 0.0F);
        this.animator.rotate(this.leftbackupperleg, 0.5F, 0.0F, 0.0F);
        this.animator.rotate(this.leftfrontcalf, 0.0F, 0.0F, 0.0F);
        this.animator.rotate(this.leftfrontfoot, 0.0F, 0.0F, 0.0F);
        this.animator.rotate(this.rightfrontcalf, 0.0F, 0.0F, 0.0F);
        this.animator.rotate(this.rightfrontfoot, 0.0F, 0.0F, 0.0F);
        this.animator.rotate(this.leftbackcalf, 0.0F, 0.0F, 0.0F);
        this.animator.rotate(this.leftbackfoot, 0.0F, 0.0F, 0.0F);
        this.animator.rotate(this.rightbackcalf, -0.25F, 0.0F, 0.0F);
        this.animator.rotate(this.rightbackfoot, -0.25F, 0.0F, 0.0F);
        this.animator.endPhase();
        this.animator.startPhase(20);
        this.animator.move(this.bottomBody, 0.0F, 0.0F, 0.0F);
        this.animator.move(this.leftfrontupperleg, 0.0F, 0.0F, 0.0F);
        this.animator.move(this.rightfrontupperleg, 0.0F, 0.0F, 0.0F);
        this.animator.move(this.rightbackupperleg, 0.0F, 0.0F, 0.0F);
        this.animator.move(this.leftbackupperleg, 0.0F, 0.0F, 0.0F);
        this.animator.rotate(this.head, 0.25F, 0.0F, 0.0F);
        this.animator.rotate(this.bottomTop, 0.25F, 0.0F, 0.0F);
        this.animator.rotate(this.bottomMiddle, 0.25F, 0.0F, 0.0F);
        this.animator.rotate(this.bottomBody, 0.25F, 0.0F, 0.0F);
        this.animator.rotate(this.rightfrontupperleg, 0.0F, 0.0F, 0.0F);
        this.animator.rotate(this.leftfrontupperleg, 0.0F, 0.0F, 0.0F);
        this.animator.rotate(this.rightbackupperleg, 0.0F, 0.0F, 0.0F);
        this.animator.rotate(this.leftbackupperleg, -0.75F, 0.0F, 0.0F);
        this.animator.rotate(this.leftfrontcalf, 0.0F, 0.0F, 0.0F);
        this.animator.rotate(this.leftfrontfoot, 0.0F, 0.0F, 0.0F);
        this.animator.rotate(this.rightfrontcalf, 0.0F, 0.0F, 0.0F);
        this.animator.rotate(this.rightfrontfoot, 0.0F, 0.0F, 0.0F);
        this.animator.rotate(this.leftbackcalf, 0.0F, 0.0F, 0.0F);
        this.animator.rotate(this.leftbackfoot, 0.0F, 0.0F, 0.0F);
        this.animator.rotate(this.rightbackcalf, 0.0F, 0.0F, 0.0F);
        this.animator.rotate(this.rightbackfoot, 0.0F, 0.0F, 0.0F);
        this.animator.endPhase();
        this.animator.startPhase(20);
        this.animator.move(this.bottomBody, 0.0F, 0.0F, 0.0F);
        this.animator.move(this.leftfrontupperleg, 0.0F, 0.0F, 0.0F);
        this.animator.move(this.rightfrontupperleg, 0.0F, 0.0F, 0.0F);
        this.animator.move(this.rightbackupperleg, 0.0F, 0.0F, 0.0F);
        this.animator.move(this.leftbackupperleg, 0.0F, 0.0F, 0.0F);
        this.animator.rotate(this.head, -0.5F, 0.25F, 0.0F);
        this.animator.rotate(this.bottomTop, 0.25F, 0.0F, -0.3F);
        this.animator.rotate(this.bottomMiddle, 0.25F, 0.0F, 0.1F);
        this.animator.rotate(this.bottomBody, 0.25F, 0.0F, 0.2F);
        this.animator.rotate(this.rightfrontupperleg, 0.0F, 0.0F, 0.0F);
        this.animator.rotate(this.leftfrontupperleg, 0.0F, 0.0F, 0.0F);
        this.animator.rotate(this.rightbackupperleg, 0.0F, 0.0F, 0.0F);
        this.animator.rotate(this.leftbackupperleg, 0.0F, 0.0F, 0.0F);
        this.animator.rotate(this.leftfrontcalf, 0.0F, 0.0F, 0.0F);
        this.animator.rotate(this.leftfrontfoot, 0.0F, 0.0F, 0.0F);
        this.animator.rotate(this.rightfrontcalf, 0.0F, 0.0F, 0.0F);
        this.animator.rotate(this.rightfrontfoot, 0.0F, 0.0F, 0.0F);
        this.animator.rotate(this.leftbackcalf, 0.0F, 0.0F, 0.0F);
        this.animator.rotate(this.leftbackfoot, 0.0F, 0.0F, 0.0F);
        this.animator.rotate(this.rightbackcalf, 0.0F, 0.0F, 0.0F);
        this.animator.rotate(this.rightbackfoot, 0.0F, 0.0F, 0.0F);
        this.animator.endPhase();
        this.animator.startPhase(20);
        this.animator.move(this.bottomBody, 0.0F, 0.0F, 0.0F);
        this.animator.move(this.leftfrontupperleg, 0.0F, 0.0F, 0.0F);
        this.animator.move(this.rightfrontupperleg, 0.0F, 0.0F, 0.0F);
        this.animator.move(this.rightbackupperleg, 0.0F, 0.0F, 0.0F);
        this.animator.move(this.leftbackupperleg, 0.0F, 0.0F, 0.0F);
        this.animator.rotate(this.head, -0.5F, -0.25F, 0.0F);
        this.animator.rotate(this.bottomTop, 0.25F, 0.0F, 0.3F);
        this.animator.rotate(this.bottomMiddle, 0.25F, 0.0F, -0.1F);
        this.animator.rotate(this.bottomBody, 0.25F, 0.0F, -0.2F);
        this.animator.rotate(this.rightfrontupperleg, 0.0F, 0.0F, 0.0F);
        this.animator.rotate(this.leftfrontupperleg, 0.0F, 0.0F, 0.0F);
        this.animator.rotate(this.rightbackupperleg, 0.0F, 0.0F, 0.0F);
        this.animator.rotate(this.leftbackupperleg, 0.0F, 0.0F, 0.0F);
        this.animator.rotate(this.leftfrontcalf, 0.0F, 0.0F, 0.0F);
        this.animator.rotate(this.leftfrontfoot, 0.0F, 0.0F, 0.0F);
        this.animator.rotate(this.rightfrontcalf, 0.0F, 0.0F, 0.0F);
        this.animator.rotate(this.rightfrontfoot, 0.0F, 0.0F, 0.0F);
        this.animator.rotate(this.leftbackcalf, 0.0F, 0.0F, 0.0F);
        this.animator.rotate(this.leftbackfoot, 0.0F, 0.0F, 0.0F);
        this.animator.rotate(this.rightbackcalf, 0.0F, 0.0F, 0.0F);
        this.animator.rotate(this.rightbackfoot, 0.0F, 0.0F, 0.0F);
        this.animator.endPhase();
        this.animator.resetPhase(40);
    }
}
