package net.titans.util;

import java.util.List;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.titans.item.ItemAdminiumAxe;
import net.titans.item.ItemAdminiumHoe;
import net.titans.item.ItemAdminiumPickaxe;
import net.titans.item.ItemAdminiumShovel;
import net.titans.item.ItemAdminiumSword;
import net.titans.item.ItemHarcadiumAxe;
import net.titans.item.ItemHarcadiumBow;
import net.titans.item.ItemHarcadiumHoe;
import net.titans.item.ItemHarcadiumPickaxe;
import net.titans.item.ItemHarcadiumShovel;
import net.titans.item.ItemHarcadiumSword;
import net.titans.item.ItemOptimaAxe;
import net.titans.item.ItemUltimaBlade;
import net.titans.item.ItemVoidAxe;
import net.titans.item.ItemVoidHoe;
import net.titans.item.ItemVoidPickaxe;
import net.titans.item.ItemVoidShovel;
import net.titans.item.ItemVoidSword;

public class ItemUtils {
    public static boolean hasItem(List<ItemStack> itemStacks, Item item) {
        for (ItemStack itemStack : itemStacks) {
            if (itemStack.is(item)) {
                return true;
            }
        }

        return false;
    }

    public static boolean hasItem(Inventory inventory, Item item) {
        return hasItem(inventory.items, item) || hasItem(inventory.offhand, item);
    }

    public static boolean isAdminiumTool(Item item) {
        return item instanceof ItemAdminiumSword
            || item instanceof ItemAdminiumAxe
            || item instanceof ItemAdminiumPickaxe
            || item instanceof ItemAdminiumShovel
            || item instanceof ItemAdminiumHoe;
    }

    public static boolean isUltimateTool(Item item) {
        return item instanceof ItemUltimaBlade || item instanceof ItemOptimaAxe;
    }

    /**
     * 判断物品是否为模组内的武器/工具（唯一能对泰坦造成伤害的来源）。
     */
    public static boolean isTitanWeapon(Item item) {
        return isUltimateTool(item)
            || item instanceof ItemAdminiumSword
            || item instanceof ItemAdminiumAxe
            || item instanceof ItemAdminiumPickaxe
            || item instanceof ItemAdminiumShovel
            || item instanceof ItemAdminiumHoe
            || item instanceof ItemHarcadiumSword
            || item instanceof ItemHarcadiumAxe
            || item instanceof ItemHarcadiumPickaxe
            || item instanceof ItemHarcadiumShovel
            || item instanceof ItemHarcadiumHoe
            || item instanceof ItemHarcadiumBow
            || item instanceof ItemVoidSword
            || item instanceof ItemVoidAxe
            || item instanceof ItemVoidPickaxe
            || item instanceof ItemVoidShovel
            || item instanceof ItemVoidHoe;
    }

    public static boolean isTitanWeapon(ItemStack itemStack) {
        return itemStack != null && !itemStack.isEmpty() && isTitanWeapon(itemStack.getItem());
    }
}
