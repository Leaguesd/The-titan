package net.titans.loader;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.ItemTags;
import net.minecraft.tags.TagKey;
import net.minecraft.world.item.Item;

public class TheTitansItemTags {
    public static final TagKey<Item> IMMORTAL = ItemTags.create(ResourceLocation.tryBuild("titan", "immortal"));
}
