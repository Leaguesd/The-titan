package net.titans.render.minion;

import net.minecraft.client.renderer.entity.EndermanRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider.Context;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.monster.EnderMan;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.titans.entity.minion.IMinion;

@OnlyIn(Dist.CLIENT)
public class RenderEnderColossusMinion extends EndermanRenderer {
    public static final ResourceLocation ENDERMAN = new ResourceLocation("minecraft", "textures/entity/enderman/enderman.png");
    public static final ResourceLocation ENDERMAN_PRIEST = ResourceLocation.tryBuild("titan", "textures/entity/minions/enderman/enderman_priest.png");
    public static final ResourceLocation ENDERMAN_ZEALOT = ResourceLocation.tryBuild("titan", "textures/entity/minions/enderman/enderman_zealot.png");
    public static final ResourceLocation ENDERMAN_BISHOP = ResourceLocation.tryBuild("titan", "textures/entity/minions/enderman/enderman_bishop.png");
    public static final ResourceLocation ENDERMAN_TEMPLAR = ResourceLocation.tryBuild("titan", "textures/entity/minions/enderman/enderman_templar.png");

    public RenderEnderColossusMinion(Context context) {
        super(context);
    }

    public ResourceLocation getTextureLocation(EnderMan entity) {
        if (entity instanceof IMinion minion) {
            switch (minion.getMinionType()) {
                case PRIEST:
                    return ENDERMAN_PRIEST;
                case ZEALOT:
                    return ENDERMAN_ZEALOT;
                case BISHOP:
                    return ENDERMAN_BISHOP;
                case TEMPLAR:
                    return ENDERMAN_TEMPLAR;
                default:
                    return ENDERMAN;
            }
        } else {
            return super.getTextureLocation(entity);
        }
    }
}
