package net.titans.render.minion;

import net.minecraft.client.renderer.entity.SkeletonRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider.Context;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.monster.AbstractSkeleton;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.titans.entity.minion.IMinion;

@OnlyIn(Dist.CLIENT)
public class RenderSkeletonTitanMinion extends SkeletonRenderer {
    public static final ResourceLocation SKELETON = new ResourceLocation("minecraft", "textures/entity/skeleton/skeleton.png");
    public static final ResourceLocation SKELETON_PRIEST = ResourceLocation.tryBuild("titan", "textures/entity/minions/skeleton/skeleton_priest.png");
    public static final ResourceLocation SKELETON_ZEALOT = ResourceLocation.tryBuild("titan", "textures/entity/minions/skeleton/skeleton_zealot.png");
    public static final ResourceLocation SKELETON_BISHOP = ResourceLocation.tryBuild("titan", "textures/entity/minions/skeleton/skeleton_bishop.png");
    public static final ResourceLocation SKELETON_TEMPLAR = ResourceLocation.tryBuild("titan", "textures/entity/minions/skeleton/skeleton_templar.png");

    public RenderSkeletonTitanMinion(Context context) {
        super(context);
    }

    public ResourceLocation getTextureLocation(AbstractSkeleton entity) {
        if (entity instanceof IMinion minion) {
            switch (minion.getMinionType()) {
                case PRIEST:
                    return SKELETON_PRIEST;
                case ZEALOT:
                    return SKELETON_ZEALOT;
                case BISHOP:
                    return SKELETON_BISHOP;
                case TEMPLAR:
                    return SKELETON_TEMPLAR;
                default:
                    return SKELETON;
            }
        } else {
            return super.getTextureLocation(entity);
        }
    }
}
