package net.titans.loot;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.storage.loot.LootContext;
import net.minecraft.world.level.storage.loot.LootTable;
import net.minecraft.world.level.storage.loot.predicates.LootItemCondition;
import net.minecraftforge.common.loot.IGlobalLootModifier;
import net.minecraftforge.common.loot.LootModifier;
import net.titans.loader.TheTitansGlobalLootModifiers;

/**
 * 把一张完整的战利品表追加到当前掉落里的 GlobalLootModifier。
 *
 * <p>对应 1.20.6+ 里 Forge 自带的 {@code forge:add_table}；1.20.1 的 Forge 没有这个实现，
 * 所以这里自己写一份。JSON 结构保持原样，只把 type 换成 {@code titan:add_table}：
 *
 * <pre>
 * {
 *   "type": "titan:add_table",
 *   "conditions": [ { "condition": "forge:loot_table_id", "loot_table_id": "minecraft:chests/end_city_treasure" } ],
 *   "table": "titan:chests/end_city_treasure"
 * }
 * </pre>
 */
public class LootModifierAddTable extends LootModifier {
    private final ResourceLocation table;

    public LootModifierAddTable(LootItemCondition[] conditions, ResourceLocation table) {
        super(conditions);
        this.table = table;
    }

    @Override
    protected ObjectArrayList<ItemStack> doApply(ObjectArrayList<ItemStack> generatedLoot, LootContext context) {
        LootTable lootTable = context.getLevel().getServer().getLootData().getLootTable(this.table);
        // 必须用 getRandomItemsRaw：getRandomItems 会再次经过 Forge 全局战利品修改器，
        // 而这里复用的 context 的 queriedLootTableId 仍是原表，forge:loot_table_id 条件会再次命中
        // 同一个 add_table，造成无限递归（StackOverflowError）。
        lootTable.getRandomItemsRaw(context, generatedLoot::add);
        return generatedLoot;
    }

    @Override
    public Codec<? extends IGlobalLootModifier> codec() {
        return TheTitansGlobalLootModifiers.ADD_TABLE.get();
    }

    /**
     * codecStart 返回的是 Products.P1（条件字段），而 P1 的 and() 只接受 App / P2..P7，不接受 P1；
     * 所以第二个字段要直接以 App 的形式传进去，不能再套一层 inst.group(...)。
     */
    public static final Codec<LootModifierAddTable> CODEC = RecordCodecBuilder.create(
            inst -> LootModifier.codecStart(inst)
                    .and(ResourceLocation.CODEC.fieldOf("table").<LootModifierAddTable>forGetter(m -> m.table))
                    .apply(inst, LootModifierAddTable::new)
    );
}
