package net.titans.enchantment;

import net.minecraft.tags.TagKey;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.EnchantmentCategory;

/**
 * 1.20.1 的附魔是代码注册的（BuiltInRegistries.ENCHANTMENT），没有 1.20.5+ 的
 * {@code data/<namespace>/enchantment/*.json} 数据格式。
 *
 * <p>这个类用来承载原先 data/titan/enchantment/*.json 里的数值，字段一一对应：
 * <ul>
 *   <li>{@code max_level} -> {@link #getMaxLevel()}</li>
 *   <li>{@code min_cost.base} / {@code min_cost.per_level_above_first} -> {@link #getMinCost(int)}</li>
 *   <li>{@code max_cost.base} / {@code max_cost.per_level_above_first} -> {@link #getMaxCost(int)}</li>
 *   <li>{@code supported_items}（物品标签）-> {@link #canEnchant(ItemStack)}</li>
 *   <li>{@code slots: ["mainhand"]} -> 构造参数固定为 MAINHAND</li>
 *   <li>{@code weight} -> 通过 {@link Rarity} 表达（COMMON=10, UNCOMMON=5, RARE=2, VERY_RARE=1）</li>
 * </ul>
 *
 * <p>{@code anvil_cost} 在 1.20.1 没有对应入口（1.20.5 才加入），已丢弃。
 */
public class EnchantmentTitan extends Enchantment {
    private final TagKey<Item> supportedItems;
    private final int maxLevel;
    private final int minCostBase;
    private final int minCostPerLevel;
    private final int maxCostBase;
    private final int maxCostPerLevel;

    public EnchantmentTitan(
            Rarity rarity,
            EnchantmentCategory category,
            TagKey<Item> supportedItems,
            int maxLevel,
            int minCostBase,
            int minCostPerLevel,
            int maxCostBase,
            int maxCostPerLevel) {
        super(rarity, category, new EquipmentSlot[]{EquipmentSlot.MAINHAND});
        this.supportedItems = supportedItems;
        this.maxLevel = maxLevel;
        this.minCostBase = minCostBase;
        this.minCostPerLevel = minCostPerLevel;
        this.maxCostBase = maxCostBase;
        this.maxCostPerLevel = maxCostPerLevel;
    }

    @Override
    public int getMaxLevel() {
        return this.maxLevel;
    }

    @Override
    public int getMinCost(int level) {
        return this.minCostBase + Math.max(0, level - 1) * this.minCostPerLevel;
    }

    @Override
    public int getMaxCost(int level) {
        return this.maxCostBase + Math.max(0, level - 1) * this.maxCostPerLevel;
    }

    /**
     * 1.20.1 没有 "supported_items" 这种数据字段，用物品标签来判断可附魔对象。
     * 附魔台（canApplyAtEnchantingTable）默认会走到这里，所以只覆盖这一个方法即可。
     */
    @Override
    public boolean canEnchant(ItemStack stack) {
        return stack.is(this.supportedItems);
    }
}
