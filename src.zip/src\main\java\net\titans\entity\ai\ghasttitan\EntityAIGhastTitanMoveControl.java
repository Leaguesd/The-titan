package net.titans.entity.ai.ghasttitan;

import net.minecraft.world.entity.ai.control.MoveControl;
import net.minecraft.world.phys.Vec3;
import net.titans.entity.titan.EntityGhastTitan;

public class EntityAIGhastTitanMoveControl extends MoveControl {
    private EntityGhastTitan entity;
    private int floatDuration;

    public EntityAIGhastTitanMoveControl(EntityGhastTitan entity) {
        super(entity);
        this.entity = entity;
    }

    public void tick() {
        if (this.operation == Operation.MOVE_TO && this.floatDuration-- <= 0) {
            this.floatDuration = this.floatDuration + this.entity.level().random.nextInt(5) + 2;
            Vec3 vec3 = new Vec3(this.wantedX - this.entity.getX(), this.wantedY - this.entity.getY(), this.wantedZ - this.entity.getZ());
            vec3 = vec3.normalize();
            this.entity.setDeltaMovement(this.entity.getDeltaMovement().add(vec3.scale(0.3)));
        }
    }
}
