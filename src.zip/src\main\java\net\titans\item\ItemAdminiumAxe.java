package net.titans.item;

import net.minecraft.sounds.SoundEvent;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.AxeItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item.Properties;
import net.titans.entity.titan.EntityTitan;
import net.titans.loader.TheTitansSounds;
import net.titans.loader.TheTitansTiers;

public class ItemAdminiumAxe extends AxeItem {
    public ItemAdminiumAxe(Properties properties) {
        super(TheTitansTiers.ADMINIUM, 1.0E9F, Float.MAX_VALUE, properties);
    }

    public boolean isFoil(ItemStack stack) {
        return true;
    }

    public boolean hurtEnemy(ItemStack stack, LivingEntity entity, LivingEntity attacker) {
        if (entity != null && (entity.getBbHeight() >= 6.0F || entity instanceof EntityTitan || !entity.onGround())) {
            entity.playSound((SoundEvent)TheTitansSounds.TITAN_PUNCH.get(), 100.0F, 0.5F);
            entity.hurt(entity.damageSources().mobAttack(attacker), 4.0E9F);
        }

        return super.hurtEnemy(stack, entity, attacker);
    }
}
