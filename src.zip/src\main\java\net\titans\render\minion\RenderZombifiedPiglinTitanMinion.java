package net.titans.render.minion;

import net.minecraft.client.model.HumanoidArmorModel;
import net.minecraft.client.model.geom.EntityModelSet;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.entity.HumanoidMobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider.Context;
import net.minecraft.client.renderer.entity.layers.HumanoidArmorLayer;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.monster.ZombifiedPiglin;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.titans.entity.minion.IMinion;
import net.titans.model.ModelZombifiedPiglinTitanMinion;

@OnlyIn(Dist.CLIENT)
public class RenderZombifiedPiglinTitanMinion extends HumanoidMobRenderer<ZombifiedPiglin, ModelZombifiedPiglinTitanMinion<ZombifiedPiglin>> {
    public static final ResourceLocation ZOMBIFIED_PIGLIN = new ResourceLocation("minecraft", "textures/entity/piglin/zombified_piglin.png");
    public static final ResourceLocation ZOMBIFIED_PIGLIN_PRIEST = ResourceLocation.tryBuild(
        "titan", "textures/entity/minions/zombie/zombie_pigman_priest.png"
    );
    public static final ResourceLocation ZOMBIFIED_PIGLIN_ZEALOT = ResourceLocation.tryBuild(
        "titan", "textures/entity/minions/zombie/zombie_pigman_zealot.png"
    );
    public static final ResourceLocation ZOMBIFIED_PIGLIN_BISHOP = ResourceLocation.tryBuild(
        "titan", "textures/entity/minions/zombie/zombie_pigman_bishop.png"
    );
    public static final ResourceLocation ZOMBIFIED_PIGLIN_TEMPLAR = ResourceLocation.tryBuild(
        "titan", "textures/entity/minions/zombie/zombie_pigman_templar.png"
    );

    public RenderZombifiedPiglinTitanMinion(Context context, ModelLayerLocation layer, ModelLayerLocation layer1, ModelLayerLocation layer2, boolean noRightEar) {
        super(context, createModel(context.getModelSet(), layer, noRightEar), 0.5F, 1.0019531F, 1.0F, 1.0019531F);
        this.addLayer(
            new HumanoidArmorLayer(
                this, new HumanoidArmorModel(context.bakeLayer(layer1)), new HumanoidArmorModel(context.bakeLayer(layer2)), context.getModelManager()
            )
        );
    }

    public RenderZombifiedPiglinTitanMinion(Context context) {
        this(context, ModelLayers.ZOMBIFIED_PIGLIN, ModelLayers.ZOMBIFIED_PIGLIN_INNER_ARMOR, ModelLayers.ZOMBIFIED_PIGLIN_OUTER_ARMOR, true);
    }

    private static ModelZombifiedPiglinTitanMinion<ZombifiedPiglin> createModel(EntityModelSet modelSet, ModelLayerLocation layer, boolean noRightEar) {
        ModelZombifiedPiglinTitanMinion<ZombifiedPiglin> piglinModel = new ModelZombifiedPiglinTitanMinion<>(modelSet.bakeLayer(layer));
        if (noRightEar) {
            piglinModel.rightEar.visible = false;
        }

        return piglinModel;
    }

    public ResourceLocation getTextureLocation(ZombifiedPiglin entity) {
        if (entity instanceof IMinion minion) {
            switch (minion.getMinionType()) {
                case PRIEST:
                    return ZOMBIFIED_PIGLIN_PRIEST;
                case ZEALOT:
                    return ZOMBIFIED_PIGLIN_ZEALOT;
                case BISHOP:
                    return ZOMBIFIED_PIGLIN_BISHOP;
                case TEMPLAR:
                    return ZOMBIFIED_PIGLIN_TEMPLAR;
                default:
                    return ZOMBIFIED_PIGLIN;
            }
        } else {
            return ZOMBIFIED_PIGLIN;
        }
    }
}
