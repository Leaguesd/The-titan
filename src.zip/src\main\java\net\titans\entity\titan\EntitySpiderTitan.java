package net.titans.entity.titan;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.Mth;
import net.minecraft.world.Difficulty;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.SpawnGroupData;
import net.minecraft.world.entity.Entity.RemovalReason;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier.Builder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.ThrownPotion;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.alchemy.PotionUtils;
import net.minecraft.world.item.alchemy.Potions;
import net.minecraft.world.level.ItemLike;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.ServerLevelAccessor;
import net.minecraft.world.level.Level.ExplosionInteraction;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;
import net.titans.entity.EntityColorLightningBolt;
import net.titans.entity.IBossBarDisplay;
import net.titans.entity.ai.EntityAINearestTargetTitan;
import net.titans.entity.ai.spidertitan.AnimationSpiderTitanAntiTitanAttack;
import net.titans.entity.ai.spidertitan.AnimationSpiderTitanAttack1;
import net.titans.entity.ai.spidertitan.AnimationSpiderTitanAttack2;
import net.titans.entity.ai.spidertitan.AnimationSpiderTitanAttack3;
import net.titans.entity.ai.spidertitan.AnimationSpiderTitanAttack4;
import net.titans.entity.ai.spidertitan.AnimationSpiderTitanCreation;
import net.titans.entity.ai.spidertitan.AnimationSpiderTitanDeath;
import net.titans.entity.ai.spidertitan.AnimationSpiderTitanShootLightning;
import net.titans.entity.ai.spidertitan.AnimationSpiderTitanShootWeb;
import net.titans.entity.ai.spidertitan.AnimationSpiderTitanSpit;
import net.titans.entity.ai.spidertitan.AnimationSpiderTitanStunned;
import net.titans.entity.minion.EntitySkeletonTitanMinion;
import net.titans.entity.minion.EntitySpiderTitanMinion;
import net.titans.entity.minion.EntityWitherSkeletonTitanMinion;
import net.titans.entity.minion.EnumMinionType;
import net.titans.entity.minion.IMinion;
import net.titans.entity.projectile.EntityWebShot;
import net.titans.loader.TheTitansEntities;
import net.titans.loader.TheTitansRegistries;
import net.titans.loader.TheTitansPredicateTargets;
import net.titans.loader.TheTitansSounds;
import net.titans.util.AnimationUtils;

public class EntitySpiderTitan extends EntityTitan implements IEntityMultiPartTitan, IBossBarDisplay {
    private static final EntityDataAccessor<Byte> DATA_FLAGS_ID = SynchedEntityData.defineId(EntitySpiderTitan.class, EntityDataSerializers.BYTE);
    private static final EntityDataAccessor<Byte> BONUS_ID = SynchedEntityData.defineId(EntitySpiderTitan.class, EntityDataSerializers.BYTE);
    public EntityTitanPart head = new EntityTitanPart(this, "head", 8.0F, 8.0F);
    public EntityTitanPart thorax = new EntityTitanPart(this, "thorax", 6.0F, 6.0F);
    public EntityTitanPart abdomen = new EntityTitanPart(this, "abdomen", 12.0F, 8.0F);
    public EntityTitanPart leftlegs = new EntityTitanPart(this, "leftleg", 12.0F, 8.0F);
    public EntityTitanPart rightlegs = new EntityTitanPart(this, "rightleg", 12.0F, 8.0F);
    public int damageToLegs;
    public boolean isStunned;

    public EntitySpiderTitan(EntityType<? extends EntityTitan> entityType, Level level) {
        super(entityType, level);
        this.parts = new EntityTitanPart[]{this.head, this.thorax, this.abdomen, this.leftlegs, this.rightlegs};
    }

    public EntitySpiderTitan(Level level) {
        this((EntityType<? extends EntityTitan>)TheTitansEntities.SPIDER_TITAN.get(), level);
    }

    public static Builder createAttributes() {
        return EntityTitan.createAttributes().add(Attributes.MAX_HEALTH, 32000.0).add(Attributes.ATTACK_DAMAGE, 800.0);
    }

    @Override
    public ResourceLocation getBossBarTexture() {
        return this.isInvisible() ? null : ResourceLocation.tryBuild("titan", "textures/gui/bossbar/spider_titan.png");
    }

    @Override
    public int getBossBarNameColor() {
        return 11013646;
    }

    @Override
    public int getBossBarWidth() {
        return 187;
    }

    @Override
    public int getBossBarHeight() {
        return 23;
    }

    @Override
    public int getBossBarInterval() {
        return 5;
    }

    @Override
    public int getBossBarVOffset() {
        return 0;
    }

    @Override
    public int getBossBarVHeight() {
        return 0;
    }

    @Override
    public int getBossBarTextOffset() {
        return 7;
    }

    @Override
    protected void registerGoals() {
        super.registerGoals();
        this.goalSelector.addGoal(1, new AnimationSpiderTitanCreation(this));
        this.goalSelector.addGoal(1, new AnimationSpiderTitanDeath(this));
        this.goalSelector.addGoal(1, new AnimationSpiderTitanAntiTitanAttack(this));
        this.goalSelector.addGoal(1, new AnimationSpiderTitanAttack1(this));
        this.goalSelector.addGoal(1, new AnimationSpiderTitanAttack2(this));
        this.goalSelector.addGoal(1, new AnimationSpiderTitanAttack3(this));
        this.goalSelector.addGoal(1, new AnimationSpiderTitanAttack4(this));
        this.goalSelector.addGoal(1, new AnimationSpiderTitanShootLightning(this));
        this.goalSelector.addGoal(1, new AnimationSpiderTitanShootWeb(this));
        this.goalSelector.addGoal(1, new AnimationSpiderTitanSpit(this));
        this.goalSelector.addGoal(1, new AnimationSpiderTitanStunned(this));
        this.targetSelector.addGoal(0, new EntityAINearestTargetTitan(this, EntitySnowGolemTitan.class, false));
        this.targetSelector.addGoal(0, new EntityAINearestTargetTitan(this, EntityIronGolemTitan.class, false));
        this.targetSelector
            .addGoal(0, new EntityAINearestTargetTitan<LivingEntity>(this, LivingEntity.class, 0, false, false, TheTitansPredicateTargets.SpiderTitan));
    }

    public boolean isClimbing() {
        return ((Byte)this.entityData.get(DATA_FLAGS_ID) & 1) != 0;
    }

    public void setClimbing(boolean climbing) {
        byte b0 = (Byte)this.entityData.get(DATA_FLAGS_ID);
        if (climbing) {
            b0 = (byte)(b0 | 1);
        } else {
            b0 = (byte)(b0 & -2);
        }

        this.entityData.set(DATA_FLAGS_ID, b0);
    }

    public int getBonusID() {
        return (Byte)this.entityData.get(BONUS_ID);
    }

    public void setBonusID(int bonusID) {
        this.entityData.set(BONUS_ID, (byte)bonusID);
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(DATA_FLAGS_ID, (byte)0);
        this.entityData.define(BONUS_ID, (byte)0);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        this.setBonusID(tag.getInt("SpawnedBonusID"));
        this.damageToLegs = tag.getInt("DamageToLegs");
        this.isStunned = tag.getBoolean("IsStunned");
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putInt("SpawnedBonusID", this.getBonusID());
        tag.putInt("DamageToLegs", this.damageToLegs);
        tag.putBoolean("IsStunned", this.isStunned);
    }

    @Override
    public SpawnGroupData finalizeSpawn(
        ServerLevelAccessor level, DifficultyInstance difficulty, MobSpawnType spawnType, @Nullable SpawnGroupData spawnGroupData, @Nullable CompoundTag tag
    ) {
        SpawnGroupData groupData = super.finalizeSpawn(level, difficulty, spawnType, spawnGroupData, null);
        this.setWaiting(true);
        if (this.level().getRandom().nextInt(10) == 0) {
            this.setBonusID(this.random.nextInt(5));
        }

        return groupData;
    }

    @Override
    protected void refreshAttributes() {
        if (this.level().getDifficulty() == Difficulty.HARD) {
            this.getAttribute(Attributes.MAX_HEALTH).setBaseValue(32000.0 + (double)this.getExtraPower() * 2000.0);
            this.getAttribute(Attributes.ATTACK_DAMAGE).setBaseValue(800.0 + (double)this.getExtraPower() * 30.0);
        } else {
            this.getAttribute(Attributes.MAX_HEALTH).setBaseValue(16000.0 + (double)this.getExtraPower() * 1000.0);
            this.getAttribute(Attributes.ATTACK_DAMAGE).setBaseValue(400.0 + (double)this.getExtraPower() * 15.0);
        }
    }

    @Override
    public boolean canAttack() {
        return false;
    }

    @Override
    public boolean canAttackEntity(Entity entity) {
        return this.getClass() != EntitySpiderTitan.class
            ? super.canAttackEntity(entity)
            : super.canAttackEntity(entity) && !(entity instanceof EntitySpiderTitanMinion);
    }

    @Override
    public boolean canBeHurtByPlayer() {
        return !this.isInvulnerable();
    }

    @Override
    public boolean shouldMove() {
        return this.getAnimationID() == 0 && !this.isStunned && this.getTarget() != null
            ? this.getTarget() != null && this.distanceToSqr(this.getTarget()) > this.getMeleeRange()
            : false;
    }

    @Override
    public boolean canRegen() {
        return !this.isStunned;
    }

    @Override
    public boolean isArmored() {
        return this.deathTicks <= 0 && this.getTitanHealth() <= this.getTitanMaxHealth() / 4.0F;
    }

    @Override
    public int getMinionCap() {
        return 160;
    }

    @Override
    public int getPriestCap() {
        return 80;
    }

    @Override
    public int getZealotCap() {
        return 40;
    }

    @Override
    public int getBishopCap() {
        return 20;
    }

    @Override
    public int getTemplarCap() {
        return 7;
    }

    @Override
    public boolean canSpawnMinion() {
        boolean flag = this.getInvulTime() > 1 && this.tickCount % 20 == 0;
        float randomRate = this.random.nextFloat() * 100.0F;
        return flag || (double)randomRate < 5.0;
    }

    @Override
    public boolean canSpawnPriest() {
        boolean flag = this.getInvulTime() > 1 && this.tickCount % 20 == 0;
        float randomRate = this.random.nextFloat() * 100.0F;
        return flag || (double)randomRate < 2.5;
    }

    @Override
    public boolean canSpawnZealot() {
        boolean flag = this.getInvulTime() > 1 && this.tickCount % 20 == 0;
        float randomRate = this.random.nextFloat() * 100.0F;
        return flag || (double)randomRate < 1.25;
    }

    @Override
    public boolean canSpawnBishop() {
        boolean flag = this.getInvulTime() > 1 && this.tickCount % 20 == 0;
        float randomRate = this.random.nextFloat() * 100.0F;
        return flag || (double)randomRate < 0.625;
    }

    @Override
    public boolean canSpawnTemplar() {
        boolean flag = this.getInvulTime() > 1 && this.tickCount % 20 == 0;
        float randomRate = this.random.nextFloat() * 100.0F;
        return flag || (double)randomRate < 0.3125;
    }

    @Override
    public EnumTitanStatus getTitanStatus() {
        return EnumTitanStatus.LESSER;
    }

    @Override
    public float getSpeed() {
        return (float)((this.getBonusID() == 1 ? 0.6 : 0.55) + (double)this.getExtraPower() * 0.001);
    }

    public boolean isInvisible() {
        return this.getBonusID() == 4;
    }

    public boolean onClimbable() {
        return this.isClimbing();
    }

    public Vec3 getPassengerRidingPosition(Entity entity) {
        return this.position();
    }

    protected SoundEvent getAmbientSound() {
        return !this.isStunned && !this.getWaiting() && this.getAnimationID() != 13 ? (SoundEvent)TheTitansSounds.TITAN_SPIDER_LIVING.get() : null;
    }

    protected SoundEvent getHurtSound(DamageSource damageSource) {
        return (SoundEvent)TheTitansSounds.TITAN_SPIDER_GRUNT.get();
    }

    protected SoundEvent getDeathSound() {
        return (SoundEvent)TheTitansSounds.TITAN_SPIDER_DEATH.get();
    }

    protected void playStepSound(BlockPos pos, BlockState state) {
        for (int i = 0; i < 2; i++) {
            this.shakeNearbyPlayerCameras(4000.0);
            this.playSound((SoundEvent)TheTitansSounds.TITAN_STEP.get(), 10.0F, 1.5F);
        }
    }

    @Override
    public boolean addEffect(MobEffectInstance mobEffectInstance, Entity entity) {
        if (mobEffectInstance.getEffect() == MobEffects.INVISIBILITY) {
            this.setBonusID(4);
            return true;
        } else {
            return super.addEffect(mobEffectInstance, entity);
        }
    }

    @Override
    public void attackEntity(LivingEntity entity, float amount) {
        if (this.getBonusID() == 2) {
            amount *= 2.0F;
            this.playSound((SoundEvent)TheTitansSounds.TITAN_PUNCH.get(), 10.0F, 1.0F);
        }

        super.attackEntity(entity, amount);
    }

    @Override
    public boolean attackEntityFromPart(EntityTitanPart entityTitanPart, DamageSource damageSource, float amount) {
        if (entityTitanPart == this.head) {
            amount *= 2.0F;
        }

        if (this.hurt(damageSource, amount)
            && damageSource.getEntity() != null
            && damageSource.getEntity() instanceof Player
            && this.damageToLegs < 8
            && !this.isStunned
            && (entityTitanPart == this.leftlegs || entityTitanPart == this.rightlegs)) {
            this.damageToLegs++;
            this.hurt(damageSource, 100.0F);
            this.setTarget((LivingEntity)damageSource.getEntity());
            if (this.damageToLegs >= 8) {
                this.playSound(this.getDeathSound(), this.getSoundVolume(), this.getVoicePitch());
                this.isStunned = true;
                this.damageToLegs = 0;
            }
        }

        return true;
    }

    @Override
    public boolean hurt(DamageSource damageSource, float amount) {
        if (this.isArmored()) {
            amount /= 2.0F;
        }

        if (this.isStunned) {
            amount *= 3.0F;
        }

        return super.hurt(damageSource, amount);
    }

    @Override
    protected void dropExperienceOrb() {
        for (int x = 0; x < 8; x++) {
            EntityExperienceOrbTitan experienceOrbTitan = new EntityExperienceOrbTitan(
                this.level(),
                this.getX() + (double)(this.random.nextFloat() * 12.0F - 6.0F),
                this.getY() + 4.0,
                this.getZ() + (double)(this.random.nextFloat() * 12.0F - 6.0F),
                this instanceof EntityCaveSpiderTitan ? 3000 : 4000
            );
            experienceOrbTitan.push(0.0, 1.0, 0.0);
            this.level().addFreshEntity(experienceOrbTitan);
        }
    }

    @Override
    protected void dropAllItem() {
        Map<ItemStack, Integer> drops = new HashMap<>();
        Map<ItemStack, Integer> rateDrops = new HashMap<>();
        drops.put(new ItemStack(Items.STRING), 256);
        drops.put(new ItemStack(Items.SPIDER_EYE), 64);
        drops.put(new ItemStack(Items.FERMENTED_SPIDER_EYE), 24);
        drops.put(new ItemStack(Items.LEATHER), 36);
        drops.put(new ItemStack(Blocks.COBWEB), 24);
        drops.put(new ItemStack(Blocks.MOSSY_COBBLESTONE), 24);
        drops.put(new ItemStack(Items.COAL), 32);
        drops.put(new ItemStack(Items.IRON_INGOT), 48);
        drops.put(new ItemStack(Items.EMERALD), 8);
        drops.put(new ItemStack(Items.DIAMOND), 8);
        rateDrops.put(new ItemStack(Items.STRING), 256);
        rateDrops.put(new ItemStack(Items.SPIDER_EYE), 64);
        rateDrops.put(new ItemStack(Items.FERMENTED_SPIDER_EYE), 24);
        rateDrops.put(new ItemStack(Items.LEATHER), 36);
        rateDrops.put(new ItemStack(Blocks.COBWEB), 24);
        rateDrops.put(new ItemStack(Blocks.MOSSY_COBBLESTONE), 24);
        rateDrops.put(new ItemStack(Items.COAL), 32);
        rateDrops.put(new ItemStack(Items.IRON_INGOT), 48);
        rateDrops.put(new ItemStack(Items.EMERALD), 8);
        rateDrops.put(new ItemStack(Items.DIAMOND), 8);
        rateDrops.put(new ItemStack((ItemLike)TheTitansRegistries.HARCADIUM_NUGGET.get()), 4);

        for (Entry<ItemStack, Integer> entry : drops.entrySet()) {
            ItemStack itemStack = entry.getKey();
            int count = entry.getValue();
            EntityItemTitan itemTitan = new EntityItemTitan(
                this.level(),
                this.getX() + (double)(this.random.nextFloat() * 12.0F - 6.0F),
                this.getY() + 4.0,
                this.getZ() + (double)(this.random.nextFloat() * 12.0F - 6.0F),
                itemStack,
                count
            );
            itemTitan.setPickUpDelay(40);
            this.level().addFreshEntity(itemTitan);
        }

        for (Entry<ItemStack, Integer> entry : rateDrops.entrySet()) {
            ItemStack itemStack = entry.getKey();
            int count = entry.getValue();
            int randomCount = this.random.nextInt(count) + 1;
            EntityItemTitan itemTitan = new EntityItemTitan(
                this.level(),
                this.getX() + (double)(this.random.nextFloat() * 12.0F - 6.0F),
                this.getY() + 4.0,
                this.getZ() + (double)(this.random.nextFloat() * 12.0F - 6.0F),
                itemStack,
                randomCount
            );
            itemTitan.setPickUpDelay(40);
            this.level().addFreshEntity(itemTitan);
        }

        if (this.random.nextInt(10) == 0) {
            EntityItemTitan itemTitan = new EntityItemTitan(
                this.level(),
                this.getX() + (double)(this.random.nextFloat() * 12.0F - 6.0F),
                this.getY() + 4.0,
                this.getZ() + (double)(this.random.nextFloat() * 12.0F - 6.0F),
                new ItemStack(Blocks.BEDROCK),
                1
            );
            itemTitan.setPickUpDelay(40);
            this.level().addFreshEntity(itemTitan);
        }
    }

    @Override
    protected void tickTitanDeath() {
        super.tickTitanDeath();
        AnimationUtils.sendPacket(this, 10);
        this.isStunned = false;
        if (this.deathTicks >= 500) {
            this.setInvulTime(this.getInvulTime() + 8);
            this.setAnimationTick(this.getAnimationTick() - 1);
            float f = (this.random.nextFloat() - 0.5F) * 12.0F;
            float f1 = (this.random.nextFloat() - 0.5F) * 3.0F;
            float f2 = (this.random.nextFloat() - 0.5F) * 12.0F;
            this.level()
                .addParticle(ParticleTypes.EXPLOSION, this.getX() + (double)f, this.getY() + 2.0 + (double)f1, this.getZ() + (double)f2, 0.0, 0.0, 0.0);
        }

        if (this.getInvulTime() >= this.getThreashHold()) {
            this.onDeath();
            if (!this.level().isClientSide() && !this.isRemoved()) {
                for (EntityTitanPart part : this.parts) {
                    part.remove(RemovalReason.KILLED);
                }

                this.removeTitan(RemovalReason.KILLED);
            }
        }
    }

    @Override
    public void finalizeMinionSummon(Entity entity, EnumMinionType minionType) {
        if (minionType != EnumMinionType.SPECIAL
            && entity instanceof EntitySpiderTitanMinion spiderTitanMinion
            && spiderTitanMinion.getPassengers().isEmpty()) {
            spiderTitanMinion.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 40, 4, true, false));
            if (this.getFirstPassenger() != null && this.getFirstPassenger() instanceof EntitySkeletonTitan) {
                EntitySkeletonTitan skeletonTitan = (EntitySkeletonTitan)this.getFirstPassenger();
                Mob mob = (Mob)(skeletonTitan.getSkeletonType() == 1
                    ? new EntityWitherSkeletonTitanMinion(this.level())
                    : new EntitySkeletonTitanMinion(this.level()));
                mob.setPos(spiderTitanMinion.getX(), spiderTitanMinion.getY(), spiderTitanMinion.getZ());
                mob.setYRot(spiderTitanMinion.getYRot());
                mob.finalizeSpawn((ServerLevelAccessor)this.level(), this.level().getCurrentDifficultyAt(mob.blockPosition()), MobSpawnType.SPAWNER, null, null);
                if (mob instanceof IMinion minion) {
                    minion.setMinionType(spiderTitanMinion.getMinionTypeInt());
                }

                mob.setHealth(mob.getMaxHealth());
                // 骑手随蜘蛛一起加入世界，见 addFreshEntityWithPassengers
                mob.startRiding(spiderTitanMinion);
            }
        }
    }

    public void animationTick() {
        if (this.getAnimationID() == 13) {
            this.addDayTime(14000L, 50L);
            if (this.getAnimationTick() == 1) {
                this.playSound((SoundEvent)TheTitansSounds.TITAN_BIRTH.get(), 100.0F, 1.25F);
            }

            if (this.getAnimationTick() == 30) {
                this.playSound((SoundEvent)TheTitansSounds.TITAN_SPIDER_LIVING.get(), this.getSoundVolume(), 0.8F);
            }

            if (this.getAnimationTick() == 40) {
                this.playSound((SoundEvent)TheTitansSounds.TITAN_RUMBLE.get(), 10.0F, 1.0F);
            }

            if (this.getAnimationTick() == 135 || this.getAnimationTick() == 155) {
                this.playStepSound(new BlockPos(0, 0, 0), Blocks.STONE.defaultBlockState());
                this.playSound((SoundEvent)TheTitansSounds.TITAN_PRESS.get(), this.getSoundVolume(), 1.0F);
            }
        }

        if (this.getAnimationID() == 1 && this.getAnimationTick() == 12 && this.getTarget() != null) {
            this.shakeNearbyPlayerCameras(20000.0);
            if (this.isArmored()) {
                this.playSound((SoundEvent)TheTitansSounds.TITAN_STRIKE.get(), 20.0F, 1.0F);
                this.playSound((SoundEvent)TheTitansSounds.TITAN_STRIKE.get(), 20.0F, 1.05F);
                this.playSound((SoundEvent)TheTitansSounds.TITAN_STRIKE.get(), 20.0F, 1.1F);

                for (int i = 0; i < 3; i++) {
                    this.collideWithEntities(this.thorax, this.level().getEntities(this, this.thorax.getBoundingBox().inflate(26.0, 26.0, 26.0)));
                }
            }

            float amount = (float)this.getAttributeBaseValue(Attributes.ATTACK_DAMAGE);
            int knockbackAmount = this.getKnockbackAmount();
            this.collideWithEntities(this.thorax, this.level().getEntities(this, this.thorax.getBoundingBox().inflate(48.0, 48.0, 48.0)));

            for (int i = 0; i < 4; i++) {
                this.attackEntity(this.getTarget(), amount);
            }

            this.knockbackEntity(this.getTarget(), (float)knockbackAmount);

            for (Entity entity : this.level().getEntities(this.getTarget(), this.getTarget().getBoundingBox().inflate(8.0, 8.0, 8.0))) {
                if (entity != null && entity != this && entity instanceof LivingEntity && this.canAttackEntity(entity)) {
                    LivingEntity livingEntity = (LivingEntity)entity;

                    for (int i = 0; i < 2; i++) {
                        this.attackEntity(livingEntity, amount);
                    }

                    this.knockbackEntity(livingEntity, (float)knockbackAmount);
                }
            }
        }

        if (this.getAnimationID() == 2) {
            if (this.getTarget() != null) {
                for (Entity entityx : this.level().getEntities(this, this.getBoundingBox().inflate(64.0, 64.0, 64.0))) {
                    if (entityx != null && entityx instanceof LivingEntity && this.canAttackEntity(entityx)) {
                        LivingEntity livingEntity = (LivingEntity)entityx;
                        livingEntity.invulnerableTime = 0;
                        livingEntity.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 100, 1));
                    }
                }
            }

            if (this.getAnimationTick() <= 70 && this.getAnimationTick() >= 60 && this.getTarget() != null) {
                this.playSound(SoundEvents.WITHER_SHOOT, 5.0F, 1.0F);
                this.attackEntity(this.getTarget(), 25.0F);

                for (int j = 0; j < 300; j++) {
                    double d8 = 5.0;
                    float xfac = Mth.sin(this.yBodyRot * (float) Math.PI / 180.0F);
                    float zfac = Mth.cos(this.yBodyRot * (float) Math.PI / 180.0F);
                    double dx = (double)xfac * d8;
                    double dz = (double)zfac * d8;
                    double d0 = this.head.getX() - dx;
                    double d1 = this.head.getY() + 4.0;
                    double d2 = this.head.getZ() + dz;
                    double d3 = this.getTarget().getX() - d0;
                    double d4 = this.getTarget().getY() - d1;
                    double d5 = this.getTarget().getZ() - d2;
                    double d6 = Math.sqrt(d3 * d3 + d5 * d5);
                    ThrownPotion thrownPotion = new ThrownPotion(this.level(), this);
                    ItemStack itemStack = PotionUtils.setPotion(new ItemStack(Items.SPLASH_POTION), Potions.LONG_POISON);
                    thrownPotion.setItem(itemStack);
                    thrownPotion.setPos(d0, d1, d2);
                    thrownPotion.shoot(d3, d4 + d6 * 0.2, d5, 1.6F, 1.0F + (float)(this.getAnimationTick() * 2 - 60));
                    if (!this.level().isClientSide()) {
                        this.level().addFreshEntity(thrownPotion);
                    }
                }
            }
        }

        if (this.getAnimationID() == 3 && this.getAnimationTick() == 54) {
            this.shakeNearbyPlayerCameras(20000.0);
            this.playSound((SoundEvent)TheTitansSounds.TITAN_STRIKE.get(), 20.0F, 1.0F);
            this.playSound((SoundEvent)TheTitansSounds.TITAN_SLAM.get(), 20.0F, 1.0F);
            float d0 = 12.0F;
            float f3 = this.yBodyRot * (float) Math.PI / 180.0F;
            float f11 = Mth.sin(f3);
            float f4 = Mth.cos(f3);
            float amount = (float)this.getAttributeBaseValue(Attributes.ATTACK_DAMAGE);
            int knockbackAmount = this.getKnockbackAmount();
            this.collideWithEntities(
                this.head,
                this.level().getEntities(this, this.head.getBoundingBox().inflate(48.0, 12.0, 48.0).move((double)(-(f11 * d0)), -8.0, (double)(f4 * d0)))
            );

            for (Entity entityxx : this.level()
                .getEntities(this, this.getBoundingBox().inflate(32.0, 2.0, 32.0).move((double)(-(f11 * d0)), -4.0, (double)(f4 * d0)))) {
                if (entityxx != null && entityxx instanceof LivingEntity && this.canAttackEntity(entityxx)) {
                    LivingEntity livingEntity = (LivingEntity)entityxx;
                    this.attackEntity(livingEntity, amount * 5.0F);
                    this.knockbackEntity(livingEntity, (float)knockbackAmount);
                    livingEntity.push(0.0, 1.0 + this.random.nextDouble() + this.random.nextDouble(), 0.0);
                }
            }
        }

        if (this.getAnimationID() == 4) {
            if (this.getAnimationTick() == 20) {
                this.playSound((SoundEvent)TheTitansSounds.TITAN_ENDER_COLOSUS_CHOMP.get(), 5.0F, 1.1F);
            }

            if (this.getAnimationTick() == 26 && this.getTarget() != null) {
                float amount = (float)this.getAttributeBaseValue(Attributes.ATTACK_DAMAGE);
                int knockbackAmount = this.getKnockbackAmount() * 2;
                this.collideWithEntities(this.head, this.level().getEntities(this, this.head.getBoundingBox().inflate(8.0, 8.0, 8.0)));
                this.attackEntity(this.getTarget(), amount);
                this.knockbackEntity(this.getTarget(), (float)knockbackAmount);

                for (Entity entityxxx : this.level().getEntities(this.getTarget(), this.getTarget().getBoundingBox().inflate(8.0, 8.0, 8.0))) {
                    if (entityxxx != null && entityxxx != this && entityxxx instanceof LivingEntity && this.canAttackEntity(entityxxx)) {
                        LivingEntity livingEntity = (LivingEntity)entityxxx;
                        this.attackEntity(livingEntity, amount);
                        this.knockbackEntity(livingEntity, (float)knockbackAmount);
                    }
                }
            }
        }

        if (this.getAnimationID() == 5 && this.getAnimationTick() == 20) {
            this.playSound((SoundEvent)TheTitansSounds.TITAN_SWING.get(), 5.0F, 1.1F);
            if (this.getTarget() != null) {
                float amount = (float)this.getAttributeBaseValue(Attributes.ATTACK_DAMAGE);
                int knockbackAmount = this.getKnockbackAmount();
                this.collideWithEntities(this.head, this.level().getEntities(this, this.head.getBoundingBox().inflate(4.0, 2.0, 4.0)));
                this.attackEntity(this.getTarget(), amount);
                this.knockbackEntity(this.getTarget(), (float)knockbackAmount);

                for (Entity entityxxxx : this.level().getEntities(this.getTarget(), this.getTarget().getBoundingBox().inflate(6.0, 2.0, 6.0))) {
                    if (entityxxxx != null && entityxxxx != this && entityxxxx instanceof LivingEntity && this.canAttackEntity(entityxxxx)) {
                        LivingEntity livingEntity = (LivingEntity)entityxxxx;
                        this.attackEntity(livingEntity, amount);
                        this.knockbackEntity(livingEntity, (float)knockbackAmount);
                    }
                }
            }
        }

        if (this.getAnimationID() == 6
            && this.getAnimationTick() <= 100
            && this.getAnimationTick() >= 30
            && this.getAnimationTick() % 5 == 0
            && this.getTarget() != null) {
            this.playSound(SoundEvents.WITHER_SHOOT, 5.0F, 1.0F);
            double d8 = 2.0;
            float xfac = Mth.sin(this.yBodyRot * (float) Math.PI / 180.0F);
            float zfac = Mth.cos(this.yBodyRot * (float) Math.PI / 180.0F);
            double d0 = this.getX() - (double)xfac * d8;
            double d1 = this.getY() + 1.0;
            double d2 = this.getZ() + (double)zfac * d8;
            double d3 = this.getTarget().getX() - d0;
            double d4 = this.getTarget().getY() - 1.0 - d1;
            double d5 = this.getTarget().getZ() - d2;
            EntityWebShot webShot = new EntityWebShot(this.level());
            webShot.setOwner(this);
            webShot.setPos(d0, d1, d2);
            webShot.shoot(d3, d4, d5, 1.0F, 0.0F);
            if (!this.level().isClientSide()) {
                this.level().addFreshEntity(webShot);
            }
        }

        if (this.getAnimationID() == 7 && this.getAnimationTick() == 68) {
            EntityColorLightningBolt colorLightningBolt = new EntityColorLightningBolt(this.level(), 0.6F, 0.1F, 0.2F);
            colorLightningBolt.setPos(this.getX(), this.getY() + 5.0, this.getZ());
            if (!this.level().isClientSide()) {
                this.level().addFreshEntity(colorLightningBolt);
            }

            if (this.getTarget() != null) {
                double d8 = -2.0;
                Vec3 vec3 = this.getViewVector(1.0F);
                double dx = vec3.x * d8;
                double dz = vec3.z * d8;
                if (!this.level().isClientSide()) {
                    this.level()
                        .explode(this, this.getTarget().getX(), this.getTarget().getY(), this.getTarget().getZ(), 2.0F, false, ExplosionInteraction.MOB);
                    this.level().explode(this, this.getX() + dx, this.getY() + 8.0, this.getZ() + dz, 1.0F, false, ExplosionInteraction.MOB);
                }

                EntityColorLightningBolt colorLightningBolt1 = new EntityColorLightningBolt(this.level(), 0.6F, 0.1F, 0.2F);
                EntityColorLightningBolt colorLightningBolt2 = new EntityColorLightningBolt(this.level(), 0.6F, 0.1F, 0.2F);
                colorLightningBolt1.setPos(this.getX() + dx, this.getY() + 3.0, this.getZ() + dz);
                colorLightningBolt2.setPos(this.getTarget().getX(), this.getTarget().getY(), this.getTarget().getZ());
                if (!this.level().isClientSide()) {
                    this.level().addFreshEntity(colorLightningBolt1);
                    this.level().addFreshEntity(colorLightningBolt2);
                }

                float amount = (float)this.getAttributeBaseValue(Attributes.ATTACK_DAMAGE);
                int knockbackAmount = this.getKnockbackAmount();
                this.attackEntity(this.getTarget(), amount);
                this.knockbackEntity(this.getTarget(), (float)knockbackAmount);
                this.getTarget().push(0.0, 2.0, 0.0);

                for (Entity entityxxxxx : this.level().getEntities(this.getTarget(), this.getTarget().getBoundingBox().inflate(6.0, 3.0, 6.0))) {
                    if (entityxxxxx != null && entityxxxxx != this && entityxxxxx instanceof LivingEntity && this.canAttackEntity(entityxxxxx)) {
                        LivingEntity livingEntity = (LivingEntity)entityxxxxx;
                        if (!this.level().isClientSide()) {
                            this.level()
                                .explode(
                                    this, livingEntity.getX(), livingEntity.getY(), livingEntity.getZ(), 2.0F, false, ExplosionInteraction.MOB
                                );
                        }

                        EntityColorLightningBolt colorLightningBolt3 = new EntityColorLightningBolt(this.level(), 0.6F, 0.1F, 0.2F);
                        colorLightningBolt3.setPos(livingEntity.getX(), livingEntity.getY(), livingEntity.getZ());
                        if (!this.level().isClientSide()) {
                            this.level().addFreshEntity(colorLightningBolt3);
                        }

                        this.attackEntity(livingEntity, amount);
                        this.knockbackEntity(livingEntity, (float)knockbackAmount);
                    }
                }
            }
        }

        if (this.getAnimationID() == 8) {
            if (this.getAnimationTick() == 58) {
                this.playSound((SoundEvent)TheTitansSounds.LARGE_FALL.get(), 8.0F, 0.9F);
                this.playSound((SoundEvent)TheTitansSounds.TITAN_FALL.get(), 10.0F, 1.0F);
            }

            if (this.getAnimationTick() == 60) {
                this.playSound((SoundEvent)TheTitansSounds.DISTANT_LARGE_FALL.get(), 10000.0F, 1.0F);
            }

            if (this.getAnimationTick() == 420) {
                this.isStunned = false;
            } else {
                this.setTarget(null);
            }
        }

        if (this.getAnimationID() == 9 && this.getAnimationTick() == 24) {
            this.shakeNearbyPlayerCameras(20000.0);
            this.playSound((SoundEvent)TheTitansSounds.TITAN_SLAM.get(), 20.0F, 1.0F);
            float d0 = 12.0F;
            float f3 = this.yBodyRot * (float) Math.PI / 180.0F;
            float f11 = Mth.sin(f3);
            float f4 = Mth.cos(f3);
            float amount = (float)this.getAttributeBaseValue(Attributes.ATTACK_DAMAGE);
            int knockbackAmount = this.getKnockbackAmount();
            this.collideWithEntities(
                this.head,
                this.level().getEntities(this, this.head.getBoundingBox().inflate(18.0, 12.0, 18.0).move((double)(-(f11 * d0)), -8.0, (double)(f4 * d0)))
            );

            for (Entity entityxxxxxx : this.level()
                .getEntities(this, this.getBoundingBox().inflate(12.0, 8.0, 12.0).move((double)(-(f11 * d0)), -4.0, (double)(f4 * d0)))) {
                if (entityxxxxxx != null && entityxxxxxx instanceof LivingEntity && this.canAttackEntity(entityxxxxxx)) {
                    LivingEntity livingEntityx = (LivingEntity)entityxxxxxx;
                    this.attackEntity(livingEntityx, amount * 2.0F);
                    this.knockbackEntity(livingEntityx, (float)knockbackAmount);
                }
            }
        }

        if (this.getAnimationID() == 10) {
            if (this.getAnimationTick() == 80 || this.getAnimationTick() == 210 || this.getAnimationTick() == 250 || this.getAnimationTick() == 260) {
                this.shakeNearbyPlayerCameras(10000.0);
                this.playSound((SoundEvent)TheTitansSounds.TITAN_FALL.get(), 20.0F, 1.0F);
                this.playSound((SoundEvent)TheTitansSounds.DISTANT_LARGE_FALL.get(), 10000.0F, 1.0F);
                this.collideWithEntities(this.leftlegs, this.level().getEntities(this, this.leftlegs.getBoundingBox().inflate(24.0, 1.0, 24.0)));
                this.collideWithEntities(this.rightlegs, this.level().getEntities(this, this.rightlegs.getBoundingBox().inflate(24.0, 1.0, 24.0)));
            }

            if (this.getAnimationTick() == 420) {
                this.isStunned = false;
            } else {
                this.setTarget(null);
            }
        }
    }

    @Override
    public void tick() {
        super.tick();
        this.checkWaiting(16.0);
        if (!this.level().isClientSide()) {
            this.setClimbing(this.horizontalCollision);
        }

        if (this.getAnimationID() == 0 && !this.isPassenger() && !this.getWaiting() && !this.isStunned) {
            if (this.getTarget() != null && this.distanceToSqr(this.getTarget()) > this.getMeleeRange() + (!this.getTarget().onGround() ? 1000.0 : 8000.0)) {
                if (this.getY() <= this.getTarget().getY() + 12.0 && this.getY() < 256.0 - (double)this.getBbHeight()) {
                    this.fallDistance = 0.0F;
                    this.setTitanDeltaMovement(this.getDeltaMovement().x, this.getDeltaMovement().y + 0.9 - this.getDeltaMovement().y, this.getDeltaMovement().z);
                    if (this.getDeltaMovement().y < 0.0) {
                        this.setTitanDeltaMovement(this.getDeltaMovement().x, 0.0, this.getDeltaMovement().z);
                    }
                }

                this.setTitanDeltaMovement(this.getDeltaMovement().x, this.getDeltaMovement().y * 0.6, this.getDeltaMovement().z);
            }

            if (!this.onGround()) {
                float f3 = (this.random.nextFloat() - 0.5F) * 10.0F;
                float f4 = (this.random.nextFloat() - 0.5F) * 1.0F;
                float f5 = (this.random.nextFloat() - 0.5F) * 10.0F;
                this.level()
                    .addParticle(
                        ParticleTypes.EXPLOSION, this.getX() + (double)f3, this.getY() + 5.0 + (double)f4, this.getZ() + (double)f5, 0.0, 0.0, 0.0
                    );
            }
        }

        if (this.tickCount > 5) {
            float size = this instanceof EntityCaveSpiderTitan ? 0.7F : 1.0F;
            float f = this.yBodyRot * (float) Math.PI / 180.0F;
            float f1 = Mth.sin(f);
            float f2 = Mth.cos(f);
            this.head
                .moveTo(
                    this.getX() - Math.sin((double)f) * 7.0 * (double)size,
                    this.getY()
                        + (this.getAnimationID() == 8 ? 0.0 : 5.0) * (double)size
                        - Math.sin((double)this.getYRot() * Math.PI / 180.0) * 4.0 * (double)size,
                    this.getZ() + Math.cos((double)f) * 7.0 * (double)size
                );
            this.thorax.moveTo(this.getX(), this.getY() + (this.getAnimationID() == 8 ? 1.0 : 6.25) * (double)size, this.getZ());
            this.abdomen
                .moveTo(
                    this.getX() + (double)(f1 * 9.0F * size),
                    this.getY() + (this.getAnimationID() == 8 ? 1.0 : 5.0) * (double)size,
                    this.getZ() - (double)(f2 * 9.0F * size)
                );
            this.leftlegs.moveTo(this.getX() - (double)(f2 * 10.0F * size), this.getY(), this.getZ() - (double)(f1 * 10.0F * size));
            this.rightlegs.moveTo(this.getX() + (double)(f2 * 10.0F * size), this.getY(), this.getZ() + (double)(f1 * 10.0F * size));
            if (this.isAlive() && !this.isStunned) {
                this.collideWithEntities(this.head, this.level().getEntities(this, this.head.getBoundingBox().inflate(1.0, 0.0, 1.0)));
                this.collideWithEntities(this.thorax, this.level().getEntities(this, this.thorax.getBoundingBox().inflate(1.0, 0.0, 1.0)));
                this.collideWithEntities(this.abdomen, this.level().getEntities(this, this.abdomen.getBoundingBox().inflate(1.0, 0.0, 1.0)));
                this.collideWithEntities(this.leftlegs, this.level().getEntities(this, this.leftlegs.getBoundingBox().inflate(1.0, 0.0, 1.0)));
                this.collideWithEntities(this.rightlegs, this.level().getEntities(this, this.rightlegs.getBoundingBox().inflate(1.0, 0.0, 1.0)));
                if (this.isArmored()) {
                    for (int i = 0; i < 3; i++) {
                        this.collideWithEntities(this.leftlegs, this.level().getEntities(this, this.leftlegs.getBoundingBox().inflate(1.0, 0.0, 1.0)));
                        this.collideWithEntities(this.rightlegs, this.level().getEntities(this, this.rightlegs.getBoundingBox().inflate(1.0, 0.0, 1.0)));
                    }
                }
            }

            for (EntityTitanPart part : this.parts) {
                this.destroyBlocksInAABB(part.getBoundingBox());
            }
        }

        if (this.getAnimationID() == 0 && this.getTarget() != null && !this.isStunned) {
            double d0 = this.distanceToSqr(this.getTarget());
            if (d0 < this.getMeleeRange()) {
                if (!(this.getTarget() instanceof EntityTitan) && !(this.getTarget().getBbHeight() >= 6.0F) && !(this.getTarget().getY() > this.getY() + 6.0)) {
                    switch (this.random.nextInt(4)) {
                        case 0:
                            AnimationUtils.sendPacket(this, 3);
                            break;
                        case 1:
                            AnimationUtils.sendPacket(this, 9);
                            break;
                        case 2:
                            AnimationUtils.sendPacket(this, 5);
                            break;
                        case 3:
                            AnimationUtils.sendPacket(this, 6);
                    }
                } else {
                    AnimationUtils.sendPacket(this, 1);
                }
            } else if (this.random.nextInt(100) == 0) {
                switch (this.random.nextInt(3)) {
                    case 0:
                        AnimationUtils.sendPacket(this, 2);
                        break;
                    case 1:
                        AnimationUtils.sendPacket(this, 7);
                        break;
                    case 2:
                        AnimationUtils.sendPacket(this, 6);
                }
            }
        }

        if (this.getAnimationID() == 0
            && this.random.nextInt(120) == 0
            && this.getTarget() != null
            && this.distanceToSqr(this.getTarget()) > 512.0
            && this.onGround()) {
            this.lookAt(this.getTarget(), 180.0F, 180.0F);
            double d0 = this.getTarget().getX() - this.getX();
            double d1 = this.getTarget().getZ() - this.getZ();
            double d2 = Math.sqrt(d0 * d0 + d1 * d1);
            double hor = 2.0;
            double ver = 2.0;
            this.setTitanDeltaMovement(d0 / d2 * hor * hor + this.getDeltaMovement().x * hor, ver, d1 / d2 * hor * hor + this.getDeltaMovement().z * hor);

            for (int i = 0; i < 3; i++) {
                this.collideWithEntities(this.leftlegs, this.level().getEntities(this, this.leftlegs.getBoundingBox().inflate(6.0, 6.0, 6.0)));
                this.collideWithEntities(this.rightlegs, this.level().getEntities(this, this.rightlegs.getBoundingBox().inflate(6.0, 6.0, 6.0)));
            }

            if (this.distanceToSqr(this.getTarget()) < 2000.0) {
                float amount = (float)this.getAttributeBaseValue(Attributes.ATTACK_DAMAGE);
                int knockbackAmount = this.getKnockbackAmount() * 2;
                this.attackEntity(this.getTarget(), amount);
                this.knockbackEntity(this.getTarget(), (float)knockbackAmount);
            }
        }

        if (this.isStunned) {
            this.setTarget(null);
            AnimationUtils.sendPacket(this, 8);
        }

        this.animationTick();
    }
}
