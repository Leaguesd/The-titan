package net.titans.entity.projectile;

import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.projectile.AbstractHurtingProjectile;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/**
 * 泰坦系抛射物基类。
 *
 * <p>原版 {@link AbstractHurtingProjectile#tick()} 每 tick 执行的是
 * {@code motion = (motion + (xPower, yPower, zPower)) * inertia}，
 * 其中 inertia 默认 0.95（凋零骷髅头危险态 0.73，水中 0.8）。
 * 只有“带方向向量”的构造器会写 xPower/yPower/zPower；
 * 用 {@link net.minecraft.world.entity.projectile.Projectile#shoot} 发射时这三个字段保持 0，
 * 速度会按 0.95^n 一路衰减，飞一段距离后几乎停住；而这类实体没有重力、也没有寿命，
 * 于是会永久悬停在空中。
 *
 * <p>本类在 {@link #shoot} 之后按原版火球的方式补写加速度（单位方向 × 0.1），
 * 让弹丸加速到稳定速度，而不是衰减到停。
 */
public abstract class EntityTitanProjectile extends AbstractHurtingProjectile implements IEntityProjectileTitan {
    /** 原版 {@code AbstractHurtingProjectile} 的加速度：单位方向向量 × 0.1。 */
    public static final double DEFAULT_ACCELERATION = 0.1D;

    protected EntityTitanProjectile(EntityType<? extends EntityTitanProjectile> entityType, Level level) {
        super(entityType, level);
    }

    @Override
    public void shoot(double x, double y, double z, float velocity, float inaccuracy) {
        super.shoot(x, y, z, velocity, inaccuracy);
        this.applyAcceleration(this.getDeltaMovement(), DEFAULT_ACCELERATION);
    }

    /**
     * 兜底：旧存档 / 指令召唤的弹丸可能只有 Motion、没有 power 字段，
     * 这类实体速度会一路衰减到停。只要还有运动方向，就补一次加速度。
     */
    @Override
    public void tick() {
        if (!this.level().isClientSide()
            && this.xPower == 0.0
            && this.yPower == 0.0
            && this.zPower == 0.0
            && this.getDeltaMovement().lengthSqr() > 1.0E-9) {
            this.applyAcceleration(this.getDeltaMovement(), DEFAULT_ACCELERATION);
        }

        super.tick();
    }

    /**
     * 把当前运动方向写入 {@link AbstractHurtingProjectile} 的加速度字段，
     * 之后每 tick 由基类的 tick() 叠加到速度上。
     */
    protected void applyAcceleration(Vec3 direction, double acceleration) {
        Vec3 normalized = direction.normalize();
        this.xPower = normalized.x * acceleration;
        this.yPower = normalized.y * acceleration;
        this.zPower = normalized.z * acceleration;
        this.hasImpulse = true;
    }
}
