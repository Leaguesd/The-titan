package net.titans.loader;

import net.minecraft.advancements.CriteriaTriggers;
import net.titans.trigger.TriggerRoot;
import net.titans.trigger.TriggerTitanDeath;
import net.titans.trigger.TriggerTitanWake;

/**
 * 1.20.1 的自定义进度触发器不是注册表项（{@code Registries.TRIGGER_TYPES} 是 1.20.5+ 才有的），
 * 而是 {@code CriteriaTriggers.CRITERIA} 这个静态 Map，键来自触发器自己的 {@code getId()}。
 * 注册方式是 {@code CriteriaTriggers.register(trigger)}。
 *
 * <p>原先这里只有三个 Supplier、{@code registerTriggers} 是空方法——触发器名字从未进过
 * {@code CRITERIA}，所以 data 里所有 {@code "trigger": "titan:xxx"} 的进度都会报
 * "Invalid criterion trigger"，连带子进度报"找不到父进度"。
 *
 * <p>现在三个触发器是唯一实例，直接持在静态字段上；调用方用
 * {@code TheTitansTriggers.TITAN_DEATH.trigger(player, entity)} 即可。
 */
public class TheTitansTriggers {
    public static final TriggerRoot ROOT = new TriggerRoot();
    public static final TriggerTitanWake TITAN_WAKE = new TriggerTitanWake();
    public static final TriggerTitanDeath TITAN_DEATH = new TriggerTitanDeath();

    public static void registerTriggers() {
        CriteriaTriggers.register(ROOT);
        CriteriaTriggers.register(TITAN_WAKE);
        CriteriaTriggers.register(TITAN_DEATH);
    }
}
